import { useMatch } from "@tanstack/react-router";
//#region ../../resources/scripts/router/params.ts
var routeParamStrings = (params) => Object.fromEntries(Object.entries(params).flatMap(([name, value]) => value === void 0 ? [] : [[name, String(value)]]));
/** Undefined outside the `/server/$id` route. */
var useServerRouteId = () => useMatch({
	from: "/authenticated/server/$id",
	shouldThrow: false,
	select: (match) => match.params.id
});
//#endregion
export { useServerRouteId as n, routeParamStrings as t };

//# sourceMappingURL=params-HmQaEn9f.js.map