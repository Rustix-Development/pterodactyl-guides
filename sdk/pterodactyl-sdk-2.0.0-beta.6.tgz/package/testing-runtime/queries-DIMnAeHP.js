import { n as ButtonWithVariants, u as useSkin } from "./Button-BzlrfY24.js";
import { C as clientDeleteFilesMutation, It as clientGetFileContents, Lt as clientGetFileDownloadUrl, P as clientGetFileContentsQueryKey, Rt as clientGetFileUploadUrl, X as clientListFilesOptions, Z as clientListFilesQueryKey, d as clientCopyFileMutation, jt as clientWriteFileContentsMutation, l as clientChangeFilePermissionsMutation, mt as clientRenameFilesMutation, p as clientCreateFolderMutation, t as notifyHttpError, u as clientCompressFilesMutation, x as clientDecompressFileMutation } from "./notifications-Ebj0Q0Io.js";
import "./generated-curw-uY5.js";
import { g as newDirectoryDisplayName, h as fileBitsToString, p as cleanDirectoryPath } from "./server-U1WA-Nu8.js";
import { n as removeListItems, r as updateListItems } from "./queryData-DzPdESJr.js";
import React, { use, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Check, Info, ShieldAlert, TriangleAlert, X } from "lucide-react";
import { queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import axios from "axios";
import { Dialog } from "@base-ui/react/dialog";
//#region ../../resources/scripts/components/elements/dialog/context.ts
var DialogContext = React.createContext({
	setIcon: () => null,
	setIconPosition: () => null,
	described: false
});
//#endregion
//#region ../../resources/scripts/components/elements/dialog/DialogFooter.tsx
var DialogFooter = ({ children }) => {
	return /* @__PURE__ */ jsx("div", {
		...useSkin("Dialog", { described: use(DialogContext).described })("footer"),
		children
	});
};
//#endregion
//#region ../../resources/scripts/components/elements/dialog/Dialog.tsx
var focusableSelector = ":is(input, select, textarea, button, a[href], [tabindex]):not([disabled]):not([tabindex=\"-1\"])";
var icons$1 = {
	danger: ShieldAlert,
	warning: TriangleAlert,
	success: Check,
	info: Info
};
function TypeIcon({ ui, icon }) {
	const Glyph = icons$1[icon.type];
	return /* @__PURE__ */ jsx("div", {
		...ui("icon", icon.className, { type: icon.type }),
		children: /* @__PURE__ */ jsx(Glyph, { ...ui("iconGlyph") })
	});
}
function DialogComponent({ open, title, description, onClose, hideCloseIcon, preventExternalClose, children }) {
	const [icon, setIcon] = useState();
	const [iconPosition, setIconPosition] = useState("title");
	const popupRef = React.useRef(null);
	const described = !!description;
	const ui = useSkin("Dialog", { described });
	const initialFocus = (interactionType) => {
		if (interactionType === "touch") return popupRef.current;
		return (popupRef.current?.querySelector(focusableSelector))?.getAttribute("role") === "combobox" ? popupRef.current : true;
	};
	const onOpenChange = (nextOpen) => {
		if (nextOpen || preventExternalClose) return;
		onClose();
	};
	const context = useMemo(() => ({
		setIcon,
		setIconPosition,
		described
	}), [
		setIcon,
		setIconPosition,
		described
	]);
	const items = React.Children.toArray(children);
	const isFooter = (child) => React.isValidElement(child) && child.type === DialogFooter;
	const footer = items.filter(isFooter);
	const content = items.filter((child) => !isFooter(child));
	const typeIcon = icon && /* @__PURE__ */ jsx(TypeIcon, {
		ui,
		icon
	});
	return /* @__PURE__ */ jsx(DialogContext.Provider, {
		value: context,
		children: /* @__PURE__ */ jsx(Dialog.Root, {
			open,
			onOpenChange,
			children: /* @__PURE__ */ jsxs(Dialog.Portal, { children: [/* @__PURE__ */ jsx(Dialog.Backdrop, { ...ui("backdrop") }), /* @__PURE__ */ jsx("div", {
				...ui("viewport"),
				children: /* @__PURE__ */ jsx("div", {
					...ui("container"),
					children: /* @__PURE__ */ jsxs(Dialog.Popup, {
						ref: popupRef,
						...ui("root"),
						initialFocus,
						children: [
							/* @__PURE__ */ jsxs("div", {
								...ui("body"),
								children: [iconPosition === "container" && typeIcon, /* @__PURE__ */ jsxs("div", {
									...ui("content"),
									children: [
										/* @__PURE__ */ jsxs("div", {
											...ui("header"),
											children: [iconPosition !== "container" && typeIcon, /* @__PURE__ */ jsxs("div", {
												...ui("heading"),
												children: [title && /* @__PURE__ */ jsx(Dialog.Title, {
													...ui("title"),
													children: title
												}), description && /* @__PURE__ */ jsx(Dialog.Description, {
													...ui("description"),
													children: description
												})]
											})]
										}),
										content,
										/* @__PURE__ */ jsx("div", { ...ui("spacer") })
									]
								})]
							}),
							footer,
							!hideCloseIcon && /* @__PURE__ */ jsx("div", {
								...ui("close"),
								children: /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
									type: "button",
									size: "xsmall",
									onClick: onClose,
									className: ui.classes("closeButton"),
									children: /* @__PURE__ */ jsx(X, { ...ui("closeIcon") })
								})
							})
						]
					})
				})
			})] })
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/dialog/DialogIcon.tsx
/** Places a type icon beside the dialog title, or beside the whole content with `position="container"`. */
var DialogIcon = ({ type, position, className }) => {
	const { setIcon, setIconPosition } = use(DialogContext);
	useEffect(() => {
		setIcon({
			type,
			className
		});
		return () => setIcon(void 0);
	}, [
		className,
		setIcon,
		type
	]);
	useEffect(() => {
		setIconPosition(position);
		return () => setIconPosition("title");
	}, [position, setIconPosition]);
	return null;
};
//#endregion
//#region ../../resources/scripts/components/elements/dialog/DialogTrigger.tsx
function DialogTrigger({ children, trigger }) {
	const [instance, setInstance] = useState({
		generation: 0,
		open: false
	});
	const show = useCallback(() => setInstance((current) => current.open ? current : {
		generation: current.generation + 1,
		open: false
	}), []);
	const hide = useCallback(() => setInstance((current) => current.open ? {
		...current,
		open: false
	} : current), []);
	useLayoutEffect(() => {
		if (instance.generation > 0) setInstance((current) => current.open ? current : {
			...current,
			open: true
		});
	}, [instance.generation]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [instance.generation > 0 && /* @__PURE__ */ jsx(React.Fragment, { children: children({
		open: instance.open,
		onClose: hide
	}) }, instance.generation), trigger({ onClick: show })] });
}
//#endregion
//#region ../../resources/scripts/components/elements/dialog/ConfirmationDialog.tsx
function ConfirmationDialog({ confirm = "Okay", pending = false, children, onConfirmed, preventExternalClose, hideCloseIcon, ...props }) {
	const confirmed = useRef(false);
	useLayoutEffect(() => {
		if (!pending) confirmed.current = false;
	});
	return /* @__PURE__ */ jsxs(DialogComponent, {
		...props,
		preventExternalClose: preventExternalClose || pending,
		hideCloseIcon: hideCloseIcon || pending,
		children: [children, /* @__PURE__ */ jsxs(DialogFooter, { children: [/* @__PURE__ */ jsx(ButtonWithVariants.Text, {
			type: "button",
			disabled: pending,
			onClick: props.onClose,
			children: "Cancel"
		}), /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
			type: "button",
			isLoading: pending,
			onClick: (event) => {
				if (props.open && !pending && !confirmed.current) {
					confirmed.current = true;
					onConfirmed(event);
				}
			},
			children: confirm
		})] })]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/dialog/useDialogState.ts
var useDialogState = (initialOpen = false) => {
	const [open, setOpen] = useState(initialOpen);
	return {
		open,
		setOpen,
		show: useCallback(() => setOpen(true), []),
		hide: useCallback(() => setOpen(false), []),
		toggle: useCallback(() => setOpen((current) => !current), [])
	};
};
//#endregion
//#region ../../resources/scripts/components/elements/dialog/ConfirmationDialogTrigger.tsx
function ConfirmationDialogTrigger({ onConfirmed, trigger, pending, ...props }) {
	const dialog = useDialogState();
	const confirmingRef = useRef(false);
	const [confirming, setConfirming] = useState(false);
	const onConfirm = (event) => {
		if (confirmingRef.current || pending) return;
		const result = onConfirmed(event, dialog.hide);
		if (!(result instanceof Promise)) return;
		confirmingRef.current = true;
		setConfirming(true);
		result.catch(() => {}).finally(() => {
			confirmingRef.current = false;
			setConfirming(false);
		});
	};
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [trigger({ onClick: dialog.show }), /* @__PURE__ */ jsx(ConfirmationDialog, {
		...props,
		pending: pending || confirming,
		open: dialog.open,
		onClose: dialog.hide,
		onConfirmed: onConfirm
	})] });
}
//#endregion
//#region ../../resources/scripts/components/elements/dialog/index.ts
var Dialog$1 = Object.assign(DialogComponent, {
	Confirm: ConfirmationDialog,
	ConfirmTrigger: ConfirmationDialogTrigger,
	Footer: DialogFooter,
	Icon: DialogIcon,
	Trigger: DialogTrigger
});
//#endregion
//#region ../../resources/scripts/api/server/files/queries.ts
var UPLOAD_CONCURRENCY = 3;
var uploadSequence = 0;
var serverFilesInput = (uuid, directory) => ({
	path: { server_uuid: uuid },
	query: { directory: cleanDirectoryPath(directory) }
});
var serverFileContentInput = (uuid, file) => ({
	path: { server_uuid: uuid },
	query: { file }
});
var createDirectoryInput = (uuid, directory, name) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		name
	}
});
var renameFilesInput = (uuid, directory, files) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		files
	}
});
var chmodFilesInput = (uuid, directory, files) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		files: files.map(({ file, mode }) => ({
			file,
			mode
		}))
	}
});
var deleteFilesInput = (uuid, directory, files) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		files
	}
});
var copyFileInput = (uuid, location) => ({
	path: { server_uuid: uuid },
	body: { location }
});
var compressFilesInput = (uuid, directory, files) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		files
	},
	timeout: 6e4,
	timeoutErrorMessage: "It looks like this archive is taking a long time to generate. It will appear once completed."
});
var decompressFileInput = (uuid, directory, file) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		file
	},
	timeout: 3e5,
	timeoutErrorMessage: "It looks like this archive is taking a long time to be unarchived. Once completed the unarchived files will appear."
});
var writeFileContentsInput = (uuid, file, content) => ({
	path: { server_uuid: uuid },
	query: { file },
	body: content
});
var serverFilesQueryKey = (uuid, directory) => clientListFilesQueryKey(serverFilesInput(uuid, directory));
var allServerFilesQueryKey = (uuid) => clientListFilesQueryKey({ path: { server_uuid: uuid } });
var serverFileContentQueryKey = (uuid, file) => clientGetFileContentsQueryKey(serverFileContentInput(uuid, file));
var serverFilesQueryUpdate = async (queryClient, uuid, directory, updater) => {
	await queryClient.cancelQueries({ queryKey: serverFilesQueryKey(uuid, directory) });
	return queryClient.setQueryData(serverFilesQueryKey(uuid, directory), updater);
};
var updateServerFileContent = async (queryClient, uuid, file, content) => {
	await queryClient.cancelQueries({ queryKey: serverFileContentQueryKey(uuid, file) });
	return queryClient.setQueryData(serverFileContentQueryKey(uuid, file), content);
};
var getFileContents = async (uuid, file, signal) => {
	return (await clientGetFileContents({
		...serverFileContentInput(uuid, file),
		signal
	})).data ?? "";
};
var getFileDownloadUrl = async (uuid, file) => {
	return (await clientGetFileDownloadUrl({
		path: { server_uuid: uuid },
		query: { file }
	})).data.attributes.url;
};
var getFileUploadUrl = async (uuid, signal) => {
	return (await clientGetFileUploadUrl({
		path: { server_uuid: uuid },
		signal
	})).data.attributes.url;
};
var isFileObjectArchiveType = ({ attributes }) => attributes.is_file && [
	"application/vnd.rar",
	"application/x-rar-compressed",
	"application/x-tar",
	"application/x-br",
	"application/x-bzip2",
	"application/gzip",
	"application/x-gzip",
	"application/x-lzip",
	"application/x-sz",
	"application/x-xz",
	"application/zstd",
	"application/zip",
	"application/x-7z-compressed"
].includes(attributes.mimetype);
var fileObjectKind = (file) => {
	if (!file.attributes.is_file) return "directory";
	if (file.attributes.is_symlink) return "symlink";
	return isFileObjectArchiveType(file) ? "archive" : "file";
};
var isFileObjectEditable = (file) => {
	if (isFileObjectArchiveType(file) || !file.attributes.is_file) return false;
	return [
		"application/jar",
		"application/octet-stream",
		"inode/directory",
		/^image\/(?!svg\+xml)/
	].every((m) => !file.attributes.mimetype.match(m));
};
var generateDirectoryData = (name) => ({
	object: "file_object",
	attributes: {
		name: newDirectoryDisplayName(name),
		mode: "drwxr-xr-x",
		mode_bits: "0755",
		size: 0,
		is_file: false,
		is_symlink: false,
		mimetype: "",
		created_at: (/* @__PURE__ */ new Date()).toISOString(),
		modified_at: (/* @__PURE__ */ new Date()).toISOString()
	}
});
var serverFilesQueryOptions = (uuid, directory) => clientListFilesOptions(serverFilesInput(uuid, directory));
var useServerFiles = (uuid, directory) => useQuery({
	...serverFilesQueryOptions(uuid, directory),
	enabled: uuid.length > 0
});
var serverFileContentQueryOptions = (uuid, file) => queryOptions({
	queryKey: serverFileContentQueryKey(uuid, file),
	queryFn: ({ signal }) => getFileContents(uuid, file, signal),
	staleTime: 0
});
var useCreateDirectory = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateFolderMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root && body.name) await serverFilesQueryUpdate(queryClient, path.server_uuid, body.root, (files) => ({
				object: files?.object ?? "list",
				data: [...files?.data ?? [], generateDirectoryData(body.name)]
			}));
			toast.success("Directory created");
		},
		onError: (error) => notifyHttpError(error, "Unable to create directory")
	});
};
var useRenameFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientRenameFilesMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root && body.files?.length === 1) {
				const [{ from, to }] = body.files;
				const staysInDirectory = to.split("/").length === 1;
				await serverFilesQueryUpdate(queryClient, path.server_uuid, body.root, (current) => staysInDirectory ? updateListItems(current, (file) => file.attributes.name === from, (file) => ({
					...file,
					attributes: {
						...file.attributes,
						name: to
					}
				})) : removeListItems(current, (file) => file.attributes.name === from));
			}
			await queryClient.invalidateQueries({ queryKey: allServerFilesQueryKey(path.server_uuid) });
			toast.success("Files updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update files")
	});
};
var useChmodFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientChangeFilePermissionsMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root && body.files?.length === 1) {
				const [{ file, mode }] = body.files;
				const modeBits = mode.padStart(4, "0");
				await serverFilesQueryUpdate(queryClient, path.server_uuid, body.root, (current) => updateListItems(current, (item) => item.attributes.name === file, (item) => ({
					...item,
					attributes: {
						...item.attributes,
						mode: fileBitsToString(modeBits, !item.attributes.is_file),
						mode_bits: modeBits
					}
				})));
			}
			if (body?.root) await queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(path.server_uuid, body.root) });
			toast.success("Permissions updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update permissions")
	});
};
var useDeleteFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDeleteFilesMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root && body.files) {
				const files = body.files;
				await serverFilesQueryUpdate(queryClient, path.server_uuid, body.root, (current) => removeListItems(current, (file) => files.includes(file.attributes.name)));
			}
			toast.success(body?.files?.length === 1 ? "File deleted" : "Files deleted");
		},
		onError: (error) => notifyHttpError(error, "Unable to delete files")
	});
};
var useCopyFile = (directory) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCopyFileMutation(),
		onSuccess: async (_data, { path }) => {
			if (directory) await queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(path.server_uuid, directory) });
			toast.success("File copied");
		},
		onError: (error) => notifyHttpError(error, "Unable to copy file")
	});
};
var useCompressFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCompressFilesMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root) await queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(path.server_uuid, body.root) });
			toast.success("Archive started");
		},
		onError: (error) => notifyHttpError(error, "Unable to archive files")
	});
};
var useDecompressFile = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDecompressFileMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root) await queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(path.server_uuid, body.root) });
			toast.success("Unarchive started");
		},
		onError: (error) => notifyHttpError(error, "Unable to unarchive file")
	});
};
var useFileDownloadUrl = () => useMutation({
	mutationFn: ({ uuid, file }) => getFileDownloadUrl(uuid, file),
	onError: (error) => notifyHttpError(error, "Unable to create file download")
});
var useSaveFileContent = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientWriteFileContentsMutation(),
		onSuccess: async (_data, { path, query, body }) => {
			await updateServerFileContent(queryClient, path.server_uuid, query.file, body);
			toast.success("File saved");
		},
		onError: (error) => notifyHttpError(error, "Unable to save file")
	});
};
var runPooled = async (items, concurrency, task) => {
	let next = 0;
	const worker = async () => {
		if (next >= items.length) return;
		await task(items[next++]);
		return worker();
	};
	await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
};
var uploadFile = async (uuid, directory, file, signal, onUploadProgress) => {
	const url = await getFileUploadUrl(uuid, signal);
	await axios.post(url, { files: file }, {
		signal,
		headers: { "Content-Type": "multipart/form-data" },
		params: { directory },
		onUploadProgress
	});
};
/** Uploads files a few at a time, then refreshes the listing once every file has settled. */
var useUploadFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async ({ callbacks, directory, files, uuid }) => {
			const queued = files.map((file) => {
				const id = `upload-${++uploadSequence}`;
				const controller = new AbortController();
				callbacks.onFileQueued(id, file, controller);
				return {
					id,
					file,
					controller
				};
			});
			const summary = {
				uploaded: [],
				cancelled: [],
				failed: []
			};
			await runPooled(queued, UPLOAD_CONCURRENCY, async ({ id, file, controller }) => {
				let outcome = "cancelled";
				if (!controller.signal.aborted) try {
					await uploadFile(uuid, directory, file, controller.signal, (progress) => callbacks.onFileProgress(id, progress));
					outcome = "uploaded";
				} catch (error) {
					if (!controller.signal.aborted && !axios.isCancel(error)) {
						outcome = "failed";
						notifyHttpError(error, `Unable to upload ${file.name}`);
					}
				}
				summary[outcome].push(file);
				callbacks.onFileSettled(id, outcome);
			});
			return summary;
		},
		onSuccess: ({ uploaded, failed }) => {
			if (uploaded.length > 0 && failed.length === 0) toast.success("Upload complete");
		},
		onError: (error) => notifyHttpError(error, "Unable to upload files"),
		onSettled: (_data, _error, { uuid, directory }) => queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(uuid, directory) })
	});
};
//#endregion
export { useUploadFiles as C, useDialogState as E, useServerFiles as S, Dialog$1 as T, useDecompressFile as _, decompressFileInput as a, useRenameFiles as b, isFileObjectArchiveType as c, serverFileContentQueryOptions as d, serverFilesQueryOptions as f, useCreateDirectory as g, useCopyFile as h, createDirectoryInput as i, isFileObjectEditable as l, useCompressFiles as m, compressFilesInput as n, deleteFilesInput as o, useChmodFiles as p, copyFileInput as r, fileObjectKind as s, chmodFilesInput as t, renameFilesInput as u, useDeleteFiles as v, writeFileContentsInput as w, useSaveFileContent as x, useFileDownloadUrl as y };

//# sourceMappingURL=queries-DIMnAeHP.js.map