import { a as Spinner, n as ButtonWithVariants } from "./Button-BzlrfY24.js";
import { At as Code$1, Dt as ServerContentBlock, Q as ListToolbar, Rt as SpinnerOverlay, U as DeleteAction, X as actionsColumn, Y as Table, at as EmptyTitle, et as Empty, ht as NewButton, it as EmptyMedia, jt as Badge, mt as InputSpinner, nt as EmptyDescription, q as RowActions, rt as EmptyHeader, tt as EmptyContent, wt as CopyOnClick } from "./sdk-Chrtpiam.js";
import { c as View } from "./theme-Cgy7R6cy.js";
import { f as TextArea, t as useDebouncedCallback } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { t as usePending } from "./usePending-DoheVZuN.js";
import { useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Network } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/server/network/NetworkPage.tsx
function NetworkPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(ServerContentBlock, {
			title: "Network",
			className,
			children: /* @__PURE__ */ jsx(View, { name: "server.allocations" })
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/network/Allocations.tsx
function NotesCell({ model, allocation }) {
	const [saving, track] = usePending();
	const save = useDebouncedCallback((notes) => track(model.actions.setNotes(allocation.id, notes)), 750);
	return /* @__PURE__ */ jsx(InputSpinner, {
		visible: saving,
		children: /* @__PURE__ */ jsx(TextArea, {
			"aria-label": `Notes for ${allocation.ip}:${allocation.port}`,
			className: "min-h-9 resize-y bg-input hover:border-input-border border-transparent",
			placeholder: "Notes",
			defaultValue: allocation.notes || void 0,
			onChange: (event) => save(event.currentTarget.value),
			onBlur: save.flush
		})
	});
}
function DeleteAllocationButton({ model, allocation }) {
	return /* @__PURE__ */ jsx(Dialog.ConfirmTrigger, {
		title: "Remove Allocation",
		confirm: "Delete",
		onConfirmed: (_event, close) => model.actions.remove(allocation.id).then(close),
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(DeleteAction, {
			"aria-label": `Delete allocation ${allocation.address}:${allocation.port}`,
			onClick
		}),
		children: "This allocation will be immediately removed from your server."
	});
}
function ActionsCell({ model, allocation }) {
	const [settingPrimary, track] = usePending();
	if (allocation.primary) return /* @__PURE__ */ jsx(Badge, {
		tone: "info",
		className: "inline-flex rounded-full font-medium",
		children: "Primary"
	});
	return /* @__PURE__ */ jsxs(RowActions, { children: [model.permissions.update && /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
		size: "xsmall",
		disabled: settingPrimary,
		onClick: () => track(model.actions.setPrimary(allocation.id)),
		children: "Make Primary"
	}), model.permissions.delete && /* @__PURE__ */ jsx(DeleteAllocationButton, {
		model,
		allocation
	})] });
}
function allocationColumns(model) {
	return [
		{
			id: "address",
			label: "Address",
			sortValue: (allocation) => allocation.address,
			cell: (allocation) => /* @__PURE__ */ jsx(CopyOnClick, {
				text: allocation.address,
				children: /* @__PURE__ */ jsx(Code$1, {
					dark: true,
					className: "max-w-52 truncate",
					children: allocation.address
				})
			})
		},
		{
			id: "port",
			label: "Port",
			sortValue: (allocation) => allocation.port,
			cell: (allocation) => /* @__PURE__ */ jsx(Code$1, {
				dark: true,
				children: allocation.port
			}),
			headerClassName: "w-24",
			cellClassName: "w-24"
		},
		{
			id: "notes",
			label: "Notes",
			cell: (allocation) => /* @__PURE__ */ jsx(NotesCell, {
				model,
				allocation
			}),
			headerClassName: "hidden md:table-cell",
			cellClassName: "hidden md:table-cell min-w-56"
		},
		actionsColumn(2, (allocation) => /* @__PURE__ */ jsx(ActionsCell, {
			model,
			allocation
		}), "w-52")
	];
}
function Allocations({ model, className }) {
	const [creating, track] = usePending();
	const columns = useMemo(() => allocationColumns(model), [model]);
	if (model.loading) return /* @__PURE__ */ jsx("div", {
		className,
		children: /* @__PURE__ */ jsx(Spinner, {
			size: "large",
			centered: true
		})
	});
	const newAllocationButton = /* @__PURE__ */ jsx(NewButton, {
		onClick: () => track(model.actions.create()),
		children: "New allocation"
	});
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [
			/* @__PURE__ */ jsx(SpinnerOverlay, { visible: creating }),
			model.canManage && /* @__PURE__ */ jsx(ListToolbar, {
				summary: `You are currently using ${model.allocations.length} of ${model.limit} allowed allocations for this server.`,
				children: model.canCreate && newAllocationButton
			}),
			/* @__PURE__ */ jsx(Table, {
				rows: model.allocations,
				columns,
				keyOf: (allocation) => String(allocation.id),
				emptyState: /* @__PURE__ */ jsxs(Empty, {
					size: "compact",
					children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
						/* @__PURE__ */ jsx(EmptyMedia, {
							variant: "icon",
							children: /* @__PURE__ */ jsx(Network, {})
						}),
						/* @__PURE__ */ jsx(EmptyTitle, { children: "No allocations" }),
						/* @__PURE__ */ jsx(EmptyDescription, { children: "This server doesn't have any network allocations assigned." })
					] }), model.canCreate && /* @__PURE__ */ jsx(EmptyContent, { children: newAllocationButton })]
				})
			})
		]
	});
}
//#endregion
export { Allocations, NetworkPage };

//# sourceMappingURL=network-qWmVJwsb.js.map