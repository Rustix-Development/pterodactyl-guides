import { t as cn } from "./cn-f7uEsK4g.js";
import { a as Spinner } from "./Button-BzlrfY24.js";
import "./client.gen-Ci-zROOW.js";
import "./queries-D_-2KdyF.js";
import "./usePermissions-pEpnhvzH.js";
import "./useNavigationBlocker-Cl3Kp0j8.js";
import { m as encodePathSegments } from "./server-U1WA-Nu8.js";
import "./useDebouncedCallback-B4Ebjqc5.js";
import "./queries-DIMnAeHP.js";
import { t as editorContainerClass } from "./layout-B0n1h8c2.js";
import { t as createTestServer } from "./fixtures-sueNo-ZT.js";
import { Suspense, createContext, use, useState } from "react";
import "@tanstack/react-router";
import { jsx } from "react/jsx-runtime";
//#region ../../resources/scripts/components/elements/LazyCodemirrorEditor.tsx
var editor;
/** Loads the editor's chunk once; a render after it has loaded does not suspend. */
function loadCodemirrorEditor() {
	if (!editor) {
		const loading = import("./CodemirrorEditor-Dk3xOcr6.js");
		loading.then((module) => Object.assign(loading, {
			status: "fulfilled",
			value: module
		}), () => {
			editor = void 0;
		});
		editor = loading;
	}
	return editor;
}
function CodemirrorEditor(props) {
	const { default: Editor } = use(loadCodemirrorEditor());
	return /* @__PURE__ */ jsx(Editor, { ...props });
}
var LazyCodemirrorEditor = (props) => /* @__PURE__ */ jsx(Suspense, {
	fallback: /* @__PURE__ */ jsx("div", {
		className: cn(editorContainerClass, props.className),
		children: /* @__PURE__ */ jsx(Spinner, {
			centered: true,
			size: "large"
		})
	}),
	children: /* @__PURE__ */ jsx(CodemirrorEditor, { ...props })
});
//#endregion
//#region ../../resources/scripts/components/server/files/breadcrumbs.ts
var fileListDestination = (id, path) => ({
	to: "/server/$id/files",
	params: { id },
	hash: encodePathSegments(path)
});
/** "container", then each directory of `directory`; the last is a link only when `linkLast` is set. */
function fileBreadcrumbs(id, directory, linkLast) {
	const segments = directory.split("/").filter(Boolean);
	return [{
		name: "container",
		path: "/",
		destination: fileListDestination(id, "/")
	}, ...segments.map((name, index) => {
		const path = `/${segments.slice(0, index + 1).join("/")}`;
		return {
			name,
			path,
			destination: linkLast || index < segments.length - 1 ? fileListDestination(id, path) : null
		};
	})];
}
//#endregion
//#region ../../resources/scripts/modes.ts
var modes = [
	{
		name: "C",
		mime: "text/x-csrc",
		mode: "clike",
		ext: [
			"c",
			"h",
			"ino"
		]
	},
	{
		name: "C++",
		mime: "text/x-c++src",
		mode: "clike",
		ext: [
			"cpp",
			"c++",
			"cc",
			"cxx",
			"hpp",
			"h++",
			"hh",
			"hxx"
		],
		alias: ["cpp"]
	},
	{
		name: "C#",
		mime: "text/x-csharp",
		mode: "clike",
		ext: ["cs"],
		alias: ["csharp", "cs"]
	},
	{
		name: "CSS",
		mime: "text/css",
		mode: "css",
		ext: ["css"]
	},
	{
		name: "CQL",
		mime: "text/x-cassandra",
		mode: "sql",
		ext: ["cql"]
	},
	{
		name: "Diff",
		mime: "text/x-diff",
		mode: "diff",
		ext: ["diff", "patch"]
	},
	{
		name: "Dockerfile",
		mime: "text/x-dockerfile",
		mode: "dockerfile",
		file: /^Dockerfile$/
	},
	{
		name: "Git Markdown",
		mime: "text/x-gfm",
		mode: "gfm",
		file: /^(readme|contributing|history|license).md$/i
	},
	{
		name: "Golang",
		mime: "text/x-go",
		mode: "go",
		ext: ["go"]
	},
	{
		name: "HTML",
		mime: "text/html",
		mode: "htmlmixed",
		ext: [
			"html",
			"htm",
			"handlebars",
			"hbs"
		],
		alias: ["xhtml"]
	},
	{
		name: "HTTP",
		mime: "message/http",
		mode: "http"
	},
	{
		name: "JavaScript",
		mime: "text/javascript",
		mimes: [
			"text/javascript",
			"text/ecmascript",
			"application/javascript",
			"application/x-javascript",
			"application/ecmascript"
		],
		mode: "javascript",
		ext: ["js"],
		alias: [
			"ecmascript",
			"js",
			"node"
		]
	},
	{
		name: "JSON",
		mime: "application/json",
		mimes: ["application/json", "application/x-json"],
		mode: "javascript",
		ext: ["json", "map"],
		alias: ["json5"]
	},
	{
		name: "Lua",
		mime: "text/x-lua",
		mode: "lua",
		ext: ["lua"]
	},
	{
		name: "Markdown",
		mime: "text/x-markdown",
		mode: "markdown",
		ext: [
			"markdown",
			"md",
			"mkd"
		]
	},
	{
		name: "MariaDB",
		mime: "text/x-mariadb",
		mode: "sql"
	},
	{
		name: "MS SQL",
		mime: "text/x-mssql",
		mode: "sql"
	},
	{
		name: "MySQL",
		mime: "text/x-mysql",
		mode: "sql"
	},
	{
		name: "Nginx",
		mime: "text/x-nginx-conf",
		mode: "nginx",
		file: /nginx.*\.conf$/i
	},
	{
		name: "PHP",
		mime: "text/x-php",
		mimes: [
			"text/x-php",
			"application/x-httpd-php",
			"application/x-httpd-php-open"
		],
		mode: "php",
		ext: [
			"php",
			"php3",
			"php4",
			"php5",
			"php7",
			"phtml"
		]
	},
	{
		name: "Plain Text",
		mime: "text/plain",
		mode: "null",
		ext: [
			"txt",
			"text",
			"conf",
			"def",
			"list",
			"log"
		]
	},
	{
		name: "PostgreSQL",
		mime: "text/x-pgsql",
		mode: "sql"
	},
	{
		name: "Properties",
		mime: "text/x-properties",
		mode: "properties",
		ext: [
			"properties",
			"ini",
			"in"
		],
		alias: ["ini", "properties"]
	},
	{
		name: "Pug",
		mime: "text/x-pug",
		mimes: ["text/x-pug", "text/x-jade"],
		mode: "null",
		ext: ["pug"]
	},
	{
		name: "Python",
		mime: "text/x-python",
		mode: "python",
		ext: [
			"BUILD",
			"bzl",
			"py",
			"pyw"
		],
		file: /^(BUCK|BUILD)$/
	},
	{
		name: "Ruby",
		mime: "text/x-ruby",
		mode: "ruby",
		ext: ["rb"],
		alias: [
			"jruby",
			"macruby",
			"rake",
			"rb",
			"rbx"
		]
	},
	{
		name: "Rust",
		mime: "text/x-rustsrc",
		mode: "rust",
		ext: ["rs"]
	},
	{
		name: "Sass",
		mime: "text/x-sass",
		mode: "sass",
		ext: ["sass"]
	},
	{
		name: "SCSS",
		mime: "text/x-scss",
		mode: "css",
		ext: ["scss"]
	},
	{
		name: "Shell",
		mime: "text/x-sh",
		mimes: ["text/x-sh", "application/x-sh"],
		mode: "shell",
		ext: [
			"sh",
			"ksh",
			"bash"
		],
		alias: [
			"bash",
			"sh",
			"zsh"
		],
		file: /^PKGBUILD$/
	},
	{
		name: "SQL",
		mime: "text/x-sql",
		mode: "sql",
		ext: ["sql"]
	},
	{
		name: "SQLite",
		mime: "text/x-sqlite",
		mode: "sql"
	},
	{
		name: "TOML",
		mime: "text/x-toml",
		mode: "toml",
		ext: ["toml"]
	},
	{
		name: "TypeScript",
		mime: "application/typescript",
		mode: "javascript",
		ext: ["ts"],
		alias: ["ts"]
	},
	{
		name: "Vue",
		mime: "script/x-vue",
		mimes: ["script/x-vue", "text/x-vue"],
		mode: "vue",
		ext: ["vue"]
	},
	{
		name: "XML",
		mime: "application/xml",
		mimes: ["application/xml", "text/xml"],
		mode: "xml",
		ext: [
			"xml",
			"xsl",
			"xsd",
			"svg"
		],
		alias: [
			"rss",
			"wsdl",
			"xsd"
		]
	},
	{
		name: "YAML",
		mime: "text/x-yaml",
		mimes: ["text/x-yaml", "text/yaml"],
		mode: "yaml",
		ext: ["yaml", "yml"],
		alias: ["yml"]
	}
];
//#endregion
//#region ../../resources/scripts/components/server/files/fileEditorSession.tsx
var FileEditorPageContext = createContext(null);
var FileEditorSessionContext = createContext(null);
var editorLanguages = modes.map(({ mime, name }) => ({
	mime,
	name
}));
/** The code editor of the open document; a remounted one starts from the live buffer. */
function FileEditorCanvas({ className }) {
	const model = use(FileEditorSessionContext);
	if (!model) throw new Error("The file editor renders inside an open file editing session.");
	const [initialContent] = useState(model.read);
	return /* @__PURE__ */ jsx(LazyCodemirrorEditor, {
		className,
		mode: model.language,
		initialContent,
		onContentChanged: model.change,
		onContentSaved: () => void model.save()
	});
}
/** The editor canvas bound to a model that has no editing session around it, such as a fixture's. */
function bindFileEditor(model) {
	return function BoundFileEditor(props) {
		return /* @__PURE__ */ jsx(FileEditorSessionContext.Provider, {
			value: model,
			children: /* @__PURE__ */ jsx(FileEditorCanvas, { ...props })
		});
	};
}
function useFileEditorPage() {
	const page = use(FileEditorPageContext);
	if (!page) throw new Error("The file editor page renders inside its route.");
	return page;
}
function useFileEditorSession() {
	const model = use(FileEditorSessionContext);
	if (!model) throw new Error("The file editor renders inside an open file editing session.");
	return model;
}
//#endregion
//#region ../../resources/scripts/views/server/fileFixtures.ts
function createTestFileDetails(options = {}) {
	return {
		name: "config.json",
		kind: "file",
		size: 1024,
		modifiedAt: "2026-01-01T12:00:00Z",
		...options
	};
}
/** The file object a file details model was read from. */
function createTestFileObject(model) {
	const directory = model.kind === "directory";
	return {
		object: "file_object",
		attributes: {
			name: model.name,
			mode: directory ? "drwxr-xr-x" : "-rw-r--r--",
			mode_bits: directory ? "0755" : "0644",
			size: model.size,
			is_file: !directory,
			is_symlink: model.kind === "symlink",
			mimetype: directory ? "inode/directory" : "text/plain",
			created_at: model.modifiedAt,
			modified_at: model.modifiedAt
		}
	};
}
var TEST_SERVER = "test-server";
/** A file editor model; its `Editor` is bound to it, as the editing session binds the panel's. */
function createTestFileEditor(options = {}) {
	const content = options.content ?? "motd=Hello\n";
	const model = {
		path: "/config/server.properties",
		name: "server.properties",
		isNew: false,
		content,
		language: "text/x-properties",
		languages: editorLanguages,
		readOnly: false,
		dirty: false,
		saving: false,
		Editor: () => null,
		read: () => content,
		change: () => {},
		setLanguage: () => {},
		save: async () => true,
		saveAs: async () => true,
		...options
	};
	return options.Editor ? model : {
		...model,
		Editor: bindFileEditor(model)
	};
}
function createTestFileEditorPage(options = {}) {
	return {
		breadcrumbs: fileBreadcrumbs(TEST_SERVER, "/config", true),
		file: "server.properties",
		loading: false,
		error: null,
		back: () => {},
		...options
	};
}
function createTestFileManagerEntry(options = {}) {
	const name = options.name ?? "config.json";
	const kind = options.kind ?? "file";
	const path = options.path ?? `/${name}`;
	const details = {
		name,
		kind,
		size: options.size ?? 1024,
		modifiedAt: options.modifiedAt ?? "2026-01-01T12:00:00Z"
	};
	const file = createTestFileObject(details);
	return {
		...details,
		path,
		mimetype: kind === "directory" ? "inode/directory" : "application/json",
		mode: file.attributes.mode ?? "",
		modeBits: file.attributes.mode_bits ?? "",
		openable: true,
		extractable: kind === "archive",
		destination: kind === "directory" ? {
			to: "/server/$id/files",
			params: { id: TEST_SERVER },
			hash: path
		} : {
			to: "/server/$id/files/$action",
			params: {
				id: TEST_SERVER,
				action: "edit"
			},
			hash: path
		},
		file,
		...options
	};
}
function createTestFileManager(options = {}) {
	const directory = options.directory ?? "/";
	const entries = options.entries ?? [createTestFileManagerEntry({
		name: "plugins",
		kind: "directory",
		size: 0
	}), createTestFileManagerEntry()];
	const selection = options.selection ?? [];
	return {
		directory,
		breadcrumbs: fileBreadcrumbs(TEST_SERVER, directory, false),
		entries,
		truncated: false,
		loading: false,
		refreshing: false,
		selection,
		permissions: {
			create: true,
			update: true,
			delete: true,
			archive: true
		},
		newFileDestination: {
			to: "/server/$id/files/$action",
			params: {
				id: TEST_SERVER,
				action: "new"
			},
			hash: directory
		},
		uploads: [],
		resolve: (name) => `${directory}/${name}`.replace(/^\/+/, ""),
		slot: {
			server: createTestServer(),
			directory,
			files: entries.map((entry) => entry.file),
			selectedFiles: selection,
			isFetching: false,
			setSelectedFiles: () => {},
			refresh: async () => {}
		},
		actions: {
			open: async () => {},
			navigate: async () => {},
			newFile: async () => {},
			select: () => {},
			refresh: async () => {},
			createDirectory: async () => {},
			rename: async () => {},
			remove: async () => {},
			copy: async () => {},
			archive: async () => {},
			extract: async () => {},
			chmod: async () => {},
			download: async () => {},
			upload: async () => {},
			move: async () => {},
			cancelUpload: () => {},
			clearUploads: () => {}
		},
		...options
	};
}
//#endregion
export { createTestFileManagerEntry as a, useFileEditorSession as c, loadCodemirrorEditor as d, createTestFileManager as i, fileBreadcrumbs as l, createTestFileEditor as n, createTestFileObject as o, createTestFileEditorPage as r, useFileEditorPage as s, createTestFileDetails as t, fileListDestination as u };

//# sourceMappingURL=fileFixtures-u5el1pLN.js.map