import { t as retryUnlessClientError } from "./queryRetry-CsJb-5Ht.js";
import { QueryClient } from "@tanstack/react-query";
//#region ../../resources/scripts/api/queryClient.ts
var queryClient = new QueryClient({ defaultOptions: { queries: {
	staleTime: 3e4,
	refetchOnWindowFocus: false,
	retry: retryUnlessClientError()
} } });
//#endregion
export { queryClient as t };

//# sourceMappingURL=queryClient-CU2lXun5.js.map