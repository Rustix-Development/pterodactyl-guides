import { n as ButtonWithVariants, p as Icon } from "./Button-BzlrfY24.js";
import { Dt as ServerContentBlock, H as Tooltip, Nt as ChartCard, Pt as Stat, Rt as SpinnerOverlay, mt as InputSpinner, n as AreaChart, r as cn, st as Alert, wt as CopyOnClick } from "./sdk-Chrtpiam.js";
import { a as Slot, c as View } from "./theme-Cgy7R6cy.js";
import { n as useAppForm, o as Select, r as Form } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { t as bytesToString } from "./formatters-BBp7wFVw.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ChevronsDown, ChevronsRight, Clock, CloudDownload, CloudUpload, Cpu, HardDrive, MemoryStick, TriangleAlert, Wifi } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/server/console/ConsolePage.tsx
var notices = {
	maintenance: "The node of this server is currently under maintenance and all actions are unavailable.",
	installing: "This server is currently running its installation process and most actions are unavailable.",
	transferring: "This server is currently being transferred to another node and all actions are unavailable."
};
function ConsolePage({ model, active, className }) {
	return /* @__PURE__ */ jsxs(ServerContentBlock, {
		title: active ? "Console" : void 0,
		className,
		children: [
			model.notice && /* @__PURE__ */ jsx(Alert, {
				type: "warning",
				className: "mb-4",
				children: notices[model.notice]
			}),
			/* @__PURE__ */ jsx(Slot, {
				name: "server.console.before",
				data: model.server
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid grid-cols-4 gap-4 mb-4",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "hidden sm:block sm:col-span-2 lg:col-span-3 pr-4",
					children: [/* @__PURE__ */ jsx("h1", {
						className: "font-header font-medium text-2xl text-foreground leading-relaxed line-clamp-1",
						children: model.name
					}), /* @__PURE__ */ jsx("p", {
						className: "text-sm line-clamp-2",
						children: model.description
					})]
				}), /* @__PURE__ */ jsx("div", {
					className: "col-span-4 sm:col-span-2 lg:col-span-1 self-end",
					children: /* @__PURE__ */ jsx(View, { name: "server.power" })
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid grid-cols-4 gap-2 sm:gap-4 mb-4",
				children: [/* @__PURE__ */ jsx("div", {
					className: "flex col-span-4 lg:col-span-3",
					children: /* @__PURE__ */ jsx(View, { name: "server.terminal" })
				}), /* @__PURE__ */ jsx(View, {
					name: "server.stats",
					className: "col-span-4 lg:col-span-1 order-last lg:order-0"
				})]
			}),
			/* @__PURE__ */ jsx(View, { name: "server.graphs" }),
			/* @__PURE__ */ jsx(Slot, {
				name: "server.console.after",
				data: model.server
			}),
			model.features.map((name) => /* @__PURE__ */ jsx(View, { name }, name))
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/Terminal.tsx
var overflowsContainerClass = "-ml-4 w-[calc(100%+2rem)] sm:ml-0 sm:w-full";
var terminalContainerClass = "relative min-h-[16rem] flex-1 rounded-t-sm bg-terminal p-1 font-mono text-sm caret-transparent sm:p-2";
var commandInputClass = [
	"peer relative w-full bg-terminal px-2 py-2 pr-4 pl-10 font-mono text-sm text-foreground sm:rounded-b-sm",
	"border-0 border-b-2 border-transparent transition-colors duration-100",
	"outline-hidden focus:ring-0 focus-visible:outline-hidden active:border-accent focus:border-accent"
].join(" ");
var commandIconClass = "absolute left-0 top-0 z-10 flex h-full select-none items-center px-3 text-foreground transition-colors duration-100 peer-focus:text-foreground peer-focus:animate-pulse";
function onCommandKey(command, event) {
	if (event.key === "ArrowUp") {
		event.preventDefault();
		command.previous();
	}
	if (event.key === "ArrowDown") command.next();
	if (event.key === "Enter") command.submit();
}
function Terminal({ model, className }) {
	const { command } = model;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("relative flex flex-col w-full", className),
		children: [
			/* @__PURE__ */ jsx(SpinnerOverlay, {
				visible: model.loading,
				size: "large"
			}),
			model.failed && /* @__PURE__ */ jsxs("div", {
				role: "alert",
				className: "absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 rounded-sm bg-terminal p-4 text-center text-sm text-foreground",
				children: [/* @__PURE__ */ jsx("p", { children: "The console could not be loaded." }), /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
					size: "small",
					onClick: model.retry,
					children: "Try again"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cn(terminalContainerClass, overflowsContainerClass, !command.allowed && "rounded-b-sm"),
				children: [/* @__PURE__ */ jsx(model.Terminal, {}), model.scrolledUp && /* @__PURE__ */ jsx("button", {
					type: "button",
					onClick: model.scrollToBottom,
					"aria-label": "Scroll to bottom",
					className: "absolute bottom-3 right-5 z-10 rounded-full bg-popover/90 p-2 text-foreground shadow-lg transition-colors hover:bg-popover",
					children: /* @__PURE__ */ jsx(ChevronsDown, { className: "w-4 h-4" })
				})]
			}),
			command.allowed && /* @__PURE__ */ jsxs("div", {
				className: cn("relative", overflowsContainerClass),
				children: [/* @__PURE__ */ jsx("input", {
					className: commandInputClass,
					type: "text",
					placeholder: "Type a command...",
					"aria-label": "Console command input.",
					disabled: command.disabled,
					value: command.value,
					onChange: (event) => command.setValue(event.currentTarget.value),
					onKeyDown: (event) => onCommandKey(command, event),
					autoCorrect: "off",
					autoCapitalize: "none"
				}), /* @__PURE__ */ jsx("div", {
					className: commandIconClass,
					children: /* @__PURE__ */ jsx(ChevronsRight, { className: "w-4 h-4" })
				})]
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/Power.tsx
function Power({ model, className }) {
	const { permissions, enabled, actions } = model;
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [
			/* @__PURE__ */ jsx(Slot, {
				name: "server.console.power.before",
				data: model.server
			}),
			(permissions.start || permissions.stop || permissions.restart) && /* @__PURE__ */ jsxs("div", {
				className: "flex sm:justify-end space-x-2",
				children: [
					permissions.start && /* @__PURE__ */ jsx(ButtonWithVariants, {
						className: "flex-1",
						disabled: !enabled.start,
						onClick: actions.start,
						children: "Start"
					}),
					permissions.restart && /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
						className: "flex-1",
						disabled: !enabled.restart,
						onClick: actions.restart,
						children: "Restart"
					}),
					permissions.stop && (model.killable ? /* @__PURE__ */ jsx(Dialog.ConfirmTrigger, {
						hideCloseIcon: true,
						title: "Forcibly Stop Process",
						confirm: "Continue",
						trigger: ({ onClick }) => /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
							className: "flex-1",
							disabled: !enabled.kill,
							onClick,
							children: "Kill"
						}),
						onConfirmed: (_event, close) => {
							close();
							actions.kill();
						},
						children: "Forcibly stopping a server can lead to data corruption."
					}, "killable") : /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
						className: "flex-1",
						disabled: !enabled.stop,
						onClick: actions.stop,
						children: "Stop"
					}, "stoppable"))
				]
			}),
			/* @__PURE__ */ jsx(Slot, {
				name: "server.console.power.after",
				data: model.server
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/Stats.tsx
var tile = "col-span-3 md:col-span-2 lg:col-span-6";
function uptimeTone(state) {
	if (state === "running") return "neutral";
	return state === "offline" ? "danger" : "warning";
}
/** "1d 2h 3m", or "2h 3m 4s" under a day. */
function UptimeDuration({ seconds }) {
	const days = Math.floor(seconds / (1440 * 60));
	const hours = Math.floor(Math.floor(seconds) / 60 / 60 % 24);
	const remainder = Math.floor(seconds - hours * 60 * 60);
	const minutes = Math.floor(remainder / 60 % 60);
	if (days > 0) return /* @__PURE__ */ jsxs(Fragment, { children: [
		days,
		"d ",
		hours,
		"h ",
		minutes,
		"m"
	] });
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		hours,
		"h ",
		minutes,
		"m ",
		remainder % 60,
		"s"
	] });
}
function Uptime({ state, uptime }) {
	if (state === null) return "Offline";
	if (uptime > 0) return /* @__PURE__ */ jsx(UptimeDuration, { seconds: uptime / 1e3 });
	return state.charAt(0).toUpperCase() + state.slice(1);
}
var limitText = (limit) => /* @__PURE__ */ jsxs(Fragment, { children: ["/ ", limit || /* @__PURE__ */ jsx(Fragment, { children: "∞" })] });
var bytesLimit = (limit) => limit ? bytesToString(limit) : null;
var tone = (metric) => metric.alarm ?? "neutral";
function Stats({ model, className }) {
	const offline = model.state === "offline";
	const address = model.address ?? "n/a";
	const { cpu, memory, disk } = model;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("grid grid-cols-6 gap-2 md:gap-4", className),
		children: [
			/* @__PURE__ */ jsx(CopyOnClick, {
				text: address,
				children: /* @__PURE__ */ jsx(Stat, {
					icon: Wifi,
					label: "Address",
					value: address,
					className: tile
				})
			}),
			/* @__PURE__ */ jsx(Stat, {
				icon: Clock,
				label: "Uptime",
				value: /* @__PURE__ */ jsx(Uptime, {
					state: model.state,
					uptime: model.uptime
				}),
				tone: uptimeTone(model.state),
				className: tile
			}),
			/* @__PURE__ */ jsx(Stat, {
				icon: Cpu,
				label: "CPU Load",
				value: offline ? "Offline" : `${cpu.value.toFixed(2)}%`,
				limit: offline ? void 0 : limitText(cpu.limit ? `${cpu.limit}%` : null),
				tone: tone(cpu),
				unavailable: offline,
				className: tile
			}),
			/* @__PURE__ */ jsx(Stat, {
				icon: MemoryStick,
				label: "Memory",
				value: offline ? "Offline" : bytesToString(memory.value),
				limit: offline ? void 0 : limitText(bytesLimit(memory.limit)),
				tone: tone(memory),
				unavailable: offline,
				className: tile
			}),
			/* @__PURE__ */ jsx(Stat, {
				icon: HardDrive,
				label: "Disk",
				value: bytesToString(disk.value),
				limit: limitText(bytesLimit(disk.limit)),
				tone: tone(disk),
				className: tile
			}),
			/* @__PURE__ */ jsx(Stat, {
				icon: CloudDownload,
				label: "Network (Inbound)",
				value: offline ? "Offline" : bytesToString(model.network.rx),
				unavailable: offline,
				className: tile
			}),
			/* @__PURE__ */ jsx(Stat, {
				icon: CloudUpload,
				label: "Network (Outbound)",
				value: offline ? "Offline" : bytesToString(model.network.tx),
				unavailable: offline,
				className: tile
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/Graphs.tsx
var CYAN = "var(--chart-1)";
var YELLOW = "var(--chart-2)";
var VALUE_SERIES = [{
	dataKey: "value",
	color: CYAN
}];
var NETWORK_SERIES = [{
	dataKey: "tx",
	color: CYAN
}, {
	dataKey: "rx",
	color: YELLOW
}];
function Graphs({ model, className }) {
	const { live, windowMs } = model;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("grid grid-cols-1 md:grid-cols-3 gap-2 sm:gap-4", className),
		children: [
			/* @__PURE__ */ jsx(ChartCard, {
				title: "CPU Load",
				children: /* @__PURE__ */ jsx(AreaChart, {
					data: model.cpu.points,
					series: VALUE_SERIES,
					live,
					windowMs,
					suggestedMax: model.cpu.limit,
					tickFormatter: (value) => `${value.toFixed(2)}%`
				})
			}),
			/* @__PURE__ */ jsx(ChartCard, {
				title: "Memory",
				children: /* @__PURE__ */ jsx(AreaChart, {
					data: model.memory.points,
					series: VALUE_SERIES,
					live,
					windowMs,
					suggestedMax: model.memory.limit,
					tickFormatter: (value) => `${value}MiB`
				})
			}),
			/* @__PURE__ */ jsx(ChartCard, {
				title: "Network",
				legend: /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Tooltip, {
					arrow: true,
					content: "Inbound",
					children: /* @__PURE__ */ jsx(CloudDownload, { className: "mr-2 w-4 h-4 text-chart-2" })
				}), /* @__PURE__ */ jsx(Tooltip, {
					arrow: true,
					content: "Outbound",
					children: /* @__PURE__ */ jsx(CloudUpload, { className: "w-4 h-4 text-chart-1" })
				})] }),
				children: /* @__PURE__ */ jsx(AreaChart, {
					data: model.network.points,
					series: NETWORK_SERIES,
					live,
					windowMs,
					tickFormatter: bytesToString
				})
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/prompts/parts.tsx
var cancelClass = "w-full sm:w-auto border-transparent";
var Close = ({ onClick }) => /* @__PURE__ */ jsx("div", {
	className: "mt-8 sm:flex items-center justify-end",
	children: /* @__PURE__ */ jsx(ButtonWithVariants, {
		onClick,
		className: cancelClass,
		children: "Close"
	})
});
var LimitIcon = () => /* @__PURE__ */ jsx("div", {
	className: "mt-4 sm:flex items-center",
	children: /* @__PURE__ */ jsx(Icon, {
		icon: TriangleAlert,
		className: "pr-4 text-warning",
		size: 64
	})
});
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/prompts/EulaPrompt.tsx
function EulaPrompt({ model }) {
	return /* @__PURE__ */ jsxs(Dialog, {
		open: model.open,
		title: /* @__PURE__ */ jsx(Fragment, { children: "Accept Minecraft® EULA" }),
		onClose: model.close,
		preventExternalClose: model.pending,
		hideCloseIcon: model.pending,
		children: [
			/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.pending }),
			/* @__PURE__ */ jsxs("p", {
				className: "text-foreground",
				children: [
					"By pressing \"I Accept\" below you are indicating your agreement to the\xA0",
					/* @__PURE__ */ jsx("a", {
						target: "_blank",
						className: "text-accent underline transition-colors duration-150 hover:text-accent/80",
						rel: "noreferrer noopener",
						href: "https://www.minecraft.net/eula",
						children: "Minecraft® EULA"
					}),
					"."
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-8 sm:flex items-center justify-end",
				children: [/* @__PURE__ */ jsx(ButtonWithVariants, {
					isSecondary: true,
					onClick: model.close,
					className: cancelClass,
					children: "Cancel"
				}), /* @__PURE__ */ jsx(ButtonWithVariants, {
					onClick: () => void model.accept().catch(() => {}),
					className: "mt-4 sm:mt-0 sm:ml-4 w-full sm:w-auto",
					children: "I Accept"
				})]
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/prompts/JavaVersionPrompt.tsx
function JavaVersionPrompt({ model }) {
	return /* @__PURE__ */ jsxs(Dialog, {
		open: model.open,
		title: "Unsupported Java version",
		onClose: model.close,
		preventExternalClose: model.pending,
		hideCloseIcon: model.pending,
		children: [
			/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.pending }),
			/* @__PURE__ */ jsxs("p", {
				className: "mt-4",
				children: ["This server is currently running an unsupported version of Java and cannot be started.", model.canChangeImage && /* @__PURE__ */ jsx(Fragment, { children: "\xA0Please select a supported version from the list below to continue starting the server." })]
			}),
			model.canChangeImage && /* @__PURE__ */ jsx("div", {
				className: "mt-4",
				children: /* @__PURE__ */ jsx(InputSpinner, {
					visible: model.loading,
					children: /* @__PURE__ */ jsx(Select, {
						disabled: !model.images,
						value: model.selected,
						onChange: (value) => model.select(String(value)),
						options: (model.images ?? []).map(({ label, value }) => ({
							value,
							label
						}))
					})
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-8 flex flex-col sm:flex-row justify-end sm:space-x-4 space-y-4 sm:space-y-0",
				children: [/* @__PURE__ */ jsx(ButtonWithVariants, {
					isSecondary: true,
					onClick: model.close,
					className: "w-full sm:w-auto",
					children: "Cancel"
				}), model.canChangeImage && /* @__PURE__ */ jsx(ButtonWithVariants, {
					onClick: () => void model.update().catch(() => {}),
					className: "w-full sm:w-auto",
					children: "Update Docker Image"
				})]
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/prompts/GslTokenPrompt.tsx
function GslTokenPrompt({ model }) {
	const form = useAppForm({
		defaultValues: { gslToken: "" },
		onSubmit: async ({ value }) => {
			await model.submit(value.gslToken).catch(() => {});
		}
	});
	return /* @__PURE__ */ jsxs(Dialog, {
		open: model.open,
		title: "Invalid GSL token",
		onClose: model.close,
		preventExternalClose: model.pending,
		hideCloseIcon: model.pending,
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.pending }), /* @__PURE__ */ jsxs(Form, {
			form,
			children: [
				/* @__PURE__ */ jsx("p", {
					className: "mt-4",
					children: "It seems like your Gameserver Login Token (GSL token) is invalid or has expired."
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-4",
					children: "You can either generate a new one and enter it below or leave the field blank to remove it completely."
				}),
				/* @__PURE__ */ jsx("div", {
					className: "sm:flex items-center mt-4",
					children: /* @__PURE__ */ jsx(form.AppField, {
						name: "gslToken",
						children: (field) => /* @__PURE__ */ jsx(field.TextField, {
							label: "GSL Token",
							description: "Visit https://steamcommunity.com/dev/managegameservers to generate a token.",
							autoFocus: true
						})
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-8 sm:flex items-center justify-end",
					children: /* @__PURE__ */ jsx("div", {
						className: "mt-4 sm:mt-0 sm:ml-4 w-full sm:w-auto",
						children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
							className: "w-full sm:w-auto",
							children: "Update GSL Token"
						}) })
					})
				})
			]
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/prompts/PidLimitPrompt.tsx
function PidLimitPrompt({ model }) {
	return /* @__PURE__ */ jsxs(Dialog, {
		open: model.open,
		title: model.admin ? "Memory or process limit reached" : "Possible resource limit reached",
		onClose: model.close,
		children: [
			/* @__PURE__ */ jsx(LimitIcon, {}),
			model.admin ? /* @__PURE__ */ jsxs(Fragment, { children: [
				/* @__PURE__ */ jsx("p", {
					className: "mt-4",
					children: "This server has reached the maximum process or memory limit."
				}),
				/* @__PURE__ */ jsxs("p", {
					className: "mt-4",
					children: [
						"Increasing ",
						/* @__PURE__ */ jsx("code", {
							className: "font-mono bg-muted",
							children: "container_pid_limit"
						}),
						" in the wings configuration, ",
						/* @__PURE__ */ jsx("code", {
							className: "font-mono bg-muted",
							children: "config.yml"
						}),
						", might help resolve this issue."
					]
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-4",
					children: /* @__PURE__ */ jsx("b", { children: "Note: Wings must be restarted for the configuration file changes to take effect" })
				})
			] }) : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("p", {
				className: "mt-4",
				children: "This server is attempting to use more resources than allocated. Please contact the administrator and give them the error below."
			}), /* @__PURE__ */ jsx("p", {
				className: "mt-4",
				children: /* @__PURE__ */ jsx("code", {
					className: "font-mono bg-muted",
					children: "pthread_create failed, Possibly out of memory or process/resource limits reached"
				})
			})] }),
			/* @__PURE__ */ jsx(Close, { onClick: model.close })
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/prompts/SteamDiskSpacePrompt.tsx
function SteamDiskSpacePrompt({ model }) {
	return /* @__PURE__ */ jsxs(Dialog, {
		open: model.open,
		title: "Out of available disk space",
		onClose: model.close,
		children: [model.admin ? /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("p", {
			className: "mt-4",
			children: "This server has run out of available disk space and cannot complete the install or update process."
		}), /* @__PURE__ */ jsxs("p", {
			className: "mt-4",
			children: [
				"Ensure the machine has enough disk space by typing",
				" ",
				/* @__PURE__ */ jsx("code", {
					className: "font-mono bg-muted rounded-sm py-1 px-2",
					children: "df -h"
				}),
				" on the machine hosting this server. Delete files or increase the available disk space to resolve the issue."
			]
		})] }) : /* @__PURE__ */ jsx("p", {
			className: "mt-4",
			children: "This server has run out of available disk space and cannot complete the install or update process. Please get in touch with the administrator(s) and inform them of disk space issues."
		}), /* @__PURE__ */ jsx(Close, { onClick: model.close })]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/console/prompts/HytaleOauthPrompt.tsx
function HytaleOauthPrompt({ model }) {
	return /* @__PURE__ */ jsxs(Dialog, {
		open: model.open,
		title: "Authentication required",
		onClose: model.close,
		children: [/* @__PURE__ */ jsx("p", {
			className: "text-foreground",
			children: "You need to authenticate with your Hytale account to download or update server files. Please log in to continue."
		}), /* @__PURE__ */ jsxs("div", {
			className: "mt-8 sm:flex items-center justify-end",
			children: [/* @__PURE__ */ jsx(ButtonWithVariants, {
				isSecondary: true,
				onClick: model.close,
				className: cancelClass,
				children: "Cancel"
			}), /* @__PURE__ */ jsx(ButtonWithVariants, {
				onClick: model.login,
				disabled: !model.link,
				className: "mt-4 sm:mt-0 sm:ml-4 w-full sm:w-auto",
				children: "Log in"
			})]
		})]
	});
}
//#endregion
export { ConsolePage, EulaPrompt, Graphs, GslTokenPrompt, HytaleOauthPrompt, JavaVersionPrompt, PidLimitPrompt, Power, Stats, SteamDiskSpacePrompt, Terminal };

//# sourceMappingURL=console-DpsnQWxi.js.map