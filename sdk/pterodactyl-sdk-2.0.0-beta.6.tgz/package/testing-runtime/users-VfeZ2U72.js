import { a as Spinner, p as Icon } from "./Button-BzlrfY24.js";
import { Dt as ServerContentBlock, Lt as Card, Q as ListToolbar, Rt as SpinnerOverlay, U as DeleteAction, W as EditAction, X as actionsColumn, Y as Table, at as EmptyTitle, et as Empty, gt as NewLinkButton, it as EmptyMedia, nt as EmptyDescription, q as RowActions, r as cn, rt as EmptyHeader, tt as EmptyContent } from "./sdk-Chrtpiam.js";
import { t as PanelLink } from "./navigation-9aP-0Hbq.js";
import { a as Slot, c as View } from "./theme-Cgy7R6cy.js";
import { i as Checkbox, l as Label, n as useAppForm, r as Form } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { r as setPermissionsSelected } from "./permissionSelection-BuSLUqDB.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, LockOpen, UserLock, Users } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/server/users/UsersPage.tsx
function UsersPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(ServerContentBlock, {
			title: "Users",
			className,
			children: /* @__PURE__ */ jsx(View, { name: "server.subusers" })
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/users/SubuserList.tsx
var NewUserButton = ({ model }) => /* @__PURE__ */ jsx(NewLinkButton, {
	to: `/server/${model.serverId}/users/new`,
	children: "New user"
});
function SubuserActions({ model, subuser }) {
	if (subuser.self) return null;
	return /* @__PURE__ */ jsxs(RowActions, { children: [model.canUpdate && /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(EditAction, {
			"aria-label": `Edit ${subuser.email}`,
			onClick
		}),
		children: ({ open, onClose }) => open && /* @__PURE__ */ jsx(View, {
			name: "server.subuserForm",
			subuser,
			onClose
		})
	}), model.canDelete && /* @__PURE__ */ jsxs(Dialog.ConfirmTrigger, {
		title: "Delete this subuser?",
		confirm: "Yes, remove subuser",
		preventExternalClose: model.deleting,
		pending: model.deleting,
		onConfirmed: (_event, close) => {
			model.remove(subuser.uuid).then(close);
		},
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(DeleteAction, {
			"aria-label": `Delete ${subuser.email}`,
			onClick
		}),
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.deleting }), "Are you sure you wish to remove this subuser? They will have all access to this server revoked immediately."]
	})] });
}
function columns(model) {
	return [
		{
			id: "email",
			label: "User",
			sortValue: (subuser) => subuser.email,
			cell: (subuser) => /* @__PURE__ */ jsxs("div", {
				className: "flex min-w-44 items-center gap-3",
				children: [/* @__PURE__ */ jsx("img", {
					className: "hidden h-8 w-8 rounded-full border border-border md:block",
					src: `${subuser.image}?s=96`,
					alt: ""
				}), /* @__PURE__ */ jsx("span", {
					className: "truncate font-medium",
					children: subuser.email
				})]
			})
		},
		{
			id: "2fa_enabled",
			label: "2FA",
			sortValue: (subuser) => subuser.twoFactor,
			cell: (subuser) => /* @__PURE__ */ jsxs("span", {
				className: "inline-flex items-center gap-2 text-xs",
				children: [/* @__PURE__ */ jsx(Icon, {
					icon: subuser.twoFactor ? UserLock : LockOpen,
					className: subuser.twoFactor ? "text-success" : "text-destructive"
				}), subuser.twoFactor ? "Enabled" : "Disabled"]
			}),
			headerClassName: "hidden sm:table-cell w-28",
			cellClassName: "hidden sm:table-cell w-28"
		},
		{
			id: "permissions",
			label: "Permissions",
			sortValue: (subuser) => subuser.permissionCount,
			cell: (subuser) => String(subuser.permissionCount),
			headerClassName: "hidden md:table-cell w-32",
			cellClassName: "hidden md:table-cell w-32"
		},
		actionsColumn(2, (subuser) => /* @__PURE__ */ jsx(SubuserActions, {
			model,
			subuser
		}))
	];
}
function SubuserList({ model, className }) {
	const tableColumns = useMemo(() => columns(model), [model]);
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [model.canCreate && /* @__PURE__ */ jsx(ListToolbar, { children: /* @__PURE__ */ jsx(NewUserButton, { model }) }), /* @__PURE__ */ jsx(Table, {
			rows: model.subusers,
			columns: tableColumns,
			keyOf: (subuser) => subuser.uuid,
			emptyState: /* @__PURE__ */ jsxs(Empty, {
				size: "compact",
				children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
					/* @__PURE__ */ jsx(EmptyMedia, {
						variant: "icon",
						children: /* @__PURE__ */ jsx(Users, {})
					}),
					/* @__PURE__ */ jsx(EmptyTitle, { children: "No subusers" }),
					/* @__PURE__ */ jsx(EmptyDescription, { children: "Add users to give them access to this server with the permissions you choose." })
				] }), model.canCreate && /* @__PURE__ */ jsx(EmptyContent, { children: /* @__PURE__ */ jsx(NewUserButton, { model }) })]
			})
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/users/CreateSubuserPage.tsx
function CreateSubuserPage({ model, className }) {
	return /* @__PURE__ */ jsxs(ServerContentBlock, {
		title: "Create Subuser",
		className,
		children: [/* @__PURE__ */ jsxs(PanelLink, {
			destination: {
				to: "/server/$id/users",
				params: { id: model.serverId }
			},
			className: "inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4",
			children: [/* @__PURE__ */ jsx(Icon, {
				icon: ArrowLeft,
				className: "mr-2"
			}), "Back to Users"]
		}), model.loading ? /* @__PURE__ */ jsx(Spinner, {
			size: "large",
			centered: true
		}) : /* @__PURE__ */ jsx(View, { name: "server.subuserForm" })]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/users/SubuserForm.tsx
var PermissionRowContainer = ({ className, ...props }) => /* @__PURE__ */ jsx("label", {
	className: cn("flex items-center border border-transparent rounded-sm md:p-2 transition-colors duration-75 normal-case", "[&:not(.disabled)]:cursor-pointer [&:not(.disabled):hover]:border-border [&:not(.disabled):hover]:bg-background", "not-first-of-type:mt-4 sm:not-first-of-type:mt-2", "[&.disabled]:opacity-50", className),
	...props
});
function PermissionRow({ permission, disabled, selection }) {
	const id = `permission_${permission.key}`;
	return /* @__PURE__ */ jsxs(PermissionRowContainer, {
		htmlFor: id,
		className: disabled ? "disabled" : void 0,
		children: [/* @__PURE__ */ jsx("div", {
			className: "p-2",
			children: /* @__PURE__ */ jsx(Checkbox, {
				id,
				checked: selection.selected.includes(permission.key),
				disabled,
				onChange: (checked) => selection.select(setPermissionsSelected(selection.selected, [permission.key], checked)),
				className: "w-5 h-5 mr-2"
			})
		}), /* @__PURE__ */ jsxs("div", {
			className: "flex-1",
			children: [/* @__PURE__ */ jsx(Label, {
				as: "p",
				className: "font-medium",
				children: permission.label
			}), permission.description.length > 0 && /* @__PURE__ */ jsx("p", {
				className: "text-xs text-muted-foreground mt-1",
				children: permission.description
			})]
		})]
	});
}
/** Checks every permission given, half-checked while only some are selected. */
function SelectAll({ permissions, selection, label, disabled = false }) {
	const selected = new Set(selection.selected);
	const all = permissions.length > 0 && permissions.every((permission) => selected.has(permission));
	return /* @__PURE__ */ jsx(Checkbox, {
		"aria-label": label,
		checked: all,
		indeterminate: !all && permissions.some((permission) => selected.has(permission)),
		disabled,
		onChange: (checked) => selection.select(setPermissionsSelected(selection.selected, permissions, checked)),
		className: "w-5 h-5"
	});
}
function PermissionGroup({ group, model, selection, className }) {
	const editable = group.permissions.filter((permission) => permission.editable).map((permission) => permission.key);
	return /* @__PURE__ */ jsxs(Card, {
		className,
		title: /* @__PURE__ */ jsxs("div", {
			className: "flex items-center",
			children: [/* @__PURE__ */ jsx("p", {
				className: "text-sm uppercase flex-1",
				children: group.name
			}), model.canEdit && editable.length > 0 && /* @__PURE__ */ jsx(SelectAll, {
				permissions: editable,
				selection,
				label: `Select all ${group.name} permissions`
			})]
		}),
		children: [/* @__PURE__ */ jsx("p", {
			className: "text-sm text-muted-foreground mb-4",
			children: group.description
		}), group.permissions.map((permission) => /* @__PURE__ */ jsx(PermissionRow, {
			permission,
			disabled: !model.canEdit || !permission.editable,
			selection
		}, `permission_${permission.key}`))]
	});
}
function SubmitButton({ form, model }) {
	return /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
		className: "w-full sm:w-auto",
		children: model.subuser ? "Save" : "Invite User"
	}) });
}
function FormContent({ form, model, submitting }) {
	if (model.loading) return /* @__PURE__ */ jsx(SpinnerOverlay, { visible: true });
	if (model.failed) return null;
	return /* @__PURE__ */ jsx(form.Subscribe, {
		selector: (state) => state.values.permissions,
		children: (selected) => {
			const selection = {
				selected,
				select: (permissions) => form.setFieldValue("permissions", permissions),
				enabled: model.canEdit && !submitting && !model.saving
			};
			const title = model.subuser ? `${model.canEdit ? "Modify" : "View"} permissions for ${model.subuser.email}` : "Create new subuser";
			return /* @__PURE__ */ jsxs(Form, {
				form,
				children: [
					/* @__PURE__ */ jsx(SpinnerOverlay, { visible: submitting || model.saving }),
					/* @__PURE__ */ jsxs("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ jsx("h2", {
							className: "text-2xl",
							children: title
						}), /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(SubmitButton, {
							form,
							model
						}) })]
					}),
					model.restricted && /* @__PURE__ */ jsx("div", {
						className: "mt-4 pl-4 py-2 border-l-4 border-accent",
						children: /* @__PURE__ */ jsx("p", {
							className: "text-sm text-muted-foreground",
							children: "Only permissions which your account is currently assigned may be selected when creating or modifying other users."
						})
					}),
					!model.subuser && /* @__PURE__ */ jsx("div", {
						className: "mt-6",
						children: /* @__PURE__ */ jsx(form.AppField, {
							name: "email",
							validators: { onChange: ({ value }) => model.validateEmail(value) },
							children: (field) => /* @__PURE__ */ jsx(field.TextField, {
								label: "User Email",
								description: "Enter the email address of the user you wish to invite as a subuser for this server."
							})
						})
					}),
					/* @__PURE__ */ jsx(Slot, {
						name: "server.users.permissions.before",
						data: model.permissionSlot(selected, submitting, selection.select)
					}),
					/* @__PURE__ */ jsx(Card, {
						className: "mt-6",
						title: /* @__PURE__ */ jsxs("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ jsx("span", {
								className: "text-sm uppercase",
								children: "All Permissions"
							}), model.editable.length > 0 && /* @__PURE__ */ jsx("div", {
								className: "flex items-center gap-2 text-sm",
								children: /* @__PURE__ */ jsx(SelectAll, {
									permissions: model.editable,
									selection,
									label: "Select all permissions",
									disabled: !selection.enabled
								})
							})]
						}),
						children: /* @__PURE__ */ jsxs("p", {
							className: "m-0 text-sm text-muted-foreground",
							children: [
								"Only select this if ",
								/* @__PURE__ */ jsx("strong", { children: "you entirely trust the user you are inviting" }),
								" with all available permissions!"
							]
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "my-6",
						children: model.groups.map((group, index) => /* @__PURE__ */ jsx(PermissionGroup, {
							group,
							model,
							selection,
							className: index > 0 ? "mt-4" : void 0
						}, `permission_${group.name}`))
					}),
					model.canEdit && /* @__PURE__ */ jsx("div", {
						className: "pb-6 flex justify-end",
						children: /* @__PURE__ */ jsx(SubmitButton, {
							form,
							model
						})
					})
				]
			});
		}
	});
}
/** Invites a subuser, or edits one in a dialog when the view is given `onClose`. */
function SubuserForm({ model, onClose, className }) {
	const form = useAppForm({
		defaultValues: {
			email: model.values.email,
			permissions: [...model.values.permissions]
		},
		onSubmit: async ({ value }) => {
			await model.save(value);
		}
	});
	return /* @__PURE__ */ jsx(form.Subscribe, {
		selector: (state) => state.isSubmitting,
		children: (submitting) => {
			const content = /* @__PURE__ */ jsx("div", {
				className,
				children: /* @__PURE__ */ jsx(FormContent, {
					form,
					model,
					submitting
				})
			});
			if (!onClose) return content;
			const busy = submitting || model.saving;
			return /* @__PURE__ */ jsx(Dialog, {
				open: true,
				onClose,
				preventExternalClose: busy,
				hideCloseIcon: busy,
				children: content
			});
		}
	});
}
//#endregion
export { CreateSubuserPage, SubuserForm, SubuserList, UsersPage };

//# sourceMappingURL=users-VfeZ2U72.js.map