import { a as Spinner, n as ButtonWithVariants } from "./Button-BzlrfY24.js";
import { Dt as ServerContentBlock, K as RowActionButton, Q as ListToolbar, Rt as SpinnerOverlay, U as DeleteAction, X as actionsColumn, Y as Table, Z as SecretInput, at as EmptyTitle, et as Empty, ht as NewButton, it as EmptyMedia, nt as EmptyDescription, q as RowActions, rt as EmptyHeader, tt as EmptyContent, wt as CopyOnClick } from "./sdk-Chrtpiam.js";
import { c as View } from "./theme-Cgy7R6cy.js";
import { l as Label, n as useAppForm, p as TextInput, r as Form } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Database, Eye } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/server/databases/DatabasesPage.tsx
function DatabasesPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(ServerContentBlock, {
			title: "Databases",
			className,
			children: /* @__PURE__ */ jsx(View, { name: "server.databases" })
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/databases/Databases.tsx
function CreateDatabaseDialog({ model, onClose }) {
	const form = useAppForm({
		defaultValues: {
			databaseName: "",
			connectionsFrom: ""
		},
		onSubmit: async ({ value }) => {
			try {
				await model.actions.create({
					name: value.databaseName,
					connectionsFrom: value.connectionsFrom
				});
				onClose();
			} catch {}
		}
	});
	return /* @__PURE__ */ jsx(form.Subscribe, {
		selector: (state) => state.isSubmitting,
		children: (isSubmitting) => /* @__PURE__ */ jsxs(Dialog, {
			open: true,
			title: "Create new database",
			preventExternalClose: isSubmitting,
			hideCloseIcon: isSubmitting,
			onClose: () => {
				form.reset();
				onClose();
			},
			children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: isSubmitting }), /* @__PURE__ */ jsxs(Form, {
				form,
				className: "m-0",
				children: [
					/* @__PURE__ */ jsx(form.AppField, {
						name: "databaseName",
						validators: { onChange: ({ value }) => model.validate.name(value) },
						children: (field) => /* @__PURE__ */ jsx(field.TextField, {
							type: "string",
							id: "database_name",
							label: "Database Name",
							description: "A descriptive name for your database instance."
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "mt-6",
						children: /* @__PURE__ */ jsx(form.AppField, {
							name: "connectionsFrom",
							validators: { onChange: ({ value }) => model.validate.connectionsFrom(value) },
							children: (field) => /* @__PURE__ */ jsx(field.TextField, {
								type: "string",
								id: "connections_from",
								label: "Connections From",
								description: "Where connections should be allowed from. Leave blank to allow connections from anywhere."
							})
						})
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap justify-end mt-6",
						children: [/* @__PURE__ */ jsx(ButtonWithVariants, {
							type: "button",
							isSecondary: true,
							className: "w-full sm:w-auto sm:mr-2",
							onClick: onClose,
							children: "Cancel"
						}), /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
							className: "w-full mt-4 sm:w-auto sm:mt-0",
							children: "Create Database"
						}) })]
					})
				]
			})]
		})
	});
}
var CreateDatabaseButton = ({ model }) => /* @__PURE__ */ jsx(Dialog.Trigger, {
	trigger: ({ onClick }) => /* @__PURE__ */ jsx(NewButton, {
		onClick,
		children: "New database"
	}),
	children: ({ open, onClose }) => open && /* @__PURE__ */ jsx(CreateDatabaseDialog, {
		model,
		onClose
	})
});
function DeleteDatabaseDialog({ model, database, open, onClose }) {
	const form = useAppForm({
		defaultValues: { confirm: "" },
		onSubmit: async () => {
			try {
				await model.actions.remove(database.id);
				onClose();
				form.reset();
			} catch {}
		}
	});
	const close = () => {
		onClose();
		form.reset();
	};
	return /* @__PURE__ */ jsx(form.Subscribe, {
		selector: (state) => state.isSubmitting,
		children: (isSubmitting) => /* @__PURE__ */ jsxs(Dialog, {
			open,
			title: "Confirm database deletion",
			preventExternalClose: isSubmitting,
			hideCloseIcon: isSubmitting,
			onClose: close,
			children: [
				/* @__PURE__ */ jsx(SpinnerOverlay, { visible: isSubmitting }),
				/* @__PURE__ */ jsxs("p", {
					className: "text-sm",
					children: [
						"Deleting a database is permanent. This will delete ",
						/* @__PURE__ */ jsx("strong", { children: database.name }),
						" and all associated data."
					]
				}),
				/* @__PURE__ */ jsxs(Form, {
					form,
					className: "m-0 mt-6",
					children: [/* @__PURE__ */ jsx(form.AppField, {
						name: "confirm",
						validators: { onChange: ({ value }) => value === database.name || value === database.shortName ? void 0 : "The database name must be provided." },
						children: (field) => /* @__PURE__ */ jsx(field.TextField, {
							type: "text",
							id: "confirm_name",
							label: "Confirm Database Name",
							description: "Enter the database name to confirm deletion."
						})
					}), /* @__PURE__ */ jsxs("div", {
						className: "mt-6 text-right",
						children: [/* @__PURE__ */ jsx(ButtonWithVariants, {
							type: "button",
							isSecondary: true,
							className: "mr-2",
							onClick: close,
							children: "Cancel"
						}), /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
							color: "red",
							children: "Delete Database"
						}) })]
					})]
				})
			]
		})
	});
}
function ConnectionDialog({ model, database, open, onClose }) {
	return /* @__PURE__ */ jsxs(Dialog, {
		open,
		title: "Database connection details",
		onClose,
		children: [
			/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(Label, { children: "Endpoint" }), /* @__PURE__ */ jsx(CopyOnClick, {
				text: database.endpoint,
				children: /* @__PURE__ */ jsx(TextInput, {
					type: "text",
					readOnly: true,
					value: database.endpoint
				})
			})] }),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ jsx(Label, { children: "Connections from" }), /* @__PURE__ */ jsx(TextInput, {
					type: "text",
					readOnly: true,
					value: database.connectionsFrom
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ jsx(Label, { children: "Username" }), /* @__PURE__ */ jsx(CopyOnClick, {
					text: database.username,
					children: /* @__PURE__ */ jsx(TextInput, {
						type: "text",
						readOnly: true,
						value: database.username
					})
				})]
			}),
			model.permissions.viewPassword && /* @__PURE__ */ jsxs("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ jsx(Label, { children: "Password" }), /* @__PURE__ */ jsx(SecretInput, {
					value: database.password,
					label: "Password"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ jsx(Label, { children: "JDBC Connection String" }), /* @__PURE__ */ jsx(CopyOnClick, {
					text: database.jdbc,
					showInNotification: false,
					children: /* @__PURE__ */ jsx(TextInput, {
						type: "text",
						readOnly: true,
						value: database.jdbc
					})
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6 flex justify-end gap-2",
				children: [model.permissions.update && /* @__PURE__ */ jsx(ButtonWithVariants, {
					isSecondary: true,
					color: "primary",
					className: "mr-2",
					onClick: () => void model.actions.rotatePassword(database.id).catch(() => {}),
					isLoading: model.rotating.includes(database.id),
					children: "Rotate Password"
				}), /* @__PURE__ */ jsx(ButtonWithVariants, {
					isSecondary: true,
					onClick: onClose,
					children: "Close"
				})]
			})
		]
	});
}
function DatabaseActions({ model, database }) {
	return /* @__PURE__ */ jsxs(RowActions, { children: [/* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(RowActionButton, {
			icon: Eye,
			label: "Connection details",
			"aria-label": `View ${database.name} connection details`,
			onClick
		}),
		children: ({ open, onClose }) => /* @__PURE__ */ jsx(ConnectionDialog, {
			model,
			database,
			open,
			onClose
		})
	}), model.permissions.delete && /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(DeleteAction, {
			"aria-label": `Delete ${database.name}`,
			onClick
		}),
		children: ({ open, onClose }) => /* @__PURE__ */ jsx(DeleteDatabaseDialog, {
			model,
			database,
			open,
			onClose
		})
	})] });
}
function databaseColumns(model) {
	return [
		{
			id: "name",
			label: "Database",
			sortValue: (database) => database.name,
			cell: (database) => /* @__PURE__ */ jsx(CopyOnClick, {
				text: database.name,
				children: /* @__PURE__ */ jsx("span", {
					className: "font-medium",
					children: database.name
				})
			})
		},
		{
			id: "endpoint",
			label: "Endpoint",
			sortValue: (database) => database.endpoint,
			cell: (database) => /* @__PURE__ */ jsx(CopyOnClick, {
				text: database.endpoint,
				children: /* @__PURE__ */ jsx("code", {
					className: "whitespace-nowrap text-xs",
					children: database.endpoint
				})
			}),
			headerClassName: "hidden md:table-cell",
			cellClassName: "hidden md:table-cell"
		},
		{
			id: "connections_from",
			label: "Connections from",
			sortValue: (database) => database.connectionsFrom,
			cell: (database) => database.connectionsFrom,
			headerClassName: "hidden lg:table-cell",
			cellClassName: "hidden lg:table-cell"
		},
		{
			id: "username",
			label: "Username",
			sortValue: (database) => database.username,
			cell: (database) => /* @__PURE__ */ jsx(CopyOnClick, {
				text: database.username,
				children: /* @__PURE__ */ jsx("code", {
					className: "text-xs",
					children: database.username
				})
			}),
			headerClassName: "hidden xl:table-cell",
			cellClassName: "hidden xl:table-cell"
		},
		actionsColumn(2, (database) => /* @__PURE__ */ jsx(DatabaseActions, {
			model,
			database
		}))
	];
}
var EmptyState = ({ model }) => /* @__PURE__ */ jsxs(Empty, {
	size: "compact",
	children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
		/* @__PURE__ */ jsx(EmptyMedia, {
			variant: "icon",
			children: /* @__PURE__ */ jsx(Database, {})
		}),
		/* @__PURE__ */ jsx(EmptyTitle, { children: "No databases" }),
		/* @__PURE__ */ jsx(EmptyDescription, { children: model.limit > 0 ? "This server doesn't have any databases yet." : "Databases can't be created because this server's database limit is 0." })
	] }), model.canCreate && /* @__PURE__ */ jsx(EmptyContent, { children: /* @__PURE__ */ jsx(CreateDatabaseButton, { model }) })]
});
function Databases({ model, className }) {
	const columns = useMemo(() => databaseColumns(model), [model]);
	const count = model.databases.length;
	const usage = model.permissions.create && model.limit > 0 && count > 0 ? `${count} of ${model.limit} databases have been allocated to this server.` : null;
	if (model.loading) return /* @__PURE__ */ jsx("div", {
		className,
		children: /* @__PURE__ */ jsx(Spinner, {
			size: "large",
			centered: true
		})
	});
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [(usage || model.canCreate) && /* @__PURE__ */ jsx(ListToolbar, {
			summary: usage,
			children: model.canCreate && /* @__PURE__ */ jsx(CreateDatabaseButton, { model })
		}), /* @__PURE__ */ jsx(Table, {
			rows: model.databases,
			columns,
			keyOf: (database) => database.id,
			emptyState: /* @__PURE__ */ jsx(EmptyState, { model })
		})]
	});
}
//#endregion
export { Databases, DatabasesPage };

//# sourceMappingURL=databases-BN8lEQiZ.js.map