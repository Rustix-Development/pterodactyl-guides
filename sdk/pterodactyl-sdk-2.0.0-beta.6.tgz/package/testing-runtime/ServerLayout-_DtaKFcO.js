import { p as Icon } from "./Button-BzlrfY24.js";
import { ct as SubNavigationLayout, lt as SubNavigation } from "./sdk-Chrtpiam.js";
import { a as Slot, o as Main } from "./theme-Cgy7R6cy.js";
import { t as tabLabel } from "./tabLabel-DAPdSje5.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { ExternalLink } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/layout/ServerLayout.tsx
/** An icon in the row; it is named once the navigation collapses or moves it into the menu. */
function AdminLinkLabel({ placement }) {
	return /* @__PURE__ */ jsxs("span", {
		className: "inline-flex items-center gap-2 align-top",
		title: "Open server administration",
		children: [/* @__PURE__ */ jsx(Icon, {
			icon: ExternalLink,
			"aria-hidden": true
		}), /* @__PURE__ */ jsx("span", {
			className: placement === "row" ? "sr-only in-data-collapsed:not-sr-only" : void 0,
			children: "Open Admin Area"
		})]
	});
}
function ServerLayout({ model, className, children }) {
	const { adminLink } = model;
	return /* @__PURE__ */ jsx(SubNavigationLayout, {
		className,
		navigation: /* @__PURE__ */ jsx(SubNavigation, {
			items: adminLink ? [...model.nav.items, adminLink] : model.nav.items,
			canOverflow: (item) => item.extensionId !== void 0 || item === adminLink,
			renderItem: (item, state) => item === adminLink ? /* @__PURE__ */ jsx(AdminLinkLabel, { placement: state.placement }) : tabLabel(item, state),
			before: /* @__PURE__ */ jsx(Slot, {
				name: "server.navigation.before",
				data: model.server
			}),
			after: /* @__PURE__ */ jsx(Slot, {
				name: "server.navigation.after",
				data: model.server
			})
		}),
		children: /* @__PURE__ */ jsx(Main, { children })
	});
}
//#endregion
export { ServerLayout as default };

//# sourceMappingURL=ServerLayout-_DtaKFcO.js.map