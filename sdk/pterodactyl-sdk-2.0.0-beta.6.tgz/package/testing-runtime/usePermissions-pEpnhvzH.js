import { s as useCurrentServerPermissions } from "./queries-D_-2KdyF.js";
//#region ../../resources/scripts/plugins/usePermissions.ts
var hasPermission = (userPermissions, permission) => {
	if (userPermissions[0] === "*") return true;
	if (permission.endsWith(".*")) {
		const prefix = permission.slice(0, -1);
		return userPermissions.some((granted) => granted.startsWith(prefix));
	}
	return userPermissions.includes(permission);
};
var usePermissions = (action) => {
	const userPermissions = useCurrentServerPermissions();
	return (Array.isArray(action) ? action : [action]).map((permission) => hasPermission(userPermissions, permission));
};
//#endregion
export { usePermissions as n, hasPermission as t };

//# sourceMappingURL=usePermissions-pEpnhvzH.js.map