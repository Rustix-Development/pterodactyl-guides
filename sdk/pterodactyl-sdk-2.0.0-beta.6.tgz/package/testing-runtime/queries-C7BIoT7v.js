import { t as notifyHttpError, vt as clientSendPowerActionMutation, yt as clientSendServerCommandMutation } from "./notifications-Ebj0Q0Io.js";
import { useMutation } from "@tanstack/react-query";
//#region ../../resources/scripts/api/server/power/queries.ts
var sendPowerActionInput = (uuid, signal) => ({
	path: { server_uuid: uuid },
	body: { signal }
});
var sendServerCommandInput = (uuid, command) => ({
	path: { server_uuid: uuid },
	body: { command }
});
var useSendPowerAction = () => useMutation({
	...clientSendPowerActionMutation(),
	onError: (error) => notifyHttpError(error, "Unable to send power action")
});
var useSendServerCommand = () => useMutation({
	...clientSendServerCommandMutation(),
	onError: (error) => notifyHttpError(error, "Unable to send command")
});
//#endregion
export { useSendServerCommand as i, sendServerCommandInput as n, useSendPowerAction as r, sendPowerActionInput as t };

//# sourceMappingURL=queries-C7BIoT7v.js.map