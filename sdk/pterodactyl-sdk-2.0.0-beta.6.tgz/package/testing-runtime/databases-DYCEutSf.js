import { D as clientDeleteServerDatabaseMutation, Gt as implementViews, _ as clientCreateServerDatabaseMutation, _t as clientRotateServerDatabasePasswordMutation, at as clientListServerDatabasesQueryKey, it as clientListServerDatabasesOptions, t as notifyHttpError } from "./notifications-Ebj0Q0Io.js";
import { i as useCurrentServer } from "./queries-D_-2KdyF.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { i as upsertListItem, n as removeListItems } from "./queryData-DzPdESJr.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { t as relationshipAttributes } from "./relationships-CSicEn-V.js";
import { useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/server/databases/queries.ts
var serverDatabasesInput = (uuid) => ({
	path: { server_uuid: uuid },
	query: { include: "password" }
});
var createServerDatabaseInput = (uuid, values) => ({
	path: { server_uuid: uuid },
	body: {
		database: values.databaseName,
		remote: values.connectionsFrom
	},
	query: { include: "password" }
});
var rotateServerDatabasePasswordInput = (uuid, databaseId) => ({
	path: {
		server_uuid: uuid,
		database_id: databaseId
	},
	query: { include: "password" }
});
var deleteServerDatabaseInput = (uuid, database) => ({
	path: {
		server_uuid: uuid,
		database_id: database.attributes.id
	},
	meta: { name: database.attributes.name }
});
var serverDatabasesQueryOptions = (uuid) => clientListServerDatabasesOptions(serverDatabasesInput(uuid));
var useServerDatabases = (uuid) => useQuery({
	...serverDatabasesQueryOptions(uuid),
	enabled: uuid.length > 0
});
var upsertDatabase = async (queryClient, uuid, database) => {
	await queryClient.cancelQueries({ queryKey: clientListServerDatabasesQueryKey(serverDatabasesInput(uuid)) });
	return queryClient.setQueryData(clientListServerDatabasesQueryKey(serverDatabasesInput(uuid)), (current) => upsertListItem(current, database, (item) => item.attributes.id === database.attributes.id, (item) => ({
		object: "list",
		data: [item]
	})));
};
var removeDatabase = async (queryClient, uuid, databaseId) => {
	await queryClient.cancelQueries({ queryKey: clientListServerDatabasesQueryKey(serverDatabasesInput(uuid)) });
	return queryClient.setQueryData(clientListServerDatabasesQueryKey(serverDatabasesInput(uuid)), (current) => removeListItems(current, (database) => database.attributes.id === databaseId));
};
var useCreateServerDatabase = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateServerDatabaseMutation(),
		onSuccess: async (database, { path }) => {
			await upsertDatabase(queryClient, path.server_uuid, database);
			toast.success("Database created", { description: `${database.attributes.name} is ready to use.` });
		},
		onError: (error) => notifyHttpError(error, "Unable to create database")
	});
};
var useDeleteServerDatabase = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDeleteServerDatabaseMutation(),
		onSuccess: async (_data, variables) => {
			await removeDatabase(queryClient, variables.path.server_uuid, variables.path.database_id);
			const name = variables.meta?.name;
			toast.success("Database deleted", { description: name ? `${name} has been removed.` : void 0 });
		},
		onError: (error) => notifyHttpError(error, "Unable to delete database")
	});
};
var useRotateDatabasePassword = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientRotateServerDatabasePasswordMutation(),
		onSuccess: async (database, { path }) => {
			await upsertDatabase(queryClient, path.server_uuid, database);
			toast.success("Database password rotated", { description: `${database.attributes.name} has a new password.` });
		},
		onError: (error) => notifyHttpError(error, "Unable to rotate database password")
	});
};
//#endregion
//#region ../../resources/scripts/lib/databases.ts
var jdbcConnectionString = ({ connectionString, name, password, username }) => {
	const credentials = new URLSearchParams({ user: username });
	if (password) credentials.set("password", password);
	return `jdbc:mysql://${connectionString}/${name}?${credentials.toString()}`;
};
/** Strips the `s{serverId}_` prefix. */
var serverDatabaseShortName = (name) => {
	const separator = name.indexOf("_");
	return separator === -1 ? name : name.slice(separator + 1);
};
//#endregion
//#region ../../resources/scripts/views/server/databases.ts
var noDatabases = [];
function validateName(value) {
	if (value.length < 1) return "A database name must be provided.";
	if (value.length < 3) return "Database name must be at least 3 characters.";
	if (value.length > 48) return "Database name must not exceed 48 characters.";
	if (!/^[\w\-.]{3,48}$/.test(value)) return "Database name should only contain alphanumeric characters, underscores, dashes, and/or periods.";
}
var validateConnectionsFrom = (value) => /^[\w\-/.%:]*$/.test(value) ? void 0 : "A valid host address must be provided.";
function databaseItem({ attributes }) {
	const endpoint = `${attributes.host.address}:${attributes.host.port}`;
	const password = relationshipAttributes(attributes.relationships?.password)?.password;
	return {
		id: attributes.id,
		name: attributes.name,
		shortName: serverDatabaseShortName(attributes.name),
		endpoint,
		connectionsFrom: attributes.connections_from,
		username: attributes.username,
		password: password ?? null,
		jdbc: jdbcConnectionString({
			connectionString: endpoint,
			name: attributes.name,
			password,
			username: attributes.username
		})
	};
}
function useDatabasesQuery() {
	const server = useCurrentServer();
	return {
		server,
		query: useServerDatabases(server?.attributes.uuid ?? "")
	};
}
var useDatabasesPageModel = () => pageStatus(useDatabasesQuery().query);
function useServerDatabasesModel() {
	const { server, query } = useDatabasesQuery();
	const uuid = server?.attributes.uuid ?? "";
	const limit = server?.attributes.feature_limits.databases ?? 0;
	const [create, update, remove, viewPassword] = usePermissions([
		"database.create",
		"database.update",
		"database.delete",
		"database.view_password"
	]);
	const { mutateAsync: createDatabase } = useCreateServerDatabase();
	const { mutateAsync: rotatePassword, isPending: rotating, variables: rotated } = useRotateDatabasePassword();
	const { mutateAsync: deleteDatabase } = useDeleteServerDatabase();
	const listed = query.data?.data ?? noDatabases;
	const rotatingId = rotating ? rotated?.path.database_id ?? null : null;
	return useMemo(() => {
		const databases = listed.map(databaseItem);
		return {
			databases,
			loading: !databases.length && query.isLoading,
			limit,
			permissions: {
				create,
				update,
				delete: remove,
				viewPassword
			},
			canCreate: create && limit > 0 && databases.length < limit,
			rotating: rotatingId ? [rotatingId] : [],
			validate: {
				name: validateName,
				connectionsFrom: validateConnectionsFrom
			},
			actions: {
				create: async ({ name, connectionsFrom }) => {
					await createDatabase(createServerDatabaseInput(uuid, {
						databaseName: name,
						connectionsFrom: connectionsFrom || "%"
					}));
				},
				rotatePassword: async (id) => {
					await rotatePassword(rotateServerDatabasePasswordInput(uuid, id));
				},
				remove: async (id) => {
					const database = listed.find(({ attributes }) => attributes.id === id);
					if (database) await deleteDatabase(deleteServerDatabaseInput(uuid, database));
				}
			}
		};
	}, [
		listed,
		query.isLoading,
		limit,
		create,
		update,
		remove,
		viewPassword,
		rotatingId,
		createDatabase,
		rotatePassword,
		deleteDatabase,
		uuid
	]);
}
var resolved = async () => {};
var database = (name, options = {}) => ({
	id: name,
	name: `s1_${name}`,
	shortName: name,
	endpoint: "203.0.113.20:3306",
	connectionsFrom: "%",
	username: `u1_${name}`,
	password: "q8V2mR7xL4",
	jdbc: `jdbc:mysql://203.0.113.20:3306/s1_${name}?user=u1_${name}&password=q8V2mR7xL4`,
	...options
});
var databasesFixture = (options = {}) => ({
	databases: [database("survival"), database("stats", { connectionsFrom: "10.0.0.%" })],
	loading: false,
	limit: 3,
	permissions: {
		create: true,
		update: true,
		delete: true,
		viewPassword: true
	},
	canCreate: true,
	rotating: [],
	validate: {
		name: validateName,
		connectionsFrom: validateConnectionsFrom
	},
	actions: {
		create: resolved,
		rotatePassword: resolved,
		remove: resolved
	},
	...options
});
implementViews({
	"page.server.databases": {
		use: useDatabasesPageModel,
		fixtures: pageStatusFixtures
	},
	"server.databases": {
		use: useServerDatabasesModel,
		fixtures: {
			databases: () => databasesFixture(),
			full: () => databasesFixture({
				limit: 2,
				canCreate: false
			}),
			empty: () => databasesFixture({ databases: [] }),
			noLimit: () => databasesFixture({
				databases: [],
				limit: 0,
				canCreate: false
			}),
			readOnly: () => databasesFixture({
				permissions: {
					create: false,
					update: false,
					delete: false,
					viewPassword: false
				},
				canCreate: false,
				databases: [database("survival", { password: null })]
			}),
			loading: () => databasesFixture({
				databases: [],
				loading: true
			})
		}
	}
});
//#endregion

//# sourceMappingURL=databases-DYCEutSf.js.map