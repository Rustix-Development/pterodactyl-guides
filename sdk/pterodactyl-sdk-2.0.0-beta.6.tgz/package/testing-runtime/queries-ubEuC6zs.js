import { R as clientGetServerResourcesOptions, Y as clientListClientServersOptions } from "./notifications-Ebj0Q0Io.js";
import { useQuery } from "@tanstack/react-query";
//#region ../../resources/scripts/api/account/servers/queries.ts
var clientServersInput = ({ page, query, type } = {}) => {
	const queryParameters = {
		page,
		type
	};
	if (query) queryParameters["filter[*]"] = query;
	return { query: queryParameters };
};
var accountServersQueryOptions = ({ page = 1, type } = {}) => clientListClientServersOptions(clientServersInput({
	page,
	type
}));
var useAccountServers = (params = {}) => useQuery(accountServersQueryOptions(params));
var accountServerSearchQueryOptions = ({ query = "", type } = {}) => clientListClientServersOptions(clientServersInput({
	query,
	type
}));
var useAccountServerSearch = (params = {}, enabled = true) => useQuery({
	...accountServerSearchQueryOptions(params),
	enabled
});
var serverResourcesInput = (uuid) => ({ path: { server_uuid: uuid } });
var serverResourceUsageQueryOptions = (uuid) => ({
	...clientGetServerResourcesOptions(serverResourcesInput(uuid)),
	retry: false
});
/** Wings refreshes usage at most every 20 seconds. */
var serverResourceUsageRefetchInterval = (query) => query.state.data?.attributes.is_suspended ? false : 3e4;
var useServerResourceUsage = (uuid, enabled = true) => useQuery({
	...serverResourceUsageQueryOptions(uuid),
	enabled: enabled && uuid.length > 0,
	refetchInterval: serverResourceUsageRefetchInterval
});
//#endregion
export { useServerResourceUsage as a, useAccountServers as i, serverResourceUsageRefetchInterval as n, useAccountServerSearch as r, serverResourceUsageQueryOptions as t };

//# sourceMappingURL=queries-ubEuC6zs.js.map