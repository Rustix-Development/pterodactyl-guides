import { Ct as screenImages, xt as ScreenBlock } from "./sdk-Chrtpiam.js";
import { jsx } from "react/jsx-runtime";
//#region ../../resources/scripts/themes/classic/views/server/ServerConflict.tsx
var notices = {
	installing: {
		title: "Running Installer",
		image: screenImages.installing,
		message: "Your server should be ready soon, please try again in a few minutes."
	},
	suspended: {
		title: "Server Suspended",
		image: screenImages.error,
		message: "This server is suspended and cannot be accessed."
	},
	maintenance: {
		title: "Node under Maintenance",
		image: screenImages.error,
		message: "The node of this server is currently under maintenance."
	},
	transferring: {
		title: "Transferring",
		image: screenImages.restoring,
		message: "Your server is being transferred to a new node, please check back later."
	},
	"restoring-backup": {
		title: "Restoring from Backup",
		image: screenImages.restoring,
		message: "Your server is currently being restored from a backup, please check back in a few minutes."
	}
};
function ServerConflict({ model, className }) {
	if (!model.kind) return null;
	const { title, image, message } = notices[model.kind];
	return /* @__PURE__ */ jsx(ScreenBlock, {
		title,
		image,
		message,
		className
	});
}
//#endregion
export { ServerConflict as default };

//# sourceMappingURL=ServerConflict-lz82f-Z2.js.map