import { Dt as ServerContentBlock, Et as TitledGreyBox, at as EmptyTitle, et as Empty, it as EmptyMedia, jt as Badge, mt as InputSpinner, nt as EmptyDescription, rt as EmptyHeader } from "./sdk-Chrtpiam.js";
import { a as Slot, c as View } from "./theme-Cgy7R6cy.js";
import { a as Switch, o as Select, p as TextInput, t as useDebouncedCallback } from "./useDebouncedCallback-B4Ebjqc5.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { t as usePending } from "./usePending-DoheVZuN.js";
import { useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Variable } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/server/startup/StartupPage.tsx
function StartupPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsxs(ServerContentBlock, {
			title: "Startup Settings",
			className,
			children: [
				model.slot && /* @__PURE__ */ jsx(Slot, {
					name: "server.startup.form",
					data: model.slot
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "md:flex md:items-start",
					children: [/* @__PURE__ */ jsx(View, {
						name: "server.startup.command",
						className: "flex-1"
					}), /* @__PURE__ */ jsx(View, {
						name: "server.startup.image",
						className: "flex-1 lg:flex-none lg:w-1/3 mt-8 md:mt-0 md:ml-10"
					})]
				}),
				/* @__PURE__ */ jsx(View, { name: "server.startup.variables" })
			]
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/startup/StartupCommand.tsx
function StartupCommand({ model, className }) {
	return /* @__PURE__ */ jsx(TitledGreyBox, {
		title: "Startup Command",
		className,
		children: /* @__PURE__ */ jsx("div", {
			className: "px-1 py-2",
			children: /* @__PURE__ */ jsx("p", {
				className: "rounded-sm bg-terminal px-4 py-2 font-mono",
				children: model.command
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/startup/StartupImage.tsx
function StartupImage({ model, className }) {
	return /* @__PURE__ */ jsx(TitledGreyBox, {
		title: "Docker Image",
		className,
		children: model.images.length > 1 && !model.custom ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(InputSpinner, {
			visible: model.pending,
			children: /* @__PURE__ */ jsx(Select, {
				disabled: model.images.length < 2,
				value: model.image,
				onChange: (value) => void model.select(String(value)).catch(() => {}),
				options: model.images.map(({ label, value }) => ({
					value,
					label
				}))
			})
		}), /* @__PURE__ */ jsx("p", {
			className: "text-xs text-muted-foreground mt-2",
			children: "This is an advanced feature allowing you to select a Docker image to use when running this server instance."
		})] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(TextInput, {
			disabled: true,
			readOnly: true,
			value: model.image
		}), model.custom && /* @__PURE__ */ jsx("p", {
			className: "text-xs text-muted-foreground mt-2",
			children: "This server's Docker image has been manually set by an administrator and cannot be changed through this UI."
		})] })
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/startup/StartupVariables.tsx
function VariableControl({ model, variable }) {
	const [draft, setDraft] = useState(null);
	const [saving, track] = usePending();
	const value = draft ?? variable.value;
	const editable = model.canEdit && variable.editable;
	const { control } = variable;
	const save = useDebouncedCallback((update, next) => {
		const saved = update(variable.key, next);
		track(saved);
		saved.then(() => setDraft((current) => current === next ? null : current), () => {});
	}, 500);
	const change = (next) => {
		setDraft(next);
		save(model.update, next);
	};
	return /* @__PURE__ */ jsxs(InputSpinner, {
		visible: saving,
		children: [
			control.kind === "switch" && /* @__PURE__ */ jsx(Switch, {
				disabled: !editable,
				checked: value === control.on,
				onChange: () => editable && change(value === control.on ? control.off : control.on)
			}),
			control.kind === "select" && /* @__PURE__ */ jsx(Select, {
				value,
				onChange: (selected) => change(String(selected)),
				disabled: !editable,
				options: control.options.map((option) => ({
					value: option,
					label: option
				}))
			}),
			control.kind === "text" && /* @__PURE__ */ jsx(TextInput, {
				onChange: (event) => editable && change(event.currentTarget.value),
				onBlur: save.flush,
				readOnly: !editable,
				name: variable.key,
				value,
				placeholder: variable.defaultValue
			})
		]
	});
}
function VariableBox({ model, variable }) {
	return /* @__PURE__ */ jsxs(TitledGreyBox, {
		title: /* @__PURE__ */ jsxs("p", {
			className: "text-sm uppercase",
			children: [!variable.editable && /* @__PURE__ */ jsx(Badge, {
				className: "bg-card rounded-full mr-2 mb-1",
				children: "Read Only"
			}), variable.name]
		}),
		children: [/* @__PURE__ */ jsx(VariableControl, {
			model,
			variable
		}), /* @__PURE__ */ jsx("p", {
			className: "mt-1 text-xs text-muted-foreground",
			children: variable.description
		})]
	});
}
function StartupVariables({ model, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [/* @__PURE__ */ jsx("h3", {
			className: "mt-8 mb-2 text-2xl",
			children: "Variables"
		}), model.variables.length === 0 ? /* @__PURE__ */ jsx(Empty, {
			size: "compact",
			className: "border",
			children: /* @__PURE__ */ jsxs(EmptyHeader, { children: [
				/* @__PURE__ */ jsx(EmptyMedia, {
					variant: "icon",
					children: /* @__PURE__ */ jsx(Variable, {})
				}),
				/* @__PURE__ */ jsx(EmptyTitle, { children: "No variables" }),
				/* @__PURE__ */ jsx(EmptyDescription, { children: "This server doesn't have any startup variables to configure." })
			] })
		}) : /* @__PURE__ */ jsx("div", {
			className: "grid gap-8 md:grid-cols-2",
			children: model.variables.map((variable) => /* @__PURE__ */ jsx(VariableBox, {
				model,
				variable
			}, variable.key))
		})]
	});
}
//#endregion
export { StartupCommand, StartupImage, StartupPage, StartupVariables };

//# sourceMappingURL=startup-BF-8IIzw.js.map