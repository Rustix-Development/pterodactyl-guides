import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { n as fixtureField, t as boundField } from "./forms-DcsxfoFI.js";
import { n as parseEmailSearch } from "./pageSearch-DKMAcuIY.js";
import { a as useRequestPasswordResetEmail, i as usePerformPasswordReset } from "./queries-DA42aKcL.js";
import { t as useCaptcha } from "./captcha-BRyXUbvn.js";
import { useParams, useSearch } from "@tanstack/react-router";
import { useField, useForm, useStore } from "@tanstack/react-form";
//#region ../../resources/scripts/views/auth/password.ts
var isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
var newPassword = {
	type: "password",
	autoComplete: "new-password"
};
function useForgotPasswordFormModel() {
	const requestReset = useRequestPasswordResetEmail();
	const { Captcha, token } = useCaptcha();
	const form = useForm({
		defaultValues: { email: "" },
		onSubmit: async ({ value, formApi }) => {
			const captcha = await token();
			if (captcha === null) return;
			try {
				await requestReset.mutateAsync({ body: {
					email: value.email,
					"g-recaptcha-response": captcha
				} });
				formApi.reset();
			} catch {}
		}
	});
	const email = useField({
		form,
		name: "email",
		validators: { onChange: ({ value }) => isEmail(value) ? void 0 : "A valid email address must be provided to continue." }
	});
	const canSubmit = useStore(form.store, (state) => state.canSubmit);
	const submitting = useStore(form.store, (state) => state.isSubmitting);
	return {
		fields: { email: boundField(email, {
			type: "email",
			autoComplete: "email"
		}) },
		submit: () => void form.handleSubmit(),
		canSubmit,
		submitting,
		Captcha,
		login: { to: "/auth/login" }
	};
}
function useResetPasswordFormModel() {
	const { token: resetToken = "" } = useParams({ strict: false });
	const { email = "" } = parseEmailSearch(useSearch({ strict: false }));
	const resetPassword = usePerformPasswordReset();
	const { Captcha, token } = useCaptcha();
	const form = useForm({
		defaultValues: {
			password: "",
			passwordConfirmation: ""
		},
		onSubmit: async ({ value }) => {
			const captcha = await token();
			if (captcha === null) return;
			try {
				await resetPassword.mutateAsync({ body: {
					email,
					token: resetToken,
					password: value.password,
					password_confirmation: value.passwordConfirmation,
					"g-recaptcha-response": captcha
				} });
				window.location.assign("/");
			} catch {}
		}
	});
	const password = useField({
		form,
		name: "password",
		validators: { onChange: ({ value }) => value.length >= 8 ? void 0 : "Your new password should be at least 8 characters in length." }
	});
	const confirmation = useField({
		form,
		name: "passwordConfirmation",
		validators: {
			onChangeListenTo: ["password"],
			onChange: ({ value, fieldApi }) => value === fieldApi.form.getFieldValue("password") ? void 0 : "Your new password does not match."
		}
	});
	const canSubmit = useStore(form.store, (state) => state.canSubmit);
	const submitting = useStore(form.store, (state) => state.isSubmitting);
	return {
		fields: {
			password: boundField(password, newPassword),
			passwordConfirmation: boundField(confirmation, newPassword)
		},
		submit: () => void form.handleSubmit(),
		canSubmit,
		submitting,
		Captcha,
		email,
		login: { to: "/auth/login" }
	};
}
var noop = () => {};
var forgotFixture = (error = null) => ({
	fields: { email: fixtureField("email", {
		type: "email",
		autoComplete: "email"
	}, "", error) },
	submit: noop,
	canSubmit: error === null,
	submitting: false,
	Captcha: null,
	login: { to: "/auth/login" }
});
var resetFixture = (mismatch) => ({
	fields: {
		password: fixtureField("password", newPassword, "correct horse"),
		passwordConfirmation: fixtureField("passwordConfirmation", newPassword, mismatch ? "correct horse battery" : "", mismatch ? "Your new password does not match." : null)
	},
	submit: noop,
	canSubmit: !mismatch,
	submitting: false,
	Captcha: null,
	email: "alex@example.test",
	login: { to: "/auth/login" }
});
implementViews({
	"page.auth.password": {
		use: useForgotPasswordFormModel,
		fixtures: {
			default: () => forgotFixture(),
			invalid: () => forgotFixture("A valid email address must be provided to continue.")
		}
	},
	"page.auth.passwordReset": {
		use: useResetPasswordFormModel,
		fixtures: {
			default: () => resetFixture(false),
			mismatch: () => resetFixture(true)
		}
	}
});
//#endregion

//# sourceMappingURL=password-BQ3tshXK.js.map