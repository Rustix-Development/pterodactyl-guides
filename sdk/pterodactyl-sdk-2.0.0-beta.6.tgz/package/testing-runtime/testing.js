import { n as registerClassPrefixes } from "./cn-f7uEsK4g.js";
import { a as Spinner, o as clearThemeSkins, s as registerSkins } from "./Button-BzlrfY24.js";
import { c as isFiniteNumber, u as isObject } from "./client.gen-Ci-zROOW.js";
import { $t as lazyView, Bt as clearThemeLayers, Qt as isPendingLazyView, Ut as getViewDefinition, Vt as defineView, Wt as getViewDefinitions, Yt as registerViewLayer, qt as loadViewImplementation } from "./notifications-Ebj0Q0Io.js";
import { d as ExtensionMount, g as registerThemeIcons, l as ExtensionResourceProvider, m as defineTheme } from "./navigation-DAcCRZlc.js";
import { r as serverQueryOptions } from "./queries-D_-2KdyF.js";
import { b as mountSlotComponents, c as SCREEN_ROOTS, n as resolvePanelDestination, p as getExtensionErrors, u as clearExtensionError } from "./navigation-9aP-0Hbq.js";
import { c as useServerStore, l as useSocketConnected, s as useServerStatus, t as Provider, u as useSocketInstance } from "./server-U1WA-Nu8.js";
import { d as mountedSlots, f as mountedViews, l as ViewFixtureProvider, o as Main, s as RenderView, t as cn, u as preloadView } from "./theme-Cgy7R6cy.js";
import { t as currentUserQueryKey } from "./queries-BF8_5ZD3.js";
import { t as queryClient } from "./queryClient-CU2lXun5.js";
import { t as siteSettingsQueryKey } from "./queries-DXZ7OlB6.js";
import { n as SocketRequest, r as useWebsocketEvent, t as SocketEvent } from "./events-BZtD8HxQ.js";
import { a as createTestFileManagerEntry, d as loadCodemirrorEditor, i as createTestFileManager, n as createTestFileEditor, t as createTestFileDetails } from "./fileFixtures-u5el1pLN.js";
import { n as createTestServerCard, t as createTestServer } from "./fixtures-sueNo-ZT.js";
import { act, createContext, createElement, useContext, useEffect, useLayoutEffect } from "react";
import { Outlet, RouterContextProvider, RouterProvider, createMemoryHistory, createRootRoute, createRoute, createRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { QueryClientProvider } from "@tanstack/react-query";
import { createRoot } from "react-dom/client";
//#region ../../resources/scripts/themes/classic/skins/buttons.ts
var button = {
	root: {
		base: "relative inline-block rounded-sm border p-2 text-sm uppercase tracking-wide transition-colors duration-150 disabled:cursor-default disabled:opacity-50",
		variants: {
			color: {
				primary: "bg-primary border-primary text-primary-foreground hover:not-disabled:bg-primary/80 hover:not-disabled:border-primary",
				grey: "border-border bg-popover text-foreground hover:not-disabled:bg-secondary hover:not-disabled:border-secondary",
				green: "border-success bg-success text-success-foreground hover:not-disabled:bg-success/80 hover:not-disabled:border-success",
				red: "border-destructive bg-destructive text-destructive-foreground hover:not-disabled:bg-destructive/80 hover:not-disabled:border-destructive",
				orange: "border-caution bg-caution text-caution-foreground hover:not-disabled:bg-caution/80 hover:not-disabled:border-caution"
			},
			size: {
				xsmall: "px-2 py-1 text-xs",
				small: "px-4 py-2",
				large: "p-4 text-sm",
				xlarge: "p-4 w-full"
			},
			secondary: { true: "border-border bg-transparent text-foreground hover:not-disabled:border-popover hover:not-disabled:bg-popover hover:not-disabled:text-foreground" }
		},
		compoundVariants: [
			{
				secondary: true,
				color: "primary",
				class: "hover:not-disabled:bg-primary hover:not-disabled:border-primary hover:not-disabled:text-primary-foreground"
			},
			{
				secondary: true,
				color: "red",
				class: "hover:not-disabled:bg-destructive hover:not-disabled:border-destructive hover:not-disabled:text-destructive-foreground"
			},
			{
				secondary: true,
				color: "green",
				class: "hover:not-disabled:bg-success hover:not-disabled:border-success hover:not-disabled:text-success-foreground"
			},
			{
				secondary: true,
				color: "orange",
				class: "hover:not-disabled:bg-caution hover:not-disabled:border-caution hover:not-disabled:text-caution-foreground"
			},
			{
				secondary: false,
				color: "primary",
				class: "active:not-disabled:bg-primary/70 active:not-disabled:border-primary/70"
			},
			{
				secondary: false,
				color: "green",
				class: "active:not-disabled:bg-success/70 active:not-disabled:border-success"
			},
			{
				secondary: false,
				color: "red",
				class: "active:not-disabled:bg-destructive/70 active:not-disabled:border-destructive"
			},
			{
				secondary: false,
				color: "orange",
				class: "active:not-disabled:bg-caution/70 active:not-disabled:border-caution"
			}
		]
	},
	spinner: "flex absolute justify-center items-center w-full h-full left-0 top-0",
	label: {
		base: "inline-flex items-center gap-2",
		variants: { loading: { true: "text-transparent" } }
	}
};
var newButton = {
	root: "inline-flex h-9 shrink-0 items-center justify-center gap-2 px-3 normal-case font-medium tracking-normal",
	content: "inline-flex items-center gap-2",
	icon: "h-4 w-4"
};
//#endregion
//#region ../../resources/scripts/themes/classic/skins/data.ts
var fading = { fetching: { true: "opacity-55" } };
var table = {
	root: "@container overflow-hidden rounded-sm border border-border bg-card",
	empty: {
		base: "flex transition-opacity",
		variants: fading
	},
	scroller: "overflow-x-auto scrollbar-thin scrollbar-thumb-(--scrollbar-thumb)",
	table: "w-full border-collapse text-left text-sm",
	head: "border-b border-border bg-muted/70",
	headerRow: "",
	headerCell: "h-10 whitespace-nowrap px-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground",
	body: {
		base: "divide-y divide-border transition-opacity",
		variants: fading
	},
	row: "transition-colors hover:bg-muted/35",
	cell: "px-3 py-2.5 align-middle text-foreground"
};
var pagination = {
	root: "mt-4 flex justify-center",
	page: "p-0 w-10 h-10 not-last-of-type:mr-2"
};
var code = { root: {
	base: "font-mono px-1.5 py-0.5 inline-block rounded-sm",
	variants: { dark: {
		true: "bg-muted text-foreground",
		false: "bg-sunken"
	} }
} };
var copyOnClick = {
	root: "fixed z-50 bottom-0 right-0 m-4",
	status: "rounded-md py-3 px-4 text-foreground bg-popover/95 shadow-sm",
	message: "",
	target: "cursor-pointer"
};
var avatar = { root: "" };
/** A tile's icon box and mobile bar by tone, and the icon on it. */
var tileFill = {
	neutral: "bg-card",
	success: "bg-success",
	warning: "bg-warning",
	danger: "bg-destructive",
	info: "bg-primary",
	accent: "bg-accent"
};
var tileInk = {
	neutral: "text-foreground",
	success: "text-success-foreground",
	warning: "text-warning-foreground",
	danger: "text-destructive-foreground",
	info: "text-primary-foreground",
	accent: "text-accent-foreground"
};
/** An inline stat colours its icon and value. */
var inlineInk = {
	neutral: "text-muted-foreground",
	success: "text-success",
	warning: "text-warning",
	danger: "text-destructive",
	info: "text-primary",
	accent: "text-accent"
};
var stat = {
	root: { variants: { variant: {
		tile: "relative flex items-center rounded-sm bg-popover px-3 py-2 shadow-lg md:p-3 lg:p-4",
		inline: "flex flex-wrap justify-center"
	} } },
	indicator: ({ variant, tone }) => variant === "tile" ? `absolute top-0 left-0 h-full w-1 rounded-l-sm sm:hidden ${tileFill[tone]}` : "hidden",
	icon: ({ variant, tone }) => variant === "tile" ? `hidden h-12 w-12 shrink-0 items-center justify-center rounded-lg shadow-md transition-colors duration-500 sm:mr-4 sm:flex ${tileFill[tone]}` : "flex",
	glyph: ({ variant, tone }) => variant === "tile" ? `m-auto size-6 ${tileInk[tone]}` : `size-[1em] shrink-0 ${inlineInk[tone]}`,
	body: { variants: { variant: {
		tile: "flex w-full flex-wrap content-center items-baseline overflow-hidden",
		inline: "contents"
	} } },
	label: { variants: { variant: {
		tile: "basis-full font-header font-medium text-xs leading-tight md:text-sm text-foreground",
		inline: "sr-only"
	} } },
	value: ({ variant, tone, unavailable }) => variant === "tile" ? `h-7 min-w-0 truncate text-lg font-semibold leading-7 md:text-xl ${unavailable ? "text-muted-foreground" : "text-foreground"}` : `ml-2 text-sm ${unavailable ? "text-muted-foreground" : inlineInk[tone]}`,
	limit: { variants: { variant: {
		tile: "ml-1 shrink-0 select-none text-xs text-muted-foreground",
		inline: "mt-1 basis-full text-center text-xs text-muted-foreground"
	} } }
};
var chartCard = {
	root: "group relative rounded-sm bg-popover pt-2 shadow-lg border-b-4 border-border",
	header: "flex items-center justify-between px-4 py-2",
	title: "font-header font-medium transition-colors duration-100 group-hover:text-foreground",
	legend: "text-sm flex items-center",
	body: "z-10 ml-2"
};
//#endregion
//#region ../../resources/scripts/themes/classic/skins/feedback.ts
var alert = {
	root: {
		base: "flex items-start rounded-sm border border-l-4 px-4 py-3 text-foreground shadow-sm",
		variants: { type: {
			success: "border-success bg-success/15",
			info: "border-accent bg-accent/10",
			warning: "border-warning bg-warning/15",
			danger: "border-destructive bg-destructive/15"
		} }
	},
	icon: {
		base: "mr-3 mt-0.5 h-5 w-5 shrink-0",
		variants: { type: {
			success: "text-success",
			info: "text-accent",
			warning: "text-warning",
			danger: "text-destructive"
		} }
	},
	body: "min-w-0 flex-1 text-sm leading-relaxed",
	title: "mb-1 font-semibold text-foreground",
	content: ""
};
var badge = { root: {
	base: "rounded-sm text-xs",
	variants: {
		size: {
			sm: "px-1.5 py-0.5",
			md: "px-2 py-1"
		},
		variant: { soft: "border" }
	},
	compoundVariants: [
		{
			variant: "solid",
			tone: "neutral",
			class: "bg-popover text-foreground"
		},
		{
			variant: "solid",
			tone: "success",
			class: "bg-success text-success-foreground"
		},
		{
			variant: "solid",
			tone: "warning",
			class: "bg-warning text-warning-foreground"
		},
		{
			variant: "solid",
			tone: "danger",
			class: "bg-destructive text-destructive-foreground"
		},
		{
			variant: "solid",
			tone: "info",
			class: "bg-primary text-primary-foreground"
		},
		{
			variant: "solid",
			tone: "accent",
			class: "bg-accent text-accent-foreground"
		},
		{
			variant: "soft",
			tone: "neutral",
			class: "border-border bg-muted text-muted-foreground"
		},
		{
			variant: "soft",
			tone: "success",
			class: "border-success/25 bg-success/10 text-success"
		},
		{
			variant: "soft",
			tone: "warning",
			class: "border-warning/25 bg-warning/10 text-warning"
		},
		{
			variant: "soft",
			tone: "danger",
			class: "border-destructive/25 bg-destructive/10 text-destructive"
		},
		{
			variant: "soft",
			tone: "info",
			class: "border-primary/25 bg-primary/10 text-primary"
		},
		{
			variant: "soft",
			tone: "accent",
			class: "border-accent/25 bg-accent/10 text-accent"
		}
	]
} };
var empty = {
	root: {
		base: "flex min-w-0 flex-1 flex-col items-center justify-center gap-6 rounded-sm border-dashed p-6 text-center text-balance md:p-12",
		variants: { size: { compact: "gap-4 md:p-8" } }
	},
	header: "flex max-w-sm flex-col items-center gap-2 text-center",
	media: {
		base: "mb-2 flex shrink-0 items-center justify-center [&_svg]:pointer-events-none [&_svg]:shrink-0",
		variants: { variant: {
			default: "bg-transparent",
			icon: "flex size-10 shrink-0 items-center justify-center rounded-sm bg-secondary text-secondary-foreground [&_svg:not([class*='size-'])]:size-6"
		} }
	},
	title: "font-header text-lg font-medium tracking-tight text-foreground",
	description: "text-sm/relaxed text-muted-foreground [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-accent",
	content: "flex w-full max-w-sm min-w-0 flex-col items-center gap-4 text-sm text-balance"
};
var progressBar = {
	root: { variants: { variant: {
		meter: "h-2 w-full rounded-sm bg-sunken overflow-hidden",
		page: "fixed h-0.5 w-full"
	} } },
	indicator: { variants: {
		variant: {
			meter: "h-2 rounded-sm transition-[width,background-color] duration-150",
			page: "h-full shadow-progress transition-[width] duration-300 ease-in-out"
		},
		tone: {
			neutral: "bg-popover",
			success: "bg-success",
			warning: "bg-warning",
			danger: "bg-destructive",
			info: "bg-primary",
			accent: "bg-accent"
		}
	} }
};
var spinner$1 = {
	root: {
		base: "block rounded-full animate-[spin_1s_cubic-bezier(0.55,0.25,0.25,0.7)_infinite] border-muted border-t-foreground",
		variants: {
			blue: { true: "border-ring border-t-primary" },
			size: {
				small: "w-4 h-4 border-2",
				base: "w-8 h-8 border-[3px]",
				large: "w-16 h-16 border-[6px]"
			}
		}
	},
	container: {
		base: "flex justify-center items-center",
		variants: { size: {
			small: "m-6",
			base: "m-6",
			large: "m-20"
		} }
	}
};
var spinnerOverlay = {
	root: {
		base: "top-0 left-0 flex items-center justify-center w-full h-full rounded-sm flex-col z-40 bg-background/(--spinner-overlay-opacity)",
		variants: { fixed: {
			true: "fixed",
			false: "absolute"
		} }
	},
	text: "mt-4 text-muted-foreground"
};
//#endregion
//#region ../../resources/scripts/themes/classic/skins/forms.ts
var control = {
	base: [
		"resize-none appearance-none outline-hidden w-full min-w-0",
		"p-3 border-2 rounded-sm text-sm transition-[background-color,border-color,color,box-shadow] duration-150",
		"bg-input border-input-border hover:border-input-border text-foreground shadow-none focus:ring-0",
		"focus:shadow-md focus:border-primary focus:ring-2 focus:ring-ring/50",
		"disabled:opacity-75 read-only:cursor-text read-only:bg-muted/40",
		"required:shadow-none invalid:shadow-none"
	].join(" "),
	variants: {
		light: { true: "bg-background border-border text-foreground focus:border-primary disabled:bg-muted disabled:border-border" },
		error: { true: "text-destructive border-destructive hover:border-destructive focus:border-destructive focus:ring-destructive" }
	}
};
var input = { root: control };
var textArea = { root: control };
var numberInput = {
	root: "",
	input: control
};
var fileInput = { root: [
	"block w-full min-w-0 rounded-sm text-sm text-foreground",
	"file:mr-3 file:rounded-sm file:border file:border-border file:bg-popover file:px-4 file:py-2 file:text-sm file:font-medium file:text-foreground",
	"enabled:cursor-pointer enabled:file:cursor-pointer enabled:hover:file:bg-secondary",
	"focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card",
	"disabled:cursor-default disabled:opacity-50"
].join(" ") };
var select = {
	root: {
		base: [
			"relative flex items-center w-full rounded-sm border text-sm transition-colors duration-150",
			"bg-input border-input-border text-foreground hover:border-input-border data-popup-open:border-input-border",
			"focus-within:shadow-md focus-within:border-primary focus-within:ring-2 focus-within:ring-ring/50",
			"data-disabled:opacity-75 data-disabled:cursor-default"
		].join(" "),
		variants: { error: { true: "border-destructive text-destructive focus-within:border-destructive focus-within:ring-destructive" } }
	},
	input: {
		base: ["w-full min-w-0 appearance-none border-0 bg-transparent p-3 pr-10 text-sm text-foreground outline-hidden", "placeholder:text-muted-foreground focus:ring-0 focus:outline-hidden disabled:cursor-default"].join(" "),
		compoundVariants: [
			{
				multiple: true,
				selected: true,
				class: "pl-0"
			},
			{
				richLabel: true,
				class: "absolute inset-0 h-full"
			},
			{
				richLabel: true,
				searching: false,
				class: "text-transparent"
			}
		]
	},
	trigger: "absolute right-0 top-0 flex h-full w-10 items-center justify-center border-0 bg-transparent p-0 text-muted-foreground [&_svg]:h-4 [&_svg]:w-4 [&_svg]:shrink-0",
	positioner: "z-99999 min-w-(--anchor-width) outline-none",
	popup: ["bg-card border border-border rounded-sm shadow-lg py-1 text-sm text-foreground", "w-(--anchor-width) max-w-(--available-width) max-h-[min(18rem,var(--available-height))]"].join(" "),
	list: "max-h-72 overflow-y-auto overscroll-contain outline-none",
	item: "flex items-center justify-between px-3 py-2 cursor-pointer select-none outline-hidden data-highlighted:bg-popover data-highlighted:text-foreground data-selected:text-accent data-disabled:opacity-50 data-disabled:cursor-default",
	itemLabel: "min-w-0",
	indicator: "",
	empty: "px-3 py-2 text-sm text-muted-foreground empty:p-0",
	group: "",
	groupLabel: "px-3 pt-2 pb-1 text-xs uppercase text-muted-foreground empty:hidden",
	summary: "pointer-events-none whitespace-nowrap px-3 py-3 text-sm text-foreground",
	preview: {
		base: "pointer-events-none flex min-w-0 flex-1 items-center px-3 py-2 pr-10 text-sm",
		variants: { searching: { true: "invisible" } }
	}
};
var checkbox = {
	root: [
		"flex items-center justify-center shrink-0 w-4 h-4 rounded-xs cursor-pointer",
		"bg-input border border-input-border text-primary-foreground transition-colors duration-75 hover:border-primary/70",
		"data-checked:bg-primary data-checked:border-transparent",
		"data-indeterminate:bg-primary data-indeterminate:border-transparent",
		"data-disabled:opacity-60 data-disabled:cursor-default",
		"[&_svg]:size-3.5"
	].join(" "),
	indicator: ""
};
var switchSkin = {
	root: {
		base: "flex gap-4",
		variants: { described: {
			true: "items-start",
			false: "items-center"
		} }
	},
	control: [
		"group relative inline-block shrink-0 w-12 h-6 rounded-full border cursor-pointer select-none p-0",
		"bg-input border-input-border transition-colors duration-75",
		"hover:border-primary/70 active:bg-popover data-checked:bg-primary data-checked:border-primary",
		"data-disabled:opacity-60 data-disabled:cursor-default"
	].join(" "),
	thumb: [
		"block absolute top-1/2 left-0.5 size-4.5 -translate-y-1/2 rounded-full border bg-background",
		"transition-[left] duration-75 ease-in",
		"group-data-checked:left-[calc(100%_-_1.125rem_-_0.125rem)]",
		"group-data-checked:bg-primary-foreground group-data-checked:border-primary-foreground"
	].join(" "),
	text: "min-w-0 flex-1",
	label: "cursor-pointer mb-0",
	description: "input-help"
};
var label = { root: {
	base: "block text-sm font-medium uppercase text-foreground mb-1",
	variants: { light: { true: "text-muted-foreground" } }
} };
//#endregion
//#region ../../resources/scripts/themes/classic/skins/overlays.ts
var dialog = {
	backdrop: ["fixed inset-0 bg-background/50 z-40 transition-opacity duration-150 ease-out", "data-starting-style:opacity-0 data-ending-style:opacity-0 data-ending-style:ease-in"].join(" "),
	viewport: "fixed inset-0 overflow-y-auto z-50",
	container: "flex min-h-full items-center justify-center p-4 text-center",
	root: [
		"relative flex flex-col overflow-hidden bg-card rounded-sm max-w-xl w-full mx-auto shadow-lg text-left",
		"max-h-[calc(100dvh-2rem)] ring-4 ring-border/80 transition duration-150 ease-out",
		"data-starting-style:opacity-0 data-starting-style:scale-75",
		"data-ending-style:opacity-0 data-ending-style:scale-75 data-ending-style:ease-in"
	].join(" "),
	body: "flex min-h-0 flex-1 overflow-y-auto p-6 pb-0",
	content: "flex-1 min-w-0",
	header: "flex items-center",
	heading: "",
	title: {
		base: "font-header text-xl font-semibold tracking-normal text-foreground pr-4",
		variants: { described: {
			true: "mb-2",
			false: "mb-5"
		} }
	},
	description: "mb-5 text-sm leading-relaxed text-muted-foreground",
	spacer: "invisible h-6",
	footer: "px-6 py-3 bg-card flex items-center justify-end space-x-3 rounded-b-sm",
	close: "absolute right-0 top-0 m-4",
	closeButton: "group w-8 h-8 p-0 inline-flex items-center justify-center",
	closeIcon: "w-5 h-5 group-hover:rotate-90 transition-transform duration-100",
	icon: {
		base: "flex items-center justify-center w-10 h-10 rounded-full mr-4",
		variants: { type: {
			danger: "bg-destructive text-destructive-foreground",
			warning: "bg-warning text-warning-foreground",
			success: "bg-success text-success-foreground",
			info: "bg-primary text-primary-foreground"
		} }
	},
	iconGlyph: "w-6 h-6"
};
var tooltip = {
	root: "bg-popover text-sm text-popover-foreground px-3 py-2 rounded-sm pointer-events-none max-w-[24rem] z-9999",
	arrow: {
		base: "absolute bg-popover w-3 h-3",
		variants: { side: {
			top: "bottom-[-6px] left-0",
			bottom: "top-[-6px] left-0",
			right: "top-0 left-[-6px]",
			left: "top-0 right-[-6px]"
		} }
	}
};
var dropdownMenu = {
	trigger: "",
	positioner: "z-9999 outline-hidden",
	root: [
		"min-w-56 bg-popover border border-border rounded-sm shadow-xl p-1.5 text-sm text-popover-foreground",
		"outline-hidden origin-(--transform-origin) transition duration-100",
		"data-starting-style:opacity-0 data-starting-style:scale-95",
		"data-ending-style:opacity-0 data-ending-style:scale-95"
	].join(" ")
};
var dropdownMenuItem = {
	root: {
		base: ["group flex w-full gap-3 px-2.5 py-2.5 rounded-sm cursor-pointer select-none outline-hidden", "text-foreground transition-colors data-highlighted:bg-muted data-highlighted:text-foreground"].join(" "),
		variants: {
			described: {
				true: "items-start",
				false: "items-center"
			},
			danger: { true: "text-destructive data-highlighted:bg-destructive/10 data-highlighted:text-destructive" },
			checked: { true: "bg-muted" }
		}
	},
	icon: {
		base: ["flex h-7 w-7 shrink-0 items-center justify-center rounded-sm border border-border bg-muted text-muted-foreground transition-colors", "group-data-highlighted:border-border group-data-highlighted:bg-background group-data-highlighted:text-foreground"].join(" "),
		variants: {
			described: { true: "mt-0.5" },
			danger: { true: "border-destructive/30 bg-destructive/10 text-destructive group-data-highlighted:border-destructive/40 group-data-highlighted:bg-destructive/15 group-data-highlighted:text-destructive" }
		}
	},
	glyph: "h-4 w-4",
	text: "flex min-w-0 flex-1 flex-col",
	label: "truncate text-sm font-medium leading-5",
	description: {
		base: "mt-0.5 text-xs leading-4 text-muted-foreground group-data-highlighted:text-muted-foreground",
		variants: { danger: { true: "group-data-highlighted:text-destructive/80" } }
	}
};
//#endregion
//#region ../../resources/scripts/themes/classic/skins/surfaces.ts
var card = {
	root: {
		base: "bg-card rounded-sm",
		variants: {
			titled: {
				true: "shadow-md",
				false: "p-4 shadow-lg relative"
			},
			loading: { true: "relative" }
		}
	},
	header: {
		base: "bg-muted rounded-t-sm p-3 border-b border-border",
		variants: { actions: { true: "flex items-center justify-between gap-3" } }
	},
	title: "font-header text-sm font-semibold uppercase tracking-wide text-foreground",
	icon: "mr-2 text-muted-foreground",
	actions: "flex shrink-0 items-center gap-2",
	body: "p-3"
};
var statusFills = {
	neutral: "bg-popover",
	success: "bg-success",
	warning: "bg-warning",
	danger: "bg-destructive",
	info: "bg-primary",
	accent: "bg-accent"
};
//#endregion
//#region ../../resources/scripts/themes/classic/skins/index.ts
/** The panel's own look: a recipe for every part of every primitive. */
var classicSkins = {
	Alert: alert,
	Avatar: avatar,
	Badge: badge,
	Button: button,
	Card: card,
	ChartCard: chartCard,
	Checkbox: checkbox,
	Code: code,
	CopyOnClick: copyOnClick,
	Dialog: dialog,
	DropdownMenu: dropdownMenu,
	DropdownMenuItem: dropdownMenuItem,
	Empty: empty,
	FileInput: fileInput,
	Input: input,
	Label: label,
	ListRow: {
		root: {
			base: "group relative flex rounded-sm no-underline text-foreground items-center bg-card p-4 border border-transparent overflow-hidden",
			variants: { interactive: { true: "transition-[background-color,border-color,color,box-shadow] duration-150 hover:bg-popover hover:border-border active:bg-popover/80" } }
		},
		icon: "flex w-16 items-center justify-center rounded-full bg-popover p-3",
		title: "text-lg wrap-break-word",
		description: "text-sm text-muted-foreground wrap-break-word line-clamp-2",
		status: ({ status }) => `absolute right-0 z-20 m-1 h-[calc(100%-0.5rem)] w-2 rounded-full opacity-50 transition-opacity duration-150 group-hover:opacity-75 ${statusFills[status ?? "neutral"]}`
	},
	NewButton: newButton,
	NumberInput: numberInput,
	PageFooter: {
		root: "page-width mb-4",
		text: "text-center text-muted-foreground text-xs",
		link: "no-underline text-muted-foreground hover:text-muted-foreground"
	},
	PageHeading: {
		root: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
		text: "min-w-0",
		title: "font-header text-2xl font-semibold tracking-normal text-foreground",
		description: "mt-1 text-sm leading-relaxed text-foreground/70",
		actions: "shrink-0"
	},
	Pagination: pagination,
	ProgressBar: progressBar,
	Select: select,
	Spinner: spinner$1,
	SpinnerOverlay: spinnerOverlay,
	Stat: stat,
	Switch: switchSkin,
	Table: table,
	TextArea: textArea,
	Tooltip: tooltip
};
//#endregion
//#region ../../resources/scripts/themes/classic/views/layout/AuthLayout.tsx
function AuthLayout({ className, children }) {
	return /* @__PURE__ */ jsx("div", {
		className: cn("pt-8 xl:pt-32", className),
		children: /* @__PURE__ */ jsx(Main, { children })
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/index.ts
var dashboard$1 = () => import("./dashboard-DXkW3jG9.js");
var auth = () => import("./auth-9xHKkPRQ.js");
var account = () => import("./account-DcIvOGRi.js");
var activity$1 = () => import("./activity-DDM3t9YW.js");
var schedules$1 = () => import("./schedules-CWm1vecO.js");
var users$1 = () => import("./users-VfeZ2U72.js");
var backups$1 = () => import("./backups-JK3sUyWI.js");
var settings$1 = () => import("./settings-DCaxLonH.js");
var serverConsole$1 = () => import("./console-DpsnQWxi.js");
var files$1 = () => import("./files-CIybYHkH.js");
var databases$1 = () => import("./databases-BN8lEQiZ.js");
var network$1 = () => import("./network-qWmVJwsb.js");
var startup$1 = () => import("./startup-BF-8IIzw.js");
//#endregion
//#region ../../resources/scripts/themes/classic/index.ts
/** The stock panel UI, built only on the public theme API. */
var classic_default = defineTheme({
	ui: classicSkins,
	views: {
		"layout.auth": AuthLayout,
		"layout.app": lazyView(() => import("./AppLayout-i6-BOrJ8.js")),
		"layout.account": lazyView(() => import("./AccountLayout-CaYY0LnS.js")),
		"layout.server": lazyView(() => import("./ServerLayout-_DtaKFcO.js")),
		"layout.admin": lazyView(() => import("./AdminLayout-63BBk-ok.js")),
		"app.search": lazyView(() => import("./Search-DUT5_8F8.js")),
		"page.dashboard": lazyView(dashboard$1, "Dashboard"),
		"dashboard.serverList": lazyView(dashboard$1, "ServerList"),
		"dashboard.serverCard": lazyView(dashboard$1, "ServerCard"),
		"dashboard.serverCard.identity": lazyView(dashboard$1, "ServerCardIdentity"),
		"dashboard.serverCard.address": lazyView(dashboard$1, "ServerCardAddress"),
		"dashboard.serverCard.metrics": lazyView(dashboard$1, "ServerCardMetrics"),
		"page.auth.login": lazyView(auth, "LoginPage"),
		"page.auth.checkpoint": lazyView(auth, "CheckpointPage"),
		"page.auth.password": lazyView(auth, "ForgotPasswordPage"),
		"page.auth.passwordReset": lazyView(auth, "ResetPasswordPage"),
		"page.account.overview": lazyView(account, "AccountOverview"),
		"account.password": lazyView(account, "PasswordCard"),
		"account.email": lazyView(account, "EmailCard"),
		"account.twoFactor": lazyView(account, "TwoFactorCard"),
		"page.account.api": lazyView(account, "ApiKeysPage"),
		"account.apiKeys.list": lazyView(account, "ApiKeyList"),
		"account.apiKeys.create": lazyView(account, "ApiKeyCreate"),
		"page.account.ssh": lazyView(account, "SshKeysPage"),
		"account.sshKeys.list": lazyView(account, "SshKeyList"),
		"account.sshKeys.create": lazyView(account, "SshKeyCreate"),
		"activity.log": lazyView(activity$1, "ActivityLog"),
		"page.account.activity": lazyView(activity$1, "AccountActivityPage"),
		"page.server.activity": lazyView(activity$1, "ServerActivityPage"),
		"server.conflict": lazyView(() => import("./ServerConflict-lz82f-Z2.js")),
		"page.server.schedules": lazyView(schedules$1, "SchedulesPage"),
		"server.schedules": lazyView(schedules$1, "ScheduleList"),
		"page.server.schedules.detail": lazyView(schedules$1, "ScheduleDetailPage"),
		"server.schedule": lazyView(schedules$1, "ScheduleDetails"),
		"server.schedule.tasks": lazyView(schedules$1, "ScheduleTasks"),
		"page.server.users": lazyView(users$1, "UsersPage"),
		"server.subusers": lazyView(users$1, "SubuserList"),
		"page.server.users.create": lazyView(users$1, "CreateSubuserPage"),
		"server.subuserForm": lazyView(users$1, "SubuserForm"),
		"page.server.backups": lazyView(backups$1, "BackupsPage"),
		"server.backups": lazyView(backups$1, "BackupList"),
		"page.server.settings": lazyView(settings$1, "SettingsPage"),
		"server.sftp": lazyView(settings$1, "ServerSftp"),
		"server.debug": lazyView(settings$1, "ServerDebug"),
		"server.rename": lazyView(settings$1, "ServerRename"),
		"server.reinstall": lazyView(settings$1, "ServerReinstall"),
		"page.server.console": lazyView(serverConsole$1, "ConsolePage"),
		"server.terminal": lazyView(serverConsole$1, "Terminal"),
		"server.power": lazyView(serverConsole$1, "Power"),
		"server.stats": lazyView(serverConsole$1, "Stats"),
		"server.graphs": lazyView(serverConsole$1, "Graphs"),
		"server.feature.eula": lazyView(serverConsole$1, "EulaPrompt"),
		"server.feature.javaVersion": lazyView(serverConsole$1, "JavaVersionPrompt"),
		"server.feature.gslToken": lazyView(serverConsole$1, "GslTokenPrompt"),
		"server.feature.pidLimit": lazyView(serverConsole$1, "PidLimitPrompt"),
		"server.feature.steamDiskSpace": lazyView(serverConsole$1, "SteamDiskSpacePrompt"),
		"server.feature.hytaleOauth": lazyView(serverConsole$1, "HytaleOauthPrompt"),
		"page.server.files": lazyView(files$1, "FilesPage"),
		"server.files.manager": lazyView(files$1, "FileManager"),
		"server.files.manager.toolbar": lazyView(files$1, "FileManagerToolbar"),
		"server.files.manager.list": lazyView(files$1, "FileManagerList"),
		"server.files.manager.selection": lazyView(files$1, "FileManagerSelection"),
		"server.files.details": lazyView(files$1, "FileDetails"),
		"page.server.files.editor": lazyView(files$1, "EditorPage"),
		"server.files.editor": lazyView(files$1, "FileEditor"),
		"server.files.editor.notice": lazyView(files$1, "FileEditorNotice"),
		"server.files.editor.canvas": lazyView(files$1, "FileEditorCanvas"),
		"server.files.editor.language": lazyView(files$1, "FileEditorLanguage"),
		"server.files.editor.actions": lazyView(files$1, "FileEditorActions"),
		"page.server.databases": lazyView(databases$1, "DatabasesPage"),
		"server.databases": lazyView(databases$1, "Databases"),
		"page.server.network": lazyView(network$1, "NetworkPage"),
		"server.allocations": lazyView(network$1, "Allocations"),
		"page.server.startup": lazyView(startup$1, "StartupPage"),
		"server.startup.command": lazyView(startup$1, "StartupCommand"),
		"server.startup.image": lazyView(startup$1, "StartupImage"),
		"server.startup.variables": lazyView(startup$1, "StartupVariables")
	}
});
//#endregion
//#region ../../resources/scripts/views/classic.ts
/** Classic needs no load: its own views are lazy, so registering it is synchronous. */
function registerClassicTheme() {
	registerViewLayer("classic", "classic", classic_default.views ?? {});
	registerSkins("classic", classic_default.ui ?? {});
}
//#endregion
//#region ../../resources/scripts/views/pages.ts
/** Routed pages that are views, defined beside their blocks. Admin pages are plain components. */
var VIEW_PAGES = {
	"page.dashboard": { context: "app" },
	"page.auth.login": {
		context: "auth",
		slots: ["auth.login.before", "auth.login.after"]
	},
	"page.auth.checkpoint": {
		context: "auth",
		slots: ["auth.checkpoint.before", "auth.checkpoint.after"]
	},
	"page.auth.password": {
		context: "auth",
		slots: ["auth.password.before", "auth.password.after"]
	},
	"page.auth.passwordReset": {
		context: "auth",
		slots: ["auth.passwordReset.before", "auth.passwordReset.after"]
	},
	"page.account.overview": { context: "account" },
	"page.account.api": {
		context: "account",
		slots: ["account.api.before", "account.api.after"]
	},
	"page.account.ssh": {
		context: "account",
		slots: ["account.ssh.before", "account.ssh.after"]
	},
	"page.account.activity": {
		context: "account",
		slots: ["account.activity.before", "account.activity.after"]
	},
	"page.server.console": { context: "server" },
	"page.server.files": { context: "server" },
	"page.server.files.editor": {
		context: "server",
		slots: ["server.files.editor.before", "server.files.editor.after"]
	},
	"page.server.databases": {
		context: "server",
		slots: ["server.databases.before", "server.databases.after"]
	},
	"page.server.network": {
		context: "server",
		slots: ["server.network.before", "server.network.after"]
	},
	"page.server.startup": {
		context: "server",
		slots: ["server.startup.before", "server.startup.after"]
	},
	"page.server.activity": {
		context: "server",
		slots: ["server.activity.before", "server.activity.after"]
	},
	"page.server.schedules": {
		context: "server",
		slots: ["server.schedules.before", "server.schedules.after"]
	},
	"page.server.schedules.detail": {
		context: "server",
		slots: ["server.schedules.detail.before", "server.schedules.detail.after"]
	},
	"page.server.users": {
		context: "server",
		slots: ["server.users.before", "server.users.after"]
	},
	"page.server.users.create": {
		context: "server",
		slots: ["server.users.create.before", "server.users.create.after"]
	},
	"page.server.backups": {
		context: "server",
		slots: ["server.backups.before", "server.backups.after"]
	},
	"page.server.settings": {
		context: "server",
		slots: ["server.settings.before", "server.settings.after"]
	}
};
var placeholder = createElement(Spinner, { centered: true });
/** What a page's definition shares with the others: its context, slots and placeholder. */
var viewPage = (name) => ({
	...VIEW_PAGES[name],
	placeholder
});
//#endregion
//#region ../../resources/scripts/views/definitions.ts
var layouts = { load: () => import("./layouts-k4uzHeoT.js") };
var search = { load: () => import("./search-C-guwVJU.js") };
var dashboard = { load: () => import("./dashboard-BTQW7vew.js") };
var login = { load: () => import("./login-BiVuGDpr.js") };
var password = { load: () => import("./password-BQ3tshXK.js") };
var overview = { load: () => import("./overview-Dk27040z.js") };
var keys = { load: () => import("./keys-Dll_-Z4N.js") };
var activity = { load: () => import("./activity-Da0zO2jw.js") };
var backups = { load: () => import("./backups-CR1ATYiq.js") };
var conflict = { load: () => import("./conflict-CGAOLd_H.js") };
var serverConsole = { load: () => import("./console-Dx_jfqze.js") };
var databases = { load: () => import("./databases-DYCEutSf.js") };
var features = { load: () => import("./features-lBvIx8eJ.js") };
var files = { load: () => import("./files-CIWenDME.js") };
var network = { load: () => import("./network-CTUq3M5u.js") };
var schedules = { load: () => import("./schedules-B_dBY0Ia.js") };
var settings = { load: () => import("./settings-BStGoXjE.js") };
var startup = { load: () => import("./startup-BWv_xQnz.js") };
var users = { load: () => import("./users-XwD0Y2Hk.js") };
var spinner = createElement(Spinner, {
	size: "large",
	centered: true
});
defineView("layout.auth", {
	context: "auth",
	...layouts
});
defineView("layout.app", {
	context: "app",
	slots: ["nav.items.before", "nav.items.after"],
	...layouts
});
defineView("layout.account", {
	context: "account",
	slots: ["account.navigation.before", "account.navigation.after"],
	...layouts
});
defineView("layout.server", {
	context: "server",
	slots: ["server.navigation.before", "server.navigation.after"],
	...layouts
});
defineView("layout.admin", {
	context: "admin",
	slots: ["panel.navigation.before", "panel.navigation.after"],
	...layouts
});
defineView("app.search", {
	context: "app",
	...search
});
defineView("page.dashboard", {
	context: "app",
	...dashboard
});
defineView("dashboard.serverList", {
	context: "app",
	slots: [
		"dashboard.before",
		"dashboard.after",
		"dashboard.serverRow.before",
		"dashboard.serverRow.metrics.after",
		"dashboard.serverRow.after"
	],
	...dashboard
});
defineView("dashboard.serverCard", {
	context: "app",
	placeholder: createElement("div", {
		className: "h-12 animate-pulse rounded-sm bg-muted",
		"aria-label": "Loading server card"
	}),
	...dashboard
});
defineView("dashboard.serverCard.identity", {
	context: "app",
	slots: ["dashboard.serverRow.name.after"],
	...dashboard
});
defineView("dashboard.serverCard.address", {
	context: "app",
	...dashboard
});
defineView("dashboard.serverCard.metrics", {
	context: "app",
	...dashboard
});
defineView("page.auth.login", {
	...VIEW_PAGES["page.auth.login"],
	slots: [
		"auth.login.before",
		"auth.login.after",
		"auth.login.form.after"
	],
	...login
});
defineView("page.auth.checkpoint", {
	...VIEW_PAGES["page.auth.checkpoint"],
	...login
});
defineView("page.auth.password", {
	...VIEW_PAGES["page.auth.password"],
	...password
});
defineView("page.auth.passwordReset", {
	...VIEW_PAGES["page.auth.passwordReset"],
	...password
});
defineView("page.account.overview", {
	...VIEW_PAGES["page.account.overview"],
	slots: ["account.overview.before", "account.overview.after"],
	...overview
});
defineView("account.password", {
	context: "account",
	...overview
});
defineView("account.email", {
	context: "account",
	...overview
});
defineView("account.twoFactor", {
	context: "account",
	...overview
});
defineView("page.account.api", {
	...VIEW_PAGES["page.account.api"],
	...keys
});
defineView("page.account.ssh", {
	...VIEW_PAGES["page.account.ssh"],
	...keys
});
defineView("account.apiKeys.list", {
	context: "account",
	...keys
});
defineView("account.apiKeys.create", {
	context: "account",
	...keys
});
defineView("account.sshKeys.list", {
	context: "account",
	...keys
});
defineView("account.sshKeys.create", {
	context: "account",
	...keys
});
defineView("activity.log", {
	context: "app",
	...activity
});
defineView("page.account.activity", {
	...VIEW_PAGES["page.account.activity"],
	...activity
});
defineView("page.server.activity", {
	...VIEW_PAGES["page.server.activity"],
	...activity
});
defineView("server.conflict", {
	context: "server",
	...conflict
});
defineView("page.server.console", {
	...viewPage("page.server.console"),
	slots: ["server.console.before", "server.console.after"],
	...serverConsole
});
defineView("server.terminal", {
	context: "server",
	...serverConsole
});
defineView("server.power", {
	context: "server",
	slots: ["server.console.power.before", "server.console.power.after"],
	...serverConsole
});
defineView("server.stats", {
	context: "server",
	...serverConsole
});
defineView("server.graphs", {
	context: "server",
	...serverConsole
});
defineView("server.feature.eula", {
	context: "server",
	...features
});
defineView("server.feature.javaVersion", {
	context: "server",
	...features
});
defineView("server.feature.gslToken", {
	context: "server",
	...features
});
defineView("server.feature.pidLimit", {
	context: "server",
	...features
});
defineView("server.feature.steamDiskSpace", {
	context: "server",
	...features
});
defineView("server.feature.hytaleOauth", {
	context: "server",
	...features
});
defineView("page.server.files", {
	...viewPage("page.server.files"),
	slots: ["server.files.before", "server.files.after"],
	...files
});
defineView("server.files.manager", {
	context: "server",
	placeholder: spinner,
	...files
});
defineView("server.files.manager.toolbar", {
	context: "server",
	slots: ["server.files.toolbar"],
	...files
});
defineView("server.files.manager.list", {
	context: "server",
	slots: ["server.files.rowActions"],
	...files
});
defineView("server.files.manager.selection", {
	context: "server",
	slots: ["server.files.selectionActions"],
	...files
});
defineView("server.files.details", {
	context: "server",
	placeholder: createElement("div", {
		className: "h-5 w-full animate-pulse rounded-sm bg-muted",
		"aria-label": "Loading file details"
	}),
	...files
});
defineView("page.server.files.editor", {
	...viewPage("page.server.files.editor"),
	...files
});
defineView("server.files.editor", {
	context: "server",
	placeholder: spinner,
	...files
});
defineView("server.files.editor.notice", {
	context: "server",
	...files
});
defineView("server.files.editor.canvas", {
	context: "server",
	...files
});
defineView("server.files.editor.language", {
	context: "server",
	...files
});
defineView("server.files.editor.actions", {
	context: "server",
	...files
});
defineView("page.server.databases", {
	...viewPage("page.server.databases"),
	...databases
});
defineView("server.databases", {
	context: "server",
	...databases
});
defineView("page.server.schedules", {
	...viewPage("page.server.schedules"),
	...schedules
});
defineView("server.schedules", {
	context: "server",
	...schedules
});
defineView("page.server.schedules.detail", {
	...viewPage("page.server.schedules.detail"),
	...schedules
});
defineView("server.schedule", {
	context: "server",
	...schedules
});
defineView("server.schedule.tasks", {
	context: "server",
	...schedules
});
defineView("page.server.users", {
	...viewPage("page.server.users"),
	...users
});
defineView("server.subusers", {
	context: "server",
	...users
});
defineView("page.server.users.create", {
	...viewPage("page.server.users.create"),
	...users
});
defineView("server.subuserForm", {
	context: "server",
	slots: ["server.users.permissions.before"],
	...users
});
defineView("page.server.backups", {
	...viewPage("page.server.backups"),
	...backups
});
defineView("server.backups", {
	context: "server",
	...backups
});
defineView("page.server.network", {
	...viewPage("page.server.network"),
	...network
});
defineView("server.allocations", {
	context: "server",
	...network
});
defineView("page.server.startup", {
	...viewPage("page.server.startup"),
	slots: [
		"server.startup.before",
		"server.startup.after",
		"server.startup.form"
	],
	...startup
});
defineView("server.startup.command", {
	context: "server",
	...startup
});
defineView("server.startup.image", {
	context: "server",
	...startup
});
defineView("server.startup.variables", {
	context: "server",
	...startup
});
defineView("page.server.settings", {
	...viewPage("page.server.settings"),
	...settings
});
defineView("server.sftp", {
	context: "server",
	...settings
});
defineView("server.debug", {
	context: "server",
	...settings
});
defineView("server.rename", {
	context: "server",
	...settings
});
defineView("server.reinstall", {
	context: "server",
	...settings
});
//#endregion
//#region ../../resources/scripts/views/catalog.ts
/** Loads every area's module, so each view comes with its hook and fixtures. */
async function loadViewCatalog() {
	await Promise.all(getViewDefinitions().map(({ name }) => loadViewImplementation(name)));
	return getViewDefinitions();
}
//#endregion
//#region ../../resources/scripts/components/server/console/stats.ts
var isNetworkStats = (value) => isObject(value) && "rx_bytes" in value && isFiniteNumber(value.rx_bytes) && "tx_bytes" in value && isFiniteNumber(value.tx_bytes);
var hasValidUptime = (value) => !("uptime" in value) || value.uptime === void 0 || isFiniteNumber(value.uptime);
var isServerStatsPayload = (value) => {
	if (!isObject(value) || !("network" in value) || !isNetworkStats(value.network)) return false;
	return "cpu_absolute" in value && isFiniteNumber(value.cpu_absolute) && "memory_bytes" in value && isFiniteNumber(value.memory_bytes) && "disk_bytes" in value && isFiniteNumber(value.disk_bytes) && hasValidUptime(value);
};
var parseServerStatsPayload = (data) => {
	try {
		const parsed = JSON.parse(data);
		return isServerStatsPayload(parsed) ? parsed : null;
	} catch {
		return null;
	}
};
//#endregion
//#region ../../resources/scripts/components/server/StatsListener.tsx
/** Records the server's resource usage once for the whole server area, however many views show it. */
function StatsListener() {
	const connected = useSocketConnected();
	const instance = useSocketInstance();
	const status = useServerStatus();
	const push = useServerStore((state) => state.stats.push);
	const clearGraphs = useServerStore((state) => state.stats.clearGraphs);
	useEffect(() => {
		if (connected && instance) instance.send(SocketRequest.SEND_STATS);
	}, [instance, connected]);
	useEffect(() => {
		if (status === "offline") clearGraphs();
	}, [clearGraphs, status]);
	useWebsocketEvent(SocketEvent.STATS, (data) => {
		const stats = parseServerStatsPayload(data);
		if (stats) push(stats, performance.now());
	});
	return null;
}
//#endregion
//#region ../../resources/scripts/state/server/context.ts
var ServerContext = { Provider };
//#endregion
//#region ../../resources/scripts/plugins/Websocket.ts
var NORMAL_CLOSE_CODES = new Set([
	1e3,
	1001,
	1003
]);
var SUSPENDED_CLOSE_CODES = new Set([4400, 4409]);
var SOCKET_OPEN_STATE = 1;
var AUTH_SUCCESS_EVENT = "auth success";
var RECONNECT_BASE_DELAY_MS = 1e3;
var RECONNECT_MAX_DELAY_MS = 3e4;
/** Exponential backoff for a 1-based attempt, jittered within the upper half of the window. */
var reconnectDelay = (attempt, random = Math.random) => {
	const ceiling = Math.min(RECONNECT_MAX_DELAY_MS, RECONNECT_BASE_DELAY_MS * 2 ** Math.max(0, attempt - 1));
	return Math.round(ceiling / 2 + random() * (ceiling / 2));
};
var isOffline = () => !navigator.onLine;
var EventEmitter = class {
	listenersByEvent = /* @__PURE__ */ new Map();
	on(event, listener) {
		let listeners = this.listenersByEvent.get(event);
		if (!listeners) {
			listeners = /* @__PURE__ */ new Set();
			this.listenersByEvent.set(event, listeners);
		}
		listeners.add(listener);
		return this;
	}
	addListener(event, listener) {
		let listeners = this.listenersByEvent.get(event);
		if (!listeners) {
			listeners = /* @__PURE__ */ new Set();
			this.listenersByEvent.set(event, listeners);
		}
		listeners.add(listener);
		return this;
	}
	removeListener(event, listener) {
		this.listenersByEvent.get(event)?.delete(listener);
		return this;
	}
	removeAllListeners(event) {
		if (event === void 0) this.listenersByEvent.clear();
		else this.listenersByEvent.delete(event);
		return this;
	}
	emit(event, ...args) {
		const listeners = this.listenersByEvent.get(event);
		if (!listeners || listeners.size === 0) return false;
		for (const listener of [...listeners]) try {
			listener(...args);
		} catch (error) {
			console.error(`Websocket listener failed for "${event}".`, error);
		}
		return true;
	}
};
var Websocket = class Websocket extends EventEmitter {
	static createSocket = (url) => new WebSocket(url);
	socket = null;
	url = null;
	token = "";
	reconnectAttempts = 0;
	reconnectTimer = null;
	awaitingResume = false;
	connect(url) {
		this.disposeSocket();
		this.url = url;
		this.reconnectAttempts = 0;
		this.clearReconnectTimer();
		this.stopAwaitingResume();
		this.openSocket();
		return this;
	}
	setToken(token, isUpdate = false) {
		this.token = token;
		if (isUpdate) this.authenticate();
		return this;
	}
	authenticate() {
		if (this.url && this.token) this.send("auth", this.token);
	}
	close(code, reason) {
		this.url = null;
		this.token = "";
		this.clearReconnectTimer();
		this.stopAwaitingResume();
		this.disposeSocket(code, reason);
	}
	send(event, payload) {
		if (!this.socket || this.socket.readyState !== SOCKET_OPEN_STATE) return false;
		this.socket.send(JSON.stringify({
			event,
			args: Array.isArray(payload) ? payload : [payload]
		}));
		return true;
	}
	openSocket() {
		if (!this.url) return;
		const socket = Websocket.createSocket(this.url);
		this.socket = socket;
		socket.onmessage = (e) => {
			let message;
			try {
				message = JSON.parse(e.data);
			} catch (ex) {
				console.warn("Failed to parse incoming websocket message.", ex);
				return;
			}
			if (message.event === AUTH_SUCCESS_EVENT) this.reconnectAttempts = 0;
			if (message.args) this.emit(message.event, ...message.args);
			else this.emit(message.event);
		};
		socket.onopen = () => {
			this.emit("SOCKET_OPEN");
			this.authenticate();
		};
		socket.onerror = (error) => this.emit("SOCKET_ERROR", error);
		socket.onclose = (event) => {
			this.socket = null;
			this.emit("SOCKET_CLOSE");
			if (!this.url) return;
			if (SUSPENDED_CLOSE_CODES.has(event.code)) {
				this.close(1e3);
				return;
			}
			if (!NORMAL_CLOSE_CODES.has(event.code)) this.scheduleReconnect();
		};
	}
	disposeSocket(code, reason) {
		const socket = this.socket;
		this.socket = null;
		if (socket) {
			socket.onopen = null;
			socket.onmessage = null;
			socket.onerror = null;
			socket.onclose = null;
			socket.close(code, reason);
		}
	}
	scheduleReconnect() {
		if (!this.url || this.reconnectTimer || this.awaitingResume) return;
		if (isOffline()) {
			this.emit("SOCKET_RECONNECT");
			this.awaitResume();
			return;
		}
		if (this.reconnectAttempts >= 10) {
			this.emit("SOCKET_CONNECT_ERROR");
			this.awaitResume();
			return;
		}
		this.reconnectAttempts += 1;
		this.emit("SOCKET_RECONNECT");
		this.reconnectTimer = setTimeout(() => {
			this.reconnectTimer = null;
			this.openSocket();
		}, reconnectDelay(this.reconnectAttempts));
	}
	clearReconnectTimer() {
		if (this.reconnectTimer) {
			clearTimeout(this.reconnectTimer);
			this.reconnectTimer = null;
		}
	}
	awaitResume() {
		if (this.awaitingResume) return;
		this.awaitingResume = true;
		window.addEventListener("online", this.resume);
		document.addEventListener("visibilitychange", this.resume);
	}
	stopAwaitingResume() {
		if (!this.awaitingResume) return;
		this.awaitingResume = false;
		window.removeEventListener("online", this.resume);
		document.removeEventListener("visibilitychange", this.resume);
	}
	resume = () => {
		if (isOffline() || document.visibilityState === "hidden") return;
		this.stopAwaitingResume();
		if (!this.url || this.socket) return;
		this.reconnectAttempts = 0;
		this.emit("SOCKET_RECONNECT");
		this.openSocket();
	};
};
//#endregion
//#region ../../resources/scripts/sdk/testing.tsx
var causeMessage = (cause) => cause instanceof Error ? cause.message : String(cause);
/** A theme or extension layer of a view that failed, which the strict test renderers throw. */
var ViewLayerError = class extends Error {
	view;
	layer;
	constructor(view, layer, cause) {
		super(`The "${layer}" layer of view "${view}" failed: ${causeMessage(cause)}`, { cause });
		this.view = view;
		this.layer = layer;
		this.name = "ViewLayerError";
	}
};
registerClassicTheme();
await Promise.all([
	loadViewCatalog(),
	...Object.keys(classic_default.views ?? {}).map(preloadView),
	loadCodemirrorEditor()
]);
/** Create one host per test; call dispose after unmounting its Wrapper. */
function createExtensionTestHost(options = {}) {
	registerClassPrefixes([options.prefix]);
	queryClient.clear();
	queryClient.setQueryData(currentUserQueryKey, options.user ?? {
		uuid: "test-user",
		username: "Alex",
		email: "alex@example.test",
		language: "en",
		rootAdmin: false,
		useTotp: false,
		createdAt: /* @__PURE__ */ new Date(0),
		updatedAt: /* @__PURE__ */ new Date(0)
	});
	queryClient.setQueryData(siteSettingsQueryKey, options.siteSettings ?? {
		name: "Test panel",
		locale: "en",
		recaptcha: {
			enabled: false,
			siteKey: ""
		}
	});
	if (options.server) queryClient.setQueryData(serverQueryOptions(options.server.attributes.identifier).queryKey, options.server);
	const socket = new Websocket();
	let updateConnected = () => {
		throw new Error("Mount the test host before changing its connection state.");
	};
	function SocketFixture() {
		const setInstance = useServerStore((state) => state.socket.setInstance);
		const setConnected = useServerStore((state) => state.socket.setConnectionState);
		useLayoutEffect(() => {
			updateConnected = setConnected;
			setInstance(socket);
			setConnected(true);
			return () => {
				setConnected(false);
				setInstance(null);
				socket.removeAllListeners();
			};
		}, [setInstance, setConnected]);
		return null;
	}
	const Content = createContext(null);
	function RenderContent() {
		return useContext(Content);
	}
	const extensionId = options.extensionId ?? "test-extension";
	function Root() {
		const content = /* @__PURE__ */ jsx(ExtensionMount, {
			extensionId,
			context: "test host",
			resetKey: "test",
			children: /* @__PURE__ */ jsx(ExtensionResourceProvider.Provider, {
				value: options.resource ?? null,
				children: /* @__PURE__ */ jsx(Outlet, {})
			})
		});
		return options.server ? /* @__PURE__ */ jsxs(ServerContext.Provider, { children: [
			/* @__PURE__ */ jsx(SocketFixture, {}),
			/* @__PURE__ */ jsx(StatsListener, {}),
			content
		] }) : content;
	}
	const root = createRootRoute({ component: Root });
	const authenticated = createRoute({
		getParentRoute: () => root,
		id: "authenticated",
		component: Outlet
	});
	const routes = Object.values(SCREEN_ROOTS).map((path) => {
		const parent = createRoute({
			getParentRoute: () => authenticated,
			path,
			component: Outlet
		});
		return parent.addChildren([createRoute({
			getParentRoute: () => parent,
			path: "/",
			component: RenderContent
		}), createRoute({
			getParentRoute: () => parent,
			path: "$",
			component: RenderContent
		})]);
	});
	const router = createRouter({
		routeTree: root.addChildren([authenticated.addChildren(routes), createRoute({
			getParentRoute: () => root,
			path: "$",
			component: RenderContent
		})]),
		history: createMemoryHistory({ initialEntries: [options.path ?? (options.server ? `/server/${options.server.attributes.identifier}` : "/account")] })
	});
	function Wrapper({ children }) {
		return /* @__PURE__ */ jsx(QueryClientProvider, {
			client: queryClient,
			children: /* @__PURE__ */ jsx(Content.Provider, {
				value: children,
				children: /* @__PURE__ */ jsx(RouterProvider, { router })
			})
		});
	}
	return {
		Wrapper,
		queryClient,
		navigate: async (destination) => {
			const { pathname, ...navigation } = resolvePanelDestination(destination);
			await router.navigate({
				to: pathname,
				...navigation,
				search: navigation.search
			});
		},
		location: () => {
			const { pathname, search, state } = router.state.location;
			return {
				pathname,
				search: { ...search },
				state: { ...state }
			};
		},
		emitWebsocket: (event, data) => {
			socket.emit(event, data);
		},
		setConnected: (connected) => updateConnected(connected),
		dispose: () => {
			socket.removeAllListeners();
			socket.close();
			queryClient.clear();
		}
	};
}
/** How layer failures name a theme of the chain: "theme" for the last, its parents "parent", "parent 2" and so on. */
function layerId(distance) {
	if (distance === 0) return "theme";
	return distance === 1 ? "parent" : `parent ${distance}`;
}
/** Replaces the registered theme layers with the chain's skins, views and icons, parent first. */
function registerThemes(themes) {
	clearThemeLayers();
	clearThemeSkins();
	for (const [index, theme] of themes.entries()) {
		const id = layerId(themes.length - 1 - index);
		registerSkins(id, theme.ui ?? {});
		registerViewLayer(id, "theme", theme.views ?? {});
		registerThemeIcons(theme.icons ?? {});
	}
}
/** Loads the chunks of a theme's `lazyView` views, or those of a chain of themes, which `renderView` renders synchronously. */
async function preloadTheme(theme) {
	const themes = "length" in theme ? theme : [theme];
	await Promise.all(themes.flatMap((each) => Object.values(each.views ?? {}).map((view) => view && isPendingLazyView(view) ? view.preload() : null)));
}
var viewRouter = createRouter({
	routeTree: createRootRoute(),
	history: createMemoryHistory({ initialEntries: ["/"] })
});
var rendered;
var viewContext = /^view "(.+)"$/;
/** Clears the failures recorded against view layers, so a render reads only its own. */
function clearLayerFailures() {
	for (const { extensionId, context } of getExtensionErrors()) if (viewContext.test(context)) clearExtensionError(extensionId, context);
}
/** The first failure recorded against a view layer, as a `ViewLayerError`. */
function layerFailure() {
	for (const { extensionId, context, message } of getExtensionErrors()) {
		const view = viewContext.exec(context)?.[1];
		if (view !== void 0) return new ViewLayerError(view, extensionId, new Error(message));
	}
}
/**
* Replaces whatever was rendered before with `content`, under the themes' skins, views and icons, and
* throws when it fails to render (and, unless `strict` is false, when one of its layers falls back).
*/
function mount(content, { themes = [], slots = {}, prefix, strict = true }) {
	rendered?.unmount();
	registerClassPrefixes([prefix]);
	registerThemes(themes);
	clearLayerFailures();
	const removeSlots = mountSlotComponents("test-slots", slots);
	const crashes = [];
	const container = document.body.appendChild(document.createElement("div"));
	const root = createRoot(container, { onUncaughtError: (error) => crashes.push(error) });
	const failure = () => crashes.at(0) ?? (strict ? layerFailure() : void 0);
	const current = {
		container,
		unmount: () => {
			if (rendered !== current) return;
			rendered = void 0;
			act(() => root.unmount());
			container.remove();
			removeSlots();
			const error = failure();
			if (error !== void 0) throw error;
		}
	};
	rendered = current;
	Reflect.set(globalThis, "IS_REACT_ACT_ENVIRONMENT", true);
	act(() => root.render(/* @__PURE__ */ jsx(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ jsx(RouterContextProvider, {
			router: viewRouter,
			children: content
		})
	})));
	if (failure() !== void 0) current.unmount();
	return current;
}
var AREA_LAYOUTS = new Set([
	"layout.account",
	"layout.server",
	"layout.admin"
]);
var pendingViews = (themes) => themes.flatMap((theme) => Object.entries(theme.views ?? {}).flatMap(([name, view]) => view && isPendingLazyView(view) ? [name] : []));
/**
* Renders a view synchronously from fixtures, with the layers of `themes` over classic. Each call
* replaces what was rendered before it; nested views read their fixtures too. Await
* `preloadTheme(themes)` first when the themes have lazy views. It throws when the view fails to
* render, and when a theme or extension layer throws unless `strict` is false.
*/
function renderView(name, options = {}) {
	const { themes = [] } = options;
	const pending = pendingViews(themes);
	if (pending.length) throw new Error(`The theme's views ${pending.join(", ")} are lazy and not loaded yet. Await preloadTheme(theme) before renderView, for example in beforeAll.`);
	const models = options.model === void 0 ? void 0 : { [name]: options.model };
	const content = /* @__PURE__ */ jsx(ViewFixtureProvider, {
		fixtures: options.fixture === void 0 ? void 0 : { [name]: options.fixture },
		models,
		children: /* @__PURE__ */ jsx(RenderView, {
			name,
			className: options.className,
			...Object(options.input ?? {})
		})
	});
	const strict = options.strict ?? true;
	const mountOptions = {
		slots: options.slots,
		prefix: options.prefix,
		strict
	};
	if (!strict || !themes.length) return mount(content, {
		...mountOptions,
		themes
	});
	mount(content, {
		...mountOptions,
		themes: []
	});
	const expected = mountedSlots();
	const view = mount(content, {
		...mountOptions,
		themes
	});
	const shell = themes.some((theme) => theme.views?.["layout.app"]);
	const owned = new Set([...mountedViews()].filter((viewName) => !(shell && AREA_LAYOUTS.has(viewName))).flatMap((viewName) => getViewDefinition(viewName)?.slots ?? []));
	const missing = [...expected].filter((slot) => owned.has(slot) && !mountedSlots().has(slot));
	if (missing.length) {
		view.unmount();
		throw new ViewLayerError(name, layerId(0), /* @__PURE__ */ new Error(`The themes leave out the ${missing.map((slot) => `"${slot}"`).join(", ")} slot${missing.length > 1 ? "s" : ""} that classic renders here, so extensions mounted there disappear. Render <Slot name="…" /> or <Default />.`));
	}
	return view;
}
/**
* Renders any element synchronously with the skins, views and icons of `themes` over classic's, such
* as a UI kit primitive: `renderWithTheme(<Button>Save</Button>, { themes: [theme] })`. Each call
* replaces what was rendered before it.
*/
function renderWithTheme(element, options = {}) {
	return mount(element, { themes: options.themes });
}
//#endregion
export { ViewLayerError, createExtensionTestHost, createTestFileDetails, createTestFileEditor, createTestFileManager, createTestFileManagerEntry, createTestServer, createTestServerCard, preloadTheme, renderView, renderWithTheme };

//# sourceMappingURL=testing.js.map