import { Et as clientUpdateAllocationNotesMutation, Gt as implementViews, T as clientDeleteServerAllocationMutation, bt as clientSetPrimaryAllocationMutation, et as clientListServerAllocationsOptions, h as clientCreateServerAllocationMutation, t as notifyHttpError, tt as clientListServerAllocationsQueryKey } from "./notifications-Ebj0Q0Io.js";
import { i as useCurrentServer, n as serverQueryFilters } from "./queries-D_-2KdyF.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { i as upsertListItem, n as removeListItems, t as mapListItems } from "./queryData-DzPdESJr.js";
import { n as ip } from "./formatters-BBp7wFVw.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/server/network/queries.ts
var serverAllocationsInput = (uuid) => ({ path: { server_uuid: uuid } });
var createServerAllocationInput = (uuid) => ({ path: { server_uuid: uuid } });
var updateAllocationNotesInput = (uuid, allocation, notes) => ({
	path: {
		server_uuid: uuid,
		allocation_id: allocation
	},
	body: { notes }
});
var setPrimaryAllocationInput = (uuid, allocation) => ({ path: {
	server_uuid: uuid,
	allocation_id: allocation
} });
var deleteServerAllocationInput = (uuid, allocation) => ({ path: {
	server_uuid: uuid,
	allocation_id: allocation
} });
var serverAllocationsQueryOptions = (uuid) => ({ ...clientListServerAllocationsOptions(serverAllocationsInput(uuid)) });
var useServerAllocations = (uuid) => useQuery({
	...serverAllocationsQueryOptions(uuid),
	enabled: uuid.length > 0
});
var upsertAllocation = async (queryClient, uuid, allocation) => {
	await queryClient.cancelQueries({ queryKey: clientListServerAllocationsQueryKey(serverAllocationsInput(uuid)) });
	return queryClient.setQueryData(clientListServerAllocationsQueryKey(serverAllocationsInput(uuid)), (current) => upsertListItem(current, allocation, (item) => item.attributes.id === allocation.attributes.id));
};
var removeAllocation = async (queryClient, uuid, allocationId) => {
	await queryClient.cancelQueries({ queryKey: clientListServerAllocationsQueryKey(serverAllocationsInput(uuid)) });
	return queryClient.setQueryData(clientListServerAllocationsQueryKey(serverAllocationsInput(uuid)), (current) => removeListItems(current, (allocation) => allocation.attributes.id === allocationId));
};
var useCreateServerAllocation = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateServerAllocationMutation(),
		onSuccess: async (allocation, { path }) => {
			await upsertAllocation(queryClient, path.server_uuid, allocation);
			toast.success("Allocation created", { description: `${allocation.attributes.ip}:${allocation.attributes.port} is available.` });
		},
		onError: (error) => notifyHttpError(error, "Unable to create allocation")
	});
};
var useUpdateAllocationNotes = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientUpdateAllocationNotesMutation(),
		onSuccess: (allocation, { path }) => upsertAllocation(queryClient, path.server_uuid, allocation),
		onError: (error) => notifyHttpError(error, "Unable to update allocation notes")
	});
};
var useSetPrimaryAllocation = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientSetPrimaryAllocationMutation(),
		onSuccess: async (_data, { path }) => {
			await queryClient.cancelQueries({ queryKey: clientListServerAllocationsQueryKey(serverAllocationsInput(path.server_uuid)) });
			queryClient.setQueryData(clientListServerAllocationsQueryKey(serverAllocationsInput(path.server_uuid)), (current) => mapListItems(current, (allocation) => ({
				...allocation,
				attributes: {
					...allocation.attributes,
					is_default: allocation.attributes.id === path.allocation_id
				}
			})));
			await queryClient.invalidateQueries(serverQueryFilters(path.server_uuid));
			toast.success("Primary allocation updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update primary allocation")
	});
};
var useDeleteServerAllocation = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDeleteServerAllocationMutation(),
		onSuccess: async (_data, { path }) => {
			await removeAllocation(queryClient, path.server_uuid, path.allocation_id);
			toast.success("Allocation deleted");
		},
		onError: (error) => notifyHttpError(error, "Unable to delete allocation")
	});
};
//#endregion
//#region ../../resources/scripts/views/server/network.ts
var noAllocations = [];
var allocationItem = ({ attributes }) => ({
	id: attributes.id,
	ip: attributes.ip,
	alias: attributes.ip_alias,
	address: attributes.ip_alias || ip(attributes.ip),
	port: attributes.port,
	notes: attributes.notes,
	primary: attributes.is_default
});
function useAllocationsQuery() {
	const server = useCurrentServer();
	return {
		server,
		query: useServerAllocations(server?.attributes.uuid ?? "")
	};
}
var useNetworkPageModel = () => pageStatus(useAllocationsQuery().query);
function useServerAllocationsModel() {
	const { server, query } = useAllocationsQuery();
	const uuid = server?.attributes.uuid ?? "";
	const limit = server?.attributes.feature_limits.allocations ?? 0;
	const [create, update, remove] = usePermissions([
		"allocation.create",
		"allocation.update",
		"allocation.delete"
	]);
	const { mutateAsync: createAllocation } = useCreateServerAllocation();
	const { mutateAsync: setPrimary } = useSetPrimaryAllocation();
	const { mutateAsync: setNotes } = useUpdateAllocationNotes();
	const { mutateAsync: deleteAllocation } = useDeleteServerAllocation();
	const listed = query.data?.data ?? noAllocations;
	const loading = query.data === void 0;
	return useMemo(() => {
		const allocations = listed.map(allocationItem);
		const canManage = create && limit > 0;
		return {
			allocations,
			loading,
			limit,
			permissions: {
				create,
				update,
				delete: remove
			},
			canManage,
			canCreate: canManage && limit > allocations.length,
			actions: {
				create: async () => {
					await createAllocation(createServerAllocationInput(uuid));
				},
				setPrimary: async (id) => {
					await setPrimary(setPrimaryAllocationInput(uuid, id));
				},
				setNotes: async (id, notes) => {
					await setNotes(updateAllocationNotesInput(uuid, id, notes));
				},
				remove: async (id) => {
					await deleteAllocation(deleteServerAllocationInput(uuid, id));
				}
			}
		};
	}, [
		listed,
		loading,
		limit,
		create,
		update,
		remove,
		createAllocation,
		setPrimary,
		setNotes,
		deleteAllocation,
		uuid
	]);
}
var resolved = async () => {};
var allocation = (id, port, options = {}) => ({
	id,
	ip: "203.0.113.10",
	alias: null,
	address: "203.0.113.10",
	port,
	notes: null,
	primary: false,
	...options
});
var allocationsFixture = (options = {}) => ({
	allocations: [
		allocation(1, 25565, {
			primary: true,
			notes: "Game port"
		}),
		allocation(2, 25575, { notes: "RCON" }),
		allocation(3, 8123, {
			alias: "play.example.com",
			address: "play.example.com"
		})
	],
	loading: false,
	limit: 5,
	permissions: {
		create: true,
		update: true,
		delete: true
	},
	canManage: true,
	canCreate: true,
	actions: {
		create: resolved,
		setPrimary: resolved,
		setNotes: resolved,
		remove: resolved
	},
	...options
});
implementViews({
	"page.server.network": {
		use: useNetworkPageModel,
		fixtures: pageStatusFixtures
	},
	"server.allocations": {
		use: useServerAllocationsModel,
		fixtures: {
			allocations: () => allocationsFixture(),
			full: () => allocationsFixture({
				limit: 3,
				canCreate: false
			}),
			unmanaged: () => allocationsFixture({
				limit: 0,
				canManage: false,
				canCreate: false
			}),
			readOnly: () => allocationsFixture({
				permissions: {
					create: false,
					update: false,
					delete: false
				},
				canManage: false,
				canCreate: false
			}),
			empty: () => allocationsFixture({ allocations: [] }),
			loading: () => allocationsFixture({
				allocations: [],
				loading: true
			})
		}
	}
});
//#endregion

//# sourceMappingURL=network-CTUq3M5u.js.map