import "./sdk-Chrtpiam.js";
import { f as TextArea, l as Label, p as TextInput } from "./useDebouncedCallback-B4Ebjqc5.js";
import { useId } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region ../../resources/scripts/themes/classic/views/shared/fields.tsx
function HelpText({ id, error, description }) {
	if (error) return /* @__PURE__ */ jsx("p", {
		id,
		className: "input-help error",
		children: error
	});
	return description ? /* @__PURE__ */ jsx("p", {
		id,
		className: "input-help",
		children: description
	}) : null;
}
function useFieldIds(field, id, description) {
	const generated = useId();
	const helpId = `${generated}-help`;
	return {
		fieldId: id ?? generated,
		helpId,
		describedBy: field.error || description ? helpId : void 0
	};
}
/** Label, input and help text for an engine field, whose own props pass through untouched. */
function TextField({ field, label, description, light, id, className, title, autoFocus }) {
	const { fieldId, helpId, describedBy } = useFieldIds(field, id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(TextInput, {
			...field.fieldProps,
			id: fieldId,
			className,
			title,
			autoFocus,
			"aria-invalid": field.error ? true : void 0,
			"aria-describedby": describedBy,
			$hasError: !!field.error,
			$isLight: light
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error: field.error,
			description
		})
	] });
}
function TextAreaField({ field, label, description, light, id, className, rows }) {
	const { fieldId, helpId, describedBy } = useFieldIds(field, id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(TextArea, {
			...field.fieldProps,
			id: fieldId,
			className,
			rows,
			"aria-invalid": field.error ? true : void 0,
			"aria-describedby": describedBy,
			$hasError: !!field.error,
			$isLight: light
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error: field.error,
			description
		})
	] });
}
//#endregion
export { TextField as n, TextAreaField as t };

//# sourceMappingURL=fields-DSobJx3_.js.map