import { d as isString, u as isObject } from "./client.gen-Ci-zROOW.js";
import { I as clientGetServerOptions, L as clientGetServerQueryKey, ht as clientRenameServerMutation, pt as clientReinstallServerMutation, t as notifyHttpError } from "./notifications-Ebj0Q0Io.js";
import { n as useServerRouteId } from "./params-HmQaEn9f.js";
import "./generated-curw-uY5.js";
import { useCallback } from "react";
import { partialMatchKey, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/queryKeyGuards.ts
var isGeneratedQueryKeyRoot = (value) => isObject(value) && (!("_id" in value) || value._id === void 0 || isString(value._id));
var hasGeneratedOperationId = (queryKey, id) => {
	const [key] = queryKey;
	return isGeneratedQueryKeyRoot(key) && key._id === id;
};
//#endregion
//#region ../../resources/scripts/api/mutationUtils.ts
var invalidateGeneratedOperations = (queryClient, operationIds) => {
	if (operationIds.length === 0) return Promise.resolve();
	return queryClient.invalidateQueries({ predicate: ({ queryKey }) => operationIds.some((operationId) => hasGeneratedOperationId(queryKey, operationId)) });
};
//#endregion
//#region ../../resources/scripts/api/server/queries.ts
var emptyPermissions = [];
var ownerPermissions = ["*"];
var serverInput = (id) => ({ path: { server_uuid: id } });
var serverQueryKey = (id) => clientGetServerQueryKey(serverInput(id));
var identifiesServer = (server, id) => isObject(server) && "attributes" in server && isObject(server.attributes) && ("uuid" in server.attributes && server.attributes.uuid === id || "identifier" in server.attributes && server.attributes.identifier === id);
/** Matches every cached copy of the server, keyed by uuid or short identifier. */
var serverQueryFilters = (id) => ({ predicate: ({ queryKey, state }) => hasGeneratedOperationId(queryKey, "clientGetServer") && (partialMatchKey(queryKey, serverQueryKey(id)) || identifiesServer(state.data, id)) });
var updateServerQueryData = (queryClient, id, updater) => {
	const filters = serverQueryFilters(id);
	queryClient.cancelQueries(filters);
	queryClient.setQueriesData(filters, (server) => server ? updater(server) : server);
};
var serverQueryOptions = (id) => clientGetServerOptions(serverInput(id));
var useServerQuery = (id, select) => useQuery({
	...serverQueryOptions(id),
	enabled: id.length > 0,
	select
});
var useCurrentServer = (select) => {
	return useServerQuery(useServerRouteId() ?? "", select).data;
};
var selectServerUuid = (server) => server.attributes.uuid;
var selectServerIdentifier = (server) => server.attributes.identifier;
var selectServerName = (server) => server.attributes.name;
var selectServerPermissions = (server) => server.meta?.is_server_owner ? ownerPermissions : server.meta?.user_permissions ?? emptyPermissions;
var useCurrentServerUuid = () => useCurrentServer(selectServerUuid);
var useCurrentServerIdentifier = () => useCurrentServer(selectServerIdentifier);
var useCurrentServerName = () => useCurrentServer(selectServerName);
var useCurrentServerPermissions = () => useCurrentServer(selectServerPermissions) ?? emptyPermissions;
var useUpdateCurrentServer = () => {
	const id = useServerRouteId();
	const queryClient = useQueryClient();
	return useCallback((updater) => {
		if (!id) return;
		updateServerQueryData(queryClient, id, updater);
	}, [id, queryClient]);
};
var useRenameServer = (serverIdentifier) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientRenameServerMutation(),
		onSuccess: async (_data, variables) => {
			updateServerQueryData(queryClient, serverIdentifier, (server) => ({
				...server,
				attributes: {
					...server.attributes,
					name: variables.body.name,
					description: variables.body.description ?? null
				}
			}));
			await invalidateGeneratedOperations(queryClient, ["clientListClientServers"]);
			toast.success("Server details updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update server details")
	});
};
var useReinstallServer = () => useMutation({
	...clientReinstallServerMutation(),
	onSuccess: () => toast.success("Server reinstall started"),
	onError: (error) => notifyHttpError(error, "Unable to reinstall server")
});
//#endregion
export { useCurrentServerIdentifier as a, useCurrentServerUuid as c, useServerQuery as d, useUpdateCurrentServer as f, useCurrentServer as i, useReinstallServer as l, serverQueryFilters as n, useCurrentServerName as o, serverQueryOptions as r, useCurrentServerPermissions as s, selectServerPermissions as t, useRenameServer as u };

//# sourceMappingURL=queries-D_-2KdyF.js.map