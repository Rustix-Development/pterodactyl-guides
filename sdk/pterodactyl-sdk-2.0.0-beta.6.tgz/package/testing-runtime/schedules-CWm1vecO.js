import { a as Spinner, n as ButtonWithVariants, p as Icon } from "./Button-BzlrfY24.js";
import { Dt as ServerContentBlock, G as EditLinkAction, H as Tooltip, Ot as PageContentBlock, Q as ListToolbar, Rt as SpinnerOverlay, U as DeleteAction, W as EditAction, X as actionsColumn, Y as Table, at as EmptyTitle, et as Empty, h as fromNow, ht as NewButton, it as EmptyMedia, jt as Badge, m as formatDate, nt as EmptyDescription, q as RowActions, r as cn, rt as EmptyHeader, tt as EmptyContent } from "./sdk-Chrtpiam.js";
import { t as PanelLink } from "./navigation-9aP-0Hbq.js";
import { c as View } from "./theme-Cgy7R6cy.js";
import { a as Switch, n as useAppForm, r as Form } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { useMemo, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { ArrowDownCircle, CalendarClock, CircleHelp, Clock, Code, FileArchive, ListTodo, ToggleRight } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/server/schedules/SchedulesPage.tsx
function SchedulesPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(ServerContentBlock, {
			title: "Schedules",
			className,
			children: /* @__PURE__ */ jsx(View, { name: "server.schedules" })
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/ScheduleCronRow.tsx
/** The cron fields in a row, as the schedule list shows them. */
function ScheduleCronRow({ cron, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn("flex", className),
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "w-1/5 sm:w-auto text-center",
				children: [/* @__PURE__ */ jsx("p", {
					className: "font-medium",
					children: cron.minute
				}), /* @__PURE__ */ jsx("p", {
					className: "text-xs text-muted-foreground uppercase",
					children: "Minute"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "w-1/5 sm:w-auto text-center ml-4",
				children: [/* @__PURE__ */ jsx("p", {
					className: "font-medium",
					children: cron.hour
				}), /* @__PURE__ */ jsx("p", {
					className: "text-xs text-muted-foreground uppercase",
					children: "Hour"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "w-1/5 sm:w-auto text-center ml-4",
				children: [/* @__PURE__ */ jsx("p", {
					className: "font-medium",
					children: cron.dayOfMonth
				}), /* @__PURE__ */ jsx("p", {
					className: "text-xs text-muted-foreground uppercase",
					children: "Day (Month)"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "w-1/5 sm:w-auto text-center ml-4",
				children: [/* @__PURE__ */ jsx("p", {
					className: "font-medium",
					children: cron.month
				}), /* @__PURE__ */ jsx("p", {
					className: "text-xs text-muted-foreground uppercase",
					children: "Month"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "w-1/5 sm:w-auto text-center ml-4",
				children: [/* @__PURE__ */ jsx("p", {
					className: "font-medium",
					children: cron.dayOfWeek
				}), /* @__PURE__ */ jsx("p", {
					className: "text-xs text-muted-foreground uppercase",
					children: "Day (Week)"
				})]
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/ScheduleCheatsheet.tsx
var examples = [
	{
		token: "*/5 * * * *",
		meaning: "every 5 minutes"
	},
	{
		token: "0 */1 * * *",
		meaning: "every hour"
	},
	{
		token: "0 8-12 * * *",
		meaning: "hour range"
	},
	{
		token: "0,30 * * * *",
		meaning: "on the hour and half past"
	},
	{
		token: "0 0 * * *",
		meaning: "once a day"
	},
	{
		token: "0 0 * * MON",
		meaning: "every Monday"
	},
	{
		token: "0 0 * * MON,FRI",
		meaning: "every Monday and Friday"
	}
];
var specialCharacters = [
	{
		token: "*",
		meaning: "any value",
		detail: "Matches every value in that field. An hour of * runs the task every hour."
	},
	{
		token: ",",
		meaning: "value list separator",
		detail: "Picks several exact values. A minute of 0,30 runs on the hour and at half past."
	},
	{
		token: "-",
		meaning: "range values",
		detail: "Covers everything between two values. An hour of 8-12 runs at 8, 9, 10, 11 and 12."
	},
	{
		token: "/",
		meaning: "step values",
		detail: "Repeats every nth value. A minute of */15 runs four times an hour."
	}
];
var hintClass = [
	"inline-flex cursor-help items-baseline gap-1.5 text-left",
	"underline decoration-dotted decoration-muted-foreground underline-offset-4",
	"hover:text-foreground hover:decoration-foreground",
	"focus-visible:text-foreground focus-visible:decoration-foreground focus-visible:outline-hidden"
].join(" ");
var RowMeaning = ({ meaning, detail }) => detail ? /* @__PURE__ */ jsx(Tooltip, {
	content: detail,
	interactions: [
		"hover",
		"focus",
		"click"
	],
	children: /* @__PURE__ */ jsxs("button", {
		type: "button",
		className: hintClass,
		children: [meaning, /* @__PURE__ */ jsx(Icon, {
			icon: CircleHelp,
			className: "shrink-0 self-center text-muted-foreground"
		})]
	})
}) : meaning;
var CheatsheetCard = ({ title, rows, tokenClass }) => /* @__PURE__ */ jsxs("div", {
	className: "overflow-hidden rounded-sm border border-border bg-background/50",
	children: [/* @__PURE__ */ jsx("h3", {
		className: "border-b border-border bg-popover px-3 py-2 text-xs font-semibold uppercase text-muted-foreground",
		children: title
	}), /* @__PURE__ */ jsx("dl", {
		className: "divide-y divide-border text-xs",
		children: rows.map((row) => /* @__PURE__ */ jsxs("div", {
			className: "flex items-baseline gap-3 px-3 py-2.5",
			children: [/* @__PURE__ */ jsx("dt", {
				className: cn("shrink-0 whitespace-nowrap font-mono text-foreground", tokenClass),
				children: row.token
			}), /* @__PURE__ */ jsx("dd", {
				className: "min-w-0 text-card-foreground",
				children: /* @__PURE__ */ jsx(RowMeaning, { ...row })
			})]
		}, row.token))
	})]
});
/** Examples of cron syntax and what its special characters mean. */
function ScheduleCheatsheet() {
	return /* @__PURE__ */ jsxs("div", {
		className: "mt-4 grid items-start gap-4 sm:grid-cols-2",
		children: [/* @__PURE__ */ jsx(CheatsheetCard, {
			title: "Examples",
			rows: examples,
			tokenClass: "w-32"
		}), /* @__PURE__ */ jsx(CheatsheetCard, {
			title: "Special characters",
			rows: specialCharacters,
			tokenClass: "w-6 text-center"
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/ScheduleDialog.tsx
var cronFieldsClass = [
	"mt-6 grid grid-cols-2 items-end gap-4 sm:grid-cols-5",
	"[&_label]:text-xs [&_label]:text-muted-foreground",
	"[&_input]:text-center [&_input]:font-mono"
].join(" ");
function ScheduleForm({ values, editing, onSubmit, onClose }) {
	const [showCheatsheet, setShowCheatsheet] = useState(false);
	const form = useAppForm({
		defaultValues: { ...values },
		onSubmit: async ({ value }) => {
			if (await onSubmit(value)) onClose();
		}
	});
	return /* @__PURE__ */ jsxs(Form, {
		form,
		children: [
			/* @__PURE__ */ jsx(form.AppField, {
				name: "name",
				children: (field) => /* @__PURE__ */ jsx(field.TextField, {
					label: "Schedule name",
					description: "A human readable identifier for this schedule."
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: cronFieldsClass,
				children: [
					/* @__PURE__ */ jsx(form.AppField, {
						name: "minute",
						children: (field) => /* @__PURE__ */ jsx(field.TextField, { label: "Minute" })
					}),
					/* @__PURE__ */ jsx(form.AppField, {
						name: "hour",
						children: (field) => /* @__PURE__ */ jsx(field.TextField, { label: "Hour" })
					}),
					/* @__PURE__ */ jsx(form.AppField, {
						name: "dayOfMonth",
						children: (field) => /* @__PURE__ */ jsx(field.TextField, { label: "Day of month" })
					}),
					/* @__PURE__ */ jsx(form.AppField, {
						name: "month",
						children: (field) => /* @__PURE__ */ jsx(field.TextField, { label: "Month" })
					}),
					/* @__PURE__ */ jsx(form.AppField, {
						name: "dayOfWeek",
						children: (field) => /* @__PURE__ */ jsx(field.TextField, { label: "Day of week" })
					})
				]
			}),
			/* @__PURE__ */ jsx("p", {
				className: "text-muted-foreground text-xs mt-2",
				children: "The schedule system supports the use of Cronjob syntax when defining when tasks should begin running. Use the fields above to specify when these tasks should begin running."
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6 bg-card border border-border shadow-inner p-4 rounded-sm",
				children: [/* @__PURE__ */ jsx(Switch, {
					label: "Show Cheatsheet",
					description: "Show the cron cheatsheet for some examples.",
					checked: showCheatsheet,
					onChange: () => setShowCheatsheet((shown) => !shown)
				}), showCheatsheet && /* @__PURE__ */ jsx(ScheduleCheatsheet, {})]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 bg-card border border-border shadow-inner p-4 rounded-sm",
				children: /* @__PURE__ */ jsx(form.AppField, {
					name: "onlyWhenOnline",
					children: (field) => /* @__PURE__ */ jsx(field.SwitchField, {
						description: "Only execute this schedule when the server is in a running state.",
						label: "Only When Server Is Online"
					})
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 bg-card border border-border shadow-inner p-4 rounded-sm",
				children: /* @__PURE__ */ jsx(form.AppField, {
					name: "enabled",
					children: (field) => /* @__PURE__ */ jsx(field.SwitchField, {
						description: "This schedule will be executed automatically if enabled.",
						label: "Schedule Enabled"
					})
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 text-right",
				children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
					className: "w-full sm:w-auto",
					children: editing ? "Save changes" : "Create schedule"
				}) })
			})
		]
	});
}
/** Creates a schedule, or edits one, with its name, cron fields and switches. */
function ScheduleDialog({ open, onClose, ...props }) {
	return /* @__PURE__ */ jsx(Dialog, {
		open,
		title: props.editing ? "Edit schedule" : "Create schedule",
		onClose,
		children: /* @__PURE__ */ jsx(ScheduleForm, {
			...props,
			onClose
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/ScheduleList.tsx
var scheduleStatus = (schedule) => {
	if (schedule.processing) return "processing";
	return schedule.active ? "active" : "inactive";
};
var scheduleDestination = (model, schedule) => ({
	to: "/server/$id/schedules/$scheduleId",
	params: {
		id: model.serverId,
		scheduleId: String(schedule.id)
	}
});
function columns$1(model) {
	return [
		{
			id: "name",
			label: "Schedule",
			sortValue: (schedule) => schedule.name,
			cell: (schedule) => /* @__PURE__ */ jsxs("div", {
				className: "min-w-40",
				children: [/* @__PURE__ */ jsx(PanelLink, {
					destination: scheduleDestination(model, schedule),
					className: "font-medium hover:text-primary",
					children: schedule.name
				}), /* @__PURE__ */ jsxs("p", {
					className: "mt-0.5 text-xs text-muted-foreground md:hidden",
					children: ["Last run ", schedule.lastRunAt ? fromNow(schedule.lastRunAt) : "never"]
				})]
			})
		},
		{
			id: "cron",
			label: "Cron",
			cell: (schedule) => /* @__PURE__ */ jsx(ScheduleCronRow, { cron: schedule.cron }),
			headerClassName: "hidden lg:table-cell",
			cellClassName: "hidden lg:table-cell"
		},
		{
			id: "last_run_at",
			label: "Last run",
			sortValue: (schedule) => schedule.lastRunAt ?? "",
			cell: (schedule) => /* @__PURE__ */ jsx("span", {
				className: "whitespace-nowrap text-xs text-muted-foreground",
				children: schedule.lastRunAt ? formatDate(schedule.lastRunAt, "MMM D, YYYY HH:mm") : "Never"
			}),
			headerClassName: "hidden md:table-cell w-40",
			cellClassName: "hidden md:table-cell w-40"
		},
		{
			id: "status",
			label: "Status",
			sortValue: scheduleStatus,
			cell: (schedule) => {
				const status = scheduleStatus(schedule);
				return /* @__PURE__ */ jsx(Badge, {
					tone: status === "active" ? "success" : "neutral",
					className: cn("inline-flex rounded-full font-medium capitalize", status === "active" && "bg-success/90"),
					children: status
				});
			},
			headerClassName: "w-28",
			cellClassName: "w-28"
		},
		actionsColumn(1, (schedule) => model.canUpdate ? /* @__PURE__ */ jsx(RowActions, { children: /* @__PURE__ */ jsx(EditLinkAction, {
			"aria-label": `Edit ${schedule.name}`,
			destination: scheduleDestination(model, schedule)
		}) }) : null)
	];
}
function CreateScheduleButton({ model }) {
	return /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(NewButton, {
			onClick,
			children: "New schedule"
		}),
		children: (dialog) => /* @__PURE__ */ jsx(ScheduleDialog, {
			...dialog,
			values: model.defaults,
			editing: false,
			onSubmit: model.create
		})
	});
}
function ScheduleList({ model, className }) {
	const tableColumns = useMemo(() => columns$1(model), [model]);
	if (model.loading) return /* @__PURE__ */ jsx("div", {
		className,
		children: /* @__PURE__ */ jsx(Spinner, {
			size: "large",
			centered: true
		})
	});
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [model.canCreate && /* @__PURE__ */ jsx(ListToolbar, { children: /* @__PURE__ */ jsx(CreateScheduleButton, { model }) }), /* @__PURE__ */ jsx(Table, {
			rows: model.schedules,
			columns: tableColumns,
			keyOf: (schedule) => String(schedule.id),
			emptyState: /* @__PURE__ */ jsxs(Empty, {
				size: "compact",
				children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
					/* @__PURE__ */ jsx(EmptyMedia, {
						variant: "icon",
						children: /* @__PURE__ */ jsx(CalendarClock, {})
					}),
					/* @__PURE__ */ jsx(EmptyTitle, { children: "No schedules" }),
					/* @__PURE__ */ jsx(EmptyDescription, { children: "Schedules run commands, power actions and backups automatically." })
				] }), model.canCreate && /* @__PURE__ */ jsx(EmptyContent, { children: /* @__PURE__ */ jsx(CreateScheduleButton, { model }) })]
			})
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/ScheduleDetailPage.tsx
function ScheduleDetailPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(PageContentBlock, {
			title: "Schedules",
			className,
			children: /* @__PURE__ */ jsx(View, {
				name: "server.schedule",
				children: /* @__PURE__ */ jsx(View, {
					name: "server.schedule.tasks",
					className: "rounded-t-none"
				})
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/TaskDialog.tsx
function TaskForm({ form: config, task, onSubmit, onClose }) {
	const [formError, setFormError] = useState(null);
	const form = useAppForm({
		defaultValues: { ...config.values(task) },
		onSubmit: async ({ value }) => {
			setFormError(null);
			const error = config.validate(value);
			if (error) {
				setFormError(error);
				return;
			}
			if (value.timeOffset !== null && await onSubmit(value)) onClose();
		}
	});
	const payloadValidators = {
		onChangeListenTo: ["action"],
		onChange: ({ value }) => config.validatePayload(form.getFieldValue("action"), value)
	};
	return /* @__PURE__ */ jsxs(Form, {
		form,
		className: "m-0",
		children: [
			formError && /* @__PURE__ */ jsx("div", {
				className: "rounded-sm border border-destructive/40 bg-destructive/10 p-3 text-sm text-foreground mb-4",
				children: formError
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex",
				children: [/* @__PURE__ */ jsx("div", {
					className: "mr-2 w-1/3",
					children: /* @__PURE__ */ jsx(form.AppField, {
						name: "action",
						children: (field) => /* @__PURE__ */ jsx(field.SelectField, {
							label: "Action",
							options: [...config.actions],
							onChange: (value) => form.setFieldValue("payload", config.payloadFor(value, task))
						})
					})
				}), /* @__PURE__ */ jsx("div", {
					className: "flex-1 ml-6",
					children: /* @__PURE__ */ jsx(form.AppField, {
						name: "timeOffset",
						validators: { onChange: ({ value }) => config.validateTimeOffset(value) },
						children: (field) => /* @__PURE__ */ jsx(field.NumberField, {
							label: "Time offset (in seconds)",
							min: 0,
							max: 900,
							description: "The amount of time to wait after the previous task executes before running this one. If this is the first task on a schedule this will not be applied."
						})
					})
				})]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6",
				children: /* @__PURE__ */ jsx(form.Subscribe, {
					selector: (state) => state.values.action,
					children: (action) => /* @__PURE__ */ jsxs(Fragment$1, { children: [
						action === "command" && /* @__PURE__ */ jsx(form.AppField, {
							name: "payload",
							validators: payloadValidators,
							children: (field) => /* @__PURE__ */ jsx(field.TextAreaField, {
								label: "Payload",
								rows: 6
							})
						}),
						action === "power" && /* @__PURE__ */ jsx(form.AppField, {
							name: "payload",
							validators: payloadValidators,
							children: (field) => /* @__PURE__ */ jsx(field.SelectField, {
								label: "Payload",
								options: [...config.powerSignals]
							})
						}),
						action === "backup" && /* @__PURE__ */ jsx(form.AppField, {
							name: "payload",
							validators: payloadValidators,
							children: (field) => /* @__PURE__ */ jsx(field.TextAreaField, {
								label: "Ignored Files",
								rows: 6,
								description: "Optional. Include the files and folders to be excluded in this backup. By default, the contents of your .pteroignore file will be used. If you have reached your backup limit, the oldest backup will be rotated."
							})
						})
					] })
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 bg-card border border-border shadow-inner p-4 rounded-sm",
				children: /* @__PURE__ */ jsx(form.AppField, {
					name: "continueOnFailure",
					children: (field) => /* @__PURE__ */ jsx(field.SwitchField, {
						description: "Future tasks will be run when this task fails.",
						label: "Continue on Failure"
					})
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "flex justify-end mt-6",
				children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, { children: task ? "Save Changes" : "Create Task" }) })
			})
		]
	});
}
/** Creates a task, or edits one: its action, delay, payload and failure behaviour. */
function TaskDialog({ open, onClose, ...props }) {
	return /* @__PURE__ */ jsx(Dialog, {
		open,
		title: props.task ? "Edit task" : "Create task",
		onClose,
		children: /* @__PURE__ */ jsx(TaskForm, {
			...props,
			onClose
		}, props.task?.id ?? "new")
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/NewTaskButton.tsx
function NewTaskButton({ form, onSubmit, className }) {
	return /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(NewButton, {
			onClick,
			className,
			children: "New task"
		}),
		children: (dialog) => /* @__PURE__ */ jsx(TaskDialog, {
			...dialog,
			form,
			onSubmit
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/ScheduleDetails.tsx
var CronBox = ({ title, value }) => /* @__PURE__ */ jsxs("div", {
	className: "bg-card rounded-sm p-3",
	children: [/* @__PURE__ */ jsx("p", {
		className: "text-muted-foreground text-sm",
		children: title
	}), /* @__PURE__ */ jsx("p", {
		className: "text-xl font-medium text-foreground",
		children: value
	})]
});
function StatusBadge({ schedule }) {
	if (schedule.processing) return /* @__PURE__ */ jsxs(Badge, {
		className: "ml-4 flex items-center rounded-full py-px uppercase",
		children: [/* @__PURE__ */ jsx(Spinner, {}), "Processing"]
	});
	return /* @__PURE__ */ jsx(Badge, {
		tone: schedule.active ? "success" : "danger",
		className: cn("ml-4 rounded-full py-px uppercase", schedule.active ? "bg-success/90" : "bg-destructive/90"),
		children: schedule.active ? "Active" : "Inactive"
	});
}
var RunTime = ({ at }) => at ? formatDate(at, "MMM Do [at] h:mmA") : /* @__PURE__ */ jsx("span", {
	className: "text-muted-foreground",
	children: "n/a"
});
/** The schedule's header, cron and actions; `children` (its tasks) render inside the box below the cron. */
function ScheduleDetails({ model, className, children }) {
	const { schedule, actions } = model;
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [
			/* @__PURE__ */ jsx(ScheduleCronRow, {
				cron: schedule.cron,
				className: "sm:hidden bg-card rounded-sm mb-4 p-3"
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "rounded-sm shadow-sm",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "sm:flex items-center bg-muted p-3 sm:p-6 border-b-4 border-border rounded-t-sm",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ jsxs("h3", {
								className: "flex items-center text-foreground text-2xl",
								children: [schedule.name, /* @__PURE__ */ jsx(StatusBadge, { schedule })]
							}), /* @__PURE__ */ jsxs("p", {
								className: "mt-1 text-sm text-foreground",
								children: [
									"Last run at:\xA0",
									/* @__PURE__ */ jsx(RunTime, { at: schedule.lastRunAt }),
									/* @__PURE__ */ jsxs("span", {
										className: "ml-4 pl-4 border-l-4 border-border py-px",
										children: ["Next run at:\xA0", /* @__PURE__ */ jsx(RunTime, { at: schedule.nextRunAt })]
									})
								]
							})]
						}), /* @__PURE__ */ jsx("div", {
							className: "flex sm:block mt-3 sm:mt-0",
							children: model.canUpdate && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Dialog.Trigger, {
								trigger: ({ onClick }) => /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
									className: "flex-1 mr-4",
									onClick,
									children: "Edit"
								}),
								children: (dialog) => /* @__PURE__ */ jsx(ScheduleDialog, {
									...dialog,
									values: model.values,
									editing: true,
									onSubmit: actions.update
								})
							}), /* @__PURE__ */ jsx(NewTaskButton, {
								form: model.taskForm,
								onSubmit: actions.createTask,
								className: "flex-1"
							})] })
						})]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "hidden sm:grid grid-cols-5 md:grid-cols-5 gap-4 mb-4 mt-4",
						children: [
							/* @__PURE__ */ jsx(CronBox, {
								title: "Minute",
								value: schedule.cron.minute
							}),
							/* @__PURE__ */ jsx(CronBox, {
								title: "Hour",
								value: schedule.cron.hour
							}),
							/* @__PURE__ */ jsx(CronBox, {
								title: "Day (Month)",
								value: schedule.cron.dayOfMonth
							}),
							/* @__PURE__ */ jsx(CronBox, {
								title: "Month",
								value: schedule.cron.month
							}),
							/* @__PURE__ */ jsx(CronBox, {
								title: "Day (Week)",
								value: schedule.cron.dayOfWeek
							})
						]
					}),
					children
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6 flex sm:justify-end",
				children: [model.canDelete && /* @__PURE__ */ jsxs(Dialog.ConfirmTrigger, {
					title: "Delete Schedule",
					confirm: "Delete",
					onConfirmed: async (_event, close) => {
						await actions.remove();
						close();
					},
					trigger: ({ onClick }) => /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
						isSecondary: true,
						className: "flex-1 sm:flex-none mr-4 border-transparent",
						onClick,
						children: "Delete"
					}),
					children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.deleting }), "All tasks will be removed and any running processes will be terminated."]
				}), model.taskCount > 0 && model.canUpdate && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(SpinnerOverlay, {
					visible: model.running,
					size: "large"
				}), /* @__PURE__ */ jsx(ButtonWithVariants, {
					isSecondary: true,
					className: "flex-1 sm:flex-none",
					disabled: schedule.processing || model.running,
					onClick: () => void actions.run(),
					children: "Run Now"
				})] })]
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/schedules/ScheduleTasks.tsx
var actionDetails = (action) => {
	switch (action) {
		case "command": return ["Send Command", Code];
		case "power": return ["Send Power Action", ToggleRight];
		case "backup": return ["Create Backup", FileArchive];
		default: return ["Unknown Action", Code];
	}
};
function TaskIdentity({ task }) {
	const [title, icon] = actionDetails(task.action);
	return /* @__PURE__ */ jsxs("div", {
		className: "flex min-w-48 items-start gap-3",
		children: [/* @__PURE__ */ jsx(Icon, {
			icon,
			className: "mt-0.5 hidden text-muted-foreground md:block"
		}), /* @__PURE__ */ jsxs("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ jsx("p", {
				className: "font-medium",
				children: title
			}), task.payload ? /* @__PURE__ */ jsx("code", {
				className: "mt-1 block max-w-xl whitespace-pre-wrap break-all text-xs text-muted-foreground",
				children: task.payload
			}) : null]
		})]
	});
}
function TaskActions({ model, task }) {
	const name = `task ${task.sequence} (${actionDetails(task.action)[0]})`;
	return /* @__PURE__ */ jsx(RowActions, { children: model.canUpdate && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(EditAction, {
			"aria-label": `Edit ${name}`,
			onClick
		}),
		children: (dialog) => /* @__PURE__ */ jsx(TaskDialog, {
			...dialog,
			form: model.form,
			task,
			onSubmit: (values) => model.actions.update(task.id, values)
		})
	}), /* @__PURE__ */ jsx(Dialog.ConfirmTrigger, {
		title: "Confirm task deletion",
		confirm: "Delete Task",
		onConfirmed: async (_event, close) => {
			if (await model.actions.remove(task.id)) close();
		},
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(DeleteAction, {
			"aria-label": `Delete ${name}`,
			onClick
		}),
		children: "Are you sure you want to delete this task? This action cannot be undone."
	})] }) });
}
function columns(model) {
	return [
		{
			id: "action",
			label: "Task",
			sortValue: (task) => actionDetails(task.action)[0],
			cell: (task) => /* @__PURE__ */ jsx(TaskIdentity, { task })
		},
		{
			id: "delay",
			label: "Delay",
			sortValue: (task) => task.timeOffset,
			cell: (task) => task.sequence > 1 && task.timeOffset > 0 ? /* @__PURE__ */ jsxs("span", {
				className: "inline-flex items-center gap-1.5 whitespace-nowrap text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ jsx(Icon, {
						icon: Clock,
						className: "h-3.5 w-3.5"
					}),
					task.timeOffset,
					"s later"
				]
			}) : "-",
			headerClassName: "hidden md:table-cell w-32",
			cellClassName: "hidden md:table-cell w-32"
		},
		{
			id: "continue_on_failure",
			label: "Failure behavior",
			cell: (task) => task.continueOnFailure ? /* @__PURE__ */ jsxs(Badge, {
				tone: "warning",
				className: "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full",
				children: [/* @__PURE__ */ jsx(Icon, {
					icon: ArrowDownCircle,
					className: "h-3.5 w-3.5"
				}), "Continues"]
			}) : /* @__PURE__ */ jsx("span", {
				className: "text-xs text-muted-foreground",
				children: "Stops"
			}),
			headerClassName: "hidden lg:table-cell w-36",
			cellClassName: "hidden lg:table-cell w-36"
		},
		actionsColumn(2, (task) => /* @__PURE__ */ jsx(TaskActions, {
			model,
			task
		}))
	];
}
function ScheduleTasks({ model, className }) {
	const tableColumns = useMemo(() => columns(model), [model]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(SpinnerOverlay, {
		visible: model.deleting,
		fixed: true,
		size: "large"
	}), /* @__PURE__ */ jsx(Table, {
		rows: model.tasks,
		columns: tableColumns,
		keyOf: (task) => String(task.id),
		className,
		emptyState: /* @__PURE__ */ jsxs(Empty, {
			size: "compact",
			children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
				/* @__PURE__ */ jsx(EmptyMedia, {
					variant: "icon",
					children: /* @__PURE__ */ jsx(ListTodo, {})
				}),
				/* @__PURE__ */ jsx(EmptyTitle, { children: "No tasks" }),
				/* @__PURE__ */ jsx(EmptyDescription, { children: "Add a task to tell this schedule what to do when it runs." })
			] }), model.canUpdate && /* @__PURE__ */ jsx(EmptyContent, { children: /* @__PURE__ */ jsx(NewTaskButton, {
				form: model.form,
				onSubmit: model.actions.create
			}) })]
		})
	})] });
}
//#endregion
export { ScheduleDetailPage, ScheduleDetails, ScheduleList, ScheduleTasks, SchedulesPage };

//# sourceMappingURL=schedules-CWm1vecO.js.map