//#region ../../resources/scripts/views/server/permissionSelection.ts
function replaceEditablePermissions(current, requested, editable) {
	const requestedSet = new Set(requested);
	return [...new Set(current.filter((permission) => !editable.has(permission))), ...[...editable].filter((permission) => requestedSet.has(permission))];
}
function setPermissionsSelected(current, permissions, selected) {
	if (selected) return [...new Set([...current, ...permissions])];
	const removed = new Set(permissions);
	return current.filter((permission) => !removed.has(permission));
}
/** Group names may contain dots, such as extension groups named `ext.<extension id>`. */
var permissionGroupRows = (group, keys) => Object.entries(keys).map(([key, description]) => ({
	permission: `${group}.${key}`,
	key,
	description
}));
//#endregion
export { replaceEditablePermissions as n, setPermissionsSelected as r, permissionGroupRows as t };

//# sourceMappingURL=permissionSelection-BuSLUqDB.js.map