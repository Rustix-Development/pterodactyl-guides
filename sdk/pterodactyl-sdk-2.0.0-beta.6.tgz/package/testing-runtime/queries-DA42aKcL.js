import { Mt as authGetCsrfCookie, a as authLoginMutation, c as authResetPasswordMutation, i as authCompleteLoginCheckpointMutation, o as authLogoutMutation, s as authRequestPasswordResetEmailMutation, t as notifyHttpError } from "./notifications-Ebj0Q0Io.js";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/auth/queries.ts
var useLogin = () => useMutation({
	...authLoginMutation(),
	onMutate: async () => {
		await authGetCsrfCookie();
	},
	onError: (error) => notifyHttpError(error, "Unable to log in")
});
var useLoginCheckpoint = () => useMutation({
	...authCompleteLoginCheckpointMutation(),
	onError: (error) => notifyHttpError(error, "Unable to verify two-step code")
});
var useRequestPasswordResetEmail = () => useMutation({
	...authRequestPasswordResetEmailMutation(),
	onSuccess: (response) => toast.success(response.status || "Password reset email sent"),
	onError: (error) => notifyHttpError(error, "Unable to request password reset")
});
var usePerformPasswordReset = () => useMutation({
	...authResetPasswordMutation(),
	onError: (error) => notifyHttpError(error, "Unable to reset password")
});
var useLogout = () => useMutation({
	...authLogoutMutation(),
	onSettled: () => {
		window.location.assign("/");
	}
});
//#endregion
export { useRequestPasswordResetEmail as a, usePerformPasswordReset as i, useLoginCheckpoint as n, useLogout as r, useLogin as t };

//# sourceMappingURL=queries-DA42aKcL.js.map