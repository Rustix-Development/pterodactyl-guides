import { p as Icon } from "./Button-BzlrfY24.js";
import { $ as Avatar, H as Tooltip, Rt as SpinnerOverlay, pt as DropdownMenuWithItems } from "./sdk-Chrtpiam.js";
import { t as PanelLink } from "./navigation-9aP-0Hbq.js";
import { a as Slot, c as View, o as Main } from "./theme-Cgy7R6cy.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Layers, LogOut, Moon, Sun, UserCog } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/layout/AppLayout.tsx
var navItemClass = [
	"flex h-full shrink-0 items-center px-3 sm:px-6 no-underline text-muted-foreground cursor-pointer",
	"transition-[background-color,border-color,color,box-shadow] duration-150 hover:bg-popover hover:border-border active:bg-popover/80",
	"hover:text-foreground active:text-foreground",
	"hover:shadow-navigation-active active:shadow-navigation-active",
	"data-[status=active]:shadow-navigation-active"
].join(" ");
var schemeLabels = {
	dark: "Dark",
	light: "Light"
};
function LinkIcon({ link, user }) {
	if (link.id === "account") return /* @__PURE__ */ jsx("span", {
		className: "flex items-center w-5 h-5",
		children: /* @__PURE__ */ jsx(Avatar, { name: user.uuid })
	});
	return /* @__PURE__ */ jsx(Icon, { icon: link.id === "admin" ? UserCog : Layers });
}
/** Only rendered when the theme offers more than one scheme. */
function SchemeMenu({ model, setScheme }) {
	return /* @__PURE__ */ jsxs(DropdownMenuWithItems, {
		triggerClassName: navItemClass,
		triggerContent: /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Icon, {
			icon: model.scheme === "light" ? Sun : Moon,
			"aria-hidden": true
		}), /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "Color scheme"
		})] }),
		children: [model.schemes.map((scheme) => /* @__PURE__ */ jsx(DropdownMenuWithItems.Item, {
			checked: scheme === model.preference,
			onClick: () => setScheme(scheme),
			children: schemeLabels[scheme]
		}, scheme)), /* @__PURE__ */ jsx(DropdownMenuWithItems.Item, {
			checked: model.preference === "system",
			onClick: () => setScheme("system"),
			children: "System"
		})]
	});
}
function NavigationBar({ model }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "w-full bg-background shadow-md overflow-x-auto scrollbar-none [&::-webkit-scrollbar]:hidden",
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.signingOut }), /* @__PURE__ */ jsxs("div", {
			className: "mx-auto flex h-14 w-full max-w-panel items-center",
			children: [/* @__PURE__ */ jsx("div", {
				id: "logo",
				className: "flex-1 min-w-0",
				children: /* @__PURE__ */ jsx(PanelLink, {
					destination: { to: "/" },
					className: "block truncate text-xl sm:text-2xl font-header font-medium px-4 no-underline text-foreground hover:text-accent transition-colors duration-150",
					children: model.brand.logoUrl ? /* @__PURE__ */ jsx("img", {
						src: model.brand.logoUrl,
						alt: model.brand.name,
						className: "h-8 w-auto"
					}) : model.brand.name
				})
			}), /* @__PURE__ */ jsxs("div", {
				className: "flex h-full shrink-0 items-center justify-center",
				children: [
					/* @__PURE__ */ jsx(Slot, { name: "nav.items.before" }),
					/* @__PURE__ */ jsx(View, {
						name: "app.search",
						className: navItemClass
					}),
					model.links.map((link) => /* @__PURE__ */ jsx(Tooltip, {
						placement: "bottom",
						content: link.label,
						children: /* @__PURE__ */ jsx(PanelLink, {
							destination: link.destination,
							exact: link.exact,
							className: navItemClass,
							"aria-label": link.label,
							children: /* @__PURE__ */ jsx(LinkIcon, {
								link,
								user: model.user
							})
						})
					}, link.id)),
					model.setScheme && /* @__PURE__ */ jsx(SchemeMenu, {
						model,
						setScheme: model.setScheme
					}),
					/* @__PURE__ */ jsx(Tooltip, {
						placement: "bottom",
						content: "Sign Out",
						children: /* @__PURE__ */ jsx("button", {
							type: "button",
							"aria-label": "Sign Out",
							onClick: model.signOut,
							className: navItemClass,
							children: /* @__PURE__ */ jsx(Icon, { icon: LogOut })
						})
					}),
					/* @__PURE__ */ jsx(Slot, { name: "nav.items.after" })
				]
			})]
		})]
	});
}
function AppLayout({ model, className, children }) {
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [/* @__PURE__ */ jsx(NavigationBar, { model }), /* @__PURE__ */ jsx(Main, { children })]
	});
}
//#endregion
export { AppLayout as default };

//# sourceMappingURL=AppLayout-i6-BOrJ8.js.map