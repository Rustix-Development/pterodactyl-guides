import { ut as NavigationLabel } from "./sdk-Chrtpiam.js";
import { jsx } from "react/jsx-runtime";
//#region ../../resources/scripts/themes/classic/views/layout/tabLabel.tsx
/** Classic's tabs name the panel's own pages in text; extension screens keep their icons. */
var tabLabel = (item, state) => /* @__PURE__ */ jsx(NavigationLabel, {
	label: item.label,
	group: item.group,
	icon: item.extensionId === void 0 ? null : item.icon,
	badge: state.badge
});
//#endregion
export { tabLabel as t };

//# sourceMappingURL=tabLabel-DAPdSje5.js.map