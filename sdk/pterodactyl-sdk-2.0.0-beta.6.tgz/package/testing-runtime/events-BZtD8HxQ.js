import { l as useSocketConnected, u as useSocketInstance } from "./server-U1WA-Nu8.js";
import { useEffect, useRef } from "react";
//#region ../../resources/scripts/plugins/useWebsocketEvent.ts
var useWebsocketEvent = (event, callback) => {
	const connected = useSocketConnected();
	const instance = useSocketInstance();
	const savedCallback = useRef(callback);
	useEffect(() => {
		savedCallback.current = callback;
	}, [callback]);
	return useEffect(() => {
		const eventListener = (data) => savedCallback.current(data);
		if (connected && instance) instance.addListener(event, eventListener);
		return () => {
			instance?.removeListener(event, eventListener);
		};
	}, [
		event,
		connected,
		instance
	]);
};
//#endregion
//#region ../../resources/scripts/components/server/events.ts
var SocketEvent = /* @__PURE__ */ function(SocketEvent) {
	SocketEvent["DAEMON_MESSAGE"] = "daemon message";
	SocketEvent["DAEMON_ERROR"] = "daemon error";
	SocketEvent["INSTALL_OUTPUT"] = "install output";
	SocketEvent["INSTALL_STARTED"] = "install started";
	SocketEvent["INSTALL_COMPLETED"] = "install completed";
	SocketEvent["CONSOLE_OUTPUT"] = "console output";
	SocketEvent["STATUS"] = "status";
	SocketEvent["STATS"] = "stats";
	SocketEvent["TRANSFER_LOGS"] = "transfer logs";
	SocketEvent["TRANSFER_STATUS"] = "transfer status";
	SocketEvent["BACKUP_COMPLETED"] = "backup completed";
	SocketEvent["BACKUP_RESTORE_COMPLETED"] = "backup restore completed";
	return SocketEvent;
}({});
var SocketRequest = /* @__PURE__ */ function(SocketRequest) {
	SocketRequest["SEND_COMMAND"] = "send command";
	SocketRequest["SEND_LOGS"] = "send logs";
	SocketRequest["SEND_STATS"] = "send stats";
	SocketRequest["SET_STATE"] = "set state";
	return SocketRequest;
}({});
//#endregion
export { SocketRequest as n, useWebsocketEvent as r, SocketEvent as t };

//# sourceMappingURL=events-BZtD8HxQ.js.map