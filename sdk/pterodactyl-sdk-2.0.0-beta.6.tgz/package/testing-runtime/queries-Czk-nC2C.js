import { Ct as clientToggleBackupLockMutation, E as clientDeleteServerBackupMutation, Pt as clientGetBackupDownloadUrl, g as clientCreateServerBackupMutation, gt as clientRestoreServerBackupMutation, nt as clientListServerBackupsOptions, rt as clientListServerBackupsQueryKey, t as notifyHttpError } from "./notifications-Ebj0Q0Io.js";
import { f as useUpdateCurrentServer } from "./queries-D_-2KdyF.js";
import "./generated-curw-uY5.js";
import { r as updateListItems } from "./queryData-DzPdESJr.js";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/server/backups/queries.ts
var serverBackupsInput = (uuid, page) => ({
	path: { server_uuid: uuid },
	query: { page }
});
var createServerBackupInput = (uuid, values) => ({
	path: { server_uuid: uuid },
	body: {
		name: values.name,
		ignored: values.ignored,
		is_locked: values.isLocked
	}
});
var deleteServerBackupInput = (uuid, backup) => ({ path: {
	server_uuid: uuid,
	backup_uuid: backup.attributes.uuid
} });
var restoreServerBackupInput = (uuid, backup, truncate) => ({
	path: {
		server_uuid: uuid,
		backup_uuid: backup.attributes.uuid
	},
	body: { truncate }
});
var toggleServerBackupLockInput = (uuid, backup) => ({ path: {
	server_uuid: uuid,
	backup_uuid: backup.attributes.uuid
} });
var backupDownloadUrlInput = (uuid, backup) => ({ path: {
	server_uuid: uuid,
	backup_uuid: backup.attributes.uuid
} });
var serverBackupsQueryOptions = (uuid, page = 1) => clientListServerBackupsOptions(serverBackupsInput(uuid, page));
var useServerBackups = (uuid, page) => useQuery({
	...serverBackupsQueryOptions(uuid, page),
	enabled: uuid.length > 0
});
var updateServerBackup = (queryClient, uuid, page, backupId, updater) => {
	queryClient.cancelQueries({ queryKey: clientListServerBackupsQueryKey(serverBackupsInput(uuid, page)) });
	queryClient.setQueryData(clientListServerBackupsQueryKey(serverBackupsInput(uuid, page)), (current) => updateListItems(current, (backup) => backup.attributes.uuid === backupId, updater));
};
var useCreateServerBackup = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateServerBackupMutation(),
		onSuccess: async (backup, { path }) => {
			await queryClient.invalidateQueries({ queryKey: clientListServerBackupsQueryKey({ path: { server_uuid: path.server_uuid } }) });
			toast.success("Backup started", { description: `${backup.attributes.name} is being created.` });
		},
		onError: (error) => notifyHttpError(error, "Unable to create backup")
	});
};
/** Reports failures; the caller announces success, since it knows the backup's name. */
var useDeleteServerBackup = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDeleteServerBackupMutation(),
		onSuccess: (_data, { path }) => queryClient.invalidateQueries({ queryKey: clientListServerBackupsQueryKey({ path: { server_uuid: path.server_uuid } }) }),
		onError: (error) => notifyHttpError(error, "Unable to delete backup")
	});
};
/** Reports failures; the caller announces success, since it knows the backup's name. */
var useRestoreServerBackup = () => {
	const updateCurrentServer = useUpdateCurrentServer();
	return useMutation({
		...clientRestoreServerBackupMutation(),
		onSuccess: () => {
			updateCurrentServer((server) => ({
				...server,
				attributes: {
					...server.attributes,
					status: "restoring_backup"
				}
			}));
		},
		onError: (error) => notifyHttpError(error, "Unable to restore backup")
	});
};
var useToggleServerBackupLock = (page) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientToggleBackupLockMutation(),
		onSuccess: (updated, { path }) => {
			updateServerBackup(queryClient, path.server_uuid, page, path.backup_uuid, () => updated);
			toast.success(updated.attributes.is_locked ? "Backup locked" : "Backup unlocked");
		},
		onError: (error) => notifyHttpError(error, "Unable to update backup lock")
	});
};
var useBackupDownloadUrl = () => useMutation({
	mutationFn: async (input) => {
		const { data } = await clientGetBackupDownloadUrl(input);
		if (!data) throw new Error("Backup download URL response did not include data.");
		return data.attributes.url;
	},
	onError: (error) => notifyHttpError(error, "Unable to create backup download")
});
//#endregion
export { serverBackupsQueryOptions as a, useBackupDownloadUrl as c, useRestoreServerBackup as d, useServerBackups as f, restoreServerBackupInput as i, useCreateServerBackup as l, createServerBackupInput as n, toggleServerBackupLockInput as o, useToggleServerBackupLock as p, deleteServerBackupInput as r, updateServerBackup as s, backupDownloadUrlInput as t, useDeleteServerBackup as u };

//# sourceMappingURL=queries-Czk-nC2C.js.map