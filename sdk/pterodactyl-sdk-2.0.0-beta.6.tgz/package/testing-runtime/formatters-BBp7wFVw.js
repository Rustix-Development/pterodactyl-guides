//#region ../../resources/scripts/lib/formatters.ts
var _CONVERSION_UNIT = 1024;
function mbToBytes(megabytes) {
	return Math.floor(megabytes * _CONVERSION_UNIT * _CONVERSION_UNIT);
}
var _BYTE_UNITS = [
	"Bytes",
	"KiB",
	"MiB",
	"GiB",
	"TiB"
];
function byteUnitIndex(bytes) {
	return Math.min(Math.floor(Math.log(bytes) / Math.log(_CONVERSION_UNIT)), _BYTE_UNITS.length - 1);
}
function scaleBytes(bytes, unit, decimals) {
	return Number((bytes / _CONVERSION_UNIT ** unit).toFixed(Math.floor(Math.max(0, decimals))));
}
function bytesToString(bytes, decimals = 2) {
	if (bytes < 1) return "0 Bytes";
	const i = byteUnitIndex(bytes);
	return `${scaleBytes(bytes, i, decimals)} ${_BYTE_UNITS[i]}`;
}
/** Wraps IPv6 addresses in brackets. */
function ip(value) {
	return /([a-f0-9:]+:+)+[a-f0-9]+/.test(value) ? `[${value}]` : value;
}
//#endregion
export { ip as n, mbToBytes as r, bytesToString as t };

//# sourceMappingURL=formatters-BBp7wFVw.js.map