import { a as Spinner, f as ErrorBoundary, n as ButtonWithVariants, p as Icon } from "./Button-BzlrfY24.js";
import { At as Code$1, Dt as ServerContentBlock, H as Tooltip, Ot as PageContentBlock, Rt as SpinnerOverlay, St as ServerError, Tt as Portal, at as EmptyTitle, dt as ContextDropdownMenu, et as Empty, ft as DropdownMenuItem, h as fromNow, ht as NewButton, it as EmptyMedia, m as formatDate, nt as EmptyDescription, pt as DropdownMenuWithItems, r as cn, rt as EmptyHeader } from "./sdk-Chrtpiam.js";
import { t as PanelLink } from "./navigation-9aP-0Hbq.js";
import { a as Slot, c as View } from "./theme-Cgy7R6cy.js";
import { i as Checkbox, n as useAppForm, o as Select, r as Form } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { t as bytesToString } from "./formatters-BBp7wFVw.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { t as usePending } from "./usePending-DoheVZuN.js";
import { Fragment, createContext, memo, use, useEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { CloudUpload, Copy, CornerLeftUp, FileArchive, FileCode, FileDown, FileInput, FileText, Folder, FolderOpen, MoreHorizontal, PackageOpen, Pencil, Trash2, X } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/server/files/FilesPage.tsx
function FilesPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model: {
			...model,
			loading: false
		},
		className,
		children: /* @__PURE__ */ jsxs(ServerContentBlock, {
			title: "File Manager",
			className,
			children: [
				/* @__PURE__ */ jsx(Slot, { name: "server.files.before" }),
				/* @__PURE__ */ jsx(View, { name: "server.files.manager" }),
				/* @__PURE__ */ jsx(Slot, { name: "server.files.after" })
			]
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileManager.tsx
/** The browser's pieces are views of their own, so a theme replaces one and keeps the others. */
function FileManager({ className, model }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn("min-w-0", className),
		children: [
			/* @__PURE__ */ jsx(View, {
				name: "server.files.manager.toolbar",
				model
			}),
			/* @__PURE__ */ jsx(View, {
				name: "server.files.manager.list",
				model
			}),
			/* @__PURE__ */ jsx(View, {
				name: "server.files.manager.selection",
				model
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/Breadcrumbs.tsx
var linkClass = "px-1 text-foreground no-underline transition-colors duration-150 hover:text-accent";
function Breadcrumbs({ crumbs, file, children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "flex grow-0 items-center text-sm text-muted-foreground overflow-x-hidden",
		children: [
			children || /* @__PURE__ */ jsx("div", { className: "w-12" }),
			"/",
			/* @__PURE__ */ jsx("span", {
				className: "px-1 text-muted-foreground",
				children: "home"
			}),
			"/",
			crumbs.map(({ name, path, destination }) => destination ? /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PanelLink, {
				destination,
				className: linkClass,
				children: name
			}), "/"] }, path) : /* @__PURE__ */ jsx("span", {
				className: "px-1 text-muted-foreground",
				children: name
			}, path)),
			file && /* @__PURE__ */ jsx("span", {
				className: "px-1 text-muted-foreground",
				children: file
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileDialogs.tsx
/** Renames one file, or moves files to a path relative to the current directory. */
function RenameDialog({ model, files, move, ...props }) {
	const form = useAppForm({
		defaultValues: { name: files.length > 1 ? "" : files[0] || "" },
		onSubmit: async ({ value: { name } }) => {
			await (move ? model.actions.move(files, name) : model.actions.rename(files.map((from) => ({
				from,
				to: name
			})))).catch(() => {});
			props.onClose();
		}
	});
	return /* @__PURE__ */ jsx(form.Subscribe, {
		selector: (state) => state.isSubmitting,
		children: (isSubmitting) => /* @__PURE__ */ jsxs(Dialog, {
			...props,
			preventExternalClose: isSubmitting,
			hideCloseIcon: isSubmitting,
			children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: isSubmitting }), /* @__PURE__ */ jsxs(Form, {
				form,
				className: "m-0",
				children: [/* @__PURE__ */ jsxs("div", {
					className: cn("flex flex-wrap", move ? "items-center" : "items-end"),
					children: [/* @__PURE__ */ jsx("div", {
						className: "w-full sm:flex-1 sm:mr-4",
						children: /* @__PURE__ */ jsx(form.AppField, {
							name: "name",
							children: (field) => /* @__PURE__ */ jsx(field.TextField, {
								type: "string",
								id: "file_name",
								label: "File Name",
								description: move ? "Enter the new name and directory of this file or folder, relative to the current directory." : void 0,
								autoFocus: true
							})
						})
					}), /* @__PURE__ */ jsx("div", {
						className: "w-full sm:w-auto mt-4 sm:mt-0",
						children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
							className: "w-full",
							children: move ? "Move" : "Rename"
						}) })
					})]
				}), move && /* @__PURE__ */ jsx(form.Subscribe, {
					selector: (state) => state.values.name,
					children: (name) => /* @__PURE__ */ jsxs("p", {
						className: "text-xs mt-2 text-muted-foreground",
						children: [
							/* @__PURE__ */ jsx("strong", {
								className: "text-foreground",
								children: "New location:"
							}),
							"\xA0/home/container/",
							model.resolve(name)
						]
					})
				})]
			})]
		})
	});
}
function ChmodDialog({ model, files, ...props }) {
	const form = useAppForm({
		defaultValues: { mode: files.length > 1 ? "" : files[0].mode || "" },
		onSubmit: async ({ value: { mode } }) => {
			await model.actions.chmod(files.map(({ file }) => ({
				file,
				mode
			}))).catch(() => {});
			props.onClose();
		}
	});
	return /* @__PURE__ */ jsx(form.Subscribe, {
		selector: (state) => state.isSubmitting,
		children: (isSubmitting) => /* @__PURE__ */ jsxs(Dialog, {
			...props,
			preventExternalClose: isSubmitting,
			hideCloseIcon: isSubmitting,
			children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: isSubmitting }), /* @__PURE__ */ jsx(Form, {
				form,
				className: "m-0",
				children: /* @__PURE__ */ jsxs("div", {
					className: "flex flex-wrap items-end",
					children: [/* @__PURE__ */ jsx("div", {
						className: "w-full sm:flex-1 sm:mr-4",
						children: /* @__PURE__ */ jsx(form.AppField, {
							name: "mode",
							children: (field) => /* @__PURE__ */ jsx(field.TextField, {
								type: "string",
								id: "file_mode",
								label: "File Mode",
								autoFocus: true
							})
						})
					}), /* @__PURE__ */ jsx("div", {
						className: "w-full sm:w-auto mt-4 sm:mt-0",
						children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
							className: "w-full",
							children: "Update"
						}) })
					})]
				})
			})]
		})
	});
}
function NewDirectoryForm({ model, onClose }) {
	const form = useAppForm({
		defaultValues: { directoryName: "" },
		onSubmit: async ({ value }) => {
			try {
				await model.actions.createDirectory(value.directoryName);
				onClose();
			} catch {}
		}
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(Form, {
		form,
		className: "m-0",
		children: [/* @__PURE__ */ jsx(form.AppField, {
			name: "directoryName",
			validators: { onChange: ({ value }) => value.length >= 1 ? void 0 : "A valid directory name must be provided." },
			children: (field) => /* @__PURE__ */ jsx(field.TextField, {
				autoFocus: true,
				id: "directoryName",
				label: "Name"
			})
		}), /* @__PURE__ */ jsxs("p", {
			className: "mt-2 text-sm md:text-base break-all",
			children: [/* @__PURE__ */ jsx("span", {
				className: "text-foreground",
				children: "This directory will be created as\xA0"
			}), /* @__PURE__ */ jsxs(Code$1, { children: ["/home/container/", /* @__PURE__ */ jsx(form.Subscribe, {
				selector: (state) => state.values.directoryName,
				children: (name) => /* @__PURE__ */ jsx("span", {
					className: "text-accent",
					children: model.resolve(name)
				})
			})] })]
		})]
	}), /* @__PURE__ */ jsxs(Dialog.Footer, { children: [/* @__PURE__ */ jsx(ButtonWithVariants.Text, {
		className: "w-full sm:w-auto",
		onClick: onClose,
		children: "Cancel"
	}), /* @__PURE__ */ jsx(ButtonWithVariants, {
		className: "w-full sm:w-auto",
		onClick: () => form.handleSubmit(),
		children: "Create"
	})] })] });
}
function NewDirectoryButton({ model }) {
	return /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(NewButton, {
			onClick,
			children: "New folder"
		}),
		children: ({ open, onClose }) => /* @__PURE__ */ jsx(Dialog, {
			open,
			onClose,
			title: "Create folder",
			children: /* @__PURE__ */ jsx(NewDirectoryForm, {
				model,
				onClose
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/Uploads.tsx
var isFileOrDirectory = (event) => event.dataTransfer?.types.some((value) => value.toLowerCase() === "files") ?? false;
/** Shows the drop target while files are dragged over the window. */
function useDropOverlay() {
	const [open, setOpen] = useState(false);
	useEffect(() => {
		const enter = (event) => {
			event.preventDefault();
			event.stopPropagation();
			if (isFileOrDirectory(event)) setOpen(true);
		};
		const hide = () => setOpen(false);
		window.addEventListener("dragenter", enter, { capture: true });
		window.addEventListener("dragexit", hide, { capture: true });
		window.addEventListener("keydown", hide);
		return () => {
			window.removeEventListener("dragenter", enter, true);
			window.removeEventListener("dragexit", hide, true);
			window.removeEventListener("keydown", hide);
		};
	}, []);
	return [open, setOpen];
}
function UploadButton({ model }) {
	const input = useRef(null);
	const [dropping, setDropping] = useDropOverlay();
	const upload = (files) => void model.actions.upload([...files]).catch(() => {});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(Portal, { children: dropping && /* @__PURE__ */ jsx("div", {
			className: "fixed z-50 overflow-auto flex w-full inset-0 bg-background/70",
			onDragOver: (event) => event.preventDefault(),
			onDrop: (event) => {
				event.preventDefault();
				event.stopPropagation();
				setDropping(false);
				if (!event.dataTransfer?.files.length) return;
				upload(event.dataTransfer.files);
			},
			children: /* @__PURE__ */ jsx("div", {
				className: "w-full flex items-center justify-center pointer-events-none",
				children: /* @__PURE__ */ jsxs("div", {
					className: "flex items-center space-x-4 bg-muted w-full ring-4 ring-ring/50 rounded-sm p-6 mx-10 max-w-sm",
					children: [/* @__PURE__ */ jsx(CloudUpload, { className: "w-10 h-10 shrink-0" }), /* @__PURE__ */ jsx("p", {
						className: "font-header flex-1 text-lg text-foreground text-center",
						children: "Drag and drop files to upload."
					})]
				})
			})
		}) }),
		/* @__PURE__ */ jsx("input", {
			type: "file",
			ref: input,
			className: "hidden",
			"aria-label": "Upload files",
			onChange: (event) => {
				if (!event.currentTarget.files) return;
				upload(event.currentTarget.files);
				event.currentTarget.value = "";
			},
			multiple: true
		}),
		/* @__PURE__ */ jsx(NewButton, {
			icon: CloudUpload,
			onClick: () => input.current?.click(),
			children: "Upload"
		})
	] });
}
var svgProps = {
	cx: 16,
	cy: 16,
	r: 14,
	strokeWidth: 3,
	fill: "none",
	stroke: "currentColor"
};
var Progress = ({ progress, className }) => /* @__PURE__ */ jsxs("svg", {
	viewBox: "0 0 32 32",
	className,
	children: [/* @__PURE__ */ jsx("circle", {
		...svgProps,
		className: "opacity-25"
	}), /* @__PURE__ */ jsx("circle", {
		...svgProps,
		stroke: "currentColor",
		strokeDasharray: 28 * Math.PI,
		className: "-rotate-90 origin-[50%_50%] transition-[stroke-dashoffset] duration-300",
		style: { strokeDashoffset: (100 - progress) / 100 * 28 * Math.PI }
	})]
});
var percent = (loaded, total) => total > 0 ? loaded / total * 100 : 0;
function UploadList({ model, onClose }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-2 mt-6",
		children: [model.uploads.map((file) => /* @__PURE__ */ jsxs("div", {
			className: "flex items-center space-x-3 bg-card p-3 rounded-sm",
			children: [
				/* @__PURE__ */ jsx(Tooltip, {
					content: `${Math.floor(percent(file.loaded, file.total))}%`,
					placement: "left",
					children: /* @__PURE__ */ jsx("div", {
						className: "shrink-0",
						children: /* @__PURE__ */ jsx(Progress, {
							progress: percent(file.loaded, file.total),
							className: "w-6 h-6"
						})
					})
				}),
				/* @__PURE__ */ jsx(Code$1, {
					className: "flex-1 truncate",
					children: file.name
				}),
				/* @__PURE__ */ jsx("button", {
					type: "button",
					"aria-label": `Cancel upload of ${file.name}`,
					onClick: () => model.actions.cancelUpload(file.id),
					className: "text-muted-foreground hover:text-foreground transition-colors duration-75",
					children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
				})
			]
		}, file.id)), /* @__PURE__ */ jsxs(Dialog.Footer, { children: [/* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
			isSecondary: true,
			onClick: model.actions.clearUploads,
			children: "Cancel Uploads"
		}), /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
			onClick: onClose,
			children: "Close"
		})] })]
	});
}
function UploadStatus({ model }) {
	const count = model.uploads.length;
	if (count === 0) return null;
	const uploaded = model.uploads.reduce((sum, file) => sum + file.loaded, 0);
	const total = model.uploads.reduce((sum, file) => sum + file.total, 0);
	return /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(Tooltip, {
			content: `${count} files are uploading, click to view`,
			children: /* @__PURE__ */ jsxs("button", {
				type: "button",
				className: "flex items-center justify-center w-10 h-10",
				onClick,
				children: [/* @__PURE__ */ jsx(Progress, {
					progress: percent(uploaded, total),
					className: "w-8 h-8"
				}), /* @__PURE__ */ jsx(CloudUpload, { className: "h-3 absolute mx-auto animate-pulse" })]
			})
		}),
		children: ({ open, onClose }) => /* @__PURE__ */ jsx(Dialog, {
			open,
			onClose,
			title: "File Uploads",
			description: "The following files are being uploaded to your server.",
			children: /* @__PURE__ */ jsx(UploadList, {
				model,
				onClose
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileManagerToolbar.tsx
var managerActionsClass = [
	"grid grid-cols-2 sm:grid-cols-3 w-full gap-4 mb-4",
	"md:flex md:flex-1 md:justify-end md:mb-0",
	"[&_button]:w-full [&_button:first-child]:col-span-2 sm:[&_button:first-child]:col-span-1 md:[&_button]:w-auto"
].join(" ");
function FileManagerToolbar({ model, className }) {
	const { entries, selection } = model;
	return /* @__PURE__ */ jsxs(ErrorBoundary, { children: [/* @__PURE__ */ jsxs("div", {
		className: cn("flex flex-wrap-reverse md:flex-nowrap mb-4", className),
		children: [/* @__PURE__ */ jsx(Breadcrumbs, {
			crumbs: model.breadcrumbs,
			children: /* @__PURE__ */ jsx(Checkbox, {
				className: "mx-4",
				"aria-label": "Select all files",
				checked: entries.length > 0 && selection.length === entries.length,
				indeterminate: selection.length > 0 && selection.length < entries.length,
				onChange: (checked) => model.actions.select(checked ? entries.map((entry) => entry.name) : [])
			})
		}), model.permissions.create && /* @__PURE__ */ jsxs("div", {
			className: managerActionsClass,
			children: [
				/* @__PURE__ */ jsx(UploadStatus, { model }),
				/* @__PURE__ */ jsx(NewDirectoryButton, { model }),
				model.permissions.update && /* @__PURE__ */ jsx(UploadButton, { model }),
				/* @__PURE__ */ jsx(PanelLink, {
					destination: model.newFileDestination,
					children: /* @__PURE__ */ jsx(NewButton, { children: "New file" })
				})
			]
		})]
	}), /* @__PURE__ */ jsx(Slot, {
		name: "server.files.toolbar",
		data: model.slot
	})] });
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileRows.tsx
var fileRowClass = "flex items-center cursor-pointer bg-card rounded-xs mb-px text-sm no-underline hover:text-foreground hover:bg-popover";
var detailsClass = "flex flex-1 items-center text-muted-foreground no-underline px-4 py-2 overflow-hidden truncate";
var RowActionsContext = createContext(null);
var SlotContext = createContext(null);
function useRowActions() {
	const actions = use(RowActionsContext);
	if (!actions) throw new Error("File rows render inside the file list.");
	return actions;
}
/** Renders the row dialogs once for every row below it. */
function RowActionsProvider({ model, children }) {
	const [dialog, setDialog] = useState(null);
	const [target, setTarget] = useState(null);
	const [pending, run] = usePending();
	const selection = useRef(model.selection);
	const { actions, permissions } = model;
	useEffect(() => {
		selection.current = model.selection;
	});
	const value = useMemo(() => ({
		permissions,
		actions,
		open: (next, entry) => {
			setTarget(entry);
			setDialog(next);
		},
		run,
		toggle: (name, selected) => actions.select(selected ? [...selection.current.filter((file) => file !== name), name] : selection.current.filter((file) => file !== name))
	}), [
		actions,
		permissions,
		run
	]);
	const close = () => setDialog(null);
	const name = target?.name ?? "";
	return /* @__PURE__ */ jsx(RowActionsContext.Provider, {
		value,
		children: /* @__PURE__ */ jsxs(SlotContext.Provider, {
			value: model.slot,
			children: [
				children,
				/* @__PURE__ */ jsxs(Dialog.Confirm, {
					open: dialog === "delete",
					onClose: close,
					title: `Delete ${target?.kind === "directory" ? "Directory" : "File"}`,
					confirm: "Delete",
					onConfirmed: () => {
						close();
						actions.remove([name]).catch(() => {});
					},
					children: [
						"You will not be able to recover the contents of\xA0",
						/* @__PURE__ */ jsx("span", {
							className: "font-semibold text-foreground",
							children: name
						}),
						" once deleted."
					]
				}),
				target && dialog === "chmod" && /* @__PURE__ */ jsx(ChmodDialog, {
					model,
					open: true,
					files: [{
						file: name,
						mode: target.modeBits
					}],
					onClose: close
				}, name),
				target && (dialog === "rename" || dialog === "move") && /* @__PURE__ */ jsx(RenameDialog, {
					model,
					open: true,
					files: [name],
					move: dialog === "move",
					onClose: close
				}, `${dialog}:${name}`),
				/* @__PURE__ */ jsx(SpinnerOverlay, {
					visible: pending,
					fixed: true,
					size: "large"
				})
			]
		})
	});
}
function ActionItems({ entry }) {
	const { permissions, actions, open, run } = useRowActions();
	const isFile = entry.kind !== "directory";
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		permissions.update && /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx(DropdownMenuItem, {
				onClick: () => open("rename", entry),
				icon: Pencil,
				description: "Change item name",
				children: "Rename"
			}),
			/* @__PURE__ */ jsx(DropdownMenuItem, {
				onClick: () => open("move", entry),
				icon: CornerLeftUp,
				description: "Move to a path",
				children: "Move"
			}),
			/* @__PURE__ */ jsx(DropdownMenuItem, {
				onClick: () => open("chmod", entry),
				icon: FileCode,
				description: "Edit mode bits",
				children: "Permissions"
			})
		] }),
		isFile && permissions.create && /* @__PURE__ */ jsx(DropdownMenuItem, {
			onClick: () => run(actions.copy(entry.name)),
			icon: Copy,
			description: "Duplicate in place",
			children: "Copy"
		}),
		entry.extractable ? permissions.create && permissions.update && /* @__PURE__ */ jsx(DropdownMenuItem, {
			onClick: () => run(actions.extract(entry.name)),
			icon: PackageOpen,
			description: "Extract contents",
			children: "Unarchive"
		}) : permissions.archive && /* @__PURE__ */ jsx(DropdownMenuItem, {
			onClick: () => run(actions.archive([entry.name])),
			icon: FileArchive,
			description: "Compress item",
			children: "Archive"
		}),
		isFile && /* @__PURE__ */ jsx(DropdownMenuItem, {
			onClick: () => run(actions.download(entry.name)),
			icon: FileDown,
			description: "Save locally",
			children: "Download"
		}),
		permissions.delete && /* @__PURE__ */ jsx(DropdownMenuItem, {
			onClick: () => open("delete", entry),
			icon: Trash2,
			danger: true,
			description: "Permanently remove",
			className: "mt-1 border-t border-border/70 pt-3",
			children: "Delete"
		})
	] });
}
function RowActionsSlot({ entry }) {
	const slot = use(SlotContext);
	return slot && /* @__PURE__ */ jsx(Slot, {
		name: "server.files.rowActions",
		data: {
			...slot,
			file: entry.file
		}
	});
}
function Clickable({ entry, children }) {
	if (!entry.destination) return /* @__PURE__ */ jsx("div", {
		className: cn(detailsClass, "cursor-default"),
		children
	});
	return /* @__PURE__ */ jsx(PanelLink, {
		"aria-label": entry.name,
		className: detailsClass,
		destination: entry.destination,
		children
	});
}
var FileRow = memo(({ entry, selected }) => {
	const { toggle } = useRowActions();
	const items = /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionItems, { entry }), /* @__PURE__ */ jsx(RowActionsSlot, { entry })] });
	return /* @__PURE__ */ jsxs(ContextDropdownMenu, {
		className: fileRowClass,
		menuClassName: "w-64",
		items,
		children: [
			/* @__PURE__ */ jsx("div", {
				className: "flex-none px-4 py-2 absolute self-center z-30",
				children: /* @__PURE__ */ jsx(Checkbox, {
					name: "selectedFiles",
					value: entry.name,
					"aria-label": `Select ${entry.name}`,
					checked: selected,
					onChange: (checked) => toggle(entry.name, checked)
				})
			}),
			/* @__PURE__ */ jsx(Clickable, {
				entry,
				children: /* @__PURE__ */ jsx(View, {
					name: "server.files.details",
					file: entry.file
				})
			}),
			/* @__PURE__ */ jsx(DropdownMenuWithItems, {
				className: "w-64",
				triggerClassName: "mr-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",
				triggerContent: /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Icon, {
					icon: MoreHorizontal,
					className: "h-4 w-4"
				}), /* @__PURE__ */ jsx("span", {
					className: "sr-only",
					children: "Open file options"
				})] }),
				children: items
			})
		]
	});
});
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileManagerList.tsx
var entryKey = ({ kind, name }) => `${kind === "directory" ? "dir" : "file"}_${name}`;
function FileManagerList({ model, className }) {
	if (model.loading) return /* @__PURE__ */ jsx(Spinner, {
		size: "large",
		centered: true
	});
	if (!model.entries.length) return /* @__PURE__ */ jsx(Empty, {
		className: cn("border", className),
		children: /* @__PURE__ */ jsxs(EmptyHeader, { children: [
			/* @__PURE__ */ jsx(EmptyMedia, {
				variant: "icon",
				children: /* @__PURE__ */ jsx(FolderOpen, {})
			}),
			/* @__PURE__ */ jsx(EmptyTitle, { children: "This folder is empty" }),
			/* @__PURE__ */ jsx(EmptyDescription, { children: model.permissions.create ? "Upload files or create a new file or folder to get started." : "There are no files in this folder." })
		] })
	});
	const selected = new Set(model.selection);
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [model.truncated && /* @__PURE__ */ jsx("div", {
			className: "rounded-sm bg-warning mb-px p-3",
			children: /* @__PURE__ */ jsx("p", {
				className: "text-warning-foreground text-sm text-center",
				children: "This directory is too large to display in the browser, limiting output to first 250 files."
			})
		}), /* @__PURE__ */ jsx(RowActionsProvider, {
			model,
			children: model.entries.map((entry) => /* @__PURE__ */ jsx(FileRow, {
				entry,
				selected: selected.has(entry.name)
			}, entryKey(entry)))
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileManagerSelection.tsx
function MassActions({ model, className }) {
	const [pending, run] = usePending();
	const { selection, actions } = model;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("pointer-events-none fixed bottom-0 z-20 left-0 right-0 flex justify-center", className),
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, {
			visible: pending,
			size: "large",
			fixed: true
		}), /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx("div", {
			className: "pointer-events-none fixed bottom-0 mb-6 flex justify-center w-full z-50",
			children: selection.length > 0 && /* @__PURE__ */ jsxs("div", {
				className: "flex items-center space-x-4 pointer-events-auto rounded-sm p-4 bg-background/50",
				children: [
					/* @__PURE__ */ jsx(Slot, {
						name: "server.files.selectionActions",
						data: model.slot
					}),
					/* @__PURE__ */ jsx(Dialog.Trigger, {
						trigger: ({ onClick }) => /* @__PURE__ */ jsx(ButtonWithVariants, {
							onClick,
							children: "Move"
						}),
						children: ({ open, onClose }) => open && /* @__PURE__ */ jsx(RenameDialog, {
							model,
							files: [...selection],
							open,
							move: true,
							onClose
						})
					}),
					/* @__PURE__ */ jsx(ButtonWithVariants, {
						onClick: () => run(actions.archive(selection)),
						children: "Archive"
					}),
					/* @__PURE__ */ jsxs(Dialog.ConfirmTrigger, {
						title: "Delete Files",
						confirm: "Delete",
						trigger: ({ onClick }) => /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
							isSecondary: true,
							onClick,
							children: "Delete"
						}),
						onConfirmed: (_event, close) => {
							close();
							run(actions.remove(selection));
						},
						children: [/* @__PURE__ */ jsxs("p", {
							className: "mb-2",
							children: [
								"Are you sure you want to delete\xA0",
								/* @__PURE__ */ jsxs("span", {
									className: "font-semibold text-foreground",
									children: [selection.length, " files"]
								}),
								"? This is a permanent action and the files cannot be recovered."
							]
						}), /* @__PURE__ */ jsxs("ul", {
							className: "mt-2 mb-0 pl-6 list-disc list-outside",
							children: [selection.slice(0, 15).map((file) => /* @__PURE__ */ jsx("li", { children: file }, file)), selection.length > 15 && /* @__PURE__ */ jsxs("li", { children: [
								"and ",
								selection.length - 15,
								" others"
							] })]
						})]
					})
				]
			})
		}) })]
	});
}
function FileManagerSelection({ model, className }) {
	return model.entries.length > 0 ? /* @__PURE__ */ jsx(MassActions, {
		model,
		className
	}) : null;
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileDetails.tsx
var icons$1 = {
	file: FileText,
	directory: Folder,
	archive: FileArchive,
	symlink: FileInput
};
var HOUR = 3600 * 1e3;
function FileDetails({ className, model }) {
	const hours = Math.trunc((Date.parse(model.modifiedAt) - Date.now()) / HOUR);
	return /* @__PURE__ */ jsxs("div", {
		className: cn("flex flex-1 items-center min-w-0", className),
		children: [
			/* @__PURE__ */ jsx("div", {
				className: "flex-none text-muted-foreground ml-6 mr-4 text-lg pl-3",
				children: /* @__PURE__ */ jsx(Icon, { icon: icons$1[model.kind] })
			}),
			/* @__PURE__ */ jsx("div", {
				className: "flex-1 truncate",
				children: model.name
			}),
			model.kind !== "directory" && /* @__PURE__ */ jsx("div", {
				className: "w-1/6 text-right mr-4 hidden sm:block",
				children: bytesToString(model.size)
			}),
			/* @__PURE__ */ jsx("div", {
				className: "w-1/5 text-right mr-4 hidden md:block",
				title: model.modifiedAt,
				children: Math.abs(hours) > 48 ? formatDate(model.modifiedAt, "MMM Do, YYYY h:mmA") : fromNow(model.modifiedAt)
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/EditorPage.tsx
function EditorPage({ model, className }) {
	if (model.error !== null) return /* @__PURE__ */ jsx(ServerError, {
		message: model.error,
		onBack: model.back,
		className
	});
	return /* @__PURE__ */ jsxs(PageContentBlock, {
		className,
		children: [/* @__PURE__ */ jsx(ErrorBoundary, { children: /* @__PURE__ */ jsx("div", {
			className: "mb-4",
			children: /* @__PURE__ */ jsx(Breadcrumbs, {
				crumbs: model.breadcrumbs,
				file: model.file
			})
		}) }), model.loading ? /* @__PURE__ */ jsx(Spinner, {
			size: "large",
			centered: true
		}) : /* @__PURE__ */ jsx(View, { name: "server.files.editor" })]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileEditor.tsx
/** The editor's pieces are views of their own, so a theme replaces one and keeps the others. */
function FileEditor({ className, model }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn("min-w-0", className),
		children: [
			/* @__PURE__ */ jsx(View, {
				name: "server.files.editor.notice",
				model
			}),
			/* @__PURE__ */ jsx(View, {
				name: "server.files.editor.canvas",
				model
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-4 flex flex-col gap-3 sm:flex-row sm:items-stretch sm:justify-end",
				children: [/* @__PURE__ */ jsx(View, {
					name: "server.files.editor.language",
					model
				}), /* @__PURE__ */ jsx(View, {
					name: "server.files.editor.actions",
					model
				})]
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileEditorNotice.tsx
var codeClass = "font-mono bg-muted rounded-sm py-px px-1";
function FileEditorNotice({ model, className }) {
	return model.name.endsWith(".pteroignore") ? /* @__PURE__ */ jsx("div", {
		className: cn("mb-4 p-4 border-l-4 bg-muted rounded-sm border-accent", className),
		children: /* @__PURE__ */ jsxs("p", {
			className: "text-muted-foreground text-sm",
			children: [
				"You're editing a ",
				/* @__PURE__ */ jsx("code", {
					className: codeClass,
					children: ".pteroignore"
				}),
				" file. Any files or directories listed in here will be excluded from backups. Wildcards are supported by using an asterisk (",
				/* @__PURE__ */ jsx("code", {
					className: codeClass,
					children: "*"
				}),
				"). You can negate a prior rule by prepending an exclamation point (",
				/* @__PURE__ */ jsx("code", {
					className: codeClass,
					children: "!"
				}),
				")."
			]
		})
	}) : null;
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileEditorCanvas.tsx
function FileEditorCanvas({ model, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn("relative", className),
		"aria-busy": model.saving,
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.saving }), /* @__PURE__ */ jsx(model.Editor, {})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileEditorLanguage.tsx
function FileEditorLanguage({ model, className }) {
	return /* @__PURE__ */ jsx("div", {
		className: cn("w-full min-w-0 rounded-sm bg-muted sm:w-64", className),
		children: /* @__PURE__ */ jsx(Select, {
			value: model.language,
			onChange: (value) => model.setLanguage(String(value)),
			disabled: model.saving,
			options: model.languages.map((language) => ({
				value: language.mime,
				label: language.name
			}))
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/files/FileEditorActions.tsx
function FileEditorActions({ model, className }) {
	return model.readOnly ? null : /* @__PURE__ */ jsx(ButtonWithVariants, {
		className: cn("w-full sm:w-auto", className),
		disabled: model.saving,
		isLoading: model.saving,
		onClick: () => void model.save(),
		children: model.isNew ? "Create File" : "Save Content"
	});
}
//#endregion
export { EditorPage, FileDetails, FileEditor, FileEditorActions, FileEditorCanvas, FileEditorLanguage, FileEditorNotice, FileManager, FileManagerList, FileManagerSelection, FileManagerToolbar, FilesPage };

//# sourceMappingURL=files-CIybYHkH.js.map