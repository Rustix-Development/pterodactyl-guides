import { a as http, i as createClientConfig, n as createClient, o as httpErrorToHuman, r as createConfig, t as client } from "./client.gen-Ci-zROOW.js";
import { t as queryClient } from "./queryClient-CU2lXun5.js";
export { client, createClient, createClientConfig, createConfig, http, httpErrorToHuman, queryClient };
