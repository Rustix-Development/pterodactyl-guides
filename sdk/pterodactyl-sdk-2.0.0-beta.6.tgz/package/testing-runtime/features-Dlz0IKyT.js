import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { c as useCurrentServerUuid } from "./queries-D_-2KdyF.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { l as useSocketConnected, s as useServerStatus, u as useSocketInstance } from "./server-U1WA-Nu8.js";
import { r as useCurrentUser } from "./queries-BF8_5ZD3.js";
import { E as useDialogState, w as writeFileContentsInput, x as useSaveFileContent } from "./queries-DIMnAeHP.js";
import { a as useUpdateStartupVariable, i as useSetSelectedDockerImage, r as useServerStartup } from "./queries-BuegeFTA.js";
import { n as SocketRequest, r as useWebsocketEvent, t as SocketEvent } from "./events-BZtD8HxQ.js";
import { useEffect, useMemo, useRef, useState } from "react";
//#region ../../resources/scripts/components/server/features/hytaleOauth.ts
var HYTALE_OAUTH_ORIGIN = "https://oauth.accounts.hytale.com";
var HYTALE_DEVICE_VERIFY_PATH = "/oauth2/device/verify";
var hytaleOauthUrlPattern = /https:\/\/oauth\.accounts\.hytale\.com\/oauth2\/device\/verify\?user_code=[\w-]+/;
var extractHytaleOauthUrl = (line) => {
	const match = hytaleOauthUrlPattern.exec(line);
	if (!match) return null;
	const url = new URL(match[0]);
	if (url.origin !== HYTALE_OAUTH_ORIGIN || url.pathname !== HYTALE_DEVICE_VERIFY_PATH || !url.searchParams.get("user_code")) return null;
	return url.href;
};
//#endregion
//#region ../../resources/scripts/components/server/features/useConsolePatternTrigger.ts
var matchesPattern = (line, pattern) => pattern instanceof RegExp ? pattern.test(line) : line.toLowerCase().includes(pattern);
var useConsolePatternTrigger = (patterns, options = {}) => {
	const dialog = useDialogState();
	const { show } = dialog;
	const status = useServerStatus();
	const connected = useSocketConnected();
	const instance = useSocketInstance();
	const onTrigger = useRef(options.onTrigger);
	useEffect(() => {
		onTrigger.current = options.onTrigger;
	}, [options.onTrigger]);
	useEffect(() => {
		if (!connected || !instance || status === "running") return;
		const listener = (line) => {
			if (patterns.some((pattern) => matchesPattern(line, pattern))) {
				onTrigger.current?.(line);
				show();
			}
		};
		instance.addListener(SocketEvent.CONSOLE_OUTPUT, listener);
		return () => {
			instance.removeListener(SocketEvent.CONSOLE_OUTPUT, listener);
		};
	}, [
		connected,
		instance,
		patterns,
		show,
		status
	]);
	return dialog;
};
//#endregion
//#region ../../resources/scripts/components/server/features/prompts.ts
var eulaErrors = ["you need to agree to the eula in order to run the server"];
var gslTokenErrors = ["(gsl token expired)", "(account not found)"];
var steamDiskSpaceErrors = ["steamcmd needs 250mb of free disk space to update", "0x202 after update job"];
var pidLimitErrors = [
	"pthread_create failed",
	"failed to create thread",
	"unable to create thread",
	"unable to create native thread",
	"unable to create new native thread",
	"exception in thread \"craft async scheduler management thread\""
];
var javaVersionErrors = [
	"minecraft 1.17 requires running the server with java 16 or above",
	"minecraft 1.18 requires running the server with java 17 or above",
	"java.lang.unsupportedclassversionerror",
	"unsupported major.minor version",
	"has been compiled by a more recent version of the java runtime"
];
var hytaleOauthUrlPatterns = [hytaleOauthUrlPattern];
function useEulaPrompt() {
	const dialog = useConsolePatternTrigger(eulaErrors);
	const uuid = useCurrentServerUuid();
	const status = useServerStatus();
	const instance = useSocketInstance();
	const { mutateAsync, isPending } = useSaveFileContent();
	const { open, hide } = dialog;
	return useMemo(() => ({
		open,
		close: hide,
		pending: isPending,
		accept: async () => {
			await mutateAsync(writeFileContentsInput(uuid, "eula.txt", "eula=true"));
			if (status === "offline" && instance) instance.send(SocketRequest.SET_STATE, "restart");
			hide();
		}
	}), [
		open,
		hide,
		isPending,
		mutateAsync,
		uuid,
		status,
		instance
	]);
}
function useGslTokenPrompt() {
	const { open, hide } = useConsolePatternTrigger(gslTokenErrors);
	const uuid = useCurrentServerUuid();
	const instance = useSocketInstance();
	const { mutateAsync, isPending } = useUpdateStartupVariable(uuid);
	return useMemo(() => ({
		open,
		close: hide,
		pending: isPending,
		submit: async (token) => {
			await mutateAsync({
				path: { server_uuid: uuid },
				body: {
					key: "STEAM_ACC",
					value: token
				}
			});
			instance?.send(SocketRequest.SET_STATE, "restart");
			hide();
		}
	}), [
		open,
		hide,
		isPending,
		mutateAsync,
		uuid,
		instance
	]);
}
function useLimitPrompt(patterns) {
	const { open, hide } = useConsolePatternTrigger(patterns);
	const { rootAdmin } = useCurrentUser();
	return useMemo(() => ({
		open,
		close: hide,
		admin: rootAdmin
	}), [
		open,
		hide,
		rootAdmin
	]);
}
var usePidLimitPrompt = () => useLimitPrompt(pidLimitErrors);
var useSteamDiskSpacePrompt = () => useLimitPrompt(steamDiskSpaceErrors);
function useHytaleOauthPrompt() {
	const [link, setLink] = useState(null);
	const { open, hide } = useConsolePatternTrigger(hytaleOauthUrlPatterns, { onTrigger: (line) => setLink(extractHytaleOauthUrl(line)) });
	return useMemo(() => {
		const close = () => {
			hide();
			setLink(null);
		};
		return {
			open,
			close,
			link,
			login: () => {
				if (link) {
					window.open(link, "_blank", "noopener,noreferrer");
					close();
				}
			}
		};
	}, [
		open,
		hide,
		link
	]);
}
function useJavaVersionPrompt() {
	const dialog = useDialogState();
	const [override, setOverride] = useState("");
	const uuid = useCurrentServerUuid();
	const status = useServerStatus();
	const instance = useSocketInstance();
	const [canChangeImage] = usePermissions(["startup.docker-image"]);
	const { mutateAsync, isPending } = useSetSelectedDockerImage(uuid);
	const { data, isFetching } = useServerStartup(uuid, { enabled: dialog.open });
	const { open, show, hide } = dialog;
	useWebsocketEvent(SocketEvent.CONSOLE_OUTPUT, (line) => {
		if (status === "running") return;
		if (javaVersionErrors.some((pattern) => line.toLowerCase().includes(pattern))) {
			setOverride("");
			show();
		}
	});
	return useMemo(() => {
		const images = data ? Object.entries(data.meta?.docker_images ?? {}).map(([label, value]) => ({
			label,
			value
		})) : null;
		const selected = override || images?.[0]?.value || "";
		return {
			open,
			close: hide,
			canChangeImage,
			images,
			loading: !data || isFetching,
			selected,
			select: setOverride,
			pending: isPending,
			update: async () => {
				await mutateAsync({
					path: { server_uuid: uuid },
					body: { docker_image: selected }
				});
				if (status === "offline" && instance) instance.send(SocketRequest.SET_STATE, "restart");
				hide();
			}
		};
	}, [
		open,
		hide,
		canChangeImage,
		data,
		isFetching,
		override,
		isPending,
		mutateAsync,
		uuid,
		status,
		instance
	]);
}
//#endregion
//#region ../../resources/scripts/views/server/features.ts
/** The egg features whose prompt the console opens when the server's output asks for it. */
var SERVER_FEATURES = {
	eula: "server.feature.eula",
	java_version: "server.feature.javaVersion",
	gsl_token: "server.feature.gslToken",
	pid_limit: "server.feature.pidLimit",
	steam_disk_space: "server.feature.steamDiskSpace",
	hytale_oauth: "server.feature.hytaleOauth"
};
/** The prompt views of the features an egg enables. */
function featureViews(eggFeatures) {
	const enabled = new Set(eggFeatures.map((feature) => feature.toLowerCase()));
	return Object.entries(SERVER_FEATURES).flatMap(([feature, view]) => enabled.has(feature) ? [view] : []);
}
var noop = () => {};
var resolved = async () => {};
var opened = {
	open: true,
	close: noop
};
var images = [{
	label: "Java 21",
	value: "ghcr.io/pterodactyl/yolks:java_21"
}, {
	label: "Java 17",
	value: "ghcr.io/pterodactyl/yolks:java_17"
}];
var javaVersion = (canChangeImage = true) => ({
	...opened,
	canChangeImage,
	images,
	loading: false,
	selected: images[0].value,
	select: noop,
	pending: false,
	update: resolved
});
implementViews({
	"server.feature.eula": {
		use: useEulaPrompt,
		fixtures: {
			open: () => ({
				...opened,
				pending: false,
				accept: resolved
			}),
			accepting: () => ({
				...opened,
				pending: true,
				accept: resolved
			})
		}
	},
	"server.feature.javaVersion": {
		use: useJavaVersionPrompt,
		fixtures: {
			open: () => javaVersion(),
			loading: () => ({
				...javaVersion(),
				images: null,
				loading: true
			}),
			noPermission: () => javaVersion(false)
		}
	},
	"server.feature.gslToken": {
		use: useGslTokenPrompt,
		fixtures: { open: () => ({
			...opened,
			pending: false,
			submit: resolved
		}) }
	},
	"server.feature.pidLimit": {
		use: usePidLimitPrompt,
		fixtures: {
			admin: () => ({
				...opened,
				admin: true
			}),
			user: () => ({
				...opened,
				admin: false
			})
		}
	},
	"server.feature.steamDiskSpace": {
		use: useSteamDiskSpacePrompt,
		fixtures: {
			admin: () => ({
				...opened,
				admin: true
			}),
			user: () => ({
				...opened,
				admin: false
			})
		}
	},
	"server.feature.hytaleOauth": {
		use: useHytaleOauthPrompt,
		fixtures: { open: () => ({
			...opened,
			link: "https://oauth.accounts.hytale.com/oauth2/device/verify?user_code=ABCD-1234",
			login: noop
		}) }
	}
});
//#endregion
export { featureViews as n, SERVER_FEATURES as t };

//# sourceMappingURL=features-Dlz0IKyT.js.map