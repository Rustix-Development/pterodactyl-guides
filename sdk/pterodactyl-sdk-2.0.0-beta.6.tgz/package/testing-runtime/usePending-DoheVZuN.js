import { useCallback, useState } from "react";
//#region ../../resources/scripts/themes/classic/views/server/usePending.ts
/** Whether any tracked action is still running; rejections are swallowed, the panel having reported them. */
function usePending() {
	const [count, setCount] = useState(0);
	const track = useCallback((action) => {
		setCount((current) => current + 1);
		action.catch(() => {}).finally(() => setCount((current) => current - 1));
	}, []);
	return [count > 0, track];
}
//#endregion
export { usePending as t };

//# sourceMappingURL=usePending-DoheVZuN.js.map