import { u as isObject } from "./client.gen-Ci-zROOW.js";
import { At as clientUpdateStartupVariableMutation, H as clientGetStartupConfigurationOptions, St as clientSetServerDockerImageMutationKey, U as clientGetStartupConfigurationQueryKey, t as notifyHttpError, xt as clientSetServerDockerImageMutation } from "./notifications-Ebj0Q0Io.js";
import { f as useUpdateCurrentServer } from "./queries-D_-2KdyF.js";
import { t as retryUnlessClientError } from "./queryRetry-CsJb-5Ht.js";
import { r as updateListItems } from "./queryData-DzPdESJr.js";
import { useIsMutating, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/server/startup/queries.ts
var serverStartupInput = (uuid) => ({ path: { server_uuid: uuid } });
var retryStartupRead = retryUnlessClientError(3);
var serverStartupQueryOptions = (uuid) => ({
	...clientGetStartupConfigurationOptions(serverStartupInput(uuid)),
	retry: retryStartupRead
});
var useServerStartup = (uuid, config) => useQuery({
	...serverStartupQueryOptions(uuid),
	enabled: uuid.length > 0 && config?.enabled !== false
});
var useSetSelectedDockerImage = (uuid) => {
	const updateCurrentServer = useUpdateCurrentServer();
	return useMutation({
		...clientSetServerDockerImageMutation(),
		scope: { id: `server-startup:${uuid}` },
		onSuccess: (_data, variables) => {
			updateCurrentServer((server) => ({
				...server,
				attributes: {
					...server.attributes,
					docker_image: variables.body.docker_image
				}
			}));
			toast.success("Docker image updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update Docker image")
	});
};
/** A Docker image change of the server is in flight, whichever component started it. */
var useDockerImagePending = (uuid) => useIsMutating({
	mutationKey: clientSetServerDockerImageMutationKey(),
	predicate: ({ state: { variables } }) => isObject(variables) && "path" in variables && isObject(variables.path) && Reflect.get(variables.path, "server_uuid") === uuid
}) > 0;
var useUpdateStartupVariable = (uuid) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientUpdateStartupVariableMutation(),
		scope: { id: `server-startup:${uuid}` },
		onSuccess: async (resource, variables) => {
			await queryClient.cancelQueries({ queryKey: clientGetStartupConfigurationQueryKey(serverStartupInput(variables.path.server_uuid)) });
			queryClient.setQueryData(clientGetStartupConfigurationQueryKey(serverStartupInput(variables.path.server_uuid)), (data) => {
				const updated = updateListItems(data, (item) => item.attributes.env_variable === resource.attributes.env_variable, () => resource);
				if (!updated?.meta) return updated;
				return {
					...updated,
					meta: {
						...updated.meta,
						startup_command: resource.meta?.startup_command ?? updated.meta.startup_command
					}
				};
			});
		},
		onError: (error) => notifyHttpError(error, "Unable to update startup variable")
	});
};
//#endregion
export { useUpdateStartupVariable as a, useSetSelectedDockerImage as i, useDockerImagePending as n, useServerStartup as r, serverStartupQueryOptions as t };

//# sourceMappingURL=queries-BuegeFTA.js.map