import { a as Spinner } from "./Button-BzlrfY24.js";
import { St as ServerError } from "./sdk-Chrtpiam.js";
import { jsx } from "react/jsx-runtime";
//#region ../../resources/scripts/themes/classic/views/shared/PageStatus.tsx
/** A page's error with a retry, or a spinner while its data loads, in place of the page. */
function PageStatus({ model, className, children }) {
	if (model.error !== null) return /* @__PURE__ */ jsx(ServerError, {
		message: model.error,
		onRetry: model.retry,
		className
	});
	if (model.loading) return /* @__PURE__ */ jsx("div", {
		className,
		children: /* @__PURE__ */ jsx(Spinner, {
			size: "large",
			centered: true
		})
	});
	return children;
}
//#endregion
export { PageStatus as t };

//# sourceMappingURL=PageStatus-BQN7WjmQ.js.map