import { isAxiosError } from "axios";
//#region ../../resources/scripts/api/queryRetry.ts
var isClientErrorResponse = (error) => {
	const status = isAxiosError(error) ? error.response?.status : void 0;
	return status !== void 0 && status >= 400 && status < 500;
};
var retryUnlessClientError = (maxRetries = 1) => (failureCount, error) => failureCount < maxRetries && !isClientErrorResponse(error);
//#endregion
export { retryUnlessClientError as t };

//# sourceMappingURL=queryRetry-CsJb-5Ht.js.map