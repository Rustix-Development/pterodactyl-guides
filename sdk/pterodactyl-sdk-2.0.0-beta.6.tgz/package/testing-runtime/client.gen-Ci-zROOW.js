import "react";
import axios from "axios";
//#region ../../resources/scripts/lib/objects.ts
function isObject(value) {
	return value !== null && Object(value) === value && !Array.isArray(value) && !(value instanceof Function);
}
function isString(value) {
	return String(value) === value;
}
function isNumber(value) {
	return Number.isFinite(value) || Number.isNaN(value) || value === Infinity || value === -Infinity;
}
function isFiniteNumber(value) {
	return Number.isFinite(value);
}
function getObjectKeys(o) {
	return Object.keys(o);
}
//#endregion
//#region ../../resources/scripts/state/httpProgress.ts
var activeRequests = 0;
var snapshot = {
	continuous: false,
	progress: void 0
};
var listeners = /* @__PURE__ */ new Set();
var publish = (next) => {
	snapshot = next;
	for (const listener of listeners) listener();
};
var startHttpProgress = () => {
	activeRequests++;
	if (activeRequests === 1) publish({
		continuous: true,
		progress: void 0
	});
};
var completeHttpProgress = () => {
	activeRequests = Math.max(0, activeRequests - 1);
	if (activeRequests === 0) publish({
		continuous: false,
		progress: snapshot.progress ? 100 : void 0
	});
};
//#endregion
//#region ../../resources/scripts/api/http.ts
var http = axios.create({
	withCredentials: true,
	timeout: 2e4,
	headers: {
		"X-Requested-With": "XMLHttpRequest",
		Accept: "application/json",
		"Content-Type": "application/json"
	}
});
var shouldTrackHttpProgress = (url) => !url?.endsWith("/resources");
http.interceptors.request.use((req) => {
	if (req.data instanceof FormData) req.headers.delete("Content-Type");
	if (shouldTrackHttpProgress(req.url)) startHttpProgress();
	return req;
});
http.interceptors.response.use((resp) => {
	if (shouldTrackHttpProgress(resp.config.url)) completeHttpProgress();
	return resp;
}, (error) => {
	if (shouldTrackHttpProgress(axios.isAxiosError(error) ? error.config?.url : void 0)) completeHttpProgress();
	throw error;
});
function parseJson(text) {
	try {
		return JSON.parse(text);
	} catch {
		return text;
	}
}
/** The message in a JSON:API error body, or in a Wings error body (mostly from file uploads). */
function responseErrorMessage(response) {
	const data = isString(response.data) ? parseJson(response.data) : response.data;
	if (!isObject(data)) return;
	if ("errors" in data && Array.isArray(data.errors)) {
		const firstError = data.errors[0];
		if (isObject(firstError) && "detail" in firstError && isString(firstError.detail)) return firstError.detail;
	}
	if ("error" in data && isString(data.error)) return data.error;
}
function httpErrorToHuman(cause) {
	if (axios.isAxiosError(cause) && cause.response?.data) {
		const message = responseErrorMessage(cause.response);
		if (message !== void 0) return message;
	}
	return cause instanceof Error ? cause.message : "An unexpected error occurred.";
}
//#endregion
//#region ../../resources/scripts/api/hey-api-runtime.ts
var createClientConfig = (config) => ({
	...config,
	axios: http,
	baseURL: "",
	throwOnError: true
});
Object.entries({
	$body_: "body",
	$headers_: "headers",
	$path_: "path",
	$query_: "query"
});
//#endregion
//#region ../../resources/scripts/api/generated/core/serverSentEvents.gen.ts
function createSseClient({ onRequest, onSseError, onSseEvent, responseTransformer, responseValidator, sseDefaultRetryDelay, sseMaxRetryAttempts, sseMaxRetryDelay, sseSleepFn, url, ...options }) {
	let lastEventId;
	const sleep = sseSleepFn ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
	const createStream = async function* () {
		let retryDelay = sseDefaultRetryDelay ?? 3e3;
		let attempt = 0;
		const signal = options.signal ?? new AbortController().signal;
		while (true) {
			if (signal.aborted) break;
			attempt++;
			const headers = options.headers instanceof Headers ? options.headers : new Headers(options.headers);
			if (lastEventId !== void 0) headers.set("Last-Event-ID", lastEventId);
			try {
				const requestInit = {
					redirect: "follow",
					...options,
					body: options.serializedBody,
					headers,
					signal
				};
				let request = new Request(url, requestInit);
				if (onRequest) request = await onRequest(url, requestInit);
				const response = await (options.fetch ?? globalThis.fetch)(request);
				if (!response.ok) throw new Error(`SSE failed: ${response.status} ${response.statusText}`);
				if (!response.body) throw new Error("No body in SSE response");
				const reader = response.body.pipeThrough(new TextDecoderStream()).getReader();
				let buffer = "";
				const abortHandler = () => {
					try {
						reader.cancel();
					} catch {}
				};
				signal.addEventListener("abort", abortHandler);
				try {
					while (true) {
						const { done, value } = await reader.read();
						if (done) break;
						buffer += value;
						buffer = buffer.replace(/\r\n?/g, "\n");
						const chunks = buffer.split("\n\n");
						buffer = chunks.pop() ?? "";
						for (const chunk of chunks) {
							const lines = chunk.split("\n");
							const dataLines = [];
							let eventName;
							for (const line of lines) if (line.startsWith("data:")) dataLines.push(line.replace(/^data:\s*/, ""));
							else if (line.startsWith("event:")) eventName = line.replace(/^event:\s*/, "");
							else if (line.startsWith("id:")) lastEventId = line.replace(/^id:\s*/, "");
							else if (line.startsWith("retry:")) {
								const parsed = Number.parseInt(line.replace(/^retry:\s*/, ""), 10);
								if (!Number.isNaN(parsed)) retryDelay = parsed;
							}
							let data;
							let parsedJson = false;
							if (dataLines.length) {
								const rawData = dataLines.join("\n");
								try {
									data = JSON.parse(rawData);
									parsedJson = true;
								} catch {
									data = rawData;
								}
							}
							if (parsedJson) {
								if (responseValidator) await responseValidator(data);
								if (responseTransformer) data = await responseTransformer(data);
							}
							onSseEvent?.({
								data,
								event: eventName,
								id: lastEventId,
								retry: retryDelay
							});
							if (dataLines.length) yield data;
						}
					}
				} finally {
					signal.removeEventListener("abort", abortHandler);
					reader.releaseLock();
				}
				break;
			} catch (error) {
				onSseError?.(error);
				if (sseMaxRetryAttempts !== void 0 && attempt >= sseMaxRetryAttempts) break;
				await sleep(Math.min(retryDelay * 2 ** (attempt - 1), sseMaxRetryDelay ?? 3e4));
			}
		}
	};
	return { stream: createStream() };
}
//#endregion
//#region ../../resources/scripts/api/generated/core/pathSerializer.gen.ts
var separatorArrayExplode = (style) => {
	switch (style) {
		case "label": return ".";
		case "matrix": return ";";
		case "simple": return ",";
		default: return "&";
	}
};
var separatorArrayNoExplode = (style) => {
	switch (style) {
		case "form": return ",";
		case "pipeDelimited": return "|";
		case "spaceDelimited": return "%20";
		default: return ",";
	}
};
var separatorObjectExplode = (style) => {
	switch (style) {
		case "label": return ".";
		case "matrix": return ";";
		case "simple": return ",";
		default: return "&";
	}
};
var serializeArrayParam = ({ allowReserved, explode, name, style, value }) => {
	if (!explode) {
		const joinedValues = (allowReserved ? value : value.map((v) => encodeURIComponent(v))).join(separatorArrayNoExplode(style));
		switch (style) {
			case "label": return `.${joinedValues}`;
			case "matrix": return `;${name}=${joinedValues}`;
			case "simple": return joinedValues;
			default: return `${name}=${joinedValues}`;
		}
	}
	const separator = separatorArrayExplode(style);
	const joinedValues = value.map((v) => {
		if (style === "label" || style === "simple") return allowReserved ? v : encodeURIComponent(v);
		return serializePrimitiveParam({
			allowReserved,
			name,
			value: v
		});
	}).join(separator);
	return style === "label" || style === "matrix" ? separator + joinedValues : joinedValues;
};
var serializePrimitiveParam = ({ allowReserved, name, value }) => {
	if (value === void 0 || value === null) return "";
	if (typeof value === "object") throw new Error("Deeply-nested arrays/objects aren’t supported. Provide your own `querySerializer()` to handle these.");
	return `${name}=${allowReserved ? value : encodeURIComponent(value)}`;
};
var serializeObjectParam = ({ allowReserved, explode, name, style, value, valueOnly }) => {
	if (value instanceof Date) return valueOnly ? value.toISOString() : `${name}=${value.toISOString()}`;
	if (style !== "deepObject" && !explode) {
		let values = [];
		Object.entries(value).forEach(([key, v]) => {
			values = [
				...values,
				key,
				allowReserved ? v : encodeURIComponent(v)
			];
		});
		const joinedValues = values.join(",");
		switch (style) {
			case "form": return `${name}=${joinedValues}`;
			case "label": return `.${joinedValues}`;
			case "matrix": return `;${name}=${joinedValues}`;
			default: return joinedValues;
		}
	}
	const separator = separatorObjectExplode(style);
	const joinedValues = Object.entries(value).map(([key, v]) => serializePrimitiveParam({
		allowReserved,
		name: style === "deepObject" ? `${name}[${key}]` : key,
		value: v
	})).join(separator);
	return style === "label" || style === "matrix" ? separator + joinedValues : joinedValues;
};
//#endregion
//#region ../../resources/scripts/api/generated/core/utils.gen.ts
var PATH_PARAM_RE = /\{[^{}]+\}/g;
var defaultPathSerializer = ({ path, url: _url }) => {
	let url = _url;
	const matches = _url.match(PATH_PARAM_RE);
	if (matches) for (const match of matches) {
		let explode = false;
		let name = match.substring(1, match.length - 1);
		let style = "simple";
		if (name.endsWith("*")) {
			explode = true;
			name = name.substring(0, name.length - 1);
		}
		if (name.startsWith(".")) {
			name = name.substring(1);
			style = "label";
		} else if (name.startsWith(";")) {
			name = name.substring(1);
			style = "matrix";
		}
		const value = path[name];
		if (value === void 0 || value === null) continue;
		if (Array.isArray(value)) {
			url = url.replace(match, serializeArrayParam({
				explode,
				name,
				style,
				value
			}));
			continue;
		}
		if (typeof value === "object") {
			url = url.replace(match, serializeObjectParam({
				explode,
				name,
				style,
				value,
				valueOnly: true
			}));
			continue;
		}
		if (style === "matrix") {
			url = url.replace(match, `;${serializePrimitiveParam({
				name,
				value
			})}`);
			continue;
		}
		const replaceValue = encodeURIComponent(style === "label" ? `.${value}` : value);
		url = url.replace(match, replaceValue);
	}
	return url;
};
var getUrl = ({ baseUrl, path, query, querySerializer, url: _url }) => {
	const pathUrl = _url.startsWith("/") ? _url : `/${_url}`;
	let url = (baseUrl ?? "") + pathUrl;
	if (path) url = defaultPathSerializer({
		path,
		url
	});
	let search = query ? querySerializer(query) : "";
	if (search.startsWith("?")) search = search.substring(1);
	if (search) url += `?${search}`;
	return url;
};
function getValidRequestBody(options) {
	const hasBody = options.body !== void 0;
	if (hasBody && options.bodySerializer) {
		if ("serializedBody" in options) return options.serializedBody !== void 0 && options.serializedBody !== "" ? options.serializedBody : null;
		return options.body !== "" ? options.body : null;
	}
	if (hasBody) return options.body;
}
//#endregion
//#region ../../resources/scripts/api/generated/core/auth.gen.ts
var getAuthToken = async (auth, callback) => {
	const token = typeof callback === "function" ? await callback(auth) : callback;
	if (!token) return;
	if (auth.scheme === "bearer") return `Bearer ${token}`;
	if (auth.scheme === "basic") return `Basic ${btoa(token)}`;
	return token;
};
//#endregion
//#region ../../resources/scripts/api/generated/client/utils.gen.ts
var createQuerySerializer = ({ parameters = {}, ...args } = {}) => {
	const querySerializer = (queryParams) => {
		const search = [];
		if (queryParams && typeof queryParams === "object") for (const name in queryParams) {
			const value = queryParams[name];
			if (value === void 0 || value === null) continue;
			const options = parameters[name] || args;
			if (Array.isArray(value)) {
				const serializedArray = serializeArrayParam({
					allowReserved: options.allowReserved,
					explode: true,
					name,
					style: "form",
					value,
					...options.array
				});
				if (serializedArray) search.push(serializedArray);
			} else if (typeof value === "object") {
				const serializedObject = serializeObjectParam({
					allowReserved: options.allowReserved,
					explode: true,
					name,
					style: "deepObject",
					value,
					...options.object
				});
				if (serializedObject) search.push(serializedObject);
			} else {
				const serializedPrimitive = serializePrimitiveParam({
					allowReserved: options.allowReserved,
					name,
					value
				});
				if (serializedPrimitive) search.push(serializedPrimitive);
			}
		}
		return search.join("&");
	};
	return querySerializer;
};
var checkForExistence = (options, name) => {
	if (!name) return false;
	if (name in options.headers || options.query?.[name]) return true;
	if ("Cookie" in options.headers && options.headers["Cookie"] && typeof options.headers["Cookie"] === "string") return options.headers["Cookie"].includes(`${name}=`);
	return false;
};
async function setAuthParams(options) {
	for (const auth of options.security ?? []) {
		if (checkForExistence(options, auth.name)) continue;
		const token = await getAuthToken(auth, options.auth);
		if (!token) continue;
		const name = auth.name ?? "Authorization";
		switch (auth.in) {
			case "query":
				if (!options.query) options.query = {};
				options.query[name] = token;
				break;
			case "cookie": {
				const value = `${name}=${token}`;
				if ("Cookie" in options.headers && options.headers["Cookie"]) options.headers["Cookie"] = `${options.headers["Cookie"]}; ${value}`;
				else options.headers["Cookie"] = value;
				break;
			}
			default:
				options.headers[name] = token;
				break;
		}
	}
}
var buildUrl = (options) => {
	const instanceBaseUrl = options.axios?.defaults?.baseURL;
	return getUrl({
		baseUrl: options.baseURL && typeof options.baseURL === "string" ? options.baseURL : instanceBaseUrl,
		path: options.path,
		query: !options.paramsSerializer ? options.query : void 0,
		querySerializer: typeof options.querySerializer === "function" ? options.querySerializer : createQuerySerializer(options.querySerializer),
		url: options.url
	});
};
var mergeConfigs = (a, b) => {
	const config = {
		...a,
		...b
	};
	config.headers = mergeHeaders(a.headers, b.headers);
	return config;
};
/**
* Special Axios headers keywords allowing to set headers by request method.
*/
var axiosHeadersKeywords = [
	"common",
	"delete",
	"get",
	"head",
	"patch",
	"post",
	"put"
];
var mergeHeaders = (...headers) => {
	const mergedHeaders = {};
	for (const header of headers) {
		if (!header || typeof header !== "object") continue;
		const iterator = Object.entries(header);
		for (const [key, value] of iterator) if (axiosHeadersKeywords.includes(key) && typeof value === "object") mergedHeaders[key] = {
			...mergedHeaders[key],
			...value
		};
		else if (value === null) delete mergedHeaders[key];
		else if (Array.isArray(value)) for (const v of value) mergedHeaders[key] = [...mergedHeaders[key] ?? [], v];
		else if (value !== void 0) mergedHeaders[key] = typeof value === "object" ? JSON.stringify(value) : value;
	}
	return mergedHeaders;
};
var createConfig = (override = {}) => ({ ...override });
//#endregion
//#region ../../resources/scripts/api/generated/client/client.gen.ts
var createClient = (config = {}) => {
	let _config = mergeConfigs(createConfig(), config);
	let instance;
	if (_config.axios && !("Axios" in _config.axios)) instance = _config.axios;
	else {
		const { auth, ...configWithoutAuth } = _config;
		instance = axios.create(configWithoutAuth);
	}
	const getConfig = () => ({ ..._config });
	const setConfig = (config) => {
		_config = mergeConfigs(_config, config);
		instance.defaults = {
			...instance.defaults,
			..._config,
			headers: mergeHeaders(instance.defaults.headers, _config.headers)
		};
		return getConfig();
	};
	const beforeRequest = async (options) => {
		const opts = {
			..._config,
			...options,
			axios: options.axios ?? _config.axios ?? instance,
			headers: mergeHeaders(_config.headers, options.headers)
		};
		if (opts.security) await setAuthParams(opts);
		if (opts.requestValidator) await opts.requestValidator(opts);
		if (opts.body !== void 0 && opts.bodySerializer) opts.body = opts.bodySerializer(opts.body);
		return {
			opts,
			url: buildUrl(opts)
		};
	};
	const request = async (options) => {
		const { opts, url } = await beforeRequest(options);
		try {
			const _axios = opts.axios;
			const { auth, ...optsWithoutAuth } = opts;
			const response = await _axios({
				...optsWithoutAuth,
				baseURL: "",
				data: getValidRequestBody(opts),
				headers: opts.headers,
				params: opts.paramsSerializer ? opts.query : void 0,
				url
			});
			let { data } = response;
			if (opts.responseType === "json") {
				if (opts.responseValidator) await opts.responseValidator(data);
				if (opts.responseTransformer) data = await opts.responseTransformer(data);
			}
			return {
				...response,
				data: data ?? {}
			};
		} catch (error) {
			const e = error;
			if (opts.throwOnError) throw e;
			e.error = e.response?.data ?? {};
			return e;
		}
	};
	const makeMethodFn = (method) => (options) => request({
		...options,
		method
	});
	const makeSseFn = (method) => async (options) => {
		const { opts, url } = await beforeRequest(options);
		return createSseClient({
			...opts,
			body: opts.body,
			headers: opts.headers,
			method,
			serializedBody: getValidRequestBody(opts),
			signal: opts.signal,
			url
		});
	};
	const _buildUrl = (options) => buildUrl({
		axios: instance,
		..._config,
		...options
	});
	return {
		buildUrl: _buildUrl,
		connect: makeMethodFn("CONNECT"),
		delete: makeMethodFn("DELETE"),
		get: makeMethodFn("GET"),
		getConfig,
		head: makeMethodFn("HEAD"),
		instance,
		options: makeMethodFn("OPTIONS"),
		patch: makeMethodFn("PATCH"),
		post: makeMethodFn("POST"),
		put: makeMethodFn("PUT"),
		request,
		setConfig,
		sse: {
			connect: makeSseFn("CONNECT"),
			delete: makeSseFn("DELETE"),
			get: makeSseFn("GET"),
			head: makeSseFn("HEAD"),
			options: makeSseFn("OPTIONS"),
			patch: makeSseFn("PATCH"),
			post: makeSseFn("POST"),
			put: makeSseFn("PUT"),
			trace: makeSseFn("TRACE")
		},
		trace: makeMethodFn("TRACE")
	};
};
//#endregion
//#region ../../resources/scripts/api/generated/client.gen.ts
var client = createClient(createClientConfig(createConfig({ throwOnError: true })));
//#endregion
export { http as a, isFiniteNumber as c, isString as d, createClientConfig as i, isNumber as l, createClient as n, httpErrorToHuman as o, createConfig as r, getObjectKeys as s, client as t, isObject as u };

//# sourceMappingURL=client.gen-Ci-zROOW.js.map