import { Gt as implementViews, Jt as modelFromInput } from "./notifications-Ebj0Q0Io.js";
import { t as selectServerPermissions } from "./queries-D_-2KdyF.js";
import { t as hasPermission } from "./usePermissions-pEpnhvzH.js";
import { r as useCurrentUser } from "./queries-BF8_5ZD3.js";
import { a as useServerResourceUsage, i as useAccountServers, n as serverResourceUsageRefetchInterval, t as serverResourceUsageQueryOptions } from "./queries-ubEuC6zs.js";
import { r as useSendPowerAction, t as sendPowerActionInput } from "./queries-C7BIoT7v.js";
import { n as ip, r as mbToBytes } from "./formatters-BBp7wFVw.js";
import { n as serverConflict, r as statMetric, t as runState } from "./state-CUrz93jS.js";
import { n as createTestServerCard, t as createTestServer } from "./fixtures-sueNo-ZT.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { n as relationshipData } from "./relationships-CSicEn-V.js";
import { i as useDashboardSearch, t as getPageSearch } from "./pageSearch-DKMAcuIY.js";
import { useEffect, useMemo } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQueries, useQueryClient } from "@tanstack/react-query";
//#region ../../resources/scripts/views/dashboard.ts
function useServerListQuery() {
	const { page, type } = useDashboardSearch();
	const { rootAdmin } = useCurrentUser();
	const scope = rootAdmin && type === "admin" ? "others" : "mine";
	return {
		query: useAccountServers({
			page,
			type: scope === "others" ? "admin" : void 0
		}),
		scope,
		rootAdmin
	};
}
var useDashboardModel = () => pageStatus(useServerListQuery().query);
var tracksResources = ({ attributes }) => attributes.status !== "suspended" && !attributes.is_node_under_maintenance && attributes.uuid.length > 0;
function resolveState(server, stats) {
	const { attributes } = server;
	if (stats?.is_suspended || attributes.status === "suspended") return {
		kind: "unavailable",
		reason: attributes.status === "suspended" ? "suspended" : "connection-error"
	};
	if (attributes.is_node_under_maintenance) return {
		kind: "unavailable",
		reason: "maintenance"
	};
	if (stats) {
		const { limits } = attributes;
		return {
			kind: "ready",
			power: runState(stats.current_state),
			cpu: statMetric(stats.resources.cpu_absolute, limits.cpu),
			memory: statMetric(stats.resources.memory_bytes, mbToBytes(limits.memory)),
			disk: statMetric(stats.resources.disk_bytes, mbToBytes(limits.disk))
		};
	}
	if (attributes.is_transferring) return {
		kind: "unavailable",
		reason: "transferring"
	};
	if (attributes.status === "installing") return {
		kind: "unavailable",
		reason: "installing"
	};
	if (attributes.status === "restoring_backup") return {
		kind: "unavailable",
		reason: "restoring-backup"
	};
	return attributes.status ? {
		kind: "unavailable",
		reason: "unavailable"
	} : { kind: "loading" };
}
function cardPermissions(server, rootAdmin = false) {
	const granted = server.meta || !(server.attributes.server_owner || rootAdmin) ? selectServerPermissions(server) : ["*"];
	return {
		start: hasPermission(granted, "control.start"),
		stop: hasPermission(granted, "control.stop"),
		restart: hasPermission(granted, "control.restart"),
		console: hasPermission(granted, "control.console")
	};
}
var primaryAddress = ({ attributes }) => relationshipData(attributes.relationships?.allocations).filter((allocation) => allocation.attributes.is_default).map(({ attributes: allocation }) => `${allocation.ip_alias || ip(allocation.ip)}:${allocation.port}`).join("") || null;
/** Sends power signals through the client API and refreshes the server's usage once Wings accepts one. */
function usePowerSender() {
	const queryClient = useQueryClient();
	const { mutate, isPending, variables } = useSendPowerAction();
	return useMemo(() => ({
		send: (uuid, signal) => mutate(sendPowerActionInput(uuid, signal), { onSuccess: () => void queryClient.invalidateQueries({ queryKey: serverResourceUsageQueryOptions(uuid).queryKey }) }),
		sending: isPending ? variables?.path.server_uuid ?? null : null
	}), [
		mutate,
		isPending,
		variables,
		queryClient
	]);
}
function cardModel(server, stats, power, rootAdmin) {
	const { identifier, uuid, name, description } = server.attributes;
	const send = (signal) => () => power.send(uuid, signal);
	return {
		identifier,
		uuid,
		name,
		description,
		address: primaryAddress(server),
		state: resolveState(server, stats),
		permissions: cardPermissions(server, rootAdmin),
		actions: {
			start: send("start"),
			stop: send("stop"),
			restart: send("restart")
		},
		sending: power.sending === uuid
	};
}
var usageOf = (results) => results.map((result) => result.data?.attributes);
var countPower = (items, power) => items.filter(({ state }) => state.kind === "ready" && state.power === power).length;
function useServerListModel() {
	const navigate = useNavigate();
	const { query, scope, rootAdmin } = useServerListQuery();
	const servers = query.data;
	const power = usePowerSender();
	const usage = useQueries({
		queries: (servers?.data ?? []).map((server) => Object.assign(serverResourceUsageQueryOptions(server.attributes.uuid), {
			enabled: tracksResources(server),
			refetchInterval: serverResourceUsageRefetchInterval
		})),
		combine: usageOf
	});
	const type = scope === "others" ? "admin" : void 0;
	useEffect(() => {
		if (servers && servers.meta.pagination.current_page > 1 && !servers.data.length) navigate({
			to: "/",
			search: type ? { type } : {},
			replace: true,
			viewTransition: false
		});
	}, [
		navigate,
		type,
		servers
	]);
	return useMemo(() => {
		const pagination = servers?.meta.pagination;
		const items = (servers?.data ?? []).map((server, index) => Object.assign(cardModel(server, usage[index], power, rootAdmin), { server }));
		return {
			servers: items,
			totals: {
				servers: pagination?.total ?? 0,
				runningOnPage: countPower(items, "running"),
				offlineOnPage: countPower(items, "offline")
			},
			loading: !servers,
			pagination: pagination ? {
				total: pagination.total,
				count: pagination.count,
				perPage: pagination.per_page,
				currentPage: pagination.current_page,
				totalPages: pagination.total_pages
			} : null,
			scope,
			canViewOthers: rootAdmin,
			canCreateServers: rootAdmin,
			actions: {
				setPage: (page) => void navigate({
					to: "/",
					search: type ? {
						...getPageSearch(page),
						type
					} : getPageSearch(page),
					replace: true,
					viewTransition: false
				}),
				setScope: (next) => void navigate({
					to: "/",
					search: next === "others" ? { type: "admin" } : {},
					replace: true,
					viewTransition: false
				})
			}
		};
	}, [
		servers,
		usage,
		power,
		scope,
		rootAdmin,
		type,
		navigate
	]);
}
function useServerCardModel({ server }) {
	const stats = useServerResourceUsage(server.attributes.uuid, tracksResources(server)).data?.attributes;
	const power = usePowerSender();
	const rootAdmin = useCurrentUser().rootAdmin;
	return useMemo(() => cardModel(server, stats, power, rootAdmin), [
		server,
		stats,
		power,
		rootAdmin
	]);
}
/** The cards of the list fixtures' rows, so a card placed in a row shows that row's state. */
var listedCards = /* @__PURE__ */ new Map();
/** A card for a fixture server: its row's, else its conflict when it has one, else running. */
function cardFromServer(server) {
	const listed = listedCards.get(server.attributes.uuid);
	if (listed) return listed;
	const conflict = serverConflict(server);
	const card = createTestServerCard({
		identifier: server.attributes.identifier,
		uuid: server.attributes.uuid,
		name: server.attributes.name,
		description: server.attributes.description,
		permissions: cardPermissions(server)
	});
	return conflict ? {
		...card,
		state: {
			kind: "unavailable",
			reason: conflict
		}
	} : card;
}
var noop = () => {};
var offline = {
	kind: "ready",
	power: "offline",
	cpu: statMetric(0, 100),
	memory: statMetric(0, 1024 ** 3),
	disk: statMetric(800 * 1024 ** 2, 2048 * 1024 ** 2)
};
var listFixture = (servers, options = {}) => {
	const items = servers.map(([server, state]) => {
		const derived = cardFromServer(server);
		const card = state ? {
			...derived,
			state
		} : derived;
		listedCards.set(server.attributes.uuid, card);
		return {
			...card,
			server
		};
	});
	return {
		servers: items,
		totals: {
			servers: items.length,
			runningOnPage: countPower(items, "running"),
			offlineOnPage: countPower(items, "offline")
		},
		loading: false,
		pagination: {
			total: items.length,
			count: items.length,
			perPage: 50,
			currentPage: 1,
			totalPages: 1
		},
		scope: "mine",
		canViewOthers: true,
		canCreateServers: true,
		actions: {
			setPage: noop,
			setScope: noop
		},
		...options
	};
};
implementViews({
	"page.dashboard": {
		use: useDashboardModel,
		fixtures: pageStatusFixtures
	},
	"dashboard.serverList": {
		use: useServerListModel,
		fixtures: {
			servers: () => listFixture([
				[createTestServer({
					identifier: "a1b2c3d4",
					uuid: "a1b2c3d4-0000-4000-8000-000000000001",
					name: "Survival"
				})],
				[createTestServer({
					identifier: "e5f6a7b8",
					uuid: "e5f6a7b8-0000-4000-8000-000000000002",
					name: "Creative"
				}), offline],
				[createTestServer({
					identifier: "c9d0e1f2",
					uuid: "c9d0e1f2-0000-4000-8000-000000000003",
					name: "Lobby",
					status: "suspended"
				})]
			]),
			empty: () => listFixture([], {
				canViewOthers: false,
				canCreateServers: false
			}),
			loading: () => listFixture([], {
				loading: true,
				pagination: null
			})
		}
	},
	"dashboard.serverCard": {
		use: useServerCardModel,
		fixtureInput: (card) => ({ server: createTestServer({
			identifier: card.identifier,
			uuid: card.uuid,
			name: card.name
		}) }),
		fixtureFromInput: ({ server }) => cardFromServer(server),
		fixtures: {
			running: () => createTestServerCard(),
			offline: () => createTestServerCard({ state: {
				kind: "ready",
				power: "offline",
				cpu: statMetric(0, 0),
				memory: statMetric(0, 0),
				disk: statMetric(512 * 1024 ** 2, 0)
			} }),
			suspended: () => createTestServerCard({ state: {
				kind: "unavailable",
				reason: "suspended"
			} }),
			loading: () => createTestServerCard({
				address: null,
				state: { kind: "loading" }
			})
		}
	},
	"dashboard.serverCard.identity": { use: modelFromInput },
	"dashboard.serverCard.address": { use: modelFromInput },
	"dashboard.serverCard.metrics": { use: modelFromInput }
});
//#endregion

//# sourceMappingURL=dashboard-BTQW7vew.js.map