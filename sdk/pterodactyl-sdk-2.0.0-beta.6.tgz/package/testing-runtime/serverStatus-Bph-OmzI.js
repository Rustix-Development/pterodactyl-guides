//#region ../../resources/scripts/lib/serverStatus.ts
var INSTALLING_STATUSES = new Set([
	"installing",
	"install_failed",
	"reinstall_failed"
]);
var SKIPPED_INSTALL_SCRIPT_MESSAGE = "This server is configured to skip its egg's install script. Reinstalling is not available until that setting is disabled.";
var isInstallingStatus = (status) => status !== null && INSTALLING_STATUSES.has(status);
var canReinstallServer = (status, skipScripts) => !skipScripts || isInstallingStatus(status);
//#endregion
export { canReinstallServer as n, isInstallingStatus as r, SKIPPED_INSTALL_SCRIPT_MESSAGE as t };

//# sourceMappingURL=serverStatus-Bph-OmzI.js.map