import { Gt as implementViews, k as clientDeleteServerSubuserMutation, kt as clientUpdateServerSubuserMutation, lt as clientListServerSubusersOptions, ot as clientListServerPermissionsOptions, t as notifyHttpError, ut as clientListServerSubusersQueryKey, y as clientCreateServerSubuserMutation } from "./notifications-Ebj0Q0Io.js";
import { s as useCurrentServerPermissions } from "./queries-D_-2KdyF.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { r as useCurrentUser } from "./queries-BF8_5ZD3.js";
import { i as upsertListItem, n as removeListItems } from "./queryData-DzPdESJr.js";
import { n as replaceEditablePermissions, t as permissionGroupRows } from "./permissionSelection-BuSLUqDB.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { t as attempt } from "./attempt-B1fyfDS4.js";
import { t as useLoadedServer } from "./loadedServer-Bw7lSBA6.js";
import { useCallback, useMemo } from "react";
import { useNavigate } from "@tanstack/react-router";
import { queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/server/users/queries.ts
var serverSubusersInput = (uuid) => ({ path: { server_uuid: uuid } });
var serverSubusersQueryOptions = (uuid) => clientListServerSubusersOptions(serverSubusersInput(uuid));
var useServerSubusers = (uuid) => useQuery({
	...serverSubusersQueryOptions(uuid),
	enabled: uuid.length > 0
});
var createServerSubuserInput = (uuid, values) => ({
	path: { server_uuid: uuid },
	body: values
});
/** `subuser` is the subuser's user uuid. */
var updateServerSubuserInput = (uuid, subuser, values) => ({
	path: {
		server_uuid: uuid,
		user: subuser
	},
	body: { permissions: values.permissions }
});
/** `subuser` is the subuser's user uuid. */
var deleteServerSubuserInput = (uuid, subuser) => ({ path: {
	server_uuid: uuid,
	user: subuser
} });
var upsertSubuser = async (queryClient, uuid, subuser) => {
	await queryClient.cancelQueries({ queryKey: clientListServerSubusersQueryKey(serverSubusersInput(uuid)) });
	return queryClient.setQueryData(clientListServerSubusersQueryKey(serverSubusersInput(uuid)), (current) => upsertListItem(current, subuser, (item) => item.attributes.uuid === subuser.attributes.uuid));
};
var removeSubuser = async (queryClient, uuid, subuserUuid) => {
	await queryClient.cancelQueries({ queryKey: clientListServerSubusersQueryKey(serverSubusersInput(uuid)) });
	return queryClient.setQueryData(clientListServerSubusersQueryKey(serverSubusersInput(uuid)), (current) => removeListItems(current, (subuser) => subuser.attributes.uuid === subuserUuid));
};
var useCreateSubuser = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateServerSubuserMutation(),
		onSuccess: (subuser, { path }) => upsertSubuser(queryClient, path.server_uuid, subuser),
		onError: (error) => notifyHttpError(error, "Unable to invite subuser")
	});
};
var useUpdateSubuser = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientUpdateServerSubuserMutation(),
		onSuccess: (subuser, { path }) => upsertSubuser(queryClient, path.server_uuid, subuser),
		onError: (error) => notifyHttpError(error, "Unable to update subuser")
	});
};
/** Reports failures; the caller announces success, since it knows the subuser's email. */
var useDeleteSubuser = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDeleteServerSubuserMutation(),
		onSuccess: (_data, { path }) => removeSubuser(queryClient, path.server_uuid, path.user),
		onError: (error) => notifyHttpError(error, "Unable to remove subuser")
	});
};
//#endregion
//#region ../../resources/scripts/api/system/queries.ts
var systemPermissionsQueryOptions = queryOptions({
	...clientListServerPermissionsOptions(),
	staleTime: Infinity
});
var useSystemPermissions = () => useQuery(systemPermissionsQueryOptions);
//#endregion
//#region ../../resources/scripts/views/server/users.ts
var subuserSummary = ({ attributes }, viewer) => ({
	uuid: attributes.uuid,
	email: attributes.email,
	image: attributes.image,
	twoFactor: attributes["2fa_enabled"],
	permissions: attributes.permissions,
	permissionCount: attributes.permissions.filter((permission) => permission !== "websocket.connect").length,
	self: attributes.uuid === viewer
});
var validateEmail = (value) => {
	if (value.length > 191) return "Email addresses must not exceed 191 characters.";
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? void 0 : "A valid email address must be provided.";
};
/** The subusers, and the permission catalogue their forms list. */
var useSubusersPageModel = () => pageStatus(useServerSubusers(useLoadedServer().attributes.uuid), useSystemPermissions());
function useSubuserListModel() {
	const { uuid, identifier } = useLoadedServer().attributes;
	const viewer = useCurrentUser().uuid;
	const { data } = useServerSubusers(uuid);
	const [canCreate, canUpdate, canDelete] = usePermissions([
		"user.create",
		"user.update",
		"user.delete"
	]);
	const { mutateAsync, isPending: deleting } = useDeleteSubuser();
	const remove = useCallback(async (subuserUuid) => {
		const subuser = data?.data.find((item) => item.attributes.uuid === subuserUuid);
		return !!subuser && attempt(async () => {
			await mutateAsync(deleteServerSubuserInput(uuid, subuserUuid));
			toast.success("Subuser removed", { description: `${subuser.attributes.email} no longer has access to this server.` });
		});
	}, [
		data,
		mutateAsync,
		uuid
	]);
	return useMemo(() => ({
		serverId: identifier,
		subusers: (data?.data ?? []).map((subuser) => subuserSummary(subuser, viewer)),
		canCreate,
		canUpdate,
		canDelete,
		deleting,
		remove
	}), [
		identifier,
		data,
		viewer,
		canCreate,
		canUpdate,
		canDelete,
		deleting,
		remove
	]);
}
function useSubuserCreatePageModel() {
	const { identifier } = useLoadedServer().attributes;
	const permissions = useSystemPermissions().data?.attributes.permissions;
	const loading = !permissions || !Object.keys(permissions).length;
	return useMemo(() => ({
		serverId: identifier,
		loading
	}), [identifier, loading]);
}
function useSubuserFormModel({ subuser, onClose }) {
	const navigate = useNavigate();
	const { uuid, identifier } = useLoadedServer().attributes;
	const { rootAdmin } = useCurrentUser();
	const granted = useCurrentServerPermissions();
	const { data: catalogue, isLoading: loading, isError: failed } = useSystemPermissions();
	const [canEdit] = usePermissions(subuser ? "user.update" : "user.create");
	const { mutateAsync: invite, isPending: inviting } = useCreateSubuser();
	const { mutateAsync: update, isPending: updating } = useUpdateSubuser();
	const permissions = catalogue?.attributes.permissions;
	const { groups, editable } = useMemo(() => {
		const entries = Object.entries(permissions ?? {});
		const all = entries.flatMap(([group, { keys }]) => permissionGroupRows(group, keys).map((row) => row.permission));
		const held = new Set(granted);
		const grantable = new Set(rootAdmin || granted.length === 1 && granted[0] === "*" ? all : all.filter((key) => held.has(key)));
		return {
			editable: grantable,
			groups: entries.filter(([group]) => group !== "websocket").map(([group, { description, keys }]) => ({
				name: group,
				description,
				permissions: permissionGroupRows(group, keys).map((row) => ({
					key: row.permission,
					label: row.key,
					description: row.description,
					editable: grantable.has(row.permission)
				}))
			}))
		};
	}, [
		permissions,
		granted,
		rootAdmin
	]);
	const save = useCallback((values) => {
		const body = {
			email: values.email,
			permissions: [...values.permissions]
		};
		return attempt(async () => {
			if (subuser) {
				await update(updateServerSubuserInput(uuid, subuser.uuid, body));
				onClose?.();
				return;
			}
			const invited = await invite(createServerSubuserInput(uuid, body));
			toast.success("Subuser invited", { description: `${invited.attributes.email} has been invited.` });
			navigate({
				to: "/server/$id/users",
				params: { id: identifier }
			});
		});
	}, [
		subuser,
		onClose,
		update,
		invite,
		navigate,
		uuid,
		identifier
	]);
	const saving = inviting || updating;
	const mode = subuser ? "edit" : "create";
	const permissionSlot = useCallback((selected, submitting, apply) => {
		const disabled = !canEdit || submitting || saving;
		return {
			mode,
			selectedPermissions: selected,
			editablePermissions: [...editable],
			disabled,
			setPermissions: (requested) => {
				if (!disabled) apply(replaceEditablePermissions(selected, requested, editable));
			}
		};
	}, [
		canEdit,
		saving,
		mode,
		editable
	]);
	const restricted = !rootAdmin && granted[0] !== "*";
	return useMemo(() => ({
		mode,
		subuser: subuser ?? null,
		loading,
		failed,
		canEdit,
		restricted,
		groups,
		editable: [...editable],
		values: {
			email: subuser?.email ?? "",
			permissions: subuser?.permissions ?? []
		},
		saving,
		validateEmail,
		save,
		permissionSlot
	}), [
		mode,
		subuser,
		loading,
		failed,
		canEdit,
		restricted,
		groups,
		editable,
		saving,
		save,
		permissionSlot
	]);
}
var saved = async () => true;
var noop = () => {};
var subuserFixtures = [
	{
		uuid: "11111111-1111-4111-8111-111111111111",
		email: "alex@example.test",
		image: "https://www.gravatar.com/avatar/00000000000000000000000000000000",
		twoFactor: true,
		permissions: [
			"websocket.connect",
			"control.console",
			"control.start",
			"control.stop",
			"control.restart"
		],
		permissionCount: 4,
		self: true
	},
	{
		uuid: "22222222-2222-4222-8222-222222222222",
		email: "sam@example.test",
		image: "https://www.gravatar.com/avatar/11111111111111111111111111111111",
		twoFactor: false,
		permissions: [
			"websocket.connect",
			"control.console",
			"backup.read",
			"backup.create"
		],
		permissionCount: 3,
		self: false
	},
	{
		uuid: "33333333-3333-4333-8333-333333333333",
		email: "jordan@example.test",
		image: "https://www.gravatar.com/avatar/22222222222222222222222222222222",
		twoFactor: true,
		permissions: [
			"websocket.connect",
			"user.read",
			"user.create",
			"user.update",
			"user.delete"
		],
		permissionCount: 4,
		self: false
	}
];
var listFixture = (options = {}) => ({
	serverId: "a1b2c3d4",
	subusers: subuserFixtures,
	canCreate: true,
	canUpdate: true,
	canDelete: true,
	deleting: false,
	remove: saved,
	...options
});
var permissionCatalogue = [
	[
		"control",
		"Permissions that control a user's ability to control the power state of a server, or send commands.",
		{
			console: "Allows a user to send commands to the server instance via the console.",
			start: "Allows a user to start the server if it is stopped.",
			stop: "Allows a user to stop a server if it is running.",
			restart: "Allows a user to perform a server restart."
		}
	],
	[
		"user",
		"Permissions that allow a user to manage other subusers on a server.",
		{
			create: "Allows a user to create new subusers for the server.",
			read: "Allows the user to view subusers and their permissions for the server.",
			update: "Allows a user to modify other subusers.",
			delete: "Allows a user to delete a subuser from the server."
		}
	],
	[
		"backup",
		"Permissions that control a user's ability to generate and manage server backups.",
		{
			create: "Allows a user to create new backups for this server.",
			read: "Allows a user to view all backups that exist for this server.",
			delete: "Allows a user to remove backups from the system."
		}
	]
];
var groupsFixture = (held) => permissionCatalogue.map(([name, description, keys]) => ({
	name,
	description,
	permissions: permissionGroupRows(name, keys).map((row) => ({
		key: row.permission,
		label: row.key,
		description: row.description,
		editable: !held || held.has(row.permission)
	}))
}));
var formFixture = (options = {}) => {
	const groups = options.groups ?? groupsFixture();
	const editable = groups.flatMap((group) => group.permissions.filter((row) => row.editable).map((row) => row.key));
	return {
		mode: "create",
		subuser: null,
		loading: false,
		failed: false,
		canEdit: true,
		restricted: false,
		groups,
		editable: ["websocket.connect", ...editable],
		values: {
			email: "",
			permissions: []
		},
		saving: false,
		validateEmail,
		save: saved,
		permissionSlot: (selected, submitting) => ({
			mode: options.mode ?? "create",
			selectedPermissions: selected,
			editablePermissions: ["websocket.connect", ...editable],
			disabled: submitting,
			setPermissions: noop
		}),
		...options
	};
};
var editing = subuserFixtures[1];
implementViews({
	"page.server.users": {
		use: useSubusersPageModel,
		fixtures: pageStatusFixtures
	},
	"server.subusers": {
		use: useSubuserListModel,
		fixtures: {
			subusers: () => listFixture(),
			empty: () => listFixture({ subusers: [] }),
			readOnly: () => listFixture({
				canCreate: false,
				canUpdate: false,
				canDelete: false
			})
		}
	},
	"page.server.users.create": {
		use: useSubuserCreatePageModel,
		fixtures: {
			default: () => ({
				serverId: "a1b2c3d4",
				loading: false
			}),
			loading: () => ({
				serverId: "a1b2c3d4",
				loading: true
			})
		}
	},
	"server.subuserForm": {
		use: useSubuserFormModel,
		fixtureInput: (model) => model.subuser ? { subuser: model.subuser } : {},
		fixtures: {
			create: () => formFixture(),
			edit: () => formFixture({
				mode: "edit",
				subuser: editing,
				values: {
					email: editing.email,
					permissions: editing.permissions
				}
			}),
			restricted: () => formFixture({
				restricted: true,
				groups: groupsFixture(new Set([
					"control.console",
					"control.start",
					"backup.read"
				]))
			}),
			viewOnly: () => formFixture({
				mode: "edit",
				subuser: editing,
				canEdit: false,
				values: {
					email: editing.email,
					permissions: editing.permissions
				}
			}),
			loading: () => formFixture({ loading: true })
		}
	}
});
//#endregion

//# sourceMappingURL=users-XwD0Y2Hk.js.map