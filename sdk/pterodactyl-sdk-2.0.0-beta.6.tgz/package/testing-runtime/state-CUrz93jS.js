import { r as isInstallingStatus } from "./serverStatus-Bph-OmzI.js";
//#region ../../resources/scripts/views/server/state.ts
/** The API's power state, where `stopped` means offline. */
var runState = (state) => state === "stopped" ? "offline" : state;
function statMetric(value, limit) {
	const used = limit ? value / limit : 0;
	let alarm = null;
	if (used > .9) alarm = "danger";
	else if (used > .8) alarm = "warning";
	return {
		value,
		limit,
		alarm
	};
}
function serverConflict({ attributes }) {
	if (isInstallingStatus(attributes.status)) return "installing";
	if (attributes.status === "suspended") return "suspended";
	if (attributes.is_node_under_maintenance) return "maintenance";
	if (attributes.is_transferring) return "transferring";
	return attributes.status === null ? null : "restoring-backup";
}
//#endregion
export { serverConflict as n, statMetric as r, runState as t };

//# sourceMappingURL=state-CUrz93jS.js.map