import { a as Spinner, p as Icon } from "./Button-BzlrfY24.js";
import { Dt as ServerContentBlock, J as RowActionsMenu, Q as ListToolbar, Rt as SpinnerOverlay, U as DeleteAction, X as actionsColumn, Y as Table, at as EmptyTitle, et as Empty, ft as DropdownMenuItem, h as fromNow, ht as NewButton, it as EmptyMedia, jt as Badge, m as formatDate, nt as EmptyDescription, q as RowActions, rt as EmptyHeader, tt as EmptyContent } from "./sdk-Chrtpiam.js";
import { c as View } from "./theme-Cgy7R6cy.js";
import { i as Checkbox, n as useAppForm, r as Form } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { t as bytesToString } from "./formatters-BBp7wFVw.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { useMemo, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Archive, ArrowLeft, CloudDownload, Lock, PackageOpen, Unlock } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/server/backups/BackupsPage.tsx
function BackupsPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(ServerContentBlock, {
			title: "Backups",
			className,
			children: /* @__PURE__ */ jsx(View, { name: "server.backups" })
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/backups/BackupActions.tsx
/** A backup's delete action and its menu of download, restore and lock. */
function BackupActions({ model, backup }) {
	const [confirming, setConfirming] = useState("");
	const [truncate, setTruncate] = useState(false);
	const { actions, pending, permissions } = model;
	const close = () => setConfirming("");
	const closeOnSuccess = (done) => {
		if (done) close();
	};
	const onLockToggle = () => {
		if (backup.locked && confirming !== "unlock") {
			setConfirming("unlock");
			return;
		}
		actions.toggleLock(backup.uuid).then(closeOnSuccess);
	};
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(Dialog.Confirm, {
			open: confirming === "unlock",
			onClose: close,
			title: `Unlock "${backup.name}"`,
			pending: pending.lock,
			onConfirmed: onLockToggle,
			children: "This backup will no longer be protected from automated or accidental deletions."
		}),
		/* @__PURE__ */ jsxs(Dialog.Confirm, {
			open: confirming === "restore",
			onClose: close,
			confirm: "Restore",
			title: `Restore "${backup.name}"`,
			pending: pending.restore,
			onConfirmed: () => void actions.restore(backup.uuid, truncate).then(closeOnSuccess),
			children: [/* @__PURE__ */ jsx("p", { children: "Your server will be stopped. You will not be able to control the power state, access the file manager, or create additional backups until completed." }), /* @__PURE__ */ jsx("p", {
				className: "mt-4 -mb-2 bg-card p-3 rounded-sm",
				children: /* @__PURE__ */ jsxs("label", {
					htmlFor: "restore_truncate",
					className: "text-base flex items-center cursor-pointer",
					children: [/* @__PURE__ */ jsx(Checkbox, {
						className: "mr-2 h-5 w-5 data-[checked]:border-destructive data-[checked]:bg-destructive data-[checked]:text-destructive-foreground",
						id: "restore_truncate",
						value: "true",
						checked: truncate,
						onChange: () => setTruncate((checked) => !checked)
					}), "Delete all files before restoring backup."]
				})
			})]
		}),
		/* @__PURE__ */ jsx(Dialog.Confirm, {
			title: `Delete "${backup.name}"`,
			confirm: "Continue",
			open: confirming === "delete",
			pending: pending.remove,
			onClose: close,
			onConfirmed: () => void actions.remove(backup.uuid).then(closeOnSuccess),
			children: "This is a permanent operation. The backup cannot be recovered once deleted."
		}),
		/* @__PURE__ */ jsxs(RowActions, { children: [permissions.delete && /* @__PURE__ */ jsx(DeleteAction, {
			"aria-label": `Delete ${backup.name}`,
			disabled: backup.locked,
			disabledReason: "Unlock this backup before deleting it.",
			onClick: () => setConfirming("delete")
		}), backup.successful && /* @__PURE__ */ jsxs(RowActionsMenu, {
			label: `More actions for ${backup.name}`,
			children: [
				permissions.download && /* @__PURE__ */ jsx(DropdownMenuItem, {
					onClick: () => void actions.download(backup.uuid),
					icon: CloudDownload,
					children: "Download"
				}),
				permissions.restore && /* @__PURE__ */ jsx(DropdownMenuItem, {
					onClick: () => setConfirming("restore"),
					icon: PackageOpen,
					children: "Restore"
				}),
				permissions.delete && /* @__PURE__ */ jsx(DropdownMenuItem, {
					onClick: onLockToggle,
					icon: backup.locked ? Unlock : Lock,
					children: backup.locked ? "Unlock" : "Lock"
				})
			]
		})] })
	] });
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/backups/CreateBackupButton.tsx
var ignoredDescription = [
	"Enter the files or folders to ignore while generating this backup.",
	"Leave blank to use the contents of the .pteroignore file in the root of the server directory if present.",
	"Wildcard matching of files and folders is supported in addition to negating a rule by prefixing the path",
	"with an exclamation point."
].join(" ");
function CreateBackupDialog({ model, onClose }) {
	const form = useAppForm({
		defaultValues: {
			name: "",
			ignored: "",
			isLocked: false
		},
		onSubmit: async ({ value }) => {
			if (await model.actions.create(value)) onClose();
		}
	});
	return /* @__PURE__ */ jsx(form.Subscribe, {
		selector: (state) => state.isSubmitting,
		children: (submitting) => /* @__PURE__ */ jsxs(Dialog, {
			open: true,
			title: "Create server backup",
			onClose,
			preventExternalClose: submitting,
			hideCloseIcon: submitting,
			children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: submitting }), /* @__PURE__ */ jsxs(Form, {
				form,
				children: [
					/* @__PURE__ */ jsx(form.AppField, {
						name: "name",
						validators: { onChange: ({ value }) => model.validateName(value) },
						children: (field) => /* @__PURE__ */ jsx(field.TextField, {
							label: "Backup name",
							description: "If provided, the name that should be used to reference this backup."
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "mt-6",
						children: /* @__PURE__ */ jsx(form.AppField, {
							name: "ignored",
							children: (field) => /* @__PURE__ */ jsx(field.TextAreaField, {
								label: "Ignored Files & Directories",
								rows: 6,
								description: ignoredDescription
							})
						})
					}),
					model.permissions.delete && /* @__PURE__ */ jsx("div", {
						className: "mt-6 bg-card border border-border shadow-inner p-4 rounded-sm",
						children: /* @__PURE__ */ jsx(form.AppField, {
							name: "isLocked",
							children: (field) => /* @__PURE__ */ jsx(field.SwitchField, {
								label: "Locked",
								description: "Prevents this backup from being deleted until explicitly unlocked."
							})
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "flex justify-end mt-6",
						children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, { children: "Start backup" }) })
					})
				]
			})]
		})
	});
}
function CreateBackupButton({ model }) {
	return /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(NewButton, {
			onClick,
			children: "New backup"
		}),
		children: ({ open, onClose }) => open && /* @__PURE__ */ jsx(CreateBackupDialog, {
			model,
			onClose
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/backups/BackupList.tsx
var backupUsage = (model) => {
	const { limit, count } = model;
	if (limit === 0 && model.backups.length > 0) return "Backups cannot be created for this server because the backup limit is set to 0.";
	if (model.permissions.create && limit > 0 && count > 0) return `${count} of ${limit} backups have been created for this server.`;
	return null;
};
var canAddBackup = (model) => model.permissions.create && model.limit > model.count;
function BackupIdentity({ backup }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "flex min-w-44 items-center gap-3",
		children: [backup.completedAt === null ? /* @__PURE__ */ jsx(Spinner, { size: "small" }) : /* @__PURE__ */ jsx(Icon, {
			icon: backup.locked ? Lock : Archive,
			className: backup.locked ? "text-warning" : "text-muted-foreground"
		}), /* @__PURE__ */ jsxs("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-2",
				children: [backup.completedAt !== null && !backup.successful ? /* @__PURE__ */ jsx(Badge, {
					tone: "danger",
					size: "sm",
					children: "Failed"
				}) : null, /* @__PURE__ */ jsx("p", {
					className: "truncate font-medium",
					children: backup.name
				})]
			}), /* @__PURE__ */ jsx("p", {
				className: "mt-0.5 truncate font-mono text-xs text-muted-foreground",
				children: backup.checksum
			})]
		})]
	});
}
function columns(model) {
	const { permissions } = model;
	const hasActions = permissions.download || permissions.restore || permissions.delete;
	return [
		{
			id: "name",
			label: "Backup",
			cell: (backup) => /* @__PURE__ */ jsx(BackupIdentity, { backup })
		},
		{
			id: "bytes",
			label: "Size",
			cell: (backup) => /* @__PURE__ */ jsx("span", {
				className: "whitespace-nowrap text-xs",
				children: backup.completedAt && backup.successful ? bytesToString(backup.bytes) : "-"
			}),
			headerClassName: "hidden md:table-cell w-28",
			cellClassName: "hidden md:table-cell w-28"
		},
		{
			id: "created_at",
			label: "Created",
			cell: (backup) => /* @__PURE__ */ jsx("time", {
				dateTime: backup.createdAt,
				title: formatDate(backup.createdAt, "ddd, MMMM D, YYYY HH:mm:ss"),
				className: "whitespace-nowrap text-xs text-muted-foreground",
				children: fromNow(backup.createdAt)
			}),
			headerClassName: "hidden sm:table-cell w-32",
			cellClassName: "hidden sm:table-cell w-32"
		},
		actionsColumn(2, (backup) => hasActions && backup.completedAt ? /* @__PURE__ */ jsx(BackupActions, {
			model,
			backup
		}) : null)
	];
}
function EmptyBackups({ model }) {
	if (model.pagination.page > 1) return /* @__PURE__ */ jsxs(Empty, {
		size: "compact",
		children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
			/* @__PURE__ */ jsx(EmptyMedia, {
				variant: "icon",
				children: /* @__PURE__ */ jsx(Archive, {})
			}),
			/* @__PURE__ */ jsx(EmptyTitle, { children: "No backups on this page" }),
			/* @__PURE__ */ jsx(EmptyDescription, { children: "This page is past the end of the backup list." })
		] }), /* @__PURE__ */ jsx(EmptyContent, { children: /* @__PURE__ */ jsx(NewButton, {
			isSecondary: true,
			icon: ArrowLeft,
			onClick: () => model.actions.setPage(1),
			children: "First page"
		}) })]
	});
	return /* @__PURE__ */ jsxs(Empty, {
		size: "compact",
		children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
			/* @__PURE__ */ jsx(EmptyMedia, {
				variant: "icon",
				children: /* @__PURE__ */ jsx(Archive, {})
			}),
			/* @__PURE__ */ jsx(EmptyTitle, { children: "No backups" }),
			/* @__PURE__ */ jsx(EmptyDescription, { children: model.limit > 0 ? "This server doesn't have any backups yet." : "Backups can't be created because this server's backup limit is 0." })
		] }), canAddBackup(model) && /* @__PURE__ */ jsx(EmptyContent, { children: /* @__PURE__ */ jsx(CreateBackupButton, { model }) })]
	});
}
function BackupList({ model, className }) {
	const tableColumns = useMemo(() => columns(model), [model]);
	const usage = backupUsage(model);
	const canAdd = canAddBackup(model);
	const { pending } = model;
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [
			(usage || canAdd) && /* @__PURE__ */ jsx(ListToolbar, {
				summary: usage,
				children: canAdd && /* @__PURE__ */ jsx(CreateBackupButton, { model })
			}),
			/* @__PURE__ */ jsx(SpinnerOverlay, {
				visible: pending.download || pending.remove || pending.restore || pending.lock,
				fixed: true
			}),
			/* @__PURE__ */ jsx(Table, {
				rows: model.backups,
				columns: tableColumns,
				keyOf: (backup) => backup.uuid,
				emptyState: /* @__PURE__ */ jsx(EmptyBackups, { model }),
				pagination: {
					...model.pagination,
					itemLabel: "backups",
					onPageSelect: model.actions.setPage
				}
			})
		]
	});
}
//#endregion
export { BackupList, BackupsPage };

//# sourceMappingURL=backups-JK3sUyWI.js.map