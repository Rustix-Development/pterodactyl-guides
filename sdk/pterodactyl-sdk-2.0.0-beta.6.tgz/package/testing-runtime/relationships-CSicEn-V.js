//#region ../../resources/scripts/api/relationships.ts
function relationshipData(relationship) {
	return relationship && "data" in relationship ? relationship.data : [];
}
function relationshipAttributes(relationship) {
	return relationship?.attributes ?? void 0;
}
//#endregion
export { relationshipData as n, relationshipAttributes as t };

//# sourceMappingURL=relationships-CSicEn-V.js.map