import { o as httpErrorToHuman } from "./client.gen-Ci-zROOW.js";
import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { r as useCurrentUser } from "./queries-BF8_5ZD3.js";
import { r as useAccountServerSearch } from "./queries-ubEuC6zs.js";
import { n as ip } from "./formatters-BBp7wFVw.js";
import { n as useShortcut, t as describeShortcut } from "./useShortcut-BKaL2-k7.js";
import { t as createTestServer } from "./fixtures-sueNo-ZT.js";
import { n as fixtureField, r as stateField } from "./forms-DcsxfoFI.js";
import { n as relationshipData } from "./relationships-CSicEn-V.js";
import { useEffect, useMemo, useState } from "react";
//#region ../../resources/scripts/plugins/useDebouncedValue.ts
var useDebouncedValue = (value, delay) => {
	const [debouncedValue, setDebouncedValue] = useState(value);
	useEffect(() => {
		const timeout = setTimeout(() => {
			setDebouncedValue(value);
		}, delay);
		return () => clearTimeout(timeout);
	}, [delay, value]);
	return debouncedValue;
};
//#endregion
//#region ../../resources/scripts/views/search.ts
var SHORT = "Please enter at least three characters to begin searching.";
var searchResult = ({ attributes }) => ({
	identifier: attributes.identifier,
	uuid: attributes.uuid,
	name: attributes.name,
	addresses: relationshipData(attributes.relationships?.allocations).filter((allocation) => allocation.attributes.is_default).map(({ attributes: allocation }) => `${allocation.ip_alias || ip(allocation.ip)}:${allocation.port}`),
	node: attributes.node,
	destination: {
		to: "/server/$id",
		params: { id: attributes.identifier }
	}
});
var shortcut = describeShortcut("mod+/");
function useAppSearchModel() {
	const { rootAdmin } = useCurrentUser();
	const [open, setOpen] = useState(false);
	const [term, setTerm] = useState("");
	const query = useDebouncedValue(term, 500).trim();
	const enabled = open && query.length >= 3;
	const { data, error, isFetching } = useAccountServerSearch({
		query,
		type: rootAdmin ? "admin-all" : void 0
	}, enabled);
	useShortcut("mod+/", () => setOpen(true), { when: !open });
	return useMemo(() => {
		return {
			open,
			show: () => setOpen(true),
			close: () => {
				setOpen(false);
				setTerm("");
			},
			shortcut,
			field: {
				...stateField("term", term, setTerm),
				error: term.length > 0 && term.length < 3 ? SHORT : null
			},
			results: enabled ? (data?.data.slice(0, 5) ?? []).map(searchResult) : [],
			loading: enabled && isFetching,
			searched: enabled && !isFetching && !error && data !== void 0,
			error: enabled && error && !isFetching ? httpErrorToHuman(error) : null
		};
	}, [
		open,
		term,
		enabled,
		data,
		error,
		isFetching
	]);
}
var noop = () => {};
var results = [createTestServer({
	identifier: "a1b2c3d4",
	uuid: "a1b2c3d4-0000-4000-8000-000000000001",
	name: "Survival"
}), createTestServer({
	identifier: "e5f6a7b8",
	uuid: "e5f6a7b8-0000-4000-8000-000000000002",
	name: "Survival Tests"
})].map(searchResult);
var searchFixture = (options = {}) => ({
	open: true,
	show: noop,
	close: noop,
	shortcut,
	field: fixtureField("term", {}, "surv"),
	results,
	loading: false,
	searched: true,
	error: null,
	...options
});
implementViews({ "app.search": {
	use: useAppSearchModel,
	fixtures: {
		closed: () => searchFixture({
			open: false,
			field: fixtureField("term"),
			results: [],
			searched: false
		}),
		results: () => searchFixture(),
		loading: () => searchFixture({
			results: [],
			loading: true,
			searched: false
		}),
		none: () => searchFixture({
			field: fixtureField("term", {}, "zzz"),
			results: []
		}),
		short: () => searchFixture({
			field: fixtureField("term", {}, "su", SHORT),
			results: [],
			searched: false
		}),
		error: () => searchFixture({
			results: [],
			searched: false,
			error: "Request failed with status code 500."
		})
	}
} });
//#endregion

//# sourceMappingURL=search-C-guwVJU.js.map