import { a as Spinner } from "./Button-BzlrfY24.js";
import { It as ListRow, Ot as PageContentBlock, Pt as Stat, _t as PageHeading, at as EmptyTitle, et as Empty, gt as NewLinkButton, it as EmptyMedia, jt as Badge, nt as EmptyDescription, ot as Pagination, r as cn, rt as EmptyHeader, tt as EmptyContent } from "./sdk-Chrtpiam.js";
import { a as Slot, c as View } from "./theme-Cgy7R6cy.js";
import { a as Switch } from "./useDebouncedCallback-B4Ebjqc5.js";
import { t as bytesToString } from "./formatters-BBp7wFVw.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Cpu, EthernetPort, HardDrive, MemoryStick, Server } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/dashboard/Dashboard.tsx
function Dashboard({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(PageContentBlock, {
			title: "Dashboard",
			className,
			children: /* @__PURE__ */ jsx(View, { name: "dashboard.serverList" })
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/dashboard/ServerList.tsx
/** Running is good, starting and stopping are on their way, and anything else is down. */
function status({ state }) {
	if (state.kind !== "ready" || state.power === "offline") return "danger";
	return state.power === "running" ? "success" : "warning";
}
function ServerRow({ item, className }) {
	const { server } = item;
	return /* @__PURE__ */ jsxs(ListRow, {
		destination: {
			to: "/server/$id",
			params: { id: item.identifier }
		},
		"aria-label": item.name,
		status: status(item),
		className: cn("grid grid-cols-12 gap-4", className),
		children: [
			/* @__PURE__ */ jsx(Slot, {
				name: "dashboard.serverRow.before",
				data: server
			}),
			/* @__PURE__ */ jsx("div", {
				className: "col-span-12",
				children: /* @__PURE__ */ jsx(View, {
					name: "dashboard.serverCard",
					server
				})
			}),
			/* @__PURE__ */ jsx(Slot, {
				name: "dashboard.serverRow.metrics.after",
				data: server
			}),
			/* @__PURE__ */ jsx(Slot, {
				name: "dashboard.serverRow.after",
				data: server
			})
		]
	});
}
function NoServers({ model }) {
	const others = model.scope === "others";
	return /* @__PURE__ */ jsxs(Empty, {
		className: "border bg-card",
		children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
			/* @__PURE__ */ jsx(EmptyMedia, {
				variant: "icon",
				children: /* @__PURE__ */ jsx(Server, {})
			}),
			/* @__PURE__ */ jsx(EmptyTitle, { children: others ? "No other servers" : "No servers yet" }),
			/* @__PURE__ */ jsx(EmptyDescription, { children: others ? "There are no servers owned by other users." : "Servers you own or are invited to will appear here." })
		] }), model.canCreateServers && /* @__PURE__ */ jsx(EmptyContent, { children: /* @__PURE__ */ jsx(NewLinkButton, {
			to: "/panel/servers/new",
			children: "New server"
		}) })]
	});
}
function ServerList({ model, className }) {
	const others = model.scope === "others";
	const { pagination } = model;
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [
			/* @__PURE__ */ jsx(PageHeading, {
				title: "Servers",
				className: "mb-4",
				actions: model.canViewOthers && /* @__PURE__ */ jsx(Switch, {
					checked: others,
					onChange: () => model.actions.setScope(others ? "mine" : "others"),
					label: others ? "Showing others' servers" : "Showing your servers",
					controlPosition: "end",
					className: "gap-2"
				})
			}),
			/* @__PURE__ */ jsx(Slot, { name: "dashboard.before" }),
			pagination ? /* @__PURE__ */ jsx(Pagination, {
				data: {
					data: [...model.servers],
					meta: { pagination: {
						total: pagination.total,
						count: pagination.count,
						per_page: pagination.perPage,
						current_page: pagination.currentPage,
						total_pages: pagination.totalPages
					} }
				},
				onPageSelect: model.actions.setPage,
				children: ({ items }) => items.length > 0 ? items.map((item, index) => /* @__PURE__ */ jsx(ServerRow, {
					item,
					className: index > 0 ? "mt-2" : void 0
				}, item.uuid)) : /* @__PURE__ */ jsx(NoServers, { model })
			}) : /* @__PURE__ */ jsx(Spinner, {
				centered: true,
				size: "large"
			}),
			/* @__PURE__ */ jsx(Slot, { name: "dashboard.after" })
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/dashboard/ServerCard.tsx
/** The card's pieces are views of their own, so a theme replaces one and keeps the others. */
function ServerCard({ model, server, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn("grid grid-cols-12 gap-4", className),
		children: [
			/* @__PURE__ */ jsx(View, {
				name: "dashboard.serverCard.identity",
				model,
				server
			}),
			/* @__PURE__ */ jsx(View, {
				name: "dashboard.serverCard.address",
				model,
				server
			}),
			/* @__PURE__ */ jsx(View, {
				name: "dashboard.serverCard.metrics",
				model,
				server
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/dashboard/ServerCardIdentity.tsx
function ServerCardIdentity({ model, server, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn("flex items-center col-span-12 sm:col-span-5 lg:col-span-6", className),
		children: [
			/* @__PURE__ */ jsx(ListRow.Icon, {
				className: "mr-4",
				children: /* @__PURE__ */ jsx(Server, {
					size: "1em",
					className: "inline-block"
				})
			}),
			/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(ListRow.Title, { children: model.name }), !!model.description && /* @__PURE__ */ jsx(ListRow.Description, { children: model.description })] }),
			/* @__PURE__ */ jsx(Slot, {
				name: "dashboard.serverRow.name.after",
				data: server
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/dashboard/ServerCardAddress.tsx
function ServerCardAddress({ model, className }) {
	return /* @__PURE__ */ jsx("div", {
		className: cn("flex-1 ml-4 lg:block lg:col-span-2 hidden", className),
		children: /* @__PURE__ */ jsxs("div", {
			className: "flex justify-center",
			children: [/* @__PURE__ */ jsx(EthernetPort, {
				size: "1em",
				className: "inline-block shrink-0 text-muted-foreground"
			}), /* @__PURE__ */ jsx("p", {
				className: "text-sm text-muted-foreground ml-2",
				children: model.address
			})]
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/dashboard/ServerCardMetrics.tsx
var unavailableLabels = {
	suspended: "Suspended",
	"connection-error": "Connection Error",
	maintenance: "Under Maintenance",
	transferring: "Transferring",
	installing: "Installing",
	"restoring-backup": "Restoring Backup",
	unavailable: "Unavailable"
};
var unavailableTones = {
	suspended: "danger",
	"connection-error": "danger",
	maintenance: "warning",
	transferring: "neutral",
	installing: "neutral",
	"restoring-backup": "neutral",
	unavailable: "neutral"
};
function UnavailableBadge({ reason }) {
	return /* @__PURE__ */ jsx("div", {
		className: "flex-1 text-center",
		children: /* @__PURE__ */ jsx(Badge, {
			tone: unavailableTones[reason],
			children: unavailableLabels[reason]
		})
	});
}
var tone = ({ alarm }) => alarm === "danger" ? "danger" : "neutral";
function MetricsContent({ state }) {
	if (state.kind === "loading") return /* @__PURE__ */ jsx(Spinner, { size: "small" });
	if (state.kind === "unavailable") return /* @__PURE__ */ jsx(UnavailableBadge, { reason: state.reason });
	return /* @__PURE__ */ jsx(Fragment, { children: [
		{
			label: "CPU",
			icon: Cpu,
			metric: state.cpu,
			value: `${state.cpu.value.toFixed(2)} %`,
			limit: state.cpu.limit === 0 ? "Unlimited" : `${state.cpu.limit} %`
		},
		{
			label: "Memory",
			icon: MemoryStick,
			metric: state.memory,
			value: bytesToString(state.memory.value),
			limit: state.memory.limit === 0 ? "Unlimited" : bytesToString(state.memory.limit)
		},
		{
			label: "Disk",
			icon: HardDrive,
			metric: state.disk,
			value: bytesToString(state.disk.value),
			limit: state.disk.limit === 0 ? "Unlimited" : bytesToString(state.disk.limit)
		}
	].map(({ label, icon, metric, value, limit }) => /* @__PURE__ */ jsx(Stat, {
		variant: "inline",
		icon,
		label,
		value,
		limit: `of ${limit}`,
		tone: tone(metric),
		className: "flex-1 ml-4 hidden sm:flex"
	}, label)) });
}
function ServerCardMetrics({ model, className }) {
	return /* @__PURE__ */ jsx("div", {
		className: cn("hidden col-span-7 lg:col-span-4 sm:flex items-baseline justify-center", className),
		children: /* @__PURE__ */ jsx(MetricsContent, { state: model.state })
	});
}
//#endregion
export { Dashboard, ServerCard, ServerCardAddress, ServerCardIdentity, ServerCardMetrics, ServerList };

//# sourceMappingURL=dashboard-DXkW3jG9.js.map