import { d as isString, l as isNumber, o as httpErrorToHuman } from "./client.gen-Ci-zROOW.js";
import { $ as clientListServerActivityOptions, G as clientListAccountActivityFilterOptionsOptions, Gt as implementViews, K as clientListAccountActivityOptions, Q as clientListServerActivityFilterOptionsOptions, n as adminListActivityFilterOptionsOptions, r as adminListActivityOptions } from "./notifications-Ebj0Q0Io.js";
import { n as useServerRouteId } from "./params-HmQaEn9f.js";
import { c as useCurrentServerUuid } from "./queries-D_-2KdyF.js";
import { t as relationshipAttributes } from "./relationships-CSicEn-V.js";
import { r as useActivitySearch, t as getPageSearch } from "./pageSearch-DKMAcuIY.js";
import { useNavigate } from "@tanstack/react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
//#region ../../resources/scripts/api/queryParameters.ts
var queryFilterValue = (value) => {
	if (value === void 0 || value === null || value === "") return;
	const normalized = Array.isArray(value) ? value.join(",") : String(value);
	return normalized.length > 0 ? normalized : void 0;
};
//#endregion
//#region ../../resources/scripts/api/activity.ts
var timestampSorts = new Map([
	[-1, "-timestamp"],
	["desc", "-timestamp"],
	[1, "timestamp"],
	["asc", "timestamp"]
]);
var userIdFilter = (user) => {
	if (user === void 0 || !Number.isFinite(Number(user))) return;
	return Number(user);
};
var activityLogQuery = (filters) => {
	const event = queryFilterValue(filters?.filters?.event);
	const userId = userIdFilter(queryFilterValue(filters?.filters?.user));
	const sort = timestampSorts.get(filters?.sorts?.timestamp);
	const query = { include: "actor" };
	if (filters?.page !== void 0) query.page = filters.page;
	if (event) query["filter[event_name]"] = event;
	if (userId !== void 0) query["filter[user_id]"] = userId;
	if (sort) query.sort = sort;
	return query;
};
//#endregion
//#region ../../resources/scripts/api/account/activity/queries.ts
var accountActivityLogsQueryOptions = (filters) => clientListAccountActivityOptions({ query: activityLogQuery(filters) });
var accountActivityFacetsQueryOptions = () => clientListAccountActivityFilterOptionsOptions();
//#endregion
//#region ../../resources/scripts/api/activityFacets.ts
var toActivityFacets = (body) => ({
	events: (body?.data?.events ?? []).filter(isString),
	users: (body?.data?.users ?? []).flatMap((user) => isNumber(user.id) && isString(user.username) ? [{
		id: user.id,
		username: user.username,
		email: user.email ?? ""
	}] : [])
});
var emptyActivityFacets = toActivityFacets(void 0);
//#endregion
//#region ../../resources/scripts/api/admin/activity/queries.ts
var adminActivityLogsQueryOptions = (filters) => adminListActivityOptions({ query: activityLogQuery(filters) });
var adminActivityFacetsQueryOptions = () => adminListActivityFilterOptionsOptions();
//#endregion
//#region ../../resources/scripts/api/server/activity/queries.ts
var serverActivityLogsQueryOptions = (uuid, filters) => ({
	...clientListServerActivityOptions({
		path: { server_uuid: uuid },
		query: activityLogQuery(filters)
	}),
	enabled: !!uuid
});
var serverActivityFacetsQueryOptions = (uuid) => ({
	...clientListServerActivityFilterOptionsOptions({ path: { server_uuid: uuid } }),
	enabled: !!uuid
});
//#endregion
//#region ../../resources/scripts/views/activity/index.ts
var ACRONYMS = new Map([
	["api", "API"],
	["sftp", "SFTP"],
	["ip", "IP"],
	["2fa", "2FA"]
]);
var humanise = (value) => value.split(/[-_]/).map((word, index) => ACRONYMS.get(word.toLowerCase()) ?? (index === 0 ? word.charAt(0).toUpperCase() + word.slice(1) : word)).join(" ");
/** `server:power.start` lists as "Start" under "Power". */
function eventGroups(events) {
	const grouped = /* @__PURE__ */ new Map();
	for (const event of events) {
		const [namespace = "", remainder = ""] = event.split(":");
		const separator = remainder.indexOf(".");
		const resource = separator === -1 ? namespace : remainder.slice(0, separator);
		const action = separator === -1 ? remainder : remainder.slice(separator + 1);
		const options = grouped.get(resource) ?? [];
		options.push({
			value: event,
			label: humanise(action),
			textLabel: `${humanise(resource)} · ${humanise(action)}`
		});
		grouped.set(resource, options);
	}
	return [...grouped.entries()].map(([resource, options]) => ({
		label: humanise(resource),
		options: options.sort((a, b) => a.label.localeCompare(b.label))
	})).sort((a, b) => a.label.localeCompare(b.label));
}
var userOptions = ({ users }) => users.map((option) => ({
	value: String(option.id),
	label: option.email ? `${option.username} (${option.email})` : option.username
}));
function toEntry(activity, filter) {
	const { attributes } = activity;
	const actor = relationshipAttributes(attributes.relationships?.actor);
	const userAgent = attributes.properties.useragent;
	return {
		id: attributes.id,
		event: attributes.event,
		actor: actor ? {
			username: actor.username ?? null,
			email: actor.email ?? null
		} : null,
		properties: attributes.properties,
		hasMetadata: attributes.has_additional_metadata,
		ip: attributes.ip,
		timestamp: attributes.timestamp,
		api: attributes.is_api,
		sftp: attributes.event.startsWith("server:sftp."),
		userAgent: isString(userAgent) ? userAgent : null,
		filter: filter(attributes.event)
	};
}
function useActivityQueries(scope, filters) {
	const uuid = useCurrentServerUuid() ?? "";
	const options = {
		refetchOnWindowFocus: false,
		placeholderData: keepPreviousData
	};
	return {
		logs: {
			account: useQuery({
				...accountActivityLogsQueryOptions(filters),
				...options,
				enabled: scope === "account"
			}),
			server: useQuery({
				...serverActivityLogsQueryOptions(uuid, filters),
				...options,
				enabled: scope === "server" && !!uuid
			}),
			admin: useQuery({
				...adminActivityLogsQueryOptions(filters),
				...options,
				enabled: scope === "admin"
			})
		}[scope],
		facets: {
			account: useQuery({
				...accountActivityFacetsQueryOptions(),
				select: toActivityFacets,
				enabled: scope === "account"
			}),
			server: useQuery({
				...serverActivityFacetsQueryOptions(uuid),
				select: toActivityFacets,
				enabled: scope === "server" && !!uuid
			}),
			admin: useQuery({
				...adminActivityFacetsQueryOptions(),
				select: toActivityFacets,
				enabled: scope === "admin"
			})
		}[scope].data ?? emptyActivityFacets
	};
}
function useActivityNavigation(scope) {
	const navigate = useNavigate();
	const id = useServerRouteId() ?? "";
	const go = (search) => {
		const options = {
			search,
			replace: true,
			viewTransition: false
		};
		if (scope === "server") {
			navigate({
				to: "/server/$id/activity",
				params: { id },
				...options
			});
			return;
		}
		navigate({
			to: scope === "admin" ? "/panel/activity" : "/account/activity",
			...options
		});
	};
	const filter = (event) => {
		if (scope === "server") return {
			to: "/server/$id/activity",
			params: { id },
			search: { event }
		};
		return {
			to: scope === "admin" ? "/panel/activity" : "/account/activity",
			search: { event }
		};
	};
	return {
		go,
		filter
	};
}
function useActivityLogModel({ scope }) {
	const { page, event, user } = useActivitySearch();
	const { logs, facets } = useActivityQueries(scope, {
		page,
		filters: {
			event,
			user
		},
		sorts: { timestamp: -1 }
	});
	const { go, filter } = useActivityNavigation(scope);
	const { data, error, isFetching, refetch } = logs;
	const pagination = data?.meta.pagination;
	const withFilter = (next) => {
		const search = {};
		if (next.user) search.user = next.user;
		if (next.event) search.event = next.event;
		go(search);
	};
	return {
		scope,
		entries: (data?.data ?? []).map((activity) => toEntry(activity, filter)),
		loading: !data && isFetching,
		error: error && !isFetching ? httpErrorToHuman(error) : null,
		retry: () => void refetch(),
		pagination: pagination ? {
			total: pagination.total,
			count: pagination.count,
			perPage: pagination.per_page,
			currentPage: pagination.current_page,
			totalPages: pagination.total_pages
		} : null,
		event: event ?? null,
		user: user ?? null,
		events: eventGroups(facets.events),
		users: scope === "account" ? null : userOptions(facets),
		actions: {
			setEvent: (value) => withFilter({
				event: value ?? void 0,
				user
			}),
			setUser: (value) => withFilter({
				event,
				user: value ?? void 0
			}),
			clearFilters: () => go({}),
			setPage: (next) => {
				const search = getPageSearch(next);
				if (event) search.event = event;
				if (user) search.user = user;
				go(search);
			}
		}
	};
}
var noop = () => {};
function entry(id, event, properties, overrides = {}) {
	return {
		id,
		event,
		actor: {
			username: "alex",
			email: "alex@example.test"
		},
		properties,
		hasMetadata: false,
		ip: "203.0.113.10",
		timestamp: "2026-10-12T09:30:00Z",
		api: false,
		sftp: false,
		userAgent: null,
		filter: {
			to: "/account/activity",
			search: { event }
		},
		...overrides
	};
}
var entries = [
	entry("1", "user:account.email-changed", {
		old: "alex@old.test",
		new: "alex@example.test"
	}, { userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_0) Firefox/131.0" }),
	entry("2", "user:api-key.create", { identifier: "ptlc_7hX2kQ9vLm" }, {
		api: true,
		hasMetadata: true
	}),
	entry("3", "server:sftp.write", { files: ["server.properties"] }, {
		sftp: true,
		ip: null
	}),
	entry("4", "auth:success", {}, {
		actor: null,
		timestamp: "2026-10-01T07:00:00Z"
	})
];
function logFixture(scope, overrides = {}) {
	return {
		scope,
		entries,
		loading: false,
		error: null,
		retry: noop,
		pagination: {
			total: 4,
			count: 4,
			perPage: 25,
			currentPage: 1,
			totalPages: 1
		},
		event: null,
		user: null,
		events: eventGroups([
			"auth:success",
			"server:sftp.write",
			"user:account.email-changed",
			"user:api-key.create"
		]),
		users: scope === "account" ? null : [{
			value: "1",
			label: "alex (alex@example.test)"
		}, {
			value: "2",
			label: "sam (sam@example.test)"
		}],
		actions: {
			setEvent: noop,
			setUser: noop,
			clearFilters: noop,
			setPage: noop
		},
		...overrides
	};
}
var pageModel = Object.freeze({});
var page = {
	use: () => pageModel,
	fixtures: { default: () => pageModel }
};
implementViews({
	"activity.log": {
		use: useActivityLogModel,
		fixtureInput: (model) => ({ scope: model.scope }),
		fixtures: {
			account: () => logFixture("account"),
			server: () => logFixture("server"),
			filtered: () => logFixture("server", {
				entries: [],
				pagination: {
					total: 0,
					count: 0,
					perPage: 25,
					currentPage: 1,
					totalPages: 1
				},
				event: "server:power.start",
				user: "2"
			}),
			empty: () => logFixture("account", {
				entries: [],
				pagination: {
					total: 0,
					count: 0,
					perPage: 25,
					currentPage: 1,
					totalPages: 1
				}
			}),
			paged: () => logFixture("account", { pagination: {
				total: 120,
				count: 25,
				perPage: 25,
				currentPage: 3,
				totalPages: 5
			} }),
			loading: () => logFixture("account", {
				entries: [],
				loading: true,
				pagination: null
			}),
			error: () => logFixture("account", {
				entries: [],
				pagination: null,
				error: "Request failed with status code 500."
			})
		}
	},
	"page.account.activity": page,
	"page.server.activity": page
});
//#endregion
export { eventGroups };

//# sourceMappingURL=activity-Da0zO2jw.js.map