import { i as useCurrentServer } from "./queries-D_-2KdyF.js";
//#region ../../resources/scripts/views/server/loadedServer.ts
/** The current server, which the server area loads before any of its views render. */
function useLoadedServer() {
	const server = useCurrentServer();
	if (!server) throw new Error("Server views render once their server has loaded.");
	return server;
}
//#endregion
export { useLoadedServer as t };

//# sourceMappingURL=loadedServer-Bw7lSBA6.js.map