//#region ../../resources/scripts/views/server/attempt.ts
/** Runs a mutation whose failure the mutation itself reports, resolving whether it succeeded. */
async function attempt(mutation) {
	try {
		await mutation();
		return true;
	} catch {
		return false;
	}
}
//#endregion
export { attempt as t };

//# sourceMappingURL=attempt-B1fyfDS4.js.map