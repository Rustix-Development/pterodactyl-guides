import { t as getBootstrapSiteSettings } from "./bootstrap-XdDfwDao.js";
import { queryOptions, useQuery } from "@tanstack/react-query";
//#region ../../resources/scripts/api/settings/queries.ts
var siteSettingsQueryKey = ["bootstrap", "site-settings"];
var getSiteSettings = () => {
	const settings = getBootstrapSiteSettings();
	if (!settings) throw new Error("Site settings have not been hydrated.");
	return settings;
};
/** Bootstrap data with no fetcher; changed only by `setSiteSettingsQueryData`. */
var siteSettingsQueryOptions = () => queryOptions({
	queryKey: siteSettingsQueryKey,
	initialData: getSiteSettings,
	staleTime: "static"
});
var useSiteSettings = () => useQuery(siteSettingsQueryOptions()).data;
//#endregion
export { useSiteSettings as n, siteSettingsQueryKey as t };

//# sourceMappingURL=queries-DXZ7OlB6.js.map