import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { l as useReinstallServer, u as useRenameServer } from "./queries-D_-2KdyF.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { r as useCurrentUser } from "./queries-BF8_5ZD3.js";
import { n as canReinstallServer, t as SKIPPED_INSTALL_SCRIPT_MESSAGE } from "./serverStatus-Bph-OmzI.js";
import { t as attempt } from "./attempt-B1fyfDS4.js";
import { t as useLoadedServer } from "./loadedServer-Bw7lSBA6.js";
import { useCallback, useMemo } from "react";
//#region ../../resources/scripts/views/server/settings.ts
var settingsPageModel = Object.freeze({});
function useSftpModel() {
	const { username } = useCurrentUser();
	const { identifier, sftp_details: sftp } = useLoadedServer().attributes;
	const [allowed] = usePermissions("file.sftp");
	return useMemo(() => ({
		allowed,
		ip: sftp.ip,
		port: sftp.port,
		username: `${username}.${identifier}`
	}), [
		allowed,
		sftp,
		username,
		identifier
	]);
}
function useDebugModel() {
	const { node, uuid } = useLoadedServer().attributes;
	return useMemo(() => ({
		node,
		uuid
	}), [node, uuid]);
}
var validateName = (name) => name.length >= 1 ? void 0 : "Required";
function useRenameModel() {
	const { identifier, uuid, name, description } = useLoadedServer().attributes;
	const [allowed] = usePermissions("settings.rename");
	const { mutateAsync } = useRenameServer(identifier);
	const save = useCallback((values) => attempt(() => mutateAsync({
		path: { server_uuid: uuid },
		body: {
			name: values.name,
			description: values.description
		}
	})), [mutateAsync, uuid]);
	return useMemo(() => ({
		allowed,
		values: {
			name,
			description: description ?? ""
		},
		validateName,
		save
	}), [
		allowed,
		name,
		description,
		save
	]);
}
function useReinstallModel() {
	const { uuid, status, skip_scripts: skipScripts } = useLoadedServer().attributes;
	const [allowed] = usePermissions("settings.reinstall");
	const { mutateAsync } = useReinstallServer();
	const reinstall = useCallback(() => attempt(() => mutateAsync({ path: { server_uuid: uuid } })), [mutateAsync, uuid]);
	const unavailable = canReinstallServer(status, skipScripts) ? null : SKIPPED_INSTALL_SCRIPT_MESSAGE;
	return useMemo(() => ({
		allowed,
		unavailable,
		reinstall
	}), [
		allowed,
		unavailable,
		reinstall
	]);
}
var succeeded = async () => true;
var sftpFixture = (options = {}) => ({
	allowed: true,
	ip: "203.0.113.10",
	port: 2022,
	username: "alex.a1b2c3d4",
	...options
});
var renameFixture = (options = {}) => ({
	allowed: true,
	values: {
		name: "Survival",
		description: "The main survival world."
	},
	validateName,
	save: succeeded,
	...options
});
implementViews({
	"page.server.settings": {
		use: () => settingsPageModel,
		fixtures: { default: () => settingsPageModel }
	},
	"server.sftp": {
		use: useSftpModel,
		fixtures: {
			default: () => sftpFixture(),
			ipv6: () => sftpFixture({ ip: "2001:db8::10" }),
			denied: () => sftpFixture({ allowed: false })
		}
	},
	"server.debug": {
		use: useDebugModel,
		fixtures: { default: () => ({
			node: "Node 1",
			uuid: "11111111-1111-4111-8111-111111111111"
		}) }
	},
	"server.rename": {
		use: useRenameModel,
		fixtures: {
			default: () => renameFixture(),
			empty: () => renameFixture({ values: {
				name: "Survival",
				description: ""
			} }),
			denied: () => renameFixture({ allowed: false })
		}
	},
	"server.reinstall": {
		use: useReinstallModel,
		fixtures: {
			default: () => ({
				allowed: true,
				unavailable: null,
				reinstall: succeeded
			}),
			skipped: () => ({
				allowed: true,
				unavailable: SKIPPED_INSTALL_SCRIPT_MESSAGE,
				reinstall: succeeded
			}),
			denied: () => ({
				allowed: false,
				unavailable: null,
				reinstall: succeeded
			})
		}
	}
});
//#endregion

//# sourceMappingURL=settings-BStGoXjE.js.map