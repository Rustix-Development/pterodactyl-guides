import { c as isFiniteNumber, d as isString, u as isObject } from "./client.gen-Ci-zROOW.js";
import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { c as useBackupDownloadUrl, d as useRestoreServerBackup, f as useServerBackups, i as restoreServerBackupInput, l as useCreateServerBackup, n as createServerBackupInput, o as toggleServerBackupLockInput, p as useToggleServerBackupLock, r as deleteServerBackupInput, s as updateServerBackup, t as backupDownloadUrlInput, u as useDeleteServerBackup } from "./queries-Czk-nC2C.js";
import { r as useWebsocketEvent, t as SocketEvent } from "./events-BZtD8HxQ.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { a as usePageSearch, t as getPageSearch } from "./pageSearch-DKMAcuIY.js";
import { t as attempt } from "./attempt-B1fyfDS4.js";
import { t as useLoadedServer } from "./loadedServer-Bw7lSBA6.js";
import { useMemo } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/views/server/backupCompletion.ts
var isBackupCompletedPayload = (value) => isObject(value) && "uuid" in value && isString(value.uuid) && "is_successful" in value && (value.is_successful === true || value.is_successful === false) && (!("checksum" in value) || isString(value.checksum)) && (!("checksum_type" in value) || isString(value.checksum_type)) && (!("file_size" in value) || isFiniteNumber(value.file_size));
var parseBackupCompletedPayload = (data) => {
	try {
		const parsed = JSON.parse(data);
		return isBackupCompletedPayload(parsed) ? parsed : null;
	} catch {
		return null;
	}
};
var completeBackup = (backup, payload, completedAt) => {
	const { attributes } = backup;
	if (!payload.is_successful) return {
		...backup,
		attributes: {
			...attributes,
			is_successful: false,
			is_locked: false,
			checksum: null,
			bytes: 0,
			completed_at: completedAt
		}
	};
	return {
		...backup,
		attributes: {
			...attributes,
			is_successful: true,
			checksum: payload.checksum && payload.checksum_type ? `${payload.checksum_type}:${payload.checksum}` : attributes.checksum,
			bytes: payload.file_size ?? attributes.bytes,
			completed_at: completedAt
		}
	};
};
//#endregion
//#region ../../resources/scripts/views/server/backups.ts
var backupSummary = ({ attributes }) => ({
	uuid: attributes.uuid,
	name: attributes.name,
	checksum: attributes.checksum,
	bytes: attributes.bytes,
	createdAt: attributes.created_at,
	completedAt: attributes.completed_at,
	successful: attributes.is_successful,
	locked: attributes.is_locked
});
var validateName = (name) => name.length <= 191 ? void 0 : "The backup name must not exceed 191 characters.";
var useBackupsPageModel = () => pageStatus(useServerBackups(useLoadedServer().attributes.uuid, usePageSearch()));
function useBackupListModel() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const page = usePageSearch();
	const { uuid, identifier, feature_limits: limits } = useLoadedServer().attributes;
	const { data } = useServerBackups(uuid, page);
	const [create, download, restore, remove] = usePermissions([
		"backup.create",
		"backup.download",
		"backup.restore",
		"backup.delete"
	]);
	const { mutateAsync: createBackup } = useCreateServerBackup();
	const { mutateAsync: downloadUrl, isPending: downloading } = useBackupDownloadUrl();
	const { mutateAsync: deleteBackup, isPending: deleting } = useDeleteServerBackup();
	const { mutateAsync: restoreBackup, isPending: restoring } = useRestoreServerBackup();
	const { mutateAsync: toggleLock, isPending: locking } = useToggleServerBackupLock(page);
	useWebsocketEvent(SocketEvent.BACKUP_COMPLETED, (payload) => {
		const completed = parseBackupCompletedPayload(payload);
		if (!completed) {
			console.warn("Ignoring a malformed backup completion event.", payload);
			return;
		}
		updateServerBackup(queryClient, uuid, page, completed.uuid, (backup) => completeBackup(backup, completed, (/* @__PURE__ */ new Date()).toISOString()));
	});
	const actions = useMemo(() => {
		const find = (backupUuid) => data?.data.find((backup) => backup.attributes.uuid === backupUuid);
		const withBackup = async (backupUuid, act) => {
			const backup = find(backupUuid);
			return backup ? attempt(() => act(backup)) : false;
		};
		return {
			setPage: (next) => void navigate({
				to: "/server/$id/backups",
				params: { id: identifier },
				search: getPageSearch(next),
				replace: true,
				viewTransition: false
			}),
			create: (values) => attempt(() => createBackup(createServerBackupInput(uuid, values))),
			download: async (backupUuid) => {
				await withBackup(backupUuid, async (backup) => {
					window.location.assign(await downloadUrl(backupDownloadUrlInput(uuid, backup)));
				});
			},
			remove: (backupUuid) => withBackup(backupUuid, async (backup) => {
				await deleteBackup(deleteServerBackupInput(uuid, backup));
				toast.success("Backup deleted", { description: `${backup.attributes.name} has been removed.` });
			}),
			restore: (backupUuid, truncate) => withBackup(backupUuid, async (backup) => {
				await restoreBackup(restoreServerBackupInput(uuid, backup, truncate));
				toast.success("Backup restore started", { description: `${backup.attributes.name} is being restored.` });
			}),
			toggleLock: (backupUuid) => withBackup(backupUuid, (backup) => toggleLock(toggleServerBackupLockInput(uuid, backup)))
		};
	}, [
		data,
		navigate,
		identifier,
		uuid,
		createBackup,
		downloadUrl,
		deleteBackup,
		restoreBackup,
		toggleLock
	]);
	return useMemo(() => {
		const pagination = data?.meta.pagination;
		return {
			backups: (data?.data ?? []).map(backupSummary),
			pagination: {
				page,
				perPage: pagination?.per_page ?? 20,
				total: pagination?.total ?? 0,
				count: pagination?.count ?? 0
			},
			limit: limits.backups ?? 0,
			count: data?.meta.backup_count ?? 0,
			permissions: {
				create,
				download,
				restore,
				delete: remove
			},
			pending: {
				download: downloading,
				remove: deleting,
				restore: restoring,
				lock: locking
			},
			validateName,
			actions
		};
	}, [
		data,
		page,
		limits.backups,
		create,
		download,
		restore,
		remove,
		downloading,
		deleting,
		restoring,
		locking,
		actions
	]);
}
var succeeded = async () => true;
var noop = () => {};
var backupFixture = (options = {}) => ({
	uuid: "b1b2b3b4-0000-4000-8000-000000000001",
	name: "Before the 1.21 upgrade",
	checksum: "sha1:3f786850e387550fdab836ed7e6dc881de23001b",
	bytes: 1536 * 1024 ** 2,
	createdAt: "2026-10-10T18:30:00Z",
	completedAt: "2026-10-10T18:34:12Z",
	successful: true,
	locked: false,
	...options
});
var backupFixtures = [
	backupFixture({
		uuid: "b1b2b3b4-0000-4000-8000-000000000004",
		name: "Nightly backup",
		checksum: null,
		bytes: 0,
		createdAt: "2026-10-12T04:00:00Z",
		completedAt: null
	}),
	backupFixture({
		uuid: "b1b2b3b4-0000-4000-8000-000000000003",
		name: "Weekly world snapshot",
		createdAt: "2026-10-11T04:00:00Z",
		completedAt: "2026-10-11T04:06:40Z",
		bytes: 2048 * 1024 ** 2,
		locked: true
	}),
	backupFixture({
		uuid: "b1b2b3b4-0000-4000-8000-000000000002",
		name: "Plugin test",
		checksum: null,
		bytes: 0,
		createdAt: "2026-10-10T21:00:00Z",
		completedAt: "2026-10-10T21:00:05Z",
		successful: false
	}),
	backupFixture()
];
var listFixture = (options = {}) => ({
	backups: backupFixtures,
	pagination: {
		page: 1,
		perPage: 20,
		total: backupFixtures.length,
		count: backupFixtures.length
	},
	limit: 5,
	count: 3,
	permissions: {
		create: true,
		download: true,
		restore: true,
		delete: true
	},
	pending: {
		download: false,
		remove: false,
		restore: false,
		lock: false
	},
	validateName,
	actions: {
		setPage: noop,
		create: succeeded,
		download: async () => {},
		remove: succeeded,
		restore: succeeded,
		toggleLock: succeeded
	},
	...options
});
implementViews({
	"page.server.backups": {
		use: useBackupsPageModel,
		fixtures: pageStatusFixtures
	},
	"server.backups": {
		use: useBackupListModel,
		fixtures: {
			backups: () => listFixture(),
			empty: () => listFixture({
				backups: [],
				pagination: {
					page: 1,
					perPage: 20,
					total: 0,
					count: 0
				},
				count: 0
			}),
			full: () => listFixture({ limit: 3 }),
			noLimit: () => listFixture({
				backups: [],
				pagination: {
					page: 1,
					perPage: 20,
					total: 0,
					count: 0
				},
				limit: 0,
				count: 0
			}),
			paged: () => listFixture({
				pagination: {
					page: 2,
					perPage: 4,
					total: 9,
					count: backupFixtures.length
				},
				limit: 10,
				count: 8
			}),
			pastEnd: () => listFixture({
				backups: [],
				pagination: {
					page: 4,
					perPage: 20,
					total: 9,
					count: 0
				},
				limit: 10,
				count: 8
			}),
			readOnly: () => listFixture({ permissions: {
				create: false,
				download: false,
				restore: false,
				delete: false
			} })
		}
	}
});
//#endregion

//# sourceMappingURL=backups-CR1ATYiq.js.map