import { a as Spinner, n as ButtonWithVariants, t as ButtonStyle } from "./Button-BzlrfY24.js";
import { $ as Avatar, Dt as ServerContentBlock, H as Tooltip, Ot as PageContentBlock, at as EmptyTitle, et as Empty, h as fromNow, ht as NewButton, it as EmptyMedia, m as formatDate, nt as EmptyDescription, r as cn, rt as EmptyHeader, st as Alert, tt as EmptyContent, vt as Translate, yt as PaginationFooter } from "./sdk-Chrtpiam.js";
import { t as PanelLink } from "./navigation-9aP-0Hbq.js";
import { c as View } from "./theme-Cgy7R6cy.js";
import { o as Select } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { ClipboardList, FolderOpen, History, ListFilter, Monitor, Terminal, XCircle } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/activity/ActivityMetadataButton.tsx
function ActivityMetadataButton({ meta }) {
	return /* @__PURE__ */ jsx("div", {
		className: "self-center md:px-4",
		children: /* @__PURE__ */ jsx(Dialog.Trigger, {
			trigger: ({ onClick }) => /* @__PURE__ */ jsx("button", {
				type: "button",
				"aria-label": "View additional event metadata",
				className: "p-2 transition-colors duration-100 text-muted-foreground group-hover:text-muted-foreground hover:group-hover:text-foreground",
				onClick,
				children: /* @__PURE__ */ jsx(ClipboardList, { className: "w-5 h-5" })
			}),
			children: ({ open, onClose }) => /* @__PURE__ */ jsxs(Dialog, {
				open,
				onClose,
				hideCloseIcon: true,
				title: "Metadata",
				children: [/* @__PURE__ */ jsx("pre", {
					className: "bg-muted rounded-sm p-2 font-mono text-sm leading-relaxed overflow-x-scroll whitespace-pre-wrap",
					children: JSON.stringify(meta, null, 2)
				}), /* @__PURE__ */ jsx(Dialog.Footer, { children: /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
					onClick: onClose,
					children: "Close"
				}) })]
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/activity/ActivityLogEntry.tsx
var activityIconClass = "flex space-x-1 mx-2 transition-colors duration-100 text-muted-foreground [&_svg]:px-1 [&_svg]:py-px [&_svg]:cursor-pointer [&_svg]:h-5 [&_svg]:w-auto [&_svg]:hover:text-foreground";
var activityDescriptionClass = "mt-1 text-sm break-words line-clamp-2 pr-4 [&_strong]:break-all [&_strong]:font-semibold [&_strong]:text-foreground";
/** Emphasises every value the description interpolates, apart from the counts its plurals read. */
function wrapProperty(value) {
	if (Array.isArray(value)) return value.map(wrapProperty);
	if (value === true || value === false) return value;
	if (value instanceof Object) return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, key === "count" || key.endsWith("_count") ? item : wrapProperty(item)]));
	return `<strong>${String(value)}</strong>`;
}
var wrapProperties = (properties) => Object.fromEntries(Object.entries(properties).map(([key, value]) => [key, wrapProperty(value)]));
function ActivityLogEntry({ entry }) {
	const { actor } = entry;
	return /* @__PURE__ */ jsxs("div", {
		className: "grid grid-cols-10 py-4 border-b-2 border-border last:rounded-b-sm last:border-0 group",
		children: [/* @__PURE__ */ jsx("div", {
			className: "hidden sm:flex sm:col-span-1 items-center justify-center select-none",
			children: /* @__PURE__ */ jsx("div", {
				className: "flex items-center w-10 h-10 rounded-full bg-popover overflow-hidden",
				children: /* @__PURE__ */ jsx(Avatar, { name: actor?.username || actor?.email || "system" })
			})
		}), /* @__PURE__ */ jsxs("div", {
			className: "col-span-10 sm:col-span-9 flex",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "flex-1 px-4 sm:px-0",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-center text-foreground",
						children: [
							/* @__PURE__ */ jsx(Tooltip, {
								placement: "top",
								content: actor?.email || "System User",
								children: /* @__PURE__ */ jsx("span", { children: actor?.username || "System" })
							}),
							/* @__PURE__ */ jsx("span", {
								className: "text-muted-foreground",
								children: "\xA0—\xA0"
							}),
							/* @__PURE__ */ jsx(PanelLink, {
								destination: entry.filter,
								includeSearch: true,
								className: "transition-colors duration-75 active:text-accent hover:text-accent",
								children: entry.event
							}),
							/* @__PURE__ */ jsxs("div", {
								className: cn(activityIconClass, "group-hover:text-muted-foreground"),
								children: [
									entry.api && /* @__PURE__ */ jsx(Tooltip, {
										placement: "top",
										content: "Using API Key",
										children: /* @__PURE__ */ jsx(Terminal, {})
									}),
									entry.sftp && /* @__PURE__ */ jsx(Tooltip, {
										placement: "top",
										content: "Using SFTP",
										children: /* @__PURE__ */ jsx(FolderOpen, {})
									}),
									entry.userAgent !== null && /* @__PURE__ */ jsx(Tooltip, {
										content: entry.userAgent,
										placement: "top",
										children: /* @__PURE__ */ jsx("span", { children: /* @__PURE__ */ jsx(Monitor, {}) })
									})
								]
							})
						]
					}),
					/* @__PURE__ */ jsx("p", {
						className: activityDescriptionClass,
						children: /* @__PURE__ */ jsx(Translate, {
							ns: "activity",
							values: wrapProperties(entry.properties),
							i18nKey: entry.event.replace(":", ".")
						})
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-1 flex items-center text-sm",
						children: [entry.ip && /* @__PURE__ */ jsxs("span", { children: [entry.ip, /* @__PURE__ */ jsx("span", {
							className: "text-muted-foreground",
							children: "\xA0|\xA0"
						})] }), /* @__PURE__ */ jsx(Tooltip, {
							placement: "right",
							content: formatDate(entry.timestamp, "MMM Do, YYYY H:mm:ss"),
							children: /* @__PURE__ */ jsx("span", { children: fromNow(entry.timestamp) })
						})]
					})
				]
			}), entry.hasMetadata && /* @__PURE__ */ jsx(ActivityMetadataButton, { meta: entry.properties })]
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/activity/ActivityLog.tsx
var emptyMessages = {
	account: "Actions taken on your account will appear here.",
	server: "Actions taken on this server will appear here.",
	admin: "Actions taken through the admin panel will appear here."
};
function Results({ model, filtered }) {
	if (model.loading) return /* @__PURE__ */ jsx(Spinner, { centered: true });
	if (model.entries.length) return /* @__PURE__ */ jsx("div", {
		className: "bg-card",
		children: model.entries.map((entry) => /* @__PURE__ */ jsx(ActivityLogEntry, { entry }, entry.id))
	});
	return /* @__PURE__ */ jsxs(Empty, {
		className: "border bg-card",
		children: [/* @__PURE__ */ jsxs(EmptyHeader, { children: [
			/* @__PURE__ */ jsx(EmptyMedia, {
				variant: "icon",
				children: filtered ? /* @__PURE__ */ jsx(ListFilter, {}) : /* @__PURE__ */ jsx(History, {})
			}),
			/* @__PURE__ */ jsx(EmptyTitle, { children: filtered ? "No matching activity" : "No activity yet" }),
			/* @__PURE__ */ jsx(EmptyDescription, { children: filtered ? "No activity matches the selected filters." : emptyMessages[model.scope] })
		] }), filtered && /* @__PURE__ */ jsx(EmptyContent, { children: /* @__PURE__ */ jsx(NewButton, {
			isSecondary: true,
			icon: XCircle,
			onClick: model.actions.clearFilters,
			children: "Clear filters"
		}) })]
	});
}
function Filters({ model, filtered }) {
	const { actions } = model;
	return /* @__PURE__ */ jsxs("div", {
		className: "mb-3 flex flex-col gap-2 sm:flex-row sm:items-stretch",
		children: [
			model.users && /* @__PURE__ */ jsx("div", {
				className: "w-full sm:max-w-xs",
				children: /* @__PURE__ */ jsx(Select, {
					options: [{
						value: "",
						label: "All users"
					}, ...model.users],
					value: model.user ?? "",
					placeholder: "All users",
					searchPlaceholder: "Search users…",
					emptyMessage: "No users have acted here yet.",
					onChange: (value) => actions.setUser(String(value) || null)
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "w-full sm:max-w-sm",
				children: /* @__PURE__ */ jsx(Select, {
					groups: [{
						label: "",
						options: [{
							value: "",
							label: "All events"
						}]
					}, ...model.events.map((group) => ({
						label: group.label,
						options: [...group.options]
					}))],
					value: model.event ?? "",
					placeholder: "All events",
					searchPlaceholder: "Search events…",
					emptyMessage: "Nothing has been recorded here yet.",
					onChange: (value) => actions.setEvent(String(value) || null)
				})
			}),
			filtered && /* @__PURE__ */ jsxs(ButtonStyle, {
				type: "button",
				color: "grey",
				className: "inline-flex items-center justify-center w-full sm:w-auto sm:shrink-0 h-auto",
				onClick: actions.clearFilters,
				children: ["Clear Filters ", /* @__PURE__ */ jsx(XCircle, { className: "w-4 h-4 ml-2" })]
			})
		]
	});
}
function ActivityLog({ model, className }) {
	const filtered = model.event !== null || model.user !== null;
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [
			model.error !== null && /* @__PURE__ */ jsxs("div", {
				className: "mb-4 space-y-3",
				children: [/* @__PURE__ */ jsx(Alert, {
					type: "danger",
					children: model.error
				}), /* @__PURE__ */ jsx(ButtonStyle, {
					type: "button",
					color: "grey",
					onClick: model.retry,
					children: "Retry"
				})]
			}),
			/* @__PURE__ */ jsx(Filters, {
				model,
				filtered
			}),
			/* @__PURE__ */ jsx(Results, {
				model,
				filtered
			}),
			model.pagination && /* @__PURE__ */ jsx(PaginationFooter, {
				pagination: model.pagination,
				onPageSelect: model.actions.setPage
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/activity/AccountActivityPage.tsx
function AccountActivityPage({ className }) {
	return /* @__PURE__ */ jsx(PageContentBlock, {
		title: "Account Activity Log",
		className,
		children: /* @__PURE__ */ jsx(View, {
			name: "activity.log",
			scope: "account"
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/activity/ServerActivityPage.tsx
function ServerActivityPage({ className }) {
	return /* @__PURE__ */ jsx(ServerContentBlock, {
		title: "Activity Log",
		className,
		children: /* @__PURE__ */ jsx(View, {
			name: "activity.log",
			scope: "server"
		})
	});
}
//#endregion
export { AccountActivityPage, ActivityLog, ServerActivityPage };

//# sourceMappingURL=activity-DDM3t9YW.js.map