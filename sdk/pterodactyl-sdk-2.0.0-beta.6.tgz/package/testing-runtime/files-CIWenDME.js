import { Gt as implementViews, Jt as modelFromInput } from "./notifications-Ebj0Q0Io.js";
import { c as useCurrentServerUuid, i as useCurrentServer } from "./queries-D_-2KdyF.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { _ as normalizeServerPath, c as useServerStore, i as useServerDirectory, m as encodePathSegments, n as useFileUploadActions, r as useSelectedFiles, v as join, y as normalize } from "./server-U1WA-Nu8.js";
import { C as useUploadFiles, S as useServerFiles, _ as useDecompressFile, a as decompressFileInput, b as useRenameFiles, c as isFileObjectArchiveType, g as useCreateDirectory, h as useCopyFile, i as createDirectoryInput, l as isFileObjectEditable, m as useCompressFiles, n as compressFilesInput, o as deleteFilesInput, p as useChmodFiles, r as copyFileInput, s as fileObjectKind, t as chmodFilesInput, u as renameFilesInput, v as useDeleteFiles, y as useFileDownloadUrl } from "./queries-DIMnAeHP.js";
import { c as useFileEditorSession, i as createTestFileManager, l as fileBreadcrumbs, n as createTestFileEditor, o as createTestFileObject, r as createTestFileEditorPage, s as useFileEditorPage, t as createTestFileDetails, u as fileListDestination } from "./fileFixtures-u5el1pLN.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { useCallback, useEffect, useMemo, useRef } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
//#region ../../resources/scripts/components/server/files/useFileUploader.ts
var UPLOADED_DISPLAY_MS = 500;
/** Uploads into the current directory; rejects when any file failed, after its error toast. */
function useFileUploader() {
	const removals = useRef(/* @__PURE__ */ new Map());
	const { mutateAsync } = useUploadFiles();
	const uuid = useCurrentServerUuid();
	const directory = useServerDirectory();
	const { removeFileUpload, pushFileUpload, setUploadProgress } = useFileUploadActions();
	useEffect(() => {
		const pending = removals.current;
		return () => {
			for (const [id, timeout] of pending) {
				clearTimeout(timeout);
				removeFileUpload(id);
			}
			pending.clear();
		};
	}, [removeFileUpload]);
	return useCallback(async (files) => {
		if (files.some((file) => !file.type && (!file.size || file.size === 4096))) {
			toast.error("Folder uploads are not supported.");
			throw new Error("Folder uploads are not supported.");
		}
		const { failed } = await mutateAsync({
			uuid,
			directory,
			files: [...files],
			callbacks: {
				onFileQueued: (id, file, abort) => {
					pushFileUpload({
						id,
						data: {
							name: file.name,
							abort,
							loaded: 0,
							total: file.size
						}
					});
				},
				onFileProgress: (id, progress) => setUploadProgress({
					id,
					loaded: progress.loaded
				}),
				onFileSettled: (id, outcome) => {
					if (outcome !== "uploaded") {
						removeFileUpload(id);
						return;
					}
					const timeout = setTimeout(() => {
						removals.current.delete(id);
						removeFileUpload(id);
					}, UPLOADED_DISPLAY_MS);
					removals.current.set(id, timeout);
				}
			}
		});
		if (failed.length > 0) throw new Error(failed.length === 1 ? `Unable to upload ${failed[0].name}.` : `Unable to upload ${failed.length} files.`);
	}, [
		mutateAsync,
		uuid,
		directory,
		removeFileUpload,
		pushFileUpload,
		setUploadProgress
	]);
}
var noFiles = [];
var sortFiles = (files) => {
	const sortedFiles = files.sort((a, b) => a.attributes.name.localeCompare(b.attributes.name)).sort((a, b) => Number(a.attributes.is_file) - Number(b.attributes.is_file));
	return sortedFiles.filter((file, index) => index === 0 || file.attributes.name !== sortedFiles[index - 1].attributes.name);
};
function allow(granted, permission) {
	if (!granted) throw new Error(`This action requires the ${permission} permission.`);
}
/** Where opening an entry leads: its directory, the editor for a readable text file, or nowhere. */
function entryDestination(id, file, path, openable) {
	if (!openable) return null;
	return file.attributes.is_file ? {
		to: "/server/$id/files/$action",
		params: {
			id,
			action: "edit"
		},
		hash: encodePathSegments(path)
	} : fileListDestination(id, path);
}
/** The listing of the directory in the URL and its selection, as the file manager slots receive them. */
function useFileListing() {
	const server = useCurrentServer();
	const directory = useServerDirectory();
	const { data, refetch, isFetching } = useServerFiles(server?.attributes.uuid ?? "", directory);
	const setSelectedFiles = useServerStore((state) => state.files.setSelectedFiles);
	const storedSelection = useSelectedFiles();
	const files = data?.data ?? noFiles;
	const listed = useMemo(() => new Set(files.slice(0, 250).map((file) => file.attributes.name)), [files]);
	const selection = useMemo(() => {
		const present = storedSelection.filter((name) => listed.has(name));
		return present.length === storedSelection.length ? storedSelection : present;
	}, [storedSelection, listed]);
	const select = useCallback((names) => {
		setSelectedFiles({
			directory,
			files: [...new Set(names)].filter((name) => listed.has(name))
		});
	}, [
		listed,
		directory,
		setSelectedFiles
	]);
	const refresh = useCallback(async () => {
		const result = await refetch();
		if (result.error) throw result.error;
	}, [refetch]);
	const slot = useMemo(() => server ? {
		server,
		directory,
		files,
		selectedFiles: selection,
		isFetching,
		setSelectedFiles: select,
		refresh
	} : null, [
		server,
		directory,
		files,
		selection,
		isFetching,
		select,
		refresh
	]);
	if (!slot) throw new Error("The file manager renders once its server has loaded.");
	return {
		slot,
		listed: data !== void 0
	};
}
function useUploads() {
	const uploadsById = useServerStore((state) => state.files.uploads);
	const cancelUpload = useServerStore((state) => state.files.cancelFileUpload);
	const clearUploads = useServerStore((state) => state.files.clearFileUploads);
	return {
		uploads: useMemo(() => Object.entries(uploadsById).sort(([a, first], [b, second]) => first.name.localeCompare(second.name) || a.localeCompare(b)).map(([id, { name, loaded, total }]) => ({
			id,
			name,
			loaded,
			total
		})), [uploadsById]),
		cancelUpload,
		clearUploads
	};
}
function useFileManagerModel() {
	const { slot, listed } = useFileListing();
	const { server, directory, selectedFiles, isFetching, setSelectedFiles, refresh } = slot;
	const { identifier: id, uuid } = server.attributes;
	const navigate = useNavigate();
	const [canRead, canReadContent, canCreate, canUpdate, canDelete, canArchive] = usePermissions([
		"file.read",
		"file.read-content",
		"file.create",
		"file.update",
		"file.delete",
		"file.archive"
	]);
	const clearSelectedFiles = useServerStore((state) => state.files.clearSelectedFiles);
	const removeSelectedFile = useServerStore((state) => state.files.removeSelectedFile);
	const { mutateAsync: createDirectory } = useCreateDirectory();
	const { mutateAsync: renameFiles } = useRenameFiles();
	const { mutateAsync: deleteFiles } = useDeleteFiles();
	const { mutateAsync: copyFile } = useCopyFile(directory);
	const { mutateAsync: compressFiles } = useCompressFiles();
	const { mutateAsync: decompressFile } = useDecompressFile();
	const { mutateAsync: chmodFiles } = useChmodFiles();
	const { mutateAsync: downloadUrl } = useFileDownloadUrl();
	const upload = useFileUploader();
	const { uploads, cancelUpload, clearUploads } = useUploads();
	const files = useMemo(() => sortFiles(slot.files.slice(0, 250)), [slot.files]);
	const entries = useMemo(() => files.map((file) => {
		const path = join(directory, file.attributes.name);
		const openable = file.attributes.is_file ? isFileObjectEditable(file) && canReadContent : canRead;
		return {
			name: file.attributes.name,
			path,
			kind: fileObjectKind(file),
			size: file.attributes.size ?? 0,
			mimetype: file.attributes.mimetype,
			mode: file.attributes.mode ?? "",
			modeBits: file.attributes.mode_bits ?? "",
			modifiedAt: file.attributes.modified_at,
			openable,
			extractable: isFileObjectArchiveType(file),
			destination: entryDestination(id, file, path, openable),
			file
		};
	}), [
		files,
		id,
		directory,
		canRead,
		canReadContent
	]);
	const permissions = useMemo(() => ({
		create: canCreate,
		update: canUpdate,
		delete: canDelete,
		archive: canArchive
	}), [
		canCreate,
		canUpdate,
		canDelete,
		canArchive
	]);
	const actions = useMemo(() => {
		const show = (target) => navigate({
			to: "/server/$id/files",
			params: { id },
			hash: encodePathSegments(target)
		});
		const deselect = (names) => {
			for (const name of names) removeSelectedFile({
				directory,
				name
			});
		};
		const rename = async (renamed) => {
			allow(canUpdate, "file.update");
			await renameFiles(renameFilesInput(uuid, directory, renamed.map(({ from, to }) => ({
				from,
				to
			}))));
			clearSelectedFiles();
		};
		return {
			open: async (name) => {
				const entry = entries.find((entry) => entry.name === name);
				if (!entry?.openable) throw new Error(`"${name}" cannot be opened.`);
				await (entry.kind === "directory" ? show(entry.path) : navigate({
					to: "/server/$id/files/$action",
					params: {
						id,
						action: "edit"
					},
					hash: encodePathSegments(entry.path)
				}));
			},
			navigate: async (target) => {
				await show(normalize(target.startsWith("/") ? target : join(directory, target)));
			},
			newFile: async () => {
				allow(canCreate, "file.create");
				await navigate({
					to: "/server/$id/files/$action",
					params: {
						id,
						action: "new"
					},
					hash: encodePathSegments(directory)
				});
			},
			select: setSelectedFiles,
			refresh,
			createDirectory: async (name) => {
				allow(canCreate, "file.create");
				await createDirectory(createDirectoryInput(uuid, directory, name));
			},
			rename,
			move: (names, to) => rename(names.map((from) => ({
				from,
				to: names.length > 1 ? join(to, from) : to
			}))),
			remove: async (names) => {
				allow(canDelete, "file.delete");
				await deleteFiles(deleteFilesInput(uuid, directory, [...names]));
				deselect(names);
			},
			copy: async (name) => {
				allow(canCreate, "file.create");
				await copyFile(copyFileInput(uuid, join(directory, name)));
			},
			archive: async (names) => {
				allow(canArchive, "file.archive");
				await compressFiles(compressFilesInput(uuid, directory, [...names]));
				deselect(names);
			},
			extract: async (name) => {
				allow(canCreate, "file.create");
				allow(canUpdate, "file.update");
				await decompressFile(decompressFileInput(uuid, directory, name));
			},
			chmod: async (changed) => {
				allow(canUpdate, "file.update");
				await chmodFiles(chmodFilesInput(uuid, directory, changed.map(({ file, mode }) => ({
					file,
					mode
				}))));
				clearSelectedFiles();
			},
			download: async (name) => {
				window.location.assign(await downloadUrl({
					uuid,
					file: join(directory, name)
				}));
			},
			upload: async (uploaded) => {
				allow(canCreate, "file.create");
				allow(canUpdate, "file.update");
				await upload(uploaded);
			},
			cancelUpload,
			clearUploads
		};
	}, [
		navigate,
		id,
		uuid,
		directory,
		entries,
		canCreate,
		canUpdate,
		canDelete,
		canArchive,
		setSelectedFiles,
		refresh,
		clearSelectedFiles,
		removeSelectedFile,
		createDirectory,
		renameFiles,
		deleteFiles,
		copyFile,
		compressFiles,
		decompressFile,
		chmodFiles,
		downloadUrl,
		upload,
		cancelUpload,
		clearUploads
	]);
	return useMemo(() => ({
		directory,
		breadcrumbs: fileBreadcrumbs(id, directory, false),
		entries,
		truncated: slot.files.length > 250,
		loading: !listed,
		refreshing: listed && isFetching,
		selection: selectedFiles,
		permissions,
		newFileDestination: {
			to: "/server/$id/files/$action",
			params: {
				id,
				action: "new"
			},
			hash: encodePathSegments(directory)
		},
		uploads,
		resolve: (name) => normalizeServerPath(join(directory, name)),
		actions,
		slot
	}), [
		id,
		directory,
		entries,
		slot,
		listed,
		isFetching,
		selectedFiles,
		permissions,
		uploads,
		actions
	]);
}
//#endregion
//#region ../../resources/scripts/views/server/files.ts
var useFilesPageModel = () => pageStatus(useServerFiles(useCurrentServerUuid() ?? "", useServerDirectory()));
var fileDetails = ({ file }) => ({
	name: file.attributes.name,
	kind: fileObjectKind(file),
	size: file.attributes.size ?? 0,
	modifiedAt: file.attributes.modified_at
});
function useFileDetailsModel({ file }) {
	return useMemo(() => fileDetails({ file }), [file]);
}
implementViews({
	"page.server.files": {
		use: useFilesPageModel,
		fixtures: pageStatusFixtures
	},
	"server.files.manager": {
		use: useFileManagerModel,
		fixtures: {
			directory: () => createTestFileManager(),
			selected: () => createTestFileManager({ selection: ["config.json"] }),
			uploading: () => createTestFileManager({ uploads: [{
				id: "upload-1",
				name: "world.zip",
				loaded: 12 * 1024 ** 2,
				total: 48 * 1024 ** 2
			}] }),
			readOnly: () => createTestFileManager({ permissions: {
				create: false,
				update: false,
				delete: false,
				archive: false
			} }),
			empty: () => createTestFileManager({ entries: [] }),
			loading: () => createTestFileManager({
				entries: [],
				loading: true
			})
		}
	},
	"server.files.details": {
		use: useFileDetailsModel,
		fixtureFromInput: fileDetails,
		fixtures: {
			file: () => createTestFileDetails(),
			directory: () => createTestFileDetails({
				name: "plugins",
				kind: "directory",
				size: 0
			})
		},
		fixtureInput: (model) => ({ file: createTestFileObject(model) })
	},
	"page.server.files.editor": {
		use: useFileEditorPage,
		fixtures: {
			file: () => createTestFileEditorPage(),
			new: () => createTestFileEditorPage({ file: null }),
			loading: () => createTestFileEditorPage({ loading: true }),
			error: () => createTestFileEditorPage({ error: "Request failed with status code 404." })
		}
	},
	"server.files.editor": {
		use: useFileEditorSession,
		fixtures: {
			file: () => createTestFileEditor(),
			dirty: () => createTestFileEditor({ dirty: true }),
			saving: () => createTestFileEditor({
				dirty: true,
				saving: true
			}),
			readOnly: () => createTestFileEditor({ readOnly: true }),
			pteroignore: () => createTestFileEditor({
				path: "/.pteroignore",
				name: ".pteroignore",
				content: "*.log\n"
			}),
			new: () => createTestFileEditor({
				path: "/config",
				name: "",
				isNew: true,
				content: ""
			})
		}
	},
	"server.files.editor.notice": { use: modelFromInput },
	"server.files.editor.canvas": { use: modelFromInput },
	"server.files.editor.language": { use: modelFromInput },
	"server.files.editor.actions": { use: modelFromInput },
	"server.files.manager.toolbar": { use: modelFromInput },
	"server.files.manager.list": { use: modelFromInput },
	"server.files.manager.selection": { use: modelFromInput }
});
//#endregion

//# sourceMappingURL=files-CIWenDME.js.map