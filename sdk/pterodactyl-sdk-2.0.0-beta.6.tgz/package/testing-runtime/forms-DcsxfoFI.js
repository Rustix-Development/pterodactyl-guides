import { n as firstError, t as capitalize } from "./strings-BdGk5jKK.js";
//#region ../../resources/scripts/views/forms.ts
var noop = () => {};
function boundField(field, attributes = {}) {
	const error = firstError(field.state.meta.errors);
	return {
		fieldProps: {
			...attributes,
			name: field.name,
			value: field.state.value,
			onChange: (event) => field.handleChange(event.currentTarget.value),
			onBlur: field.handleBlur
		},
		error: error ? capitalize(error) : null
	};
}
/** A field kept in plain state, without validation. */
function stateField(name, value, setValue, attributes = {}) {
	return {
		fieldProps: {
			...attributes,
			name,
			value,
			onChange: (event) => setValue(event.currentTarget.value),
			onBlur: noop
		},
		error: null
	};
}
function fixtureField(name, attributes = {}, value = "", error = null) {
	return {
		fieldProps: {
			...attributes,
			name,
			value,
			onChange: noop,
			onBlur: noop
		},
		error
	};
}
//#endregion
export { fixtureField as n, stateField as r, boundField as t };

//# sourceMappingURL=forms-DcsxfoFI.js.map