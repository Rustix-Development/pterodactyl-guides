import { n as ButtonWithVariants, u as useSkin } from "./Button-BzlrfY24.js";
import { d as isString, l as isNumber } from "./client.gen-Ci-zROOW.js";
import { n as firstError, t as capitalize } from "./strings-BdGk5jKK.js";
import React, { useEffect, useId, useMemo, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Check, ChevronDown, Minus } from "lucide-react";
import { Input } from "@base-ui/react/input";
import { NumberField } from "@base-ui/react/number-field";
import { createFormHook, createFormHookContexts } from "@tanstack/react-form";
import { Combobox } from "@base-ui/react/combobox";
import { Switch } from "@base-ui/react/switch";
import { Checkbox } from "@base-ui/react/checkbox";
//#region ../../resources/scripts/components/form/controls.tsx
var controlState = ({ $isLight, $hasError }) => ({
	light: !!$isLight,
	error: !!$hasError
});
var TextInput = ({ $isLight, $hasError, className, ...props }) => {
	return /* @__PURE__ */ jsx(Input, {
		...useSkin("Input", controlState({
			$isLight,
			$hasError
		}))("root", className),
		...props
	});
};
var FileInput$1 = ({ className, ...props }) => {
	const ui = useSkin("FileInput", {});
	return /* @__PURE__ */ jsx("input", {
		...props,
		type: "file",
		...ui("root", className)
	});
};
var TextArea = ({ $isLight, $hasError, className, ...props }) => {
	return /* @__PURE__ */ jsx("textarea", {
		...useSkin("TextArea", controlState({
			$isLight,
			$hasError
		}))("root", className),
		...props
	});
};
var NumberInput = ({ $isLight, $hasError, className, value, onValueChange, min, max, step, format, disabled, ...props }) => {
	const ui = useSkin("NumberInput", controlState({
		$isLight,
		$hasError
	}));
	return /* @__PURE__ */ jsx(NumberField.Root, {
		...ui("root"),
		value,
		onValueChange,
		min,
		max,
		step,
		format: {
			useGrouping: false,
			...format
		},
		disabled,
		children: /* @__PURE__ */ jsx(NumberField.Input, {
			...ui("input", className),
			...props
		})
	});
};
//#endregion
//#region ../../resources/scripts/components/elements/Label.tsx
var Label = ({ as, isLight, className, ...props }) => {
	return /* @__PURE__ */ jsx(as || "label", {
		...useSkin("Label", { light: !!isLight })("root", className),
		...props
	});
};
//#endregion
//#region ../../resources/scripts/components/form/context.ts
var { fieldContext, formContext, useFieldContext, useFormContext } = createFormHookContexts();
//#endregion
//#region ../../resources/scripts/components/ui/Select.tsx
var optionLabel = (option) => {
	if (!option) return "";
	if (option.textLabel !== void 0) return option.textLabel;
	if (isString(option.label) || isNumber(option.label)) return String(option.label);
	return String(option.value);
};
var isTextLabel = (label) => isString(label) || isNumber(label);
var createValue = "\0create";
var createOption = (text, options) => {
	const query = text.trim();
	if (query === "" || options.some((option) => optionLabel(option).toLowerCase() === query.toLowerCase())) return null;
	return {
		value: createValue,
		label: `Create "${query}"`,
		textLabel: query
	};
};
var sameValue = (left, right) => Object.is(left, right);
var isSameOption = (option, selected) => sameValue(option.value, selected.value);
var optionKey = (option) => `${isNumber(option.value) ? "number" : "string"}:${String(option.value)}`;
var getOptions = (options, groups) => options ?? groups?.flatMap((group) => group.options) ?? [];
var getGroups = (groups) => groups?.map((group, index) => ({
	value: group.id === void 0 ? `${index}:${group.label}` : optionKey({ value: group.id }),
	label: group.label,
	items: group.options
}));
var CheckIcon = () => /* @__PURE__ */ jsx(Check, {
	size: 14,
	strokeWidth: 2.5,
	"aria-hidden": true
});
var ChevronIcon = () => /* @__PURE__ */ jsx(ChevronDown, {
	size: 16,
	"aria-hidden": true
});
var ComboboxOptionItem = ({ ui, option, showIndicator }) => /* @__PURE__ */ jsxs(Combobox.Item, {
	...ui("item"),
	value: option,
	disabled: option.disabled,
	children: [/* @__PURE__ */ jsx("span", {
		...ui("itemLabel"),
		children: option.label
	}), showIndicator && /* @__PURE__ */ jsx(Combobox.ItemIndicator, {
		...ui("indicator"),
		children: /* @__PURE__ */ jsx(CheckIcon, {})
	})]
});
var ComboboxOptionsList = ({ ui, groups, showIndicator }) => groups ? /* @__PURE__ */ jsx(Combobox.List, {
	...ui("list"),
	children: (group) => /* @__PURE__ */ jsxs(Combobox.Group, {
		items: group.items,
		...ui("group"),
		children: [/* @__PURE__ */ jsx(Combobox.GroupLabel, {
			...ui("groupLabel"),
			children: group.label
		}), /* @__PURE__ */ jsx(Combobox.Collection, { children: (option) => /* @__PURE__ */ jsx(ComboboxOptionItem, {
			ui,
			option,
			showIndicator
		}, optionKey(option)) })]
	}, group.value)
}) : /* @__PURE__ */ jsx(Combobox.List, {
	...ui("list"),
	children: (option) => /* @__PURE__ */ jsx(ComboboxOptionItem, {
		ui,
		option,
		showIndicator
	}, optionKey(option))
});
var ComboboxPopupContent = ({ ui, groupedItems, emptyMessage, showIndicator }) => /* @__PURE__ */ jsx(Combobox.Portal, { children: /* @__PURE__ */ jsx(Combobox.Positioner, {
	...ui("positioner"),
	sideOffset: 4,
	children: /* @__PURE__ */ jsxs(Combobox.Popup, {
		...ui("popup"),
		children: [/* @__PURE__ */ jsx(Combobox.Empty, {
			...ui("empty"),
			children: emptyMessage
		}), /* @__PURE__ */ jsx(ComboboxOptionsList, {
			ui,
			groups: groupedItems,
			showIndicator
		})]
	})
}) });
var singleSelectedValues = (value) => value === null || value === void 0 ? [] : [value];
var findOption = (candidates, value) => candidates.find((option) => sameValue(option.value, value));
var resolveSelectedOptions = (values, flatOptions, fallback) => values.flatMap((value) => {
	const option = findOption(flatOptions, value) ?? findOption(fallback, value);
	return option ? [option] : [];
});
var selectionSignature = (selected) => selected.map((option) => `${optionKey(option)}:${optionLabel(option)}`).join("\n");
function useSelectedOptions(flatOptions, values) {
	const [remembered, setRemembered] = React.useState(() => resolveSelectedOptions(values, flatOptions, []));
	const selected = resolveSelectedOptions(values, flatOptions, remembered);
	if (selectionSignature(selected) !== selectionSignature(remembered)) setRemembered(selected);
	return selected;
}
var resolveRichSelection = (selectedOption) => selectedOption && !isTextLabel(selectedOption.label) ? selectedOption.label : null;
function useSelectSearch({ onBlur, onSearchChange }) {
	const [searchValue, setSearchValue] = React.useState("");
	const [inputFocused, setInputFocused] = React.useState(false);
	const resetInputValue = React.useCallback(() => {
		setSearchValue("");
		onSearchChange?.("");
	}, [onSearchChange]);
	return {
		searchValue,
		setSearchValue,
		inputFocused,
		resetInputValue,
		handleInputValueChange: React.useCallback((value, eventDetails) => {
			if (eventDetails.reason === "focus-out" || eventDetails.reason === "input-blur" || !inputFocused) {
				resetInputValue();
				return;
			}
			setSearchValue(value);
			onSearchChange?.(value);
		}, [
			inputFocused,
			onSearchChange,
			resetInputValue
		]),
		handleFocus: React.useCallback(() => {
			setInputFocused(true);
		}, []),
		handleBlur: React.useCallback((event) => {
			setInputFocused(false);
			resetInputValue();
			onBlur?.(event);
		}, [onBlur, resetInputValue]),
		externalFilter: onSearchChange ? null : void 0
	};
}
function MultiSelectCombobox({ ui, id, placeholder, searchPlaceholder, emptyMessage, disabled, items, groupedItems, selectedOptions, inputValue, inputAria, search, onChange, onCreate }) {
	return /* @__PURE__ */ jsxs(Combobox.Root, {
		multiple: true,
		items,
		value: selectedOptions,
		inputValue,
		onInputValueChange: search.handleInputValueChange,
		onOpenChange: (open) => {
			if (!open) search.resetInputValue();
		},
		onValueChange: (value) => {
			const created = value.find((option) => option.value === createValue);
			if (created && onCreate) onCreate(optionLabel(created));
			else onChange(value.map((option) => option.value));
			search.resetInputValue();
		},
		filter: search.externalFilter,
		disabled,
		itemToStringLabel: optionLabel,
		itemToStringValue: (option) => String(option?.value ?? ""),
		isItemEqualToValue: isSameOption,
		autoHighlight: true,
		children: [/* @__PURE__ */ jsxs(Combobox.InputGroup, {
			...ui("root"),
			children: [/* @__PURE__ */ jsx(Combobox.Value, { children: (value) => /* @__PURE__ */ jsxs(Fragment$1, { children: [value.length > 0 && /* @__PURE__ */ jsx("span", {
				...ui("summary"),
				children: `${value.length} selected`
			}), /* @__PURE__ */ jsx(Combobox.Input, {
				...ui("input"),
				...inputAria,
				id,
				placeholder: value.length > 0 ? searchPlaceholder : placeholder,
				onFocus: search.handleFocus,
				onBlur: search.handleBlur
			})] }) }), /* @__PURE__ */ jsx(Combobox.Trigger, {
				...ui("trigger"),
				"aria-label": "Open popup",
				children: /* @__PURE__ */ jsx(ChevronIcon, {})
			})]
		}), /* @__PURE__ */ jsx(ComboboxPopupContent, {
			ui,
			groupedItems,
			emptyMessage,
			showIndicator: true
		})]
	});
}
function SingleSelectCombobox({ ui, id, placeholder, emptyMessage, disabled, items, groupedItems, selectedOption, inputValue, richSelection, inputAria, search, onChange, onSelectLabel }) {
	return /* @__PURE__ */ jsxs(Combobox.Root, {
		items,
		value: selectedOption,
		inputValue,
		onInputValueChange: search.handleInputValueChange,
		onOpenChange: (open) => {
			if (!open) search.resetInputValue();
		},
		onValueChange: (option) => {
			if (option) {
				onChange(option.value);
				onSelectLabel(optionLabel(option));
			}
		},
		filter: search.externalFilter,
		disabled,
		itemToStringLabel: optionLabel,
		itemToStringValue: (option) => String(option?.value ?? ""),
		isItemEqualToValue: isSameOption,
		autoHighlight: true,
		children: [/* @__PURE__ */ jsxs(Combobox.InputGroup, {
			...ui("root"),
			children: [
				richSelection && /* @__PURE__ */ jsx("span", {
					...ui("preview"),
					children: richSelection
				}),
				/* @__PURE__ */ jsx(Combobox.Input, {
					...ui("input"),
					...inputAria,
					id,
					placeholder,
					onFocus: search.handleFocus,
					onBlur: search.handleBlur
				}),
				/* @__PURE__ */ jsx(Combobox.Trigger, {
					...ui("trigger"),
					"aria-label": "Open popup",
					children: /* @__PURE__ */ jsx(ChevronIcon, {})
				})
			]
		}), /* @__PURE__ */ jsx(ComboboxPopupContent, {
			ui,
			groupedItems,
			emptyMessage,
			showIndicator: false
		})]
	});
}
function Select(props) {
	const { id, options, groups, disabled, placeholder, searchPlaceholder = "Search...", emptyMessage = "No results found.", hasError, onBlur, onSearchChange } = props;
	const flatOptions = getOptions(options, groups);
	const groupedItems = getGroups(groups);
	const items = groupedItems ?? flatOptions;
	const search = useSelectSearch({
		onBlur,
		onSearchChange
	});
	const selectedOptions = useSelectedOptions(flatOptions, props.multiple ? props.value : singleSelectedValues(props.value));
	const inputAria = {
		"aria-describedby": props["aria-describedby"],
		"aria-invalid": props["aria-invalid"]
	};
	const richSelection = props.multiple ? null : resolveRichSelection(selectedOptions[0] ?? null);
	const ui = useSkin("Select", {
		error: !!hasError,
		multiple: !!props.multiple,
		selected: selectedOptions.length > 0,
		richLabel: !!richSelection,
		searching: search.inputFocused
	});
	if (props.multiple) {
		const inputValue = search.inputFocused ? search.searchValue : "";
		const creatable = props.onCreate && !groupedItems ? createOption(inputValue, flatOptions) : null;
		return /* @__PURE__ */ jsx(MultiSelectCombobox, {
			ui,
			id,
			placeholder,
			searchPlaceholder,
			emptyMessage,
			disabled,
			items: creatable ? [...flatOptions, creatable] : items,
			groupedItems,
			selectedOptions,
			inputValue,
			inputAria,
			search,
			onChange: props.onChange,
			onCreate: props.onCreate
		});
	}
	const selectedOption = selectedOptions[0] ?? null;
	const selectedLabel = optionLabel(selectedOption);
	return /* @__PURE__ */ jsx(SingleSelectCombobox, {
		ui,
		id,
		placeholder,
		emptyMessage,
		disabled,
		items,
		groupedItems,
		selectedOption,
		inputValue: search.inputFocused ? search.searchValue : selectedLabel,
		richSelection,
		inputAria,
		search,
		onChange: props.onChange,
		onSelectLabel: search.setSearchValue
	});
}
//#endregion
//#region ../../resources/scripts/components/ui/Switch.tsx
function Switch$1({ checked, onChange, disabled, id, name, label, description, controlPosition = "start", className, onBlur, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy }) {
	const generatedId = useId();
	const fieldId = id ?? generatedId;
	const labelId = `${generatedId}-label`;
	const descriptionId = `${generatedId}-description`;
	const hasText = !!label || !!description;
	const ui = useSkin("Switch", {
		described: !!description,
		position: controlPosition
	});
	const control = /* @__PURE__ */ jsx(Switch.Root, {
		id: fieldId,
		name,
		checked,
		onCheckedChange: onChange,
		onBlur,
		disabled,
		"aria-label": ariaLabel,
		"aria-labelledby": ariaLabelledBy ?? (label ? labelId : void 0),
		"aria-describedby": description ? descriptionId : void 0,
		...ui("control"),
		children: /* @__PURE__ */ jsx(Switch.Thumb, { ...ui("thumb") })
	});
	const text = hasText ? /* @__PURE__ */ jsxs("div", {
		...ui("text"),
		children: [label && /* @__PURE__ */ jsx(Label, {
			id: labelId,
			htmlFor: fieldId,
			className: ui.classes("label"),
			children: label
		}), description && /* @__PURE__ */ jsx("p", {
			id: descriptionId,
			...ui("description"),
			children: description
		})]
	}) : null;
	return /* @__PURE__ */ jsx("div", {
		...ui("root", className),
		children: controlPosition === "end" ? /* @__PURE__ */ jsxs(Fragment$1, { children: [text, control] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [control, text] })
	});
}
//#endregion
//#region ../../resources/scripts/components/ui/Checkbox.tsx
function Checkbox$1({ checked, onChange, indeterminate, className, ...props }) {
	const ui = useSkin("Checkbox", {});
	return /* @__PURE__ */ jsx(Checkbox.Root, {
		...props,
		checked,
		indeterminate,
		onCheckedChange: onChange,
		...ui("root", className),
		children: /* @__PURE__ */ jsx(Checkbox.Indicator, {
			...ui("indicator"),
			children: indeterminate ? /* @__PURE__ */ jsx(Minus, {
				size: 14,
				strokeWidth: 2.5,
				"aria-hidden": true
			}) : /* @__PURE__ */ jsx(Check, {
				size: 14,
				strokeWidth: 2.5,
				"aria-hidden": true
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/form/fields.tsx
var HelpText = ({ id, error, description }) => {
	if (error) return /* @__PURE__ */ jsx("p", {
		id,
		className: "input-help error",
		children: capitalize(error)
	});
	if (!description) return null;
	return /* @__PURE__ */ jsx("p", {
		id,
		className: "input-help",
		children: description
	});
};
var describedBy = (...ids) => ids.filter((id) => !!id).join(" ") || void 0;
function useFieldState(id, description) {
	const field = useFieldContext();
	const generatedId = useId();
	const error = firstError(field.state.meta.errors);
	const helpId = `${generatedId}-help`;
	return {
		field,
		error,
		fieldId: id ?? generatedId,
		helpId,
		describedById: error || description ? helpId : void 0
	};
}
function TextField({ id, label, description, light, onBlur, "aria-describedby": ariaDescribedBy, "aria-invalid": ariaInvalid, ...props }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(TextInput, {
			...props,
			id: fieldId,
			value: field.state.value ?? "",
			onValueChange: (value) => field.handleChange(value),
			onBlur: (event) => {
				field.handleBlur();
				onBlur?.(event);
			},
			"aria-invalid": error ? true : ariaInvalid,
			"aria-describedby": describedBy(ariaDescribedBy, describedById),
			$hasError: !!error,
			$isLight: light
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
function TextAreaField({ id, label, description, light, onBlur, "aria-describedby": ariaDescribedBy, "aria-invalid": ariaInvalid, ...props }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(TextArea, {
			...props,
			id: fieldId,
			value: field.state.value ?? "",
			onChange: (event) => field.handleChange(event.target.value),
			onBlur: (event) => {
				field.handleBlur();
				onBlur?.(event);
			},
			"aria-invalid": error ? true : ariaInvalid,
			"aria-describedby": describedBy(ariaDescribedBy, describedById),
			$hasError: !!error,
			$isLight: light
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
/** Binds a `number | null` field; an emptied input stores null. */
function NumberField$1({ id, label, description, light, min, max, format, ...props }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(NumberInput, {
			...props,
			id: fieldId,
			value: field.state.value ?? null,
			onValueChange: (value) => field.handleChange(value),
			onBlur: field.handleBlur,
			min,
			max,
			format,
			"aria-invalid": error ? true : void 0,
			"aria-describedby": describedById,
			$hasError: !!error,
			$isLight: light
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
function SelectField({ id, label, description, light, options, disabled, placeholder, emptyMessage, onChange, onSearchChange }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(Select, {
			id: fieldId,
			options,
			value: field.state.value ?? null,
			onChange: (value) => {
				field.handleChange(value);
				onChange?.(value);
			},
			disabled,
			placeholder,
			emptyMessage,
			hasError: !!error,
			"aria-invalid": error ? true : void 0,
			"aria-describedby": describedById,
			onBlur: field.handleBlur,
			onSearchChange
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
function MultiSelectField({ id, label, description, light, options, disabled, placeholder = "None selected", searchPlaceholder, onCreate }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	const selected = Array.isArray(field.state.value) ? field.state.value : [];
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(Select, {
			multiple: true,
			id: fieldId,
			options,
			value: selected,
			onChange: (value) => field.handleChange(value),
			onCreate,
			disabled,
			placeholder,
			searchPlaceholder,
			hasError: !!error,
			"aria-invalid": error ? true : void 0,
			"aria-describedby": describedById,
			onBlur: field.handleBlur
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
function SwitchField({ label, description, disabled, controlPosition, className }) {
	const field = useFieldContext();
	return /* @__PURE__ */ jsx(Switch$1, {
		checked: !!field.state.value,
		onChange: (checked) => field.handleChange(checked),
		onBlur: field.handleBlur,
		disabled,
		label,
		description,
		controlPosition,
		className
	});
}
/** Adds or removes `value` in a `string[]` field. */
function CheckboxField({ value, disabled, className }) {
	const field = useFieldContext();
	const selected = Array.isArray(field.state.value) ? field.state.value : [];
	return /* @__PURE__ */ jsx(Checkbox$1, {
		className,
		checked: selected.includes(value),
		disabled,
		onChange: (checked) => {
			const set = new Set(selected);
			if (checked) set.add(value);
			else set.delete(value);
			field.handleChange([...set]);
		}
	});
}
//#endregion
//#region ../../resources/scripts/components/form/SubmitButton.tsx
/** Disabled while the form cannot submit; shows a spinner while it submits. */
function SubmitButton({ children, disabled, ...props }) {
	return /* @__PURE__ */ jsx(useFormContext().Subscribe, {
		selector: (state) => ({
			canSubmit: state.canSubmit,
			isSubmitting: state.isSubmitting
		}),
		children: ({ canSubmit, isSubmitting }) => /* @__PURE__ */ jsx(ButtonWithVariants, {
			type: "submit",
			disabled: disabled || !canSubmit,
			isLoading: isSubmitting,
			...props,
			children
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/form/Form.tsx
function Form({ form, children, ...props }) {
	return /* @__PURE__ */ jsx("form", {
		noValidate: true,
		...props,
		onSubmit: (event) => {
			event.preventDefault();
			event.stopPropagation();
			form.handleSubmit();
		},
		children
	});
}
var { useAppForm } = createFormHook({
	fieldContext,
	formContext,
	fieldComponents: {
		TextField,
		TextAreaField,
		NumberField: NumberField$1,
		SelectField,
		MultiSelectField,
		SwitchField,
		CheckboxField
	},
	formComponents: { SubmitButton }
});
//#endregion
//#region ../../resources/scripts/plugins/useDebouncedCallback.ts
/** A pending call still runs when the component unmounts. */
var useDebouncedCallback = (callback, delay) => {
	const callbackRef = useRef(callback);
	const timeoutRef = useRef(null);
	const pendingRef = useRef(null);
	useEffect(() => {
		callbackRef.current = callback;
	}, [callback]);
	const debounced = useMemo(() => {
		const cancel = () => {
			if (timeoutRef.current) {
				clearTimeout(timeoutRef.current);
				timeoutRef.current = null;
			}
			pendingRef.current = null;
		};
		const flush = () => {
			const args = pendingRef.current;
			cancel();
			if (args) callbackRef.current(...args);
		};
		const call = (...args) => {
			cancel();
			pendingRef.current = args;
			timeoutRef.current = setTimeout(flush, delay);
		};
		return Object.assign(call, {
			cancel,
			flush
		});
	}, [delay]);
	useEffect(() => debounced.flush, [debounced]);
	return debounced;
};
//#endregion
export { Switch$1 as a, useFormContext as c, NumberInput as d, TextArea as f, Checkbox$1 as i, Label as l, useAppForm as n, Select as o, TextInput as p, Form as r, useFieldContext as s, useDebouncedCallback as t, FileInput$1 as u };

//# sourceMappingURL=useDebouncedCallback-B4Ebjqc5.js.map