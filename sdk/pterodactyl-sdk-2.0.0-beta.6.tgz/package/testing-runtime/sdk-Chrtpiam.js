import { a as __toESM, n as require_builtin_esm_external_require_react, r as __commonJSMin, t as require_shim } from "./shim-Ewd7CxJ0.js";
import { t as cn$1 } from "./cn-f7uEsK4g.js";
import { a as Spinner, c as replaceable, i as RouterLinkButton, n as ButtonWithVariants, p as Icon, u as useSkin } from "./Button-BzlrfY24.js";
import { d as isString$2 } from "./client.gen-Ci-zROOW.js";
import { F as clientGetServerLogsOptions, Ft as clientGetExtensionJobProgress, P as clientGetFileContentsQueryKey, U as clientGetStartupConfigurationQueryKey, Z as clientListFilesQueryKey, rt as clientListServerBackupsQueryKey, z as clientGetServerResourcesQueryKey, zt as clientGetServerExtensionJobProgress } from "./notifications-Ebj0Q0Io.js";
import { a as navItemKey, f as ExtensionContext, h as getThemeIcon, n as NavigationLink, o as useActiveNavItem, p as useExtensionCallback, r as navItemBadge, s as useNavItemActive, t as Navigation } from "./navigation-DAcCRZlc.js";
import { c as useCurrentServerUuid$1, i as useCurrentServer$1, n as serverQueryFilters, o as useCurrentServerName, r as serverQueryOptions$1, s as useCurrentServerPermissions$1 } from "./queries-D_-2KdyF.js";
import { n as usePermissions, t as hasPermission } from "./usePermissions-pEpnhvzH.js";
import { a as usePanelNavigate, n as resolvePanelDestination, t as PanelLink } from "./navigation-9aP-0Hbq.js";
import { f as useElementWidth } from "./server-U1WA-Nu8.js";
import { p as setPageTitle } from "./theme-Cgy7R6cy.js";
import { f as TextArea, p as TextInput } from "./useDebouncedCallback-B4Ebjqc5.js";
import { r as useCurrentUser$1 } from "./queries-BF8_5ZD3.js";
import { b as useRenameFiles, d as serverFileContentQueryOptions$1, f as serverFilesQueryOptions$1, g as useCreateDirectory, i as createDirectoryInput, o as deleteFilesInput, u as renameFilesInput, v as useDeleteFiles, w as writeFileContentsInput, x as useSaveFileContent } from "./queries-DIMnAeHP.js";
import { t as retryUnlessClientError } from "./queryRetry-CsJb-5Ht.js";
import { t as queryClient } from "./queryClient-CU2lXun5.js";
import { a as useUpdateStartupVariable, i as useSetSelectedDockerImage, t as serverStartupQueryOptions$1 } from "./queries-BuegeFTA.js";
import { a as serverBackupsQueryOptions$1, l as useCreateServerBackup$1, n as createServerBackupInput } from "./queries-Czk-nC2C.js";
import { n as serverResourceUsageRefetchInterval, t as serverResourceUsageQueryOptions } from "./queries-ubEuC6zs.js";
import { i as useSendServerCommand$1, n as sendServerCommandInput, r as useSendPowerAction, t as sendPowerActionInput } from "./queries-C7BIoT7v.js";
import "./useShortcut-BKaL2-k7.js";
import { n as useSiteSettings$1 } from "./queries-DXZ7OlB6.js";
import { r as useWebsocketEvent } from "./events-BZtD8HxQ.js";
import * as React$1 from "react";
import React, { Children, Fragment, Suspense, cloneElement, createContext, createElement, isValidElement, lazy, use, useCallback, useContext, useEffect, useId, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Link } from "@tanstack/react-router";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { ArrowDown, ArrowLeft, ArrowUp, ArrowUpDown, ChartNoAxesCombined, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Copy, Eye, EyeOff, File, Info, KeyRound, Menu, MoreHorizontal, Network, Pencil, Plus, Puzzle, RefreshCw, Server, Settings, ShieldAlert, Terminal, Trash2, TriangleAlert, Users } from "lucide-react";
import { queryOptions, skipToken, useQuery } from "@tanstack/react-query";
import { toast as toast$1 } from "sonner";
import * as ReactDOM from "react-dom";
import { createPortal } from "react-dom";
import { Menu as Menu$1 } from "@base-ui/react/menu";
import { ContextMenu } from "@base-ui/react/context-menu";
//#region ../../resources/scripts/components/elements/NamedIcon.tsx
var bundled = new Map([
	["chart-no-axes-combined", ChartNoAxesCombined],
	["file", File],
	["key-round", KeyRound],
	["network", Network],
	["puzzle", Puzzle],
	["server", Server],
	["settings", Settings],
	["terminal", Terminal],
	["users", Users]
]);
var listeners = /* @__PURE__ */ new Set();
var catalog;
var pending;
function loadCatalog() {
	pending ??= import("./iconCatalog-CCEB_yK2.js").catch(() => null).then((loaded) => {
		catalog = loaded;
		for (const listener of listeners) listener();
		return loaded;
	});
	return pending;
}
function subscribeCatalog(listener) {
	listeners.add(listener);
	loadCatalog();
	return () => {
		listeners.delete(listener);
	};
}
var subscribeNothing = () => () => {};
var getCatalog = () => catalog;
/** Every icon name this panel can render. */
async function loadIconNames() {
	return (await loadCatalog())?.iconNames ?? [...bundled.keys()];
}
/** The icon for a name, the active theme's first: `undefined` while the icon set loads, `null` when unknown. */
function useNamedIcon(name) {
	const immediate = getThemeIcon(name) ?? bundled.get(name);
	const loaded = useSyncExternalStore(immediate ? subscribeNothing : subscribeCatalog, getCatalog);
	if (immediate) return immediate;
	return loaded === void 0 ? void 0 : loaded?.resolveIcon(name) ?? null;
}
function NamedIcon({ name, fallback = Puzzle, className, size = "1em", ...rest }) {
	const Resolved = useNamedIcon(name);
	if (Resolved === void 0) return /* @__PURE__ */ jsx("span", {
		"aria-hidden": true,
		className: cn$1("inline-block", className),
		style: {
			width: size,
			height: size
		}
	});
	return /* @__PURE__ */ jsx(Resolved ?? fallback, {
		className: cn$1("inline-block", className),
		size,
		...rest
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/Can.tsx
function Can({ action, matchAny = false, renderOnError, children }) {
	const can = usePermissions(action);
	return matchAny && can.some((p) => p) || !matchAny && can.every((p) => p) ? children : renderOnError;
}
//#endregion
//#region ../../resources/scripts/components/elements/SpinnerOverlay.tsx
var SpinnerOverlay = ({ size, fixed, visible, backgroundOpacity, children }) => {
	const ui = useSkin("SpinnerOverlay", { fixed: !!fixed });
	if (!visible) return null;
	return /* @__PURE__ */ jsxs("div", {
		...ui("root"),
		style: backgroundOpacity === void 0 ? void 0 : { "--spinner-overlay-opacity": `${backgroundOpacity * 100}%` },
		children: [/* @__PURE__ */ jsx(Spinner, { size }), children && /* @__PURE__ */ jsx("p", {
			...ui("text"),
			children
		})]
	});
};
//#endregion
//#region ../../resources/scripts/components/elements/Card.tsx
/** A surface for a section of content; with a title or actions it has a header above its body. */
function CoreCard({ title, icon, actions, loading = false, className, bodyClassName, children }) {
	const titled = !!title || !!actions;
	const ui = useSkin("Card", {
		titled,
		actions: !!actions,
		loading
	});
	return /* @__PURE__ */ jsxs("div", {
		...ui("root", className),
		children: [loading && /* @__PURE__ */ jsx(SpinnerOverlay, { visible: true }), titled ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("div", {
			...ui("header"),
			children: [isString$2(title) ? /* @__PURE__ */ jsxs("h2", {
				...ui("title"),
				children: [icon && /* @__PURE__ */ jsx(Icon, {
					icon,
					...ui("icon")
				}), title]
			}) : title, !!actions && /* @__PURE__ */ jsx("div", {
				...ui("actions"),
				children: actions
			})]
		}), /* @__PURE__ */ jsx("div", {
			...ui("body", bodyClassName),
			children
		})] }) : children]
	});
}
var Card = replaceable("Card", CoreCard);
//#endregion
//#region ../../resources/scripts/components/elements/ListRow.tsx
var RowState = createContext({ interactive: false });
/** A row of a list, such as a server on the dashboard. */
function CoreListRow({ as: Element = "div", destination, exact, interactive, status, className, children, ...props }) {
	const clickable = interactive ?? (destination !== void 0 || props.onClick !== void 0);
	const state = useMemo(() => ({
		interactive: clickable,
		status
	}), [clickable, status]);
	const ui = useSkin("ListRow", state);
	const content = /* @__PURE__ */ jsxs(RowState.Provider, {
		value: state,
		children: [children, status && /* @__PURE__ */ jsx("div", { ...ui("status") })]
	});
	if (destination) return /* @__PURE__ */ jsx(PanelLink, {
		destination,
		exact,
		...ui("root", className),
		...props,
		children: content
	});
	return /* @__PURE__ */ jsx(Element, {
		...ui("root", className),
		...props,
		children: content
	});
}
/** A part of the row around it, for the row's content to place. */
function rowPart(part, Element) {
	function ListRowPart({ className, children }) {
		return /* @__PURE__ */ jsx(Element, {
			...useSkin("ListRow", useContext(RowState))(part, className),
			children
		});
	}
	ListRowPart.displayName = `ListRow.${part.charAt(0).toUpperCase()}${part.slice(1)}`;
	return ListRowPart;
}
var ListRow = Object.assign(replaceable("ListRow", CoreListRow), {
	Icon: rowPart("icon", "div"),
	Title: rowPart("title", "p"),
	Description: rowPart("description", "p")
});
//#endregion
//#region ../../resources/scripts/components/elements/ProgressBar.tsx
function CoreProgressBar({ value, variant = "meter", tone, label, className }) {
	const meter = variant === "meter";
	const ui = useSkin("ProgressBar", {
		variant,
		tone: tone ?? (meter ? "neutral" : "accent")
	});
	return /* @__PURE__ */ jsx("div", {
		...ui("root", className),
		role: meter ? "progressbar" : void 0,
		"aria-label": meter ? label : void 0,
		"aria-valuemin": meter ? 0 : void 0,
		"aria-valuemax": meter ? 100 : void 0,
		"aria-valuenow": meter ? value ?? void 0 : void 0,
		children: value !== null && /* @__PURE__ */ jsx("div", {
			...ui("indicator"),
			style: { width: `${value}%` }
		})
	});
}
var ProgressBar = replaceable("ProgressBar", CoreProgressBar);
//#endregion
//#region ../../resources/scripts/components/elements/Stat.tsx
/** A labelled value with an optional icon, limit and meter, such as a server's memory use. */
function CoreStat({ label, value, limit, icon: Icon, meter, tone = "neutral", variant = "tile", unavailable = false, className, ...props }) {
	const ui = useSkin("Stat", {
		variant,
		tone,
		unavailable
	});
	return /* @__PURE__ */ jsxs("div", {
		...ui("root", className),
		...props,
		children: [
			/* @__PURE__ */ jsx("div", { ...ui("indicator") }),
			Icon && /* @__PURE__ */ jsx("div", {
				...ui("icon"),
				children: /* @__PURE__ */ jsx(Icon, {
					"aria-hidden": true,
					...ui("glyph")
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				...ui("body"),
				children: [
					/* @__PURE__ */ jsx("p", {
						...ui("label"),
						children: label
					}),
					/* @__PURE__ */ jsx("p", {
						...ui("value"),
						children: value
					}),
					limit !== void 0 && /* @__PURE__ */ jsx("span", {
						...ui("limit"),
						children: limit
					}),
					meter !== void 0 && /* @__PURE__ */ jsx(ProgressBar, {
						value: meter,
						tone,
						label
					})
				]
			})
		]
	});
}
var Stat = replaceable("Stat", CoreStat);
//#endregion
//#region ../../resources/scripts/components/elements/ChartCard.tsx
/** The frame of a chart: a titled surface with an optional legend. */
function CoreChartCard({ title, legend, className, children }) {
	const ui = useSkin("ChartCard", {});
	return /* @__PURE__ */ jsxs("div", {
		...ui("root", className),
		children: [/* @__PURE__ */ jsxs("div", {
			...ui("header"),
			children: [/* @__PURE__ */ jsx("h3", {
				...ui("title"),
				children: title
			}), legend && /* @__PURE__ */ jsx("div", {
				...ui("legend"),
				children: legend
			})]
		}), /* @__PURE__ */ jsx("div", {
			...ui("body"),
			children
		})]
	});
}
var ChartCard = replaceable("ChartCard", CoreChartCard);
//#endregion
//#region ../../resources/scripts/components/elements/PageFooter.tsx
/** The copyright line below each page's content. Replace it with a component that renders nothing to drop it. */
function CorePageFooter({ className }) {
	const ui = useSkin("PageFooter", {});
	return /* @__PURE__ */ jsx("div", {
		...ui("root", className),
		children: /* @__PURE__ */ jsxs("p", {
			...ui("text"),
			children: [
				/* @__PURE__ */ jsx("a", {
					rel: "noopener nofollow noreferrer",
					href: "https://pterodactyl.io",
					target: "_blank",
					...ui("link"),
					children: "Pterodactyl®"
				}),
				"\xA0© 2015 - ",
				/* @__PURE__ */ jsx("span", {
					suppressHydrationWarning: true,
					children: (/* @__PURE__ */ new Date()).getFullYear()
				})
			]
		})
	});
}
var PageFooter = replaceable("PageFooter", CorePageFooter);
//#endregion
//#region ../../resources/scripts/components/elements/Badge.tsx
/** A short status or count label. */
function CoreBadge({ tone = "neutral", size = "md", variant = "solid", className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		...useSkin("Badge", {
			tone,
			size,
			variant
		})("root", className),
		...props
	});
}
var Badge = replaceable("Badge", CoreBadge);
//#endregion
//#region ../../resources/scripts/components/elements/Code.tsx
function Code$1({ dark, className, children }) {
	return /* @__PURE__ */ jsx("code", {
		...useSkin("Code", { dark: !!dark })("root", className),
		children
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/ContentBox.tsx
/** A section title above a plain `Card`. */
var ContentBox = ({ title, borderColor, showLoadingOverlay, children, ...props }) => /* @__PURE__ */ jsxs("div", {
	...props,
	children: [title && /* @__PURE__ */ jsx("h2", {
		className: cn$1("font-header text-lg font-semibold tracking-normal text-foreground", "mb-4 px-4"),
		children: title
	}), /* @__PURE__ */ jsx(Card, {
		loading: showLoadingOverlay,
		className: borderColor ? "border-t-4" : void 0,
		children
	})]
});
//#endregion
//#region ../../resources/scripts/components/elements/ContentContainer.tsx
/** Page content's width and side margins: the `page-width` utility, tuned by `--layout-gutter`. */
var ContentContainer = ({ className, ...props }) => /* @__PURE__ */ jsx("div", {
	className: cn$1("page-width", className),
	...props
});
ContentContainer.displayName = "ContentContainer";
//#endregion
//#region ../../resources/scripts/components/elements/PageContentBlock.tsx
/**
* A page's content and its footer. The content is `page-width` with `--layout-page-spacing` above and
* below; the geometry tokens cascade, so a page changes its own by setting them in `className`.
*/
var PageContentBlock = ({ title, className, children }) => {
	useEffect(() => {
		if (title) setPageTitle(title);
	}, [title]);
	return /* @__PURE__ */ jsxs("div", {
		className,
		children: [/* @__PURE__ */ jsx(ContentContainer, {
			className: "my-(--layout-page-spacing)",
			children
		}), /* @__PURE__ */ jsx(PageFooter, {})]
	});
};
//#endregion
//#region ../../resources/scripts/components/elements/ServerContentBlock.tsx
var ServerContentBlock = ({ title, children, ...props }) => {
	const name = useCurrentServerName();
	return /* @__PURE__ */ jsx(PageContentBlock, {
		title: title && name ? `${name} | ${title}` : title,
		...props,
		children
	});
};
//#endregion
//#region ../../resources/scripts/components/elements/TitledGreyBox.tsx
/** A `Card` with a header. */
var TitledGreyBox = ({ icon, title, children, className, contentClassName }) => /* @__PURE__ */ jsx(Card, {
	title,
	icon,
	className,
	bodyClassName: contentClassName,
	children
});
//#endregion
//#region ../../resources/scripts/components/elements/Portal.tsx
/** Renders `children` into the page's overlay layer, or the body where there is none, as in tests. */
function Portal({ children }) {
	return createPortal(children, document.getElementById("modal-portal") ?? document.body);
}
//#endregion
//#region ../../resources/scripts/lib/clipboard.ts
/** Falls back to execCommand('copy') where the Clipboard API is unavailable, such as over plain HTTP. */
async function copyToClipboard(text) {
	if (window.isSecureContext && navigator.clipboard) try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {}
	const textarea = document.createElement("textarea");
	textarea.value = text;
	textarea.setAttribute("readonly", "");
	textarea.style.position = "fixed";
	textarea.style.top = "0";
	textarea.style.left = "0";
	textarea.style.opacity = "0";
	textarea.style.pointerEvents = "none";
	document.body.appendChild(textarea);
	textarea.focus();
	textarea.select();
	let succeeded = false;
	try {
		succeeded = document.execCommand("copy");
	} catch {
		succeeded = false;
	}
	document.body.removeChild(textarea);
	return succeeded;
}
//#endregion
//#region ../../resources/scripts/components/elements/CopyOnClick.tsx
var interactiveTypes = new Set([
	"a",
	"button",
	"input",
	"select",
	"textarea",
	ButtonWithVariants,
	ButtonWithVariants.Text,
	ButtonWithVariants.Danger,
	TextInput,
	TextArea
]);
var copyStatusMessage = (status, text, showInNotification) => {
	if (status === "failed") return "Unable to copy text to clipboard.";
	return showInNotification ? `Copied "${String(text)}" to clipboard.` : "Copied text to clipboard.";
};
/** Copies `text` when its single child is clicked; a non-interactive child becomes a focusable button. */
var CopyOnClick = ({ text, showInNotification = false, children }) => {
	const [status, setStatus] = useState(null);
	const ui = useSkin("CopyOnClick", { status: status ?? void 0 });
	useEffect(() => {
		if (!status) return;
		const timeout = setTimeout(() => {
			setStatus(null);
		}, 2500);
		return () => {
			clearTimeout(timeout);
		};
	}, [status]);
	if (!React.isValidElement(children)) throw new Error("Component passed to <CopyOnClick/> must be a valid React element.");
	const element = React.Children.only(children);
	const copy = () => {
		copyToClipboard(String(text)).then((copied) => setStatus(copied ? "copied" : "failed"));
	};
	const interactive = interactiveTypes.has(element.type);
	const onKeyDown = (e) => {
		element.props.onKeyDown?.(e);
		if (!e.defaultPrevented && e.target === e.currentTarget && (e.key === "Enter" || e.key === " ")) {
			e.preventDefault();
			copy();
		}
	};
	const child = text ? React.cloneElement(element, {
		role: interactive ? element.props.role : element.props.role ?? "button",
		tabIndex: interactive ? element.props.tabIndex : element.props.tabIndex ?? 0,
		onKeyDown: interactive ? element.props.onKeyDown : onKeyDown,
		className: cn$1(element.props.className, ui.classes("target")),
		onClick: (e) => {
			copy();
			element.props.onClick?.(e);
		}
	}) : element;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [status && /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx("div", {
		...ui("root"),
		children: /* @__PURE__ */ jsx("div", {
			role: "status",
			...ui("status"),
			children: /* @__PURE__ */ jsx("p", {
				...ui("message"),
				children: copyStatusMessage(status, text, showInNotification)
			})
		})
	}) }), child] });
};
//#endregion
//#region ../../resources/scripts/assets/images/not_found.svg
var not_found_default = "data:image/svg+xml,%3csvg%20id='a706cf1c-1654-439b-8fcf-310eb7aa0e00'%20data-name='Layer%201'%20xmlns='http://www.w3.org/2000/svg'%20width='1120.59226'%20height='777.91584'%20viewBox='0%200%201120.59226%20777.91584'%3e%3ctitle%3enot%20found%3c/title%3e%3ccircle%20cx='212.59226'%20cy='103'%20r='64'%20fill='%23ff6584'/%3e%3cpath%20d='M563.68016,404.16381c0,151.01141-89.77389,203.73895-200.51559,203.73895S162.649,555.17522,162.649,404.16381,363.16457,61.04208,363.16457,61.04208,563.68016,253.1524,563.68016,404.16381Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%23f2f2f2'/%3e%3cpolygon%20points='316.156%20523.761%20318.21%20397.378%20403.674%20241.024%20318.532%20377.552%20319.455%20320.725%20378.357%20207.605%20319.699%20305.687%20319.699%20305.687%20321.359%20203.481%20384.433%20113.423%20321.621%20187.409%20322.658%200%20316.138%20248.096%20316.674%20237.861%20252.547%20139.704%20315.646%20257.508%20309.671%20371.654%20309.493%20368.625%20235.565%20265.329%20309.269%20379.328%20308.522%20393.603%20308.388%20393.818%20308.449%20394.99%20293.29%20684.589%20313.544%20684.589%20315.974%20535.005%20389.496%20421.285%20316.156%20523.761'%20fill='%233f3d56'/%3e%3cpath%20d='M1160.29613,466.01367c0,123.61-73.4842,166.77-164.13156,166.77s-164.13156-43.16-164.13156-166.77S996.16457,185.15218,996.16457,185.15218,1160.29613,342.40364,1160.29613,466.01367Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%23f2f2f2'/%3e%3cpolygon%20points='950.482%20552.833%20952.162%20449.383%201022.119%20321.4%20952.426%20433.154%20953.182%20386.639%201001.396%20294.044%20953.382%20374.329%20953.382%20374.329%20954.741%20290.669%201006.369%20216.952%20954.954%20277.514%20955.804%20124.11%20950.467%20327.188%20950.906%20318.811%20898.414%20238.464%20950.064%20334.893%20945.173%20428.327%20945.027%20425.847%20884.514%20341.294%20944.844%20434.608%20944.232%20446.293%20944.123%20446.469%20944.173%20447.428%20931.764%20684.478%20948.343%20684.478%20950.332%20562.037%201010.514%20468.952%20950.482%20552.833'%20fill='%233f3d56'/%3e%3cellipse%20cx='554.59226'%20cy='680.47903'%20rx='554.59226'%20ry='28.03433'%20fill='%233f3d56'/%3e%3cellipse%20cx='892.44491'%20cy='726.79663'%20rx='94.98858'%20ry='4.80162'%20fill='%233f3d56'/%3e%3cellipse%20cx='548.71959'%20cy='773.11422'%20rx='94.98858'%20ry='4.80162'%20fill='%233f3d56'/%3e%3cellipse%20cx='287.94432'%20cy='734.27887'%20rx='217.01436'%20ry='10.96996'%20fill='%233f3d56'/%3e%3ccircle%20cx='97.08375'%20cy='566.26982'%20r='79'%20fill='%232f2e41'/%3e%3crect%20x='99.80546'%20y='689.02332'%20width='24'%20height='43'%20transform='translate(-31.32451%20-62.31008)%20rotate(0.67509)'%20fill='%232f2e41'/%3e%3crect%20x='147.80213'%20y='689.58887'%20width='24'%20height='43'%20transform='translate(-31.31452%20-62.87555)%20rotate(0.67509)'%20fill='%232f2e41'/%3e%3cellipse%20cx='119.54569'%20cy='732.61606'%20rx='7.5'%20ry='20'%20transform='translate(-654.1319%20782.47948)%20rotate(-89.32491)'%20fill='%232f2e41'/%3e%3cellipse%20cx='167.55414'%20cy='732.18168'%20rx='7.5'%20ry='20'%20transform='translate(-606.25475%20830.05533)%20rotate(-89.32491)'%20fill='%232f2e41'/%3e%3ccircle%20cx='99.31925'%20cy='546.29477'%20r='27'%20fill='%23fff'/%3e%3ccircle%20cx='99.31925'%20cy='546.29477'%20r='9'%20fill='%233f3d56'/%3e%3cpath%20d='M61.02588,552.94636c-6.04185-28.64075,14.68758-57.26483,46.30049-63.93367s62.13813,11.14292,68.18,39.78367-14.97834,38.93-46.59124,45.59886S67.06774,581.58712,61.02588,552.94636Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M257.29613,671.38411c0,55.07585-32.73985,74.3063-73.13,74.3063q-1.40351,0-2.80255-.0312c-1.87139-.04011-3.72494-.1292-5.55619-.254-36.45135-2.57979-64.77127-22.79937-64.77127-74.02113,0-53.00843,67.73872-119.89612,72.827-124.84633l.00892-.00889c.19608-.19159.29409-.28516.29409-.28516S257.29613,616.30827,257.29613,671.38411Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M181.50168,737.26482l26.747-37.37367-26.81386,41.4773-.07125,4.29076c-1.87139-.04011-3.72494-.1292-5.55619-.254l2.88282-55.10258-.0223-.42775.049-.0802.27179-5.20415-26.88076-41.5798,26.96539,37.67668.06244,1.105,2.17874-41.63324-23.0132-42.96551,23.29391,35.6583,2.26789-86.31419.00892-.294v.28516l-.37871,68.064,22.91079-26.98321-23.00435,32.84678-.60595,37.27566L204.18523,621.958l-21.4805,41.259-.33863,20.723,31.05561-49.79149-31.17146,57.023Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%233f3d56'/%3e%3ccircle%20cx='712.48505'%20cy='565.41532'%20r='79'%20fill='%232f2e41'/%3e%3crect%20x='741.77716'%20y='691.82355'%20width='24'%20height='43'%20transform='translate(-215.99457%20191.86399)%20rotate(-17.08345)'%20fill='%232f2e41'/%3e%3crect%20x='787.6593'%20y='677.72286'%20width='24'%20height='43'%20transform='matrix(0.95588,%20-0.29376,%200.29376,%200.95588,%20-209.82788,%20204.72037)'%20fill='%232f2e41'/%3e%3cellipse%20cx='767.887'%20cy='732.00275'%20rx='20'%20ry='7.5'%20transform='translate(-220.8593%20196.83312)%20rotate(-17.08345)'%20fill='%232f2e41'/%3e%3cellipse%20cx='813.47537'%20cy='716.94619'%20rx='20'%20ry='7.5'%20transform='translate(-214.42477%20209.56103)%20rotate(-17.08345)'%20fill='%232f2e41'/%3e%3ccircle%20cx='708.52153'%20cy='545.71023'%20r='27'%20fill='%23fff'/%3e%3ccircle%20cx='708.52153'%20cy='545.71023'%20r='9'%20fill='%233f3d56'/%3e%3cpath%20d='M657.35526,578.74316c-14.48957-25.43323-3.47841-59.016,24.59412-75.0092s62.57592-8.34055,77.06549,17.09268-2.39072,41.6435-30.46325,57.63671S671.84483,604.17639,657.35526,578.74316Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M611.29613,661.29875c0,50.55711-30.05368,68.20979-67.13,68.20979q-1.28835,0-2.57261-.02864c-1.71785-.03682-3.41933-.1186-5.10033-.23313-33.46068-2.36813-59.45707-20.92878-59.45707-67.948,0-48.65932,62.18106-110.05916,66.85186-114.60322l.00819-.00817c.18-.17587.27-.26177.27-.26177S611.29613,610.74164,611.29613,661.29875Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M541.72029,721.77424l24.55253-34.30732-24.6139,38.07426-.0654,3.93872c-1.71785-.03682-3.41933-.1186-5.10033-.23313l2.6463-50.58165-.02047-.39266.045-.07361.24949-4.77718-24.67531-38.16836,24.753,34.58547.05731,1.01433,2-38.21741-21.12507-39.44039L541.80616,625.928l2.08182-79.23247.00819-.26994v.26177l-.34764,62.47962,21.031-24.76934-21.11693,30.15184-.55624,34.21735,19.63634-32.839-19.71812,37.87389-.31085,19.0228,28.50763-45.70631-28.614,52.34448Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%233f3d56'/%3e%3cpath%20d='M875.29613,682.38411c0,55.07585-32.73985,74.3063-73.13,74.3063q-1.4035,0-2.80255-.0312c-1.87139-.04011-3.72494-.1292-5.55619-.254-36.45135-2.57979-64.77127-22.79937-64.77127-74.02113,0-53.00843,67.73872-119.89612,72.827-124.84633l.00892-.00889c.19608-.19159.29409-.28516.29409-.28516S875.29613,627.30827,875.29613,682.38411Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M799.50168,748.26482l26.747-37.37367-26.81386,41.4773-.07125,4.29076c-1.87139-.04011-3.72494-.1292-5.55619-.254l2.88282-55.10258-.0223-.42775.049-.0802.27179-5.20415L770.108,654.01076l26.96539,37.67668.06244,1.105,2.17874-41.63324-23.0132-42.96551,23.29391,35.6583,2.26789-86.31419.00892-.294v.28516l-.37871,68.064,22.91079-26.98321-23.00435,32.84678-.606,37.27566L822.18523,632.958l-21.4805,41.259-.33863,20.723,31.05561-49.79149-31.17146,57.023Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%233f3d56'/%3e%3cellipse%20cx='721.51694'%20cy='656.82212'%20rx='12.40027'%20ry='39.5'%20transform='translate(-220.83517%20966.22323)%20rotate(-64.62574)'%20fill='%232f2e41'/%3e%3cellipse%20cx='112.51694'%20cy='651.82212'%20rx='12.40027'%20ry='39.5'%20transform='translate(-574.07936%20452.71367)%20rotate(-68.15829)'%20fill='%232f2e41'/%3e%3c/svg%3e";
//#endregion
//#region ../../resources/scripts/assets/images/server_error.svg
var server_error_default = "data:image/svg+xml,%3csvg%20id='aa03ddf9-f8f2-4819-a4ce-be9b0a220741'%20data-name='Layer%201'%20xmlns='http://www.w3.org/2000/svg'%20width='1119.60911'%20height='699'%20viewBox='0%200%201119.60911%20699'%3e%3ctitle%3eserver%20down%3c/title%3e%3ccircle%20cx='292.60911'%20cy='213'%20r='213'%20fill='%23f2f2f2'/%3e%3cpath%20d='M31.39089,151.64237c0,77.49789,48.6181,140.20819,108.70073,140.20819'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpath%20d='M140.09162,291.85056c0-78.36865,54.255-141.78356,121.30372-141.78356'%20transform='translate(-31.39089%20-100.5)'%20fill='%230967d3'/%3e%3cpath%20d='M70.77521,158.66768c0,73.61476,31.00285,133.18288,69.31641,133.18288'%20transform='translate(-31.39089%20-100.5)'%20fill='%230967d3'/%3e%3cpath%20d='M140.09162,291.85056c0-100.13772,62.7103-181.16788,140.20819-181.16788'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpath%20d='M117.22379,292.83905s15.41555-.47479,20.06141-3.783,23.713-7.2585,24.86553-1.95278,23.16671,26.38821,5.76263,26.5286-40.43935-2.711-45.07627-5.53549S117.22379,292.83905,117.22379,292.83905Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%23a8a8a8'/%3e%3cpath%20d='M168.224,311.78489c-17.40408.14042-40.43933-2.71094-45.07626-5.53548-3.53126-2.151-4.93843-9.86945-5.40926-13.43043-.32607.014-.51463.02-.51463.02s.97638,12.43276,5.61331,15.2573,27.67217,5.67589,45.07626,5.53547c5.02386-.04052,6.7592-1.82793,6.66391-4.47526C173.87935,310.756,171.96329,311.75474,168.224,311.78489Z'%20transform='translate(-31.39089%20-100.5)'%20opacity='0.2'/%3e%3cellipse%20cx='198.60911'%20cy='424.5'%20rx='187'%20ry='25.43993'%20fill='%233f3d56'/%3e%3cellipse%20cx='198.60911'%20cy='424.5'%20rx='157'%20ry='21.35866'%20opacity='0.1'/%3e%3cellipse%20cx='836.60911'%20cy='660.5'%20rx='283'%20ry='38.5'%20fill='%233f3d56'/%3e%3cellipse%20cx='310.60911'%20cy='645.5'%20rx='170'%20ry='23.12721'%20fill='%233f3d56'/%3e%3cpath%20d='M494,726.5c90,23,263-30,282-90'%20transform='translate(-31.39089%20-100.5)'%20fill='none'%20stroke='%232f2e41'%20stroke-miterlimit='10'%20stroke-width='2'/%3e%3cpath%20d='M341,359.5s130-36,138,80-107,149-17,172'%20transform='translate(-31.39089%20-100.5)'%20fill='none'%20stroke='%232f2e41'%20stroke-miterlimit='10'%20stroke-width='2'/%3e%3cpath%20d='M215.40233,637.78332s39.0723-10.82,41.47675,24.04449-32.15951,44.78287-5.10946,51.69566'%20transform='translate(-31.39089%20-100.5)'%20fill='none'%20stroke='%232f2e41'%20stroke-miterlimit='10'%20stroke-width='2'/%3e%3cpath%20d='M810.09554,663.73988,802.218,714.03505s-38.78182,20.60284-11.51335,21.20881,155.73324,0,155.73324,0,24.84461,0-14.54318-21.81478l-7.87756-52.719Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpath%20d='M785.21906,734.69812c6.193-5.51039,16.9989-11.252,16.9989-11.252l7.87756-50.2952,113.9216.10717,7.87756,49.582c9.185,5.08711,14.8749,8.987,18.20362,11.97818,5.05882-1.15422,10.58716-5.44353-18.20362-21.38921l-7.87756-52.719-113.9216,3.02983L802.218,714.03506S769.62985,731.34968,785.21906,734.69812Z'%20transform='translate(-31.39089%20-100.5)'%20opacity='0.1'/%3e%3crect%20x='578.43291'%20y='212.68859'%20width='513.25314'%20height='357.51989'%20rx='18.04568'%20fill='%232f2e41'/%3e%3crect%20x='595.70294'%20y='231.77652'%20width='478.71308'%20height='267.83694'%20fill='%233f3d56'/%3e%3ccircle%20cx='835.05948'%20cy='223.29299'%20r='3.02983'%20fill='%23f2f2f2'/%3e%3cpath%20d='M1123.07694,621.32226V652.6628a18.04341,18.04341,0,0,1-18.04568,18.04568H627.86949A18.04341,18.04341,0,0,1,609.8238,652.6628V621.32226Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpolygon%20points='968.978%20667.466%20968.978%20673.526%20642.968%20673.526%20642.968%20668.678%20643.417%20667.466%20651.452%20645.651%20962.312%20645.651%20968.978%20667.466'%20fill='%232f2e41'/%3e%3cpath%20d='M1125.828,762.03359c-.59383,2.539-2.83591,5.21743-7.90178,7.75032-18.179,9.08949-55.1429-2.42386-55.1429-2.42386s-28.4804-4.84773-28.4804-17.573a22.72457,22.72457,0,0,1,2.49658-1.48459c7.64294-4.04351,32.98449-14.02122,77.9177.42248a18.73921,18.73921,0,0,1,8.54106,5.59715C1125.07908,756.45353,1126.50669,759.15715,1125.828,762.03359Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpath%20d='M1125.828,762.03359c-22.251,8.526-42.0843,9.1622-62.43871-4.975-10.26507-7.12617-19.59089-8.88955-26.58979-8.75618,7.64294-4.04351,32.98449-14.02122,77.9177.42248a18.73921,18.73921,0,0,1,8.54106,5.59715C1125.07908,756.45353,1126.50669,759.15715,1125.828,762.03359Z'%20transform='translate(-31.39089%20-100.5)'%20opacity='0.1'/%3e%3cellipse%20cx='1066.53846'%20cy='654.13477'%20rx='7.87756'%20ry='2.42386'%20fill='%23f2f2f2'/%3e%3ccircle%20cx='835.05948'%20cy='545.66686'%20r='11.51335'%20fill='%23f2f2f2'/%3e%3cpolygon%20points='968.978%20667.466%20968.978%20673.526%20642.968%20673.526%20642.968%20668.678%20643.417%20667.466%20968.978%20667.466'%20opacity='0.1'/%3e%3crect%20x='108.60911'%20y='159'%20width='208'%20height='242'%20fill='%232f2e41'/%3e%3crect%20x='87.60911'%20y='135'%20width='250'%20height='86'%20fill='%233f3d56'/%3e%3crect%20x='87.60911'%20y='237'%20width='250'%20height='86'%20fill='%233f3d56'/%3e%3crect%20x='87.60911'%20y='339'%20width='250'%20height='86'%20fill='%233f3d56'/%3e%3crect%20x='271.60911'%20y='150'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.4'/%3e%3crect%20x='294.60911'%20y='150'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.8'/%3e%3crect%20x='317.60911'%20y='150'%20width='16'%20height='16'%20fill='%230967d3'/%3e%3crect%20x='271.60911'%20y='251'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.4'/%3e%3crect%20x='294.60911'%20y='251'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.8'/%3e%3crect%20x='317.60911'%20y='251'%20width='16'%20height='16'%20fill='%230967d3'/%3e%3crect%20x='271.60911'%20y='352'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.4'/%3e%3crect%20x='294.60911'%20y='352'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.8'/%3e%3crect%20x='317.60911'%20y='352'%20width='16'%20height='16'%20fill='%230967d3'/%3e%3ccircle%20cx='316.60911'%20cy='538'%20r='79'%20fill='%232f2e41'/%3e%3crect%20x='280.60911'%20y='600'%20width='24'%20height='43'%20fill='%232f2e41'/%3e%3crect%20x='328.60911'%20y='600'%20width='24'%20height='43'%20fill='%232f2e41'/%3e%3cellipse%20cx='300.60911'%20cy='643.5'%20rx='20'%20ry='7.5'%20fill='%232f2e41'/%3e%3cellipse%20cx='348.60911'%20cy='642.5'%20rx='20'%20ry='7.5'%20fill='%232f2e41'/%3e%3ccircle%20cx='318.60911'%20cy='518'%20r='27'%20fill='%23fff'/%3e%3ccircle%20cx='318.60911'%20cy='518'%20r='9'%20fill='%233f3d56'/%3e%3cpath%20d='M271.36733,565.03228c-6.37889-28.56758,14.01185-57.43392,45.544-64.47477s62.2651,10.41,68.644,38.9776-14.51861,39.10379-46.05075,46.14464S277.74622,593.59986,271.36733,565.03228Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%230967d3'/%3e%3cellipse%20cx='417.21511'%20cy='611.34365'%20rx='39.5'%20ry='12.40027'%20transform='translate(-238.28665%20112.98044)%20rotate(-23.17116)'%20fill='%232f2e41'/%3e%3cellipse%20cx='269.21511'%20cy='664.34365'%20rx='39.5'%20ry='12.40027'%20transform='translate(-271.07969%2059.02084)%20rotate(-23.17116)'%20fill='%232f2e41'/%3e%3cpath%20d='M394,661.5c0,7.732-19.90861,23-42,23s-43-14.268-43-22,20.90861-6,43-6S394,653.768,394,661.5Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%23fff'/%3e%3c/svg%3e";
//#endregion
//#region ../../resources/scripts/components/elements/ScreenBlock.tsx
/** The panel's illustrations for a `ScreenBlock`. */
var screenImages = {
	error: server_error_default,
	installing: "data:image/svg+xml,%3csvg%20id='f1903550-5374-4fc8-959e-1f31e4981ba4'%20data-name='Layer%201'%20xmlns='http://www.w3.org/2000/svg'%20xmlns:xlink='http://www.w3.org/1999/xlink'%20width='1017.23'%20height='708.31'%20viewBox='0%200%201017.23%20708.31'%3e%3cdefs%3e%3clinearGradient%20id='ae8f1d99-169f-42eb-bca8-084a90728b1c'%20x1='815.82'%20y1='804.15'%20x2='815.82'%20y2='292.5'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20offset='0'%20stop-color='gray'%20stop-opacity='0.25'/%3e%3cstop%20offset='0.54'%20stop-color='gray'%20stop-opacity='0.12'/%3e%3cstop%20offset='1'%20stop-color='gray'%20stop-opacity='0.1'/%3e%3c/linearGradient%3e%3c/defs%3e%3ctitle%3euploading%3c/title%3e%3cpath%20d='M685.63,207.25c-64.72-2.25-126.36-23.14-185.23-46S383.24,113.06,320.07,101c-40.63-7.79-87.09-8.89-119.83,12.89-31.5,21-41.68,57.15-47.16,90.72-4.11,25.27-6.54,51.85,4.75,75.5,7.83,16.42,21.74,30.22,31.36,45.95,33.46,54.72,9.81,122.2-26.46,175.63-17,25.06-36.74,49-49.87,75.66s-19.2,57.25-7.72,84.47c11.39,27,38.52,47.24,67.9,61.49,59.69,28.94,130,37.23,198.62,41.92,151.82,10.39,304.46,5.89,456.68,1.39,56.34-1.67,112.92-3.36,168.34-12.07,30.78-4.84,62.56-12.52,84.9-31,28.36-23.53,35.39-63.38,16.39-92.88-31.88-49.49-120-61.79-142.31-114.9-12.27-29.23.33-61.8,18.15-88.91,38.24-58.17,102.33-109.19,105.71-175.68,2.32-45.66-28.49-91.39-76.13-113-49.94-22.65-119.18-19.8-156,17.69C809.43,194.38,742.77,209.23,685.63,207.25Z'%20transform='translate(-91.39%20-95.85)'%20fill='%230967d3'%20opacity='0.1'/%3e%3cg%20opacity='0.1'%3e%3cpath%20d='M177.74,424.21S103,392.77,93.17,449.46c0,0-5.11,8.84,2,16.14,0,0,1.53-3.92,8.75.13a37.17,37.17,0,0,0,8.16,3.32,18.36,18.36,0,0,0,11.62-.62h0s24.59-1.33,45.27-33.5c0,0,8.87-5.48,9.31-7.54l-14.82,1s1.14,10.85-5,17.36c0,0,5.44-16.84,2.83-17.31-.53-.1-7.83.86-7.83.86s1.89,18.87-8,28.63c0,0,9.18-19.19,5.19-28.29l-10.94,2.11s3,19.85-7.82,31.39c0,0,8.9-20.4,5.46-30.76l-10.47,3.52s2.52,19.41-6.53,29c0,0,7.9-24.61,4.18-28,0,0-9.42,3.82-11.43,6,0,0,1.49,14-4.26,19.05,0,0,3.53-17,1.78-17.7,0,0-10.94,8.24-14.28,15.35,0,0,4.16-10.86,12.91-17,0,0-7.35-1.24-13,1.83,0,0,3.78-7.21,15.65-3.79,0,0,8.79-6.09,10.55-6,0,0-11.23-5-19.34-4.38,0,0,8.7-5,22.08,3.35l10.45-3.77s-14.5-7.43-21.76-7.4c0,0,9.66-3.74,24.47,6.66l10.7-2.18s-12-7.35-20.09-9.06c0,0,9.7-1.54,23.18,8.55l7.31-.61s-8.85-5.22-11.53-6.49-2.56-2.09-2.56-2.09a34.89,34.89,0,0,1,17.16,8.26S177.68,425.14,177.74,424.21Z'%20transform='translate(-91.39%20-95.85)'%20fill='%230967d3'/%3e%3c/g%3e%3cg%20opacity='0.1'%3e%3cpath%20d='M175,367.85s-26.51-61.27-64.63-33.17c0,0-8.06,2.34-8,10.7,0,0,3.14-1.46,5.13,5.07a30.1,30.1,0,0,0,3,6.61,15,15,0,0,0,7.25,6.25h0s15.37,13.22,46,5.89c0,0,8.4,1.79,9.83.83l-9.36-7.87s-5.51,7.1-12.89,7.44c0,0,12.83-6.9,11.55-8.67-.26-.36-5.15-3.94-5.15-3.94s-9.62,12.28-21,12.47c0,0,16.39-6.18,19.2-13.85l-7.7-5s-9.54,13.49-22.53,14.19c0,0,16.91-7.05,20.77-15.17l-8.23-3.87s-9.56,13-20.37,13.49c0,0,18.72-10.12,18.43-14.25,0,0-7.77-3.1-10.24-2.92,0,0-7.07,9.15-13.38,8.89,0,0,11.79-8.09,11.15-9.5,0,0-11.2-1.34-17.23,1,0,0,8.66-4.08,17.35-2.74,0,0-3.66-4.93-8.75-6.3,0,0,6.36-2.13,11.46,6.65,0,0,8.68,1.4,9.7,2.44,0,0-3.81-9.39-9-13.62,0,0,8,2,11.2,14.57l8.36,3.71s-4.38-12.68-8.72-16.79c0,0,7.87,3.28,10.75,17.9l7.6,4.79s-2.94-11.2-6.77-16.83c0,0,6.64,4.62,8.89,18.29l4.7,3.8s-2.29-8.14-3.16-10.42-.33-2.7-.33-2.7a28.65,28.65,0,0,1,5.49,14.68S174.41,368.36,175,367.85Z'%20transform='translate(-91.39%20-95.85)'%20fill='%230967d3'/%3e%3c/g%3e%3cpath%20d='M1024.66,763c-1-3.62-2-7.29-4-10.44a36.28,36.28,0,0,0-6.56-7.17c-7.25-6.59-16.16-13.28-25.77-11.61a34,34,0,0,0-8.56,3.12c-1.4.65-2.81,1.3-4.25,1.85a21.2,21.2,0,0,1-12.83,1.12c-2.2-.59-4.25-1.65-6.42-2.31a20.72,20.72,0,0,0-3.16-.68,58.18,58.18,0,0,0,6.1-3.21C970,727,978.61,715,977.4,702.3c-.4-4.3-1.88-8.41-3.34-12.46q-1.92-5.31-3.85-10.63c-1.66-4.61-3.37-9.3-6.41-13.13-3.38-4.26-8.18-7.15-13.14-9.31-10.66-4.63-22.31-6.26-33.81-7.84l-.8-.11V524.58a8,8,0,0,0-8-8.05H892.92q-1-6.12-2-12.23c-1.91-11.61-3.88-23.45-9.23-33.91-3.5-6.85-9.08-13.37-16.59-14.72a16.54,16.54,0,0,1-4.32-1c-2.2-1.08-3.4-3.48-5.1-5.26-4.36-4.57-11.45-4.64-17.3-7-5.16-2.05-9.38-5.92-14.08-8.89s-10.55-5.09-15.76-3.15c0,.38-.07.75-.11,1.13L805.09,430c-3.6-1.66-7.28-3.38-10.17-6.12-3.72-3.51-5.7-8.14-7.24-13.08-.16-.52-.31-1-.46-1.55a46.53,46.53,0,0,0,12.44-23.77c.27.87.55,1.75.82,2.63a13.88,13.88,0,0,0,1,2.59,6.86,6.86,0,0,0,.47.79,5.1,5.1,0,0,0,1.22,1.27,3.41,3.41,0,0,0,1.61.63,3,3,0,0,0,.84,0,4.62,4.62,0,0,0,3.36-2.87,6,6,0,0,0,.35-1.22,6.31,6.31,0,0,0,.07-.76c0-.08,0-.16,0-.24s0-.35,0-.52,0-.19,0-.28,0-.34,0-.5l0-.26c0-.2-.06-.4-.1-.59s0-.11,0-.16c-.05-.26-.11-.51-.16-.77a1,1,0,0,1,0-.17l-.15-.63-.09-.38,0-.1h0c-.1-.39-.19-.79-.28-1.19a34.44,34.44,0,0,1-.55-10.57,114.49,114.49,0,0,1,2.86-15.36l.21-.91.24-1.06c.16-.72.31-1.44.46-2.16v0c.13-.61.25-1.23.36-1.85s.19-1.09.27-1.64c0-.07,0-.13,0-.2a47.52,47.52,0,0,0,.49-11.28h0c-.47-5.23-2.09-10.18-5.65-14.13-2.51-2.79-5.81-4.85-8.14-7.78-2.19-2.75-3.42-6.13-5.68-8.82-6.25-7.46-22.28-13.21-32.12-14.21-11.27-1.14-29.48,1.74-38.56,8.4-3.36,2.46-5.66,6-8,9.37-4.3,6.26-9.19,12.5-16.08,16-2.61,1.32-5.59,2.32-7.32,4.62a12.59,12.59,0,0,0-2,5.19,102.21,102.21,0,0,0-2.06,19.8,24.41,24.41,0,0,0,1.1,8.6c.14.38.31.77.49,1.14h0c.16.33.34.66.53,1l.12.21a41.55,41.55,0,0,1,3.21,5.45,7.9,7.9,0,0,1,.48,1.66,12.29,12.29,0,0,1-.28,4.39h0c0,.22-.08.43-.13.64l-.09.46c0,.14,0,.29-.08.43q-.12.65-.21,1.29c0,.3-.06.61-.07.92a7.51,7.51,0,0,0,.69,3.6,4.58,4.58,0,0,0,.47.76,4,4,0,0,0,1.35,1.15,15.14,15.14,0,0,0,3.7.88c3.74.84,6.08,3.7,7.6,7.21a25.46,25.46,0,0,1,.89,2.41,42.63,42.63,0,0,1,1.4,6.27c1.7-.09,2.69-1.59,3.29-3.23a15.2,15.2,0,0,0,.47-1.65c.23-1.05.46-2.1.7-3.15a46.49,46.49,0,0,0,18.26,20.12c.28.82.55,1.65.8,2.49,1.31,4.53,1.94,9.28-.33,13.24-1.62,2.81-4.35,4.55-7.39,5.75a4.89,4.89,0,0,0-1.65-1.41c-2.64-1.32-5.8.29-8,2.26-4,3.62-7.26,8.81-12.53,10-1.9.44-4,.35-5.59,1.51a12.92,12.92,0,0,0-2.59,3.41,11.93,11.93,0,0,1-10.24,5.1c-1.83-.09-4-.51-5.25.83-.93,1-1,2.59-2,3.54-1.35,1.32-3.54.67-5.42.59a10,10,0,0,0-7.25,3.14,17.06,17.06,0,0,0-4.36-10.9c-2.7-2.78-6.45-4.21-9.65-6.39-8-5.44-12-15-16.17-23.76s-9.67-18-18.77-21.19c-2.09-.74-5-.8-5.94,1.23a4.43,4.43,0,0,0-.15,2.65c.88,4.66,4.2,8.4,7.07,12.15,4.83,6.32,8.88,14.05,7.71,21.95-1.37,9.35-9.7,16.61-10.7,26-.44,4.14.61,8.3.6,12.46,0,2.6-.41,5.23.15,7.76a52.63,52.63,0,0,0,2.11,5.65,33.09,33.09,0,0,1,1.38,9.31q1.06,19.88,2.11,39.77c.53,9.89-1.63,19.65-3.81,29.38a92.19,92.19,0,0,0-6.26,18c-2.46,10.83-2.53,22.37,1,32.91,1.89,5.73,4.79,11.1,6.34,16.93,0,.13.06.25.09.37.15,1.24.32,2.48.55,3.71a35.66,35.66,0,0,0,1.11,4.2,29.93,29.93,0,0,0,2.2,6.87,19.22,19.22,0,0,0,6,7c-1.44,2.82-3.77,5.09-5.32,7.85-2.7,4.78-2.81,10.65-1.83,16.07,1.89,10.46,7.54,19.81,15,27.41a8.68,8.68,0,0,0-1,0,15.68,15.68,0,0,0-6.84,2.45c-15.79,9.23-24.82,29-21.52,47.1.65,3.54,1.78,7.12,4.14,9.81a15.56,15.56,0,0,0,7.29,4.47,25.29,25.29,0,0,0,5.37,1c12.31,1,24.23-4.71,36.57-5.19a98.49,98.49,0,0,1,12.25.57q8.91.74,17.86.94c9.69.23,15.15-2.35,21.34-9.6a25.88,25.88,0,0,0,3.77-5.94c5.26-.3,11.07-.76,15.28-1.11l.06.59c.23,2,.58,4.3,2.18,5.57a7.79,7.79,0,0,0,3,1.22c10.11,2.49,20.34,5,30.74,5a129.72,129.72,0,0,0,14.6-1.13l18.3-2.11a93.21,93.21,0,0,1,15.71,3.42c5.28,1.8,10.22,4.47,15.38,6.57,12,4.87,24.92,6.61,37.71,8.31,2.18.29,4.68.49,6.3-1,2.08-2,1.38-5.35.8-8.15-.24-1.14-.42-2.3-.57-3.46a173.5,173.5,0,0,1,25.26,8.77l1.44.63c.41,2.18,2.43,3.93,4.36,6.28a15.9,15.9,0,0,0,2.21,2.73,7.25,7.25,0,0,0,3.17,1.15,148.12,148.12,0,0,0,41,1.85,42,42,0,0,1,8.45-.29,35.64,35.64,0,0,1,6.1,1.38l11.58,3.31c8.53,2.45,17.28,4.92,26.13,4.37a34.71,34.71,0,0,0,5.34-.77c7-1.62,13.53-5.54,16.89-11.84C1029.42,782.89,1027.23,772.36,1024.66,763ZM685,606.59a36.39,36.39,0,0,1-3.34,12.51c-1.24,2.51-2.84,4.82-4,7.34-1.1,2.28-1.92,6.59-2.41,11.32-.6-.1-1.21-.19-1.81-.26.89-3.12,1.56-6.32,2.45-9.45C678,620.61,681.47,613.58,685,606.59Z'%20transform='translate(-91.39%20-95.85)'%20fill='url(%23ae8f1d99-169f-42eb-bca8-084a90728b1c)'/%3e%3cpath%20d='M700.41,760.39c-2.11-4.8-4.11-10.32-2-15.12a12.85,12.85,0,0,1,6.65-6.25,32,32,0,0,1,9-2.22,125.61,125.61,0,0,1,29.26-.4c.71,5.62-.79,11.32-2.08,16.75-1.17,5-1.84,5.74-7,6C730.9,759.33,701.2,762.16,700.41,760.39Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23fbbebe'/%3e%3cellipse%20cx='698.07'%20cy='592.16'%20rx='143'%20ry='40'%20fill='%23464353'/%3e%3cellipse%20cx='698.07'%20cy='592.16'%20rx='143'%20ry='40'%20opacity='0.1'/%3e%3cpath%20d='M815.1,476.85a44.49,44.49,0,0,1-22.94,20.84A57.58,57.58,0,0,1,774,501.15c-6.79.31-13.72-.13-20.1-2.45-8.56-3.1-15.67-9.44-21-16.83s-9-15.83-12.19-24.34c-1.68-4.43-3.28-9.15-2.49-13.83,5.15-1.17,10.79-2.89,13.45-7.46,2.27-3.92,1.64-8.62.33-13.1-.37-1.27-.8-2.53-1.23-3.74-1-2.9-4.45-8.41-2.05-10.89,1.53-1.57,7.94-2.37,10.15-3.39,6.81-3.14,13.09-7.68,20.57-9.17,6.47-1.29,13.15-.08,19.61,1.26a6.45,6.45,0,0,1,2.42.87,5.82,5.82,0,0,1,1.8,2.7c1.84,4.48,2.92,9.43,4.4,14.1,1.54,4.89,3.52,9.48,7.23,12.95,2.89,2.71,6.57,4.41,10.17,6.06l8.86,4.06a11.65,11.65,0,0,1,4.19,2.71,10.61,10.61,0,0,1,2,5.44A50.82,50.82,0,0,1,815.1,476.85Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23fbbebe'/%3e%3cpath%20d='M787.63,414.88A46,46,0,0,1,732,423.14c-.37-1.27-.8-2.53-1.23-3.74-1-2.9-4.45-8.41-2.05-10.89,1.53-1.57,7.94-2.37,10.15-3.39,6.81-3.14,13.09-7.68,20.57-9.17,6.47-1.29,13.15-.08,19.61,1.26a6.45,6.45,0,0,1,2.42.87,5.82,5.82,0,0,1,1.8,2.7C785.07,405.26,786.15,410.21,787.63,414.88Z'%20transform='translate(-91.39%20-95.85)'%20opacity='0.1'/%3e%3ccircle%20cx='663.07'%20cy='285.16'%20r='46'%20fill='%23fbbebe'/%3e%3cpath%20d='M894.61,530.3l-3.78-22.9c-1.91-11.49-3.88-23.2-9.22-33.55-3.51-6.78-9.08-13.24-16.59-14.58a16.05,16.05,0,0,1-4.32-1c-2.2-1.06-3.4-3.44-5.09-5.2-4.36-4.52-11.46-4.59-17.3-6.89-5.16-2-9.38-5.85-14.08-8.79s-10.55-5-15.75-3.12c-.84,8.95-1.73,18.1-5.53,26.25a39.28,39.28,0,0,1-59.26,14.76c-8.91-6.71-14.62-17.06-17.28-27.89-.65-2.64-1.39-5.67-3.82-6.88-2.63-1.32-5.79.28-8,2.22-4.05,3.59-7.27,8.73-12.53,9.94-1.9.44-4,.35-5.58,1.5a12.7,12.7,0,0,0-2.6,3.37,12,12,0,0,1-10.23,5.06c-1.83-.09-4-.51-5.25.82-.93,1-1,2.56-2,3.49-1.35,1.31-3.54.67-5.42.6-3.56-.15-6.87,2.13-8.91,5s-3,6.42-4,9.86c10.93,24.34,20.93,48.71,31.86,73.05a6.23,6.23,0,0,1,.79,3,7.31,7.31,0,0,1-1.36,3c-5.36,8.61-5.19,19.44-4.6,29.56s1.31,20.81-3.21,29.88c-1.23,2.49-2.83,4.77-4,7.26-2.74,5.64-3.73,23.68-2.13,29.74h226c-4.31-11.85-2.67-35.63-1.77-48.21.63-8.8-1-17.59-1.7-26.39C896.48,565.29,897.58,548.24,894.61,530.3Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23f86d70'/%3e%3cpath%20d='M906.18,650.86c3.33-1.27,7-.81,10.57-.33,11.49,1.57,23.15,3.18,33.8,7.77,5,2.14,9.76,5,13.14,9.21,3,3.79,4.75,8.43,6.41,13L973.94,691c1.46,4,2.94,8.08,3.35,12.33,1.2,12.59-7.41,24.46-18.24,31s-23.58,8.87-36,11.31-24.89,5.14-37.26,8a150,150,0,0,1-17.53,3.45c-13.24,1.5-27.08-.71-39.66,3.67-5,1.75-9.91,4.35-15.1,5.56A93.93,93.93,0,0,1,803.07,768l-23.81,2.72a129.89,129.89,0,0,1-14.6,1.12c-10.4,0-20.63-2.46-30.73-4.92a7.77,7.77,0,0,1-3-1.21c-1.6-1.26-1.95-3.49-2.18-5.51q-1.53-13.41-2.68-26.85c-.24-2.91-.42-6.06,1.17-8.51,2-3,5.9-3.94,9.46-4.52a246.88,246.88,0,0,1,45.68-3.17c5.81-5.81,15.39-5.84,23-9a68.39,68.39,0,0,0,8.11-4.41A106,106,0,0,1,858,689.67a41.45,41.45,0,0,0,9.11-1.3c5.89-1.83,11.26-6.81,17.31-5.59.75-2.07,1.27-4.84,3-6.26.86-.73,1.92-1.22,2.71-2,1.67-1.69,1.82-4.35,1.57-6.71s-.81-4.78-.2-7.08a9.79,9.79,0,0,1,1.11-2.47C895.62,653,900.15,650.36,906.18,650.86Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23464353'/%3e%3cpath%20d='M906.18,650.86c3.33-1.27,7-.81,10.57-.33,11.49,1.57,23.15,3.18,33.8,7.77,5,2.14,9.76,5,13.14,9.21,3,3.79,4.75,8.43,6.41,13L973.94,691c1.46,4,2.94,8.08,3.35,12.33,1.2,12.59-7.41,24.46-18.24,31s-23.58,8.87-36,11.31-24.89,5.14-37.26,8a150,150,0,0,1-17.53,3.45c-13.24,1.5-27.08-.71-39.66,3.67-5,1.75-9.91,4.35-15.1,5.56A93.93,93.93,0,0,1,803.07,768l-23.81,2.72a129.89,129.89,0,0,1-14.6,1.12c-10.4,0-20.63-2.46-30.73-4.92a7.77,7.77,0,0,1-3-1.21c-1.6-1.26-1.95-3.49-2.18-5.51q-1.53-13.41-2.68-26.85c-.24-2.91-.42-6.06,1.17-8.51,2-3,5.9-3.94,9.46-4.52a246.88,246.88,0,0,1,45.68-3.17c5.81-5.81,15.39-5.84,23-9a68.39,68.39,0,0,0,8.11-4.41A106,106,0,0,1,858,689.67a41.45,41.45,0,0,0,9.11-1.3c5.89-1.83,11.26-6.81,17.31-5.59.75-2.07,1.27-4.84,3-6.26.86-.73,1.92-1.22,2.71-2,1.67-1.69,1.82-4.35,1.57-6.71s-.81-4.78-.2-7.08a9.79,9.79,0,0,1,1.11-2.47C895.62,653,900.15,650.36,906.18,650.86Z'%20transform='translate(-91.39%20-95.85)'%20opacity='0.05'/%3e%3cpath%20d='M709.61,766.57c-6.19,7.17-11.64,9.73-21.33,9.5q-8.94-.21-17.86-.93a100.2,100.2,0,0,0-12.24-.57c-12.34.48-24.25,6.13-36.56,5.14a25.92,25.92,0,0,1-5.37-1A15.63,15.63,0,0,1,609,774.3c-2.36-2.67-3.49-6.21-4.14-9.71-3.29-17.94,5.73-37.48,21.52-46.61a15.78,15.78,0,0,1,6.84-2.43,16.21,16.21,0,0,1,6.92,1.52l.15.06a52.33,52.33,0,0,1,17.14,11.44,9.66,9.66,0,0,0,2.62,2.11,9,9,0,0,0,3.09.58l13.14.83a31.14,31.14,0,0,1,6.6.91,52.46,52.46,0,0,1,6.94,3c7.07,3.16,14.91,4,22.55,5.22a3.37,3.37,0,0,1,2,.8,3.13,3.13,0,0,1,.62,1.3A25.51,25.51,0,0,1,709.61,766.57Z'%20transform='translate(-91.39%20-95.85)'%20fill='%233f3d56'/%3e%3cpath%20d='M640.25,717.13a78.9,78.9,0,0,0-13.15,16.44,82.28,82.28,0,0,0-10.74,32.54,60.4,60.4,0,0,0-.11,12.61A15.63,15.63,0,0,1,609,774.3c-2.36-2.67-3.49-6.21-4.14-9.71-3.29-17.94,5.73-37.48,21.52-46.61a15.78,15.78,0,0,1,6.84-2.43,16.21,16.21,0,0,1,6.92,1.52Z'%20transform='translate(-91.39%20-95.85)'%20opacity='0.1'/%3e%3cpath%20d='M894.74,742c7.35-.2,15.6-.57,21,4.38,5.15,4.68,5.83,12.4,6.17,19.35l.39,8.07c.12,2.46.22,5-.77,7.28-1.76,4-6.59,5.93-11,5.7s-8.46-2.16-12.49-3.9a175.7,175.7,0,0,0-34-10.71q.57-8.37,1.9-16.66c.61-3.83.71-10.24,3.27-13.42,2.71-3.36,6.24-1.54,9.92-.92A79.63,79.63,0,0,0,894.74,742Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23fbbebe'/%3e%3cpath%20d='M700.52,660.92c0,1-1.57,0-1.71-1.07-1.1-8.09-7.52-14.76-15-18s-16-3.41-24.1-2.64c-12.25,1.16-25.95,5.85-30.48,17.3-1.06,2.68-1.54,5.58-2.84,8.15-1.44,2.82-3.79,5.07-5.35,7.81-2.69,4.74-2.8,10.55-1.83,15.91,2.61,14.3,12.39,26.53,24.24,35s25.7,13.53,39.51,18.09a685.19,685.19,0,0,0,112,26.75c6.16.93,12.38,1.79,18.28,3.77,5.28,1.77,10.22,4.42,15.38,6.5,12,4.82,24.91,6.54,37.7,8.23,2.18.28,4.68.48,6.29-1,2.08-1.93,1.39-5.29.8-8.06a43.35,43.35,0,0,1,5.09-30.74c2.14-3.6,4.92-7.29,4.52-11.46-.48-4.86-5.32-8.3-10.14-9.08s-9.72.37-14.56,1c-1.67.22-3.49.36-5-.49a9.89,9.89,0,0,1-1.94-1.72,21.93,21.93,0,0,0-25.54-3.57c-1.79,1-4.5-1.23-6.36-2.07L798.47,710c-24.16-10.93-48.44-21.91-74-28.83a15.54,15.54,0,0,1-5.7-2.37c-1.27-1-2.18-2.36-3.35-3.47-2.55-2.41-6.1-3.37-9.16-5.08S699.8,664.35,700.52,660.92Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23464353'/%3e%3cpath%20d='M1024.71,791.61c-3.36,6.23-9.88,10.11-16.88,11.71a33.5,33.5,0,0,1-5.34.76c-8.85.55-17.59-1.9-26.12-4.32l-11.58-3.28a36.55,36.55,0,0,0-6.1-1.36,41.86,41.86,0,0,0-8.44.29,149.59,149.59,0,0,1-41-1.84,7.23,7.23,0,0,1-3.17-1.13,15.75,15.75,0,0,1-2.21-2.71c-3.15-3.79-6.54-6-2.81-11,2.15-2.9,6.14-4.35,7.81-7.68s.6-8.06-.39-11.5c-1.35-4.75-5.79-6.8-7.38-11.16-1.19-3.29.81-7.11,3.82-8.9s6.73-1.93,10.2-1.47,6.87,1.44,10.36,1.71c10.26.82,20.75-4.47,30.6-1.49,2.17.66,4.22,1.71,6.42,2.29a21.35,21.35,0,0,0,12.83-1.11c1.44-.54,2.85-1.19,4.25-1.83a34.23,34.23,0,0,1,8.55-3.09c9.61-1.65,18.52,5,25.77,11.49a36.44,36.44,0,0,1,6.55,7.1c2,3.12,3.06,6.75,4,10.33C1027.1,772.69,1029.29,783.11,1024.71,791.61Z'%20transform='translate(-91.39%20-95.85)'%20fill='%233f3d56'/%3e%3cpath%20d='M1024.71,791.61c-3.36,6.23-9.88,10.11-16.88,11.71a32.69,32.69,0,0,0,3.55-17.16c-.6-9.51-4.78-18.47-10.11-26.37a93.4,93.4,0,0,0-11.14-13.57c-3.18-3.2-7.09-5.74-10.51-8.67a34.23,34.23,0,0,1,8.55-3.09c9.61-1.65,18.52,5,25.77,11.49a36.44,36.44,0,0,1,6.55,7.1c2,3.12,3.06,6.75,4,10.33C1027.1,772.69,1029.29,783.11,1024.71,791.61Z'%20transform='translate(-91.39%20-95.85)'%20opacity='0.1'/%3e%3cpath%20d='M722.68,306.35c-3.36,2.43-5.66,5.92-8,9.27-4.31,6.19-9.19,12.37-16.08,15.82-2.61,1.31-5.59,2.3-7.32,4.58a12.34,12.34,0,0,0-1.95,5.13,101.65,101.65,0,0,0-2.06,19.6c0,3.28.14,6.66,1.59,9.64,1.37,2.8,3.84,5.17,4.35,8.22.39,2.38-.49,4.75-.8,7.14s.23,5.22,2.44,6.36a14.79,14.79,0,0,0,3.7.87c6.65,1.48,8.88,9.28,9.89,15.73,2.26-.13,3.28-2.72,3.75-4.83l6.93-30.81c.75-3.34,2-7.21,5.33-8.38,2.23-.77,4.67-.05,7,.15,9.15.75,16.89-6.32,25.84-8.27A33,33,0,0,1,766,356c7.06.35,15.27,3.25,16.77,9.84.25,1.07.4,2.35,1.4,2.88s2,.08,3.1,0c4.48-.45,7.12,4.59,8.41,8.71l4.7,15c.7,2.27,1.88,4.94,4.34,5.23,2.27.28,4.2-1.87,4.54-4s-.4-4.34-.89-6.48c-2.21-9.85,1.17-19.93,3.23-29.8s2.43-21.21-4.48-28.81c-2.51-2.75-5.81-4.8-8.15-7.7-2.18-2.72-3.41-6.06-5.67-8.73-6.25-7.37-22.28-13.06-32.11-14C750,296.91,731.76,299.76,722.68,306.35Z'%20transform='translate(-91.39%20-95.85)'%20fill='%233f3d56'/%3e%3cg%20opacity='0.1'%3e%3cpath%20d='M804.76,390.65c-2.46-.3-3.64-3-4.34-5.23q-2.35-7.51-4.7-15c-1.29-4.13-3.93-9.17-8.41-8.71-1,.11-2.18.52-3.1,0s-1.15-1.81-1.4-2.88c-1.5-6.6-9.71-9.49-16.77-9.84a33.43,33.43,0,0,0-8.71.57c-9,2-16.69,9-25.84,8.27-2.36-.19-4.8-.91-7-.14-3.37,1.16-4.58,5-5.33,8.38l-6.93,30.8c-.47,2.12-1.49,4.71-3.75,4.83-1-6.44-3.24-14.24-9.89-15.72a15.72,15.72,0,0,1-3.7-.87,4.34,4.34,0,0,1-1.93-2.15c-.18.93-.39,1.86-.51,2.79-.3,2.38.23,5.22,2.44,6.36a14.79,14.79,0,0,0,3.7.87c6.65,1.48,8.88,9.28,9.89,15.73,2.26-.13,3.28-2.72,3.75-4.83l6.93-30.81c.75-3.34,2-7.21,5.33-8.38,2.23-.77,4.67-.05,7,.15,9.15.75,16.89-6.32,25.84-8.27A33,33,0,0,1,766,356c7.06.35,15.27,3.25,16.77,9.84.25,1.07.4,2.35,1.4,2.88s2,.08,3.1,0c4.48-.45,7.12,4.59,8.41,8.71q2.34,7.51,4.7,15c.7,2.27,1.88,4.94,4.34,5.23,2.27.28,4.2-1.87,4.54-4a13.58,13.58,0,0,0-.6-5.31A4.13,4.13,0,0,1,804.76,390.65Z'%20transform='translate(-91.39%20-95.85)'/%3e%3cpath%20d='M693.22,371.61c-.51-3.05-3-5.42-4.35-8.22a16.45,16.45,0,0,1-1.48-6c0,1.12-.1,2.24-.11,3.37,0,3.28.14,6.66,1.59,9.64,1.11,2.27,2.94,4.27,3.86,6.58A15.06,15.06,0,0,0,693.22,371.61Z'%20transform='translate(-91.39%20-95.85)'/%3e%3cpath%20d='M811.64,350.33c-1.82,8.72-4.66,17.6-3.78,26.34.57-6.45,2.45-12.94,3.78-19.34a51,51,0,0,0,1.16-14.82A61.14,61.14,0,0,1,811.64,350.33Z'%20transform='translate(-91.39%20-95.85)'/%3e%3c/g%3e%3cpath%20d='M697.16,574.5c-1.21,19.86-15.78,36.27-21.33,55.37-1.38,4.78-2.21,9.74-4.19,14.29-4,9.15-12.23,15.79-21,20.47a31.54,31.54,0,0,1-10.34,3.76,19.82,19.82,0,0,1-19.91-10.59c-2.29-4.65-2.61-10-4-15-1.55-5.77-4.45-11.09-6.34-16.76-3.48-10.43-3.41-21.85-1-32.57a100,100,0,0,1,10.73-26.56c.7-1.23,1.41-2.45,2.14-3.66a83.18,83.18,0,0,1,6.93-10c6-7.23,13.71-12.79,21.34-18.27a5,5,0,0,1,2-1l.12,0a4.83,4.83,0,0,1,2.47.58A195.56,195.56,0,0,1,685.13,551c3.44,2.29,8.87,4.85,10.67,8.75S697.42,570.26,697.16,574.5Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23fbbebe'/%3e%3cpath%20d='M657.46,483.11a10.35,10.35,0,0,0-2.22,3.55,167.86,167.86,0,0,0-14.1,57.62,5.76,5.76,0,0,1-.65,2.79,12.21,12.21,0,0,1-1.47,1.59,5.52,5.52,0,0,0,.94,8c1.65-3.11,5.6-4.12,9.11-4.39,16.81-1.33,33.23,6.49,50.09,5.9-1.19-4.11-2.9-8.06-3.87-12.22-4.29-18.47,6.41-38.58-.15-56.37-1.31-3.56-3.5-7.06-6.95-8.62a18.51,18.51,0,0,0-4.45-1.18c-4.26-.77-12.74-4.06-16.86-2.74-1.52.49-2.12,1.92-3.38,2.78C661.63,481.05,659.09,481.48,657.46,483.11Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23f86d70'/%3e%3cpath%20d='M664.35,648.46a29.49,29.49,0,0,1-25,14.51,19.7,19.7,0,0,1-8-1.47c-6.39-2.82-10-9.8-11.34-16.66s-.92-13.94-1.87-20.87c-.76-5.52-2.38-10.88-3.22-16.39-2.06-13.63,2-27.09,4.89-40.66.7-1.23,1.41-2.45,2.14-3.66a83.18,83.18,0,0,1,6.93-10c6-7.23,13.71-12.79,21.34-18.27h-8a1.37,1.37,0,0,1,2.17.95c.79,7,10.66,14,12.81,20.8,1.33,4.18,2.93,8.28,4,12.54a100.47,100.47,0,0,1,1.92,11q2.13,15.53,4.24,31C669.13,623.87,670.65,637.48,664.35,648.46Z'%20transform='translate(-91.39%20-95.85)'%20opacity='0.1'/%3e%3cpath%20d='M651.11,517.16l9.65-30.27c1.44-4.53,2.9-9.13,3.07-13.89s-1.08-9.75-4.41-13.15c-2.7-2.75-6.44-4.17-9.64-6.32-8-5.39-12-14.83-16.17-23.52s-9.66-17.78-18.76-21c-2.1-.74-5-.8-5.94,1.21a4.25,4.25,0,0,0-.15,2.62c.88,4.62,4.19,8.31,7.07,12,4.83,6.25,8.87,13.9,7.71,21.72-1.38,9.26-9.7,16.44-10.7,25.75-.44,4.1.61,8.21.6,12.34,0,2.56-.42,5.17.15,7.67A51.66,51.66,0,0,0,615.7,498a33.18,33.18,0,0,1,1.38,9.21l2.11,39.36c1.14,21.29-10.41,42-7.23,63,.84,5.51,2.46,10.87,3.22,16.39,1,6.93.53,14,1.87,20.87s5,13.84,11.34,16.66a19.7,19.7,0,0,0,8,1.47,29.49,29.49,0,0,0,25-14.51c6.3-11,4.78-24.59,3.06-37.13l-4.24-31a100.47,100.47,0,0,0-1.92-11c-1.06-4.26-2.66-8.36-4-12.54C650,545.11,646.79,530.74,651.11,517.16Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23fbbebe'/%3e%3crect%20x='601.57'%20y='423.66'%20width='223'%20height='142'%20rx='7.97'%20fill='%233f3d56'/%3e%3crect%20x='601.57'%20y='423.66'%20width='223'%20height='142'%20rx='7.97'%20opacity='0.2'/%3e%3ccircle%20cx='712.57'%20cy='494.66'%20r='6'%20fill='%23fff'/%3e%3cpath%20d='M449.44,611h12.11a25,25,0,0,1,25,25v37.11a0,0,0,0,1,0,0H424.44a0,0,0,0,1,0,0V636A25,25,0,0,1,449.44,611Z'%20fill='%233f3d56'/%3e%3cpath%20d='M449.44,611h12.11a25,25,0,0,1,25,25v37.11a0,0,0,0,1,0,0H424.44a0,0,0,0,1,0,0V636A25,25,0,0,1,449.44,611Z'%20opacity='0.1'/%3e%3ccircle%20cx='453.02'%20cy='619.7'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='613.49'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='607.28'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='601.07'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='594.86'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='588.65'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='582.44'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='460.47'%20cy='584.92'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='465.44'%20cy='582.44'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='470.41'%20cy='579.95'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='576.22'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='570.01'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='563.8'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='453.02'%20cy='557.59'%20r='4.97'%20fill='%233f3d56'/%3e%3cpath%20d='M565,637.41c-1.23.18-2.47.31-3.71.39a28.56,28.56,0,0,0,3.2-3.28,21.22,21.22,0,0,0-3-5.83,10.22,10.22,0,0,1-4,1.26c-1.23.18-2.47.32-3.71.4a68.41,68.41,0,0,0,4.75-5A21.1,21.1,0,1,0,565.52,641a20.68,20.68,0,0,0-.32-3.63Z'%20transform='translate(-91.39%20-95.85)'%20fill='%230967d3'/%3e%3cpath%20d='M581.61,662.1a9.83,9.83,0,0,1-4.18,1.4c-1.23.18-2.47.31-3.71.39a36.4,36.4,0,0,0,3.68-3.82,12.44,12.44,0,1,0,4.21,2Z'%20transform='translate(-91.39%20-95.85)'%20fill='%230967d3'/%3e%3ccircle%20cx='445.56'%20cy='584.92'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='440.59'%20cy='582.44'%20r='4.97'%20fill='%233f3d56'/%3e%3ccircle%20cx='435.62'%20cy='579.95'%20r='4.97'%20fill='%233f3d56'/%3e%3cpath%20d='M507.2,662.1a9.78,9.78,0,0,0,4.18,1.4c1.23.18,2.47.31,3.71.39a35.42,35.42,0,0,1-3.68-3.82,12.44,12.44,0,1,1-4.21,2Z'%20transform='translate(-91.39%20-95.85)'%20fill='%230967d3'/%3e%3cpath%20d='M449.44,614.73h12.11a25,25,0,0,1,25,25v32.87a4.24,4.24,0,0,1-4.24,4.24H428.68a4.24,4.24,0,0,1-4.24-4.24V639.73A25,25,0,0,1,449.44,614.73Z'%20fill='%233f3d56'/%3e%3cg%20opacity='0.1'%3e%3cpath%20d='M565.38,638.77a18.83,18.83,0,0,1-1.6,1.52c.57,0,1.13-.09,1.7-.15C565.46,639.68,565.43,639.22,565.38,638.77Z'%20transform='translate(-91.39%20-95.85)'/%3e%3cpath%20d='M556.32,632.83c1.25-.08,2.48-.21,3.72-.39a12,12,0,0,0,3.23-.88,21.92,21.92,0,0,0-1.74-2.87,7.52,7.52,0,0,1-2,.85A28.79,28.79,0,0,1,556.32,632.83Z'%20transform='translate(-91.39%20-95.85)'/%3e%3cpath%20d='M525.77,643.5a21.08,21.08,0,0,1,32.5-17.76l.32-.34a21.1,21.1,0,1,0-27.82,31.73A21,21,0,0,1,525.77,643.5Z'%20transform='translate(-91.39%20-95.85)'/%3e%3c/g%3e%3cg%20opacity='0.1'%3e%3cpath%20d='M573.72,666.37c1.24-.08,2.48-.21,3.71-.39a9.7,9.7,0,0,0,4.18-1.4,12.43,12.43,0,0,1,5,8.8,11.38,11.38,0,0,0,.07-1.31,12.38,12.38,0,0,0-5-10,9.83,9.83,0,0,1-4.18,1.4l-1,.12A25.37,25.37,0,0,1,573.72,666.37Z'%20transform='translate(-91.39%20-95.85)'/%3e%3cpath%20d='M574.22,662.13a10.19,10.19,0,0,1,1.24.09c.65-.69,1.29-1.43,1.94-2.15a12.4,12.4,0,0,0-15.6,12c0,.42,0,.83.06,1.24A12.42,12.42,0,0,1,574.22,662.13Z'%20transform='translate(-91.39%20-95.85)'/%3e%3c/g%3e%3cg%20opacity='0.1'%3e%3cpath%20d='M515.09,666.37c-1.24-.08-2.48-.21-3.71-.39a9.65,9.65,0,0,1-4.18-1.4,12.43,12.43,0,0,0-5,8.8,11.38,11.38,0,0,1-.07-1.31,12.38,12.38,0,0,1,5-10,9.78,9.78,0,0,0,4.18,1.4l1,.12A23.67,23.67,0,0,0,515.09,666.37Z'%20transform='translate(-91.39%20-95.85)'/%3e%3cpath%20d='M514.59,662.13a10.36,10.36,0,0,0-1.25.09c-.64-.69-1.28-1.43-1.93-2.15a12.4,12.4,0,0,1,15.6,12c0,.42,0,.83-.06,1.24A12.42,12.42,0,0,0,514.59,662.13Z'%20transform='translate(-91.39%20-95.85)'/%3e%3c/g%3e%3crect%20x='158.11'%20y='179.65'%20width='226'%20height='88'%20fill='%230967d3'/%3e%3crect%20x='158.11'%20y='179.65'%20width='371'%20height='88'%20rx='12'%20fill='none'%20stroke='%233f3d56'%20stroke-miterlimit='10'%20stroke-width='9'/%3e%3cpath%20d='M452.76,314.79A18.1,18.1,0,0,0,418.93,310a14.48,14.48,0,0,0,1.57,28.88h31.42A12.11,12.11,0,0,0,464,326.75,11.93,11.93,0,0,0,452.76,314.79Zm-13.89,7.13v9.18h-7.74v-9.18h-8.21L435,309.83l12.08,12.09Z'%20transform='translate(-91.39%20-95.85)'%20fill='%23fff'/%3e%3c/svg%3e",
	notFound: not_found_default,
	restoring: "data:image/svg+xml,%3csvg%20id='f38f865d-e131-49ab-9ab3-db2059075423'%20data-name='Layer%201'%20xmlns='http://www.w3.org/2000/svg'%20width='529.16032'%20height='479.14405'%20viewBox='0%200%20529.16032%20479.14405'%3e%3cpath%20d='M765.72354,403.19867c-28.1703-21.05969-72.292-40.97652-121.05146-54.643-44.39571-12.44368-87.69779-18.45153-121.939-16.91729l-.17824-3.982c34.64906-1.55175,78.40036,4.50652,123.19313,17.06132,49.21419,13.794,93.81384,33.94594,122.36243,55.28863Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%233f3d56'/%3e%3cpath%20d='M762.79915,419.42a132.645,132.645,0,0,1-11.47943,54.15643q-.95064,2.14046-1.981,4.241A133.14833,133.14833,0,0,1,496.541,419.42q0-4.62167.31485-9.17157.14943-2.31379.38666-4.59967A133.13571,133.13571,0,0,1,762.79909,419.42Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%23f2f2f2'/%3e%3cpath%20d='M751.31978,473.57642q-.95064,2.14046-1.981,4.241-5.83542.63373-12.28455.92073c-3.55944.15942-7.22243.23917-10.96523.23917-32.69234,0-72.03715-6.03467-112.231-17.29881-44.79353-12.55559-85.31818-30.11744-114.11236-49.453q-1.47081-.98649-2.88975-1.977.14943-2.31378.38666-4.59966,2.28992,1.63222,4.72327,3.2684c28.45533,19.10443,68.57346,36.479,112.9684,48.923,39.843,11.16847,78.81718,17.15132,111.13487,17.15132q5.54229,0,10.8058-.23519Q744.53983,474.40949,751.31978,473.57642Z'%20transform='translate(-335.41984%20-210.42797)'%20opacity='0.1'%20style='isolation:isolate'/%3e%3cpath%20d='M726.08951,475.78934c-32.69134.00079-72.03851-6.03452-112.23055-17.29975-44.79312-12.55479-85.31948-30.11732-114.11389-49.45238-29.39541-19.73857-43.17947-39.18813-38.81332-54.76584,4.366-15.57772,26.25091-25.02983,61.623-26.615l.17824,3.982c-16.51832.74014-29.98006,3.19534-40.01121,7.29724-10.00674,4.09178-16.04676,9.61345-17.95214,16.41168-1.90539,6.798.38494,14.65439,6.8072,23.35119,6.438,8.7178,16.66275,17.81181,30.39018,27.02963,28.45209,19.10528,68.57151,36.48015,112.9678,48.92363,39.844,11.16752,78.81478,17.15181,111.13517,17.15258q5.53931,0,10.80357-.23549c16.5185-.74035,29.98024-3.19534,40.01162-7.29724,10.00675-4.09178,16.04676-9.61324,17.95215-16.41147,3.42112-12.20681-6.91811-28.06791-29.11379-44.66139l2.38689-3.19222c11.42169,8.53893,19.87659,16.95584,25.12983,25.01638,5.63166,8.64167,7.46025,16.68743,5.43507,23.913-4.3662,15.57772-26.25127,25.02942-61.623,26.61484C733.493,475.71033,729.83213,475.78934,726.08951,475.78934Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%233f3d56'/%3e%3ccircle%20cx='297.772'%20cy='50.32748'%20r='1.52555'%20fill='%23f2f2f2'/%3e%3ccircle%20cx='95.3852'%20cy='115.42627'%20r='2.62444'%20fill='%23ccc'/%3e%3ccircle%20cx='89.79158'%20cy='218.14518'%20r='5.18452'%20fill='%23ccc'/%3e%3ccircle%20cx='400.99939'%20cy='59.48065'%20r='3.45535'%20fill='%23ccc'/%3e%3ccircle%20cx='523.55018'%20cy='202.8899'%20r='5.61015'%20fill='%23ccc'/%3e%3ccircle%20cx='479.6815'%20cy='113.28657'%20r='2.40701'%20fill='%23ccc'/%3e%3ccircle%20cx='187.42543'%20cy='82.36358'%20r='3.75502'%20fill='%23ccc'/%3e%3ccircle%20cx='471.25695'%20cy='191.51423'%20r='2.40701'%20fill='%23ccc'/%3e%3ccircle%20cx='2.99584'%20cy='200.37057'%20r='2.99584'%20fill='%23ccc'/%3e%3ccircle%20cx='48.50845'%20cy='151.06835'%20r='3.24432'%20fill='%23ccc'/%3e%3cpolygon%20points='256.822%206.402%20250.42%206.402%20250.42%200%20246.985%200%20246.985%206.402%20240.58%206.402%20240.58%209.84%20246.985%209.84%20246.985%2016.242%20250.42%2016.242%20250.42%209.84%20256.822%209.84%20256.822%206.402'%20fill='%23ccc'/%3e%3cpolygon%20points='405.335%20352.829%20401.314%20352.829%20401.314%20348.81%20399.158%20348.81%20399.158%20352.829%20395.138%20352.829%20395.138%20354.986%20399.158%20354.986%20399.158%20359.006%20401.314%20359.006%20401.314%20354.986%20405.335%20354.986%20405.335%20352.829'%20fill='%23ccc'/%3e%3cpolygon%20points='498.123%20332.252%20495.118%20332.252%20495.118%20329.247%20493.504%20329.247%20493.504%20332.252%20490.499%20332.252%20490.499%20333.866%20493.504%20333.866%20493.504%20336.871%20495.118%20336.871%20495.118%20333.866%20498.123%20333.866%20498.123%20332.252'%20fill='%23ccc'/%3e%3ccircle%20cx='210.30838'%20cy='186.6176'%20r='11.1872'%20opacity='0.1'%20style='isolation:isolate'/%3e%3ccircle%20cx='333.87617'%20cy='298.99821'%20r='11.18721'%20opacity='0.1'%20style='isolation:isolate'/%3e%3ccircle%20cx='296.2465'%20cy='203.90693'%20r='11.18722'%20opacity='0.1'%20style='isolation:isolate'/%3e%3ccircle%20cx='215.90196'%20cy='265.43656'%20r='11.18719'%20opacity='0.1'%20style='isolation:isolate'/%3e%3ccircle%20cx='356.25061'%20cy='143.9028'%20r='11.18722'%20opacity='0.1'%20style='isolation:isolate'/%3e%3ccircle%20cx='393.37178'%20cy='219.67073'%20r='11.18722'%20opacity='0.1'%20style='isolation:isolate'/%3e%3ccircle%20cx='356.25061'%20cy='97.11993'%20r='14.74678'%20fill='%23fff'/%3e%3cpath%20d='M691.67038,286.19055a20.84885,20.84885,0,0,0-20.84883,20.84885c0,11.51451,20.84883,49.32542,20.84883,49.32542s20.84883-37.81091,20.84883-49.32542A20.84885,20.84885,0,0,0,691.67038,286.19055Zm0,31.01907a9.66171,9.66171,0,1,1,9.66173-9.6617,9.66167,9.66167,0,0,1-9.66173,9.6617h0Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%230967d3'/%3e%3ccircle%20cx='210.25061'%20cy='137.11993'%20r='14.74678'%20fill='%23fff'/%3e%3cpath%20d='M545.67038,326.19055a20.84885,20.84885,0,0,0-20.84883,20.84885c0,11.51451,20.84883,49.32542,20.84883,49.32542s20.84883-37.81091,20.84883-49.32542A20.84885,20.84885,0,0,0,545.67038,326.19055Zm0,31.01907a9.66171,9.66171,0,1,1,9.66173-9.6617,9.66167,9.66167,0,0,1-9.66173,9.6617h0Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%233f3d56'/%3e%3ccircle%20cx='395.25061'%20cy='171.11993'%20r='14.74678'%20fill='%23fff'/%3e%3cpath%20d='M730.67038,360.19055a20.84885,20.84885,0,0,0-20.84883,20.84885c0,11.51451,20.84883,49.32542,20.84883,49.32542s20.84883-37.81091,20.84883-49.32542A20.84885,20.84885,0,0,0,730.67038,360.19055Zm0,31.01907a9.66171,9.66171,0,1,1,9.66173-9.6617,9.66167,9.66167,0,0,1-9.66173,9.6617h0Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%23ccc'%20style='isolation:isolate'/%3e%3ccircle%20cx='145.25061'%20cy='245.11993'%20r='14.74678'%20fill='%23fff'/%3e%3cpath%20d='M480.67038,434.19055a20.84885,20.84885,0,0,0-20.84883,20.84885c0,11.51451,20.84883,49.32542,20.84883,49.32542s20.84883-37.81091,20.84883-49.32542A20.84885,20.84885,0,0,0,480.67038,434.19055Zm0,31.01907a9.66171,9.66171,0,1,1,9.66173-9.6617,9.66167,9.66167,0,0,1-9.66173,9.6617h0Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%230967d3'/%3e%3cellipse%20cx='806.28614'%20cy='557.44742'%20rx='6.76007'%20ry='21.53369'%20transform='translate(-505.20259%20437.21082)%20rotate(-39.93837)'%20fill='%232f2e41'/%3e%3ccircle%20cx='425.05916'%20cy='339.54155'%20r='43.06732'%20fill='%232f2e41'/%3e%3crect%20x='430.20422'%20y='373.34107'%20width='13.08374'%20height='23.44171'%20fill='%232f2e41'/%3e%3crect%20x='404.03674'%20y='373.34107'%20width='13.08374'%20height='23.44171'%20fill='%232f2e41'/%3e%3cellipse%20cx='432.38483'%20cy='397.05537'%20rx='10.90314'%20ry='4.08868'%20fill='%232f2e41'/%3e%3cellipse%20cx='406.21735'%20cy='396.51023'%20rx='10.90314'%20ry='4.08868'%20fill='%232f2e41'/%3e%3cpath%20d='M746.95616,495.83258c3.84558-15.487,20.82055-24.60076,37.91473-20.35617s27.83429,20.2403,23.98871,35.7273-16.604,15.537-33.69812,11.29236S743.11057,511.31961,746.95616,495.83258Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%230967d3'/%3e%3cellipse%20cx='711.97081'%20cy='529.9859'%20rx='6.76007'%20ry='21.53369'%20transform='translate(-407.4064%20735.72895)%20rotate(-64.62574)'%20fill='%232f2e41'/%3e%3ccircle%20cx='418.62054'%20cy='330.45396'%20r='14.35864'%20fill='%23fff'/%3e%3ccircle%20cx='412.71918'%20cy='325.30717'%20r='4.78621'%20fill='%233f3d56'/%3e%3cpath%20d='M763.04777,570.79734a9.57244,9.57244,0,1,1-18.83533,3.42883h0l-.00335-.01849c-.94178-5.20215,3.08038-7.043,8.28253-7.98474S762.10606,565.59525,763.04777,570.79734Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%23fff'/%3e%3cpath%20d='M671.78358,458.47658a29.898,29.898,0,1,0,1.6951,44.1547l36.67359,30.945a2.75511,2.75511,0,0,0,3.55755-4.20789l-.00405-.00342-36.6736-30.945A29.89973,29.89973,0,0,0,671.78358,458.47658Zm-2.3642,36.96358a22.39982,22.39982,0,1,1-2.67418-31.565l0,0A22.39982,22.39982,0,0,1,669.41938,495.44016Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%233f3d56'/%3e%3cpath%20d='M637.85433,498.11434a22.401,22.401,0,0,1-3.80106-30.11267q-.64243.647-1.24211,1.35516a22.39981,22.39981,0,1,0,34.23921,28.89088q.59832-.70909,1.12688-1.45239A22.401,22.401,0,0,1,637.85433,498.11434Z'%20transform='translate(-335.41984%20-210.42797)'%20opacity='0.3'%20style='isolation:isolate'/%3e%3cellipse%20cx='477.08894'%20cy='517.44733'%20rx='21.53369'%20ry='6.76007'%20transform='translate(-512.00949%20567.92143)%20rotate(-69.08217)'%20fill='%232f2e41'/%3e%3ccircle%20cx='101.8619'%20cy='339.54148'%20r='43.06735'%20fill='%232f2e41'/%3e%3crect%20x='82.2363'%20y='373.34109'%20width='13.08374'%20height='23.44171'%20fill='%232f2e41'/%3e%3crect%20x='108.40377'%20y='373.34109'%20width='13.08374'%20height='23.44171'%20fill='%232f2e41'/%3e%3cellipse%20cx='93.13944'%20cy='397.05537'%20rx='10.90314'%20ry='4.08868'%20fill='%232f2e41'/%3e%3cellipse%20cx='119.30692'%20cy='396.51022'%20rx='10.90314'%20ry='4.08868'%20fill='%232f2e41'/%3e%3ccircle%20cx='102.95225'%20cy='328.63826'%20r='14.71921'%20fill='%23fff'/%3e%3ccircle%20cx='102.95224'%20cy='328.63827'%20r='4.90643'%20fill='%233f3d56'/%3e%3cpath%20d='M395.505,509.91794c-3.47747-15.57379,7.63868-31.31042,24.82862-35.1488s33.94421,5.67511,37.42169,21.24884-7.91492,21.31763-25.10486,25.156S398.98249,525.49179,395.505,509.91794Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%230967d3'/%3e%3cellipse%20cx='388.77359'%20cy='529.98595'%20rx='6.76007'%20ry='21.53369'%20transform='translate(-592.1042%20443.71128)%20rotate(-64.62574)'%20fill='%232f2e41'/%3e%3cpath%20d='M416.12724,565.50632c0,4.21515,10.85327,12.53858,22.89657,12.53858s23.33515-11.867,23.33515-16.0821-11.29193.81775-23.33515.81775S416.12724,561.29117,416.12724,565.50632Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%23fff'/%3e%3ccircle%20cx='241.58115'%20cy='417.54139'%20r='43.06733'%20fill='%232f2e41'/%3e%3crect%20x='221.95553'%20y='451.34107'%20width='13.08374'%20height='23.44171'%20fill='%232f2e41'/%3e%3crect%20x='248.12302'%20y='451.34107'%20width='13.08373'%20height='23.44171'%20fill='%232f2e41'/%3e%3cellipse%20cx='232.85861'%20cy='475.05537'%20rx='10.90314'%20ry='4.08868'%20fill='%232f2e41'/%3e%3cellipse%20cx='259.02615'%20cy='474.5102'%20rx='10.90314'%20ry='4.08868'%20fill='%232f2e41'/%3e%3cpath%20d='M535.22424,587.91806c-3.47748-15.57379,7.63865-31.31042,24.82866-35.1488s33.94421,5.67511,37.42169,21.2489-7.91492,21.31769-25.10486,25.156S538.70173,603.49186,535.22424,587.91806Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%233f3d56'/%3e%3cpath%20d='M577.1739,620.50684s3.12411-13.7461-2.8117-13.12127-14.05851.93723-16.24539.93723-14.68333-1.56207-16.5578,6.56062-4.37375,18.11986.93724,24.36809c0,0,1.87447,27.49221,9.05992,29.36666s26.24255,4.06135,33.1156-4.99859a23.3002,23.3002,0,0,0,4.06135-19.05709H585.609Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%230967d3'/%3e%3cpath%20d='M545.62034,641.43839s5.311,2.49929,16.24538.93724v4.68617l-16.24538-1.24965Z'%20transform='translate(-335.41984%20-210.42797)'%20opacity='0.1'%20style='isolation:isolate'/%3e%3cpath%20d='M585.31128,657.10278l-3.53662-1.86914L597.50439,625.468a7.431,7.431,0,0,0-6.37036-10.90039l-16.50732-.44433.10742-3.999,16.50757.44434a11.43167,11.43167,0,0,1,9.79931,16.76855Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%230967d3'/%3e%3cpath%20d='M547.2937,657.10278,531.564,627.33715A11.43168,11.43168,0,0,1,541.363,610.5686l16.50781-.44434.10742,3.999-16.50757.44433a7.431,7.431,0,0,0-6.37012,10.90039l15.72974,29.76563Z'%20transform='translate(-335.41984%20-210.42797)'%20fill='%230967d3'/%3e%3cellipse%20cx='611.10465'%20cy='627.84819'%20rx='7.50055'%20ry='23.89244'%20transform='translate(-565.0462%20664.02437)%20rotate(-62.12179)'%20fill='%232f2e41'/%3e%3c/svg%3e"
};
var ActionButton = ({ className, ...props }) => /* @__PURE__ */ jsx(ButtonWithVariants, {
	className: cn$1("rounded-full w-8 h-8 flex items-center justify-center p-0", className),
	...props
});
var ScreenBlock = ({ title, image, message, onBack, onRetry, className }) => /* @__PURE__ */ jsx(PageContentBlock, {
	className,
	children: /* @__PURE__ */ jsx("div", {
		className: "flex justify-center",
		children: /* @__PURE__ */ jsxs("div", {
			className: "w-full sm:w-3/4 md:w-1/2 p-12 md:p-20 bg-card rounded-lg shadow-lg text-center relative",
			children: [
				(onBack ?? onRetry) && /* @__PURE__ */ jsx("div", {
					className: "absolute left-0 top-0 ml-4 mt-4",
					children: /* @__PURE__ */ jsx(ActionButton, {
						"aria-label": onRetry ? "Retry" : "Go back",
						title: onRetry ? "Retry" : "Go back",
						onClick: () => (onRetry ?? onBack)?.(),
						className: onRetry ? "hover:animate-[spin_2s_linear_infinite]" : void 0,
						children: /* @__PURE__ */ jsx(Icon, { icon: onRetry ? RefreshCw : ArrowLeft })
					})
				}),
				/* @__PURE__ */ jsx("img", {
					src: image,
					alt: "",
					className: "w-2/3 h-auto select-none mx-auto"
				}),
				/* @__PURE__ */ jsx("h2", {
					className: "mt-10 text-foreground font-bold text-4xl",
					children: title
				}),
				/* @__PURE__ */ jsx("p", {
					className: "text-sm text-muted-foreground mt-2",
					children: message
				})
			]
		})
	})
});
var ServerError = ({ title = "Something went wrong", message, onBack, onRetry, className }) => onRetry ? /* @__PURE__ */ jsx(ScreenBlock, {
	title,
	image: server_error_default,
	message,
	onRetry,
	className
}) : /* @__PURE__ */ jsx(ScreenBlock, {
	title,
	image: server_error_default,
	message,
	onBack,
	className
});
var NotFound = ({ title, message, onBack }) => /* @__PURE__ */ jsx(ScreenBlock, {
	title: title || "404",
	image: not_found_default,
	message: message || "The requested resource was not found.",
	onBack
});
//#endregion
//#region ../../resources/scripts/components/elements/table/PaginationFooter.tsx
var PaginationFooter = ({ pagination, className, onPageSelect }) => {
	const normalized = "per_page" in pagination ? {
		total: pagination.total,
		count: pagination.count,
		perPage: pagination.per_page,
		currentPage: pagination.current_page,
		totalPages: pagination.total_pages
	} : pagination;
	const offset = (normalized.currentPage - 1) * normalized.perPage;
	const start = normalized.count > 0 ? offset + 1 : 0;
	const end = normalized.count > 0 ? offset + normalized.count : 0;
	const { currentPage: current, totalPages: total } = normalized;
	const previousPages = [];
	const nextPages = [];
	for (let i = 1; i <= 2; i++) {
		if (current - i >= 1) previousPages.push(current - i);
		if (current + i <= total) nextPages.push(current + i);
	}
	if (normalized.total === 0) return null;
	const buttonProps = (page) => ({
		type: "button",
		size: "xsmall",
		isSecondary: true,
		className: "w-8 h-8 p-0 inline-flex items-center justify-center",
		onClick: () => onPageSelect(page)
	});
	return /* @__PURE__ */ jsxs("div", {
		className: cn$1("flex items-center justify-between my-2", className),
		children: [/* @__PURE__ */ jsxs("p", {
			className: "text-sm text-muted-foreground",
			children: [
				"Showing\xA0",
				/* @__PURE__ */ jsx("span", {
					className: "font-semibold text-muted-foreground",
					children: start
				}),
				"\xA0to\xA0",
				/* @__PURE__ */ jsx("span", {
					className: "font-semibold text-muted-foreground",
					children: end
				}),
				" of\xA0",
				/* @__PURE__ */ jsx("span", {
					className: "font-semibold text-muted-foreground",
					children: normalized.total
				}),
				" results."
			]
		}), (total > 1 || current > 1) && /* @__PURE__ */ jsxs("div", {
			className: "flex space-x-1",
			children: [
				/* @__PURE__ */ jsx(ButtonWithVariants.Text, {
					...buttonProps(1),
					"aria-label": "First page",
					disabled: previousPages.length !== 2,
					children: /* @__PURE__ */ jsx(ChevronsLeft, { className: "w-3 h-3" })
				}),
				previousPages.reverse().map((value) => /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
					...buttonProps(value),
					children: value
				}, `previous-${value}`)),
				/* @__PURE__ */ jsx(ButtonWithVariants, {
					type: "button",
					size: "xsmall",
					"aria-current": "page",
					className: "w-8 h-8 p-0 inline-flex items-center justify-center",
					children: current
				}),
				nextPages.map((value) => /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
					...buttonProps(value),
					children: value
				}, `next-${value}`)),
				/* @__PURE__ */ jsx(ButtonWithVariants.Text, {
					...buttonProps(total),
					"aria-label": "Last page",
					disabled: nextPages.length !== 2,
					children: /* @__PURE__ */ jsx(ChevronsRight, { className: "w-3 h-3" })
				})
			]
		})]
	});
};
//#endregion
//#region ../../node_modules/i18next/dist/esm/i18next.js
var isString$1 = (obj) => typeof obj === "string";
var defer = () => {
	let res;
	let rej;
	const promise = new Promise((resolve, reject) => {
		res = resolve;
		rej = reject;
	});
	promise.resolve = res;
	promise.reject = rej;
	return promise;
};
var makeString = (object) => {
	if (object == null) return "";
	return "" + object;
};
var copy = (a, s, t) => {
	a.forEach((m) => {
		if (s[m]) t[m] = s[m];
	});
};
var lastOfPathSeparatorRegExp = /###/g;
var cleanKey = (key) => key && key.indexOf("###") > -1 ? key.replace(lastOfPathSeparatorRegExp, ".") : key;
var canNotTraverseDeeper = (object) => !object || isString$1(object);
var getLastOfPath = (object, path, Empty) => {
	const stack = !isString$1(path) ? path : path.split(".");
	let stackIndex = 0;
	while (stackIndex < stack.length - 1) {
		if (canNotTraverseDeeper(object)) return {};
		const key = cleanKey(stack[stackIndex]);
		if (!object[key] && Empty) object[key] = new Empty();
		if (Object.prototype.hasOwnProperty.call(object, key)) object = object[key];
		else object = {};
		++stackIndex;
	}
	if (canNotTraverseDeeper(object)) return {};
	return {
		obj: object,
		k: cleanKey(stack[stackIndex])
	};
};
var setPath = (object, path, newValue) => {
	const { obj, k } = getLastOfPath(object, path, Object);
	if (obj !== void 0 || path.length === 1) {
		obj[k] = newValue;
		return;
	}
	let e = path[path.length - 1];
	let p = path.slice(0, path.length - 1);
	let last = getLastOfPath(object, p, Object);
	while (last.obj === void 0 && p.length) {
		e = `${p[p.length - 1]}.${e}`;
		p = p.slice(0, p.length - 1);
		last = getLastOfPath(object, p, Object);
		if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== "undefined") last.obj = void 0;
	}
	last.obj[`${last.k}.${e}`] = newValue;
};
var pushPath = (object, path, newValue, concat) => {
	const { obj, k } = getLastOfPath(object, path, Object);
	obj[k] = obj[k] || [];
	obj[k].push(newValue);
};
var getPath = (object, path) => {
	const { obj, k } = getLastOfPath(object, path);
	if (!obj) return void 0;
	if (!Object.prototype.hasOwnProperty.call(obj, k)) return void 0;
	return obj[k];
};
var getPathWithDefaults = (data, defaultData, key) => {
	const value = getPath(data, key);
	if (value !== void 0) return value;
	return getPath(defaultData, key);
};
var deepExtend = (target, source, overwrite) => {
	for (const prop in source) if (prop !== "__proto__" && prop !== "constructor") if (prop in target) if (isString$1(target[prop]) || target[prop] instanceof String || isString$1(source[prop]) || source[prop] instanceof String) {
		if (overwrite) target[prop] = source[prop];
	} else deepExtend(target[prop], source[prop], overwrite);
	else target[prop] = source[prop];
	return target;
};
var regexEscape = (str) => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
var _entityMap = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;",
	"/": "&#x2F;"
};
var escape = (data) => {
	if (isString$1(data)) return data.replace(/[&<>"'\/]/g, (s) => _entityMap[s]);
	return data;
};
var RegExpCache = class {
	constructor(capacity) {
		this.capacity = capacity;
		this.regExpMap = /* @__PURE__ */ new Map();
		this.regExpQueue = [];
	}
	getRegExp(pattern) {
		const regExpFromCache = this.regExpMap.get(pattern);
		if (regExpFromCache !== void 0) return regExpFromCache;
		const regExpNew = new RegExp(pattern);
		if (this.regExpQueue.length === this.capacity) this.regExpMap.delete(this.regExpQueue.shift());
		this.regExpMap.set(pattern, regExpNew);
		this.regExpQueue.push(pattern);
		return regExpNew;
	}
};
var chars = [
	" ",
	",",
	"?",
	"!",
	";"
];
var looksLikeObjectPathRegExpCache = new RegExpCache(20);
var looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
	nsSeparator = nsSeparator || "";
	keySeparator = keySeparator || "";
	const possibleChars = chars.filter((c) => nsSeparator.indexOf(c) < 0 && keySeparator.indexOf(c) < 0);
	if (possibleChars.length === 0) return true;
	const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map((c) => c === "?" ? "\\?" : c).join("|")})`);
	let matched = !r.test(key);
	if (!matched) {
		const ki = key.indexOf(keySeparator);
		if (ki > 0 && !r.test(key.substring(0, ki))) matched = true;
	}
	return matched;
};
var deepFind = (obj, path, keySeparator = ".") => {
	if (!obj) return void 0;
	if (obj[path]) {
		if (!Object.prototype.hasOwnProperty.call(obj, path)) return void 0;
		return obj[path];
	}
	const tokens = path.split(keySeparator);
	let current = obj;
	for (let i = 0; i < tokens.length;) {
		if (!current || typeof current !== "object") return;
		let next;
		let nextPath = "";
		for (let j = i; j < tokens.length; ++j) {
			if (j !== i) nextPath += keySeparator;
			nextPath += tokens[j];
			next = current[nextPath];
			if (next !== void 0) {
				if ([
					"string",
					"number",
					"boolean"
				].indexOf(typeof next) > -1 && j < tokens.length - 1) continue;
				i += j - i + 1;
				break;
			}
		}
		current = next;
	}
	return current;
};
var getCleanedCode = (code) => code?.replace(/_/g, "-");
var consoleLogger = {
	type: "logger",
	log(args) {
		this.output("log", args);
	},
	warn(args) {
		this.output("warn", args);
	},
	error(args) {
		this.output("error", args);
	},
	output(type, args) {
		console?.[type]?.apply?.(console, args);
	}
};
var baseLogger = new class Logger {
	constructor(concreteLogger, options = {}) {
		this.init(concreteLogger, options);
	}
	init(concreteLogger, options = {}) {
		this.prefix = options.prefix || "i18next:";
		this.logger = concreteLogger || consoleLogger;
		this.options = options;
		this.debug = options.debug;
	}
	log(...args) {
		return this.forward(args, "log", "", true);
	}
	warn(...args) {
		return this.forward(args, "warn", "", true);
	}
	error(...args) {
		return this.forward(args, "error", "");
	}
	deprecate(...args) {
		return this.forward(args, "warn", "WARNING DEPRECATED: ", true);
	}
	forward(args, lvl, prefix, debugOnly) {
		if (debugOnly && !this.debug) return null;
		if (isString$1(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
		return this.logger[lvl](args);
	}
	create(moduleName) {
		return new Logger(this.logger, {
			prefix: `${this.prefix}:${moduleName}:`,
			...this.options
		});
	}
	clone(options) {
		options = options || this.options;
		options.prefix = options.prefix || this.prefix;
		return new Logger(this.logger, options);
	}
}();
var EventEmitter = class {
	constructor() {
		this.observers = {};
	}
	on(events, listener) {
		events.split(" ").forEach((event) => {
			if (!this.observers[event]) this.observers[event] = /* @__PURE__ */ new Map();
			const numListeners = this.observers[event].get(listener) || 0;
			this.observers[event].set(listener, numListeners + 1);
		});
		return this;
	}
	off(event, listener) {
		if (!this.observers[event]) return;
		if (!listener) {
			delete this.observers[event];
			return;
		}
		this.observers[event].delete(listener);
	}
	emit(event, ...args) {
		if (this.observers[event]) Array.from(this.observers[event].entries()).forEach(([observer, numTimesAdded]) => {
			for (let i = 0; i < numTimesAdded; i++) observer(...args);
		});
		if (this.observers["*"]) Array.from(this.observers["*"].entries()).forEach(([observer, numTimesAdded]) => {
			for (let i = 0; i < numTimesAdded; i++) observer.apply(observer, [event, ...args]);
		});
	}
};
var ResourceStore = class extends EventEmitter {
	constructor(data, options = {
		ns: ["translation"],
		defaultNS: "translation"
	}) {
		super();
		this.data = data || {};
		this.options = options;
		if (this.options.keySeparator === void 0) this.options.keySeparator = ".";
		if (this.options.ignoreJSONStructure === void 0) this.options.ignoreJSONStructure = true;
	}
	addNamespaces(ns) {
		if (this.options.ns.indexOf(ns) < 0) this.options.ns.push(ns);
	}
	removeNamespaces(ns) {
		const index = this.options.ns.indexOf(ns);
		if (index > -1) this.options.ns.splice(index, 1);
	}
	getResource(lng, ns, key, options = {}) {
		const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
		const ignoreJSONStructure = options.ignoreJSONStructure !== void 0 ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
		let path;
		if (lng.indexOf(".") > -1) path = lng.split(".");
		else {
			path = [lng, ns];
			if (key) if (Array.isArray(key)) path.push(...key);
			else if (isString$1(key) && keySeparator) path.push(...key.split(keySeparator));
			else path.push(key);
		}
		const result = getPath(this.data, path);
		if (!result && !ns && !key && lng.indexOf(".") > -1) {
			lng = path[0];
			ns = path[1];
			key = path.slice(2).join(".");
		}
		if (result || !ignoreJSONStructure || !isString$1(key)) return result;
		return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
	}
	addResource(lng, ns, key, value, options = { silent: false }) {
		const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
		let path = [lng, ns];
		if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
		if (lng.indexOf(".") > -1) {
			path = lng.split(".");
			value = ns;
			ns = path[1];
		}
		this.addNamespaces(ns);
		setPath(this.data, path, value);
		if (!options.silent) this.emit("added", lng, ns, key, value);
	}
	addResources(lng, ns, resources, options = { silent: false }) {
		for (const m in resources) if (isString$1(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], { silent: true });
		if (!options.silent) this.emit("added", lng, ns, resources);
	}
	addResourceBundle(lng, ns, resources, deep, overwrite, options = {
		silent: false,
		skipCopy: false
	}) {
		let path = [lng, ns];
		if (lng.indexOf(".") > -1) {
			path = lng.split(".");
			deep = resources;
			resources = ns;
			ns = path[1];
		}
		this.addNamespaces(ns);
		let pack = getPath(this.data, path) || {};
		if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
		if (deep) deepExtend(pack, resources, overwrite);
		else pack = {
			...pack,
			...resources
		};
		setPath(this.data, path, pack);
		if (!options.silent) this.emit("added", lng, ns, resources);
	}
	removeResourceBundle(lng, ns) {
		if (this.hasResourceBundle(lng, ns)) delete this.data[lng][ns];
		this.removeNamespaces(ns);
		this.emit("removed", lng, ns);
	}
	hasResourceBundle(lng, ns) {
		return this.getResource(lng, ns) !== void 0;
	}
	getResourceBundle(lng, ns) {
		if (!ns) ns = this.options.defaultNS;
		return this.getResource(lng, ns);
	}
	getDataByLanguage(lng) {
		return this.data[lng];
	}
	hasLanguageSomeTranslations(lng) {
		const data = this.getDataByLanguage(lng);
		return !!(data && Object.keys(data) || []).find((v) => data[v] && Object.keys(data[v]).length > 0);
	}
	toJSON() {
		return this.data;
	}
};
var postProcessor = {
	processors: {},
	addPostProcessor(module) {
		this.processors[module.name] = module;
	},
	handle(processors, value, key, options, translator) {
		processors.forEach((processor) => {
			value = this.processors[processor]?.process(value, key, options, translator) ?? value;
		});
		return value;
	}
};
var PATH_KEY = Symbol("i18next/PATH_KEY");
function createProxy() {
	const state = [];
	const handler = Object.create(null);
	let proxy;
	handler.get = (target, key) => {
		proxy?.revoke?.();
		if (key === PATH_KEY) return state;
		state.push(key);
		proxy = Proxy.revocable(target, handler);
		return proxy.proxy;
	};
	return Proxy.revocable(Object.create(null), handler).proxy;
}
function keysFromSelector(selector, opts) {
	const { [PATH_KEY]: path } = selector(createProxy());
	const keySeparator = opts?.keySeparator ?? ".";
	const nsSeparator = opts?.nsSeparator ?? ":";
	if (path.length > 1 && nsSeparator) {
		const ns = opts?.ns;
		const nsArray = Array.isArray(ns) ? ns : null;
		if (nsArray && nsArray.length > 1 && nsArray.slice(1).includes(path[0])) return `${path[0]}${nsSeparator}${path.slice(1).join(keySeparator)}`;
	}
	return path.join(keySeparator);
}
var checkedLoadedFor = {};
var shouldHandleAsObject = (res) => !isString$1(res) && typeof res !== "boolean" && typeof res !== "number";
var Translator = class Translator extends EventEmitter {
	constructor(services, options = {}) {
		super();
		copy([
			"resourceStore",
			"languageUtils",
			"pluralResolver",
			"interpolator",
			"backendConnector",
			"i18nFormat",
			"utils"
		], services, this);
		this.options = options;
		if (this.options.keySeparator === void 0) this.options.keySeparator = ".";
		this.logger = baseLogger.create("translator");
	}
	changeLanguage(lng) {
		if (lng) this.language = lng;
	}
	exists(key, o = { interpolation: {} }) {
		const opt = { ...o };
		if (key == null) return false;
		const resolved = this.resolve(key, opt);
		if (resolved?.res === void 0) return false;
		const isObject = shouldHandleAsObject(resolved.res);
		if (opt.returnObjects === false && isObject) return false;
		return true;
	}
	extractFromKey(key, opt) {
		let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
		if (nsSeparator === void 0) nsSeparator = ":";
		const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
		let namespaces = opt.ns || this.options.defaultNS || [];
		const wouldCheckForNsInKey = nsSeparator && key.indexOf(nsSeparator) > -1;
		const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
		if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
			const m = key.match(this.interpolator.nestingRegexp);
			if (m && m.length > 0) return {
				key,
				namespaces: isString$1(namespaces) ? [namespaces] : namespaces
			};
			const parts = key.split(nsSeparator);
			if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.indexOf(parts[0]) > -1) namespaces = parts.shift();
			key = parts.join(keySeparator);
		}
		return {
			key,
			namespaces: isString$1(namespaces) ? [namespaces] : namespaces
		};
	}
	translate(keys, o, lastKey) {
		let opt = typeof o === "object" ? { ...o } : o;
		if (typeof opt !== "object" && this.options.overloadTranslationOptionHandler) opt = this.options.overloadTranslationOptionHandler(arguments);
		if (typeof opt === "object") opt = { ...opt };
		if (!opt) opt = {};
		if (keys == null) return "";
		if (typeof keys === "function") keys = keysFromSelector(keys, {
			...this.options,
			...opt
		});
		if (!Array.isArray(keys)) keys = [String(keys)];
		keys = keys.map((k) => typeof k === "function" ? keysFromSelector(k, {
			...this.options,
			...opt
		}) : String(k));
		const returnDetails = opt.returnDetails !== void 0 ? opt.returnDetails : this.options.returnDetails;
		const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
		const { key, namespaces } = this.extractFromKey(keys[keys.length - 1], opt);
		const namespace = namespaces[namespaces.length - 1];
		let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
		if (nsSeparator === void 0) nsSeparator = ":";
		const lng = opt.lng || this.language;
		const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
		if (lng?.toLowerCase() === "cimode") {
			if (appendNamespaceToCIMode) {
				if (returnDetails) return {
					res: `${namespace}${nsSeparator}${key}`,
					usedKey: key,
					exactUsedKey: key,
					usedLng: lng,
					usedNS: namespace,
					usedParams: this.getUsedParamsDetails(opt)
				};
				return `${namespace}${nsSeparator}${key}`;
			}
			if (returnDetails) return {
				res: key,
				usedKey: key,
				exactUsedKey: key,
				usedLng: lng,
				usedNS: namespace,
				usedParams: this.getUsedParamsDetails(opt)
			};
			return key;
		}
		const resolved = this.resolve(keys, opt);
		let res = resolved?.res;
		const resUsedKey = resolved?.usedKey || key;
		const resExactUsedKey = resolved?.exactUsedKey || key;
		const noObject = [
			"[object Number]",
			"[object Function]",
			"[object RegExp]"
		];
		const joinArrays = opt.joinArrays !== void 0 ? opt.joinArrays : this.options.joinArrays;
		const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
		const needsPluralHandling = opt.count !== void 0 && !isString$1(opt.count);
		const hasDefaultValue = Translator.hasDefaultValue(opt);
		const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : "";
		const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, { ordinal: false }) : "";
		const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
		const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
		let resForObjHndl = res;
		if (handleAsObjectInI18nFormat && !res && hasDefaultValue) resForObjHndl = defaultValue;
		const handleAsObject = shouldHandleAsObject(resForObjHndl);
		const resType = Object.prototype.toString.apply(resForObjHndl);
		if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && noObject.indexOf(resType) < 0 && !(isString$1(joinArrays) && Array.isArray(resForObjHndl))) {
			if (!opt.returnObjects && !this.options.returnObjects) {
				if (!this.options.returnedObjectHandler) this.logger.warn("accessing an object - but returnObjects options is not enabled!");
				const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
					...opt,
					ns: namespaces
				}) : `key '${key} (${this.language})' returned an object instead of string.`;
				if (returnDetails) {
					resolved.res = r;
					resolved.usedParams = this.getUsedParamsDetails(opt);
					return resolved;
				}
				return r;
			}
			if (keySeparator) {
				const resTypeIsArray = Array.isArray(resForObjHndl);
				const copy = resTypeIsArray ? [] : {};
				const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
				for (const m in resForObjHndl) if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
					const deepKey = `${newKeyToUse}${keySeparator}${m}`;
					if (hasDefaultValue && !res) copy[m] = this.translate(deepKey, {
						...opt,
						defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : void 0,
						joinArrays: false,
						ns: namespaces
					});
					else copy[m] = this.translate(deepKey, {
						...opt,
						joinArrays: false,
						ns: namespaces
					});
					if (copy[m] === deepKey) copy[m] = resForObjHndl[m];
				}
				res = copy;
			}
		} else if (handleAsObjectInI18nFormat && isString$1(joinArrays) && Array.isArray(res)) {
			res = res.join(joinArrays);
			if (res) res = this.extendTranslation(res, keys, opt, lastKey);
		} else {
			let usedDefault = false;
			let usedKey = false;
			if (!this.isValidLookup(res) && hasDefaultValue) {
				usedDefault = true;
				res = defaultValue;
			}
			if (!this.isValidLookup(res)) {
				usedKey = true;
				res = key;
			}
			const resForMissing = (opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey) && usedKey ? void 0 : res;
			const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
			if (usedKey || usedDefault || updateMissing) {
				this.logger.log(updateMissing ? "updateKey" : "missingKey", lng, namespace, key, updateMissing ? defaultValue : res);
				if (keySeparator) {
					const fk = this.resolve(key, {
						...opt,
						keySeparator: false
					});
					if (fk && fk.res) this.logger.warn("Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.");
				}
				let lngs = [];
				const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
				if (this.options.saveMissingTo === "fallback" && fallbackLngs && fallbackLngs[0]) for (let i = 0; i < fallbackLngs.length; i++) lngs.push(fallbackLngs[i]);
				else if (this.options.saveMissingTo === "all") lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
				else lngs.push(opt.lng || this.language);
				const send = (l, k, specificDefaultValue) => {
					const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
					if (this.options.missingKeyHandler) this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
					else if (this.backendConnector?.saveMissing) this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
					this.emit("missingKey", l, namespace, k, res);
				};
				if (this.options.saveMissing) if (this.options.saveMissingPlurals && needsPluralHandling) lngs.forEach((language) => {
					const suffixes = this.pluralResolver.getSuffixes(language, opt);
					if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && suffixes.indexOf(`${this.options.pluralSeparator}zero`) < 0) suffixes.push(`${this.options.pluralSeparator}zero`);
					suffixes.forEach((suffix) => {
						send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
					});
				});
				else send(lngs, key, defaultValue);
			}
			res = this.extendTranslation(res, keys, opt, resolved, lastKey);
			if (usedKey && res === key && this.options.appendNamespaceToMissingKey) res = `${namespace}${nsSeparator}${key}`;
			if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : void 0, opt);
		}
		if (returnDetails) {
			resolved.res = res;
			resolved.usedParams = this.getUsedParamsDetails(opt);
			return resolved;
		}
		return res;
	}
	extendTranslation(res, key, opt, resolved, lastKey) {
		if (this.i18nFormat?.parse) res = this.i18nFormat.parse(res, {
			...this.options.interpolation.defaultVariables,
			...opt
		}, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, { resolved });
		else if (!opt.skipInterpolation) {
			if (opt.interpolation) this.interpolator.init({
				...opt,
				interpolation: {
					...this.options.interpolation,
					...opt.interpolation
				}
			});
			const skipOnVariables = isString$1(res) && (opt?.interpolation?.skipOnVariables !== void 0 ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
			let nestBef;
			if (skipOnVariables) {
				const nb = res.match(this.interpolator.nestingRegexp);
				nestBef = nb && nb.length;
			}
			let data = opt.replace && !isString$1(opt.replace) ? opt.replace : opt;
			if (this.options.interpolation.defaultVariables) data = {
				...this.options.interpolation.defaultVariables,
				...data
			};
			res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
			if (skipOnVariables) {
				const na = res.match(this.interpolator.nestingRegexp);
				const nestAft = na && na.length;
				if (nestBef < nestAft) opt.nest = false;
			}
			if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
			if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
				if (lastKey?.[0] === args[0] && !opt.context) {
					this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
					return null;
				}
				return this.translate(...args, key);
			}, opt);
			if (opt.interpolation) this.interpolator.reset();
		}
		const postProcess = opt.postProcess || this.options.postProcess;
		const postProcessorNames = isString$1(postProcess) ? [postProcess] : postProcess;
		if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
			i18nResolved: {
				...resolved,
				usedParams: this.getUsedParamsDetails(opt)
			},
			...opt
		} : opt, this);
		return res;
	}
	resolve(keys, opt = {}) {
		let found;
		let usedKey;
		let exactUsedKey;
		let usedLng;
		let usedNS;
		if (isString$1(keys)) keys = [keys];
		if (Array.isArray(keys)) keys = keys.map((k) => typeof k === "function" ? keysFromSelector(k, {
			...this.options,
			...opt
		}) : k);
		keys.forEach((k) => {
			if (this.isValidLookup(found)) return;
			const extracted = this.extractFromKey(k, opt);
			const key = extracted.key;
			usedKey = key;
			let namespaces = extracted.namespaces;
			if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
			const needsPluralHandling = opt.count !== void 0 && !isString$1(opt.count);
			const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
			const needsContextHandling = opt.context !== void 0 && (isString$1(opt.context) || typeof opt.context === "number") && opt.context !== "";
			const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
			namespaces.forEach((ns) => {
				if (this.isValidLookup(found)) return;
				usedNS = ns;
				if (!checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
					checkedLoadedFor[`${codes[0]}-${ns}`] = true;
					this.logger.warn(`key "${usedKey}" for languages "${codes.join(", ")}" won't get resolved as namespace "${usedNS}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
				}
				codes.forEach((code) => {
					if (this.isValidLookup(found)) return;
					usedLng = code;
					const finalKeys = [key];
					if (this.i18nFormat?.addLookupKeys) this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
					else {
						let pluralSuffix;
						if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
						const zeroSuffix = `${this.options.pluralSeparator}zero`;
						const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
						if (needsPluralHandling) {
							if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
							finalKeys.push(key + pluralSuffix);
							if (needsZeroSuffixLookup) finalKeys.push(key + zeroSuffix);
						}
						if (needsContextHandling) {
							const contextKey = `${key}${this.options.contextSeparator || "_"}${opt.context}`;
							finalKeys.push(contextKey);
							if (needsPluralHandling) {
								if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
								finalKeys.push(contextKey + pluralSuffix);
								if (needsZeroSuffixLookup) finalKeys.push(contextKey + zeroSuffix);
							}
						}
					}
					let possibleKey;
					while (possibleKey = finalKeys.pop()) if (!this.isValidLookup(found)) {
						exactUsedKey = possibleKey;
						found = this.getResource(code, ns, possibleKey, opt);
					}
				});
			});
		});
		return {
			res: found,
			usedKey,
			exactUsedKey,
			usedLng,
			usedNS
		};
	}
	isValidLookup(res) {
		return res !== void 0 && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === "");
	}
	getResource(code, ns, key, options = {}) {
		if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
		return this.resourceStore.getResource(code, ns, key, options);
	}
	getUsedParamsDetails(options = {}) {
		const optionsKeys = [
			"defaultValue",
			"ordinal",
			"context",
			"replace",
			"lng",
			"lngs",
			"fallbackLng",
			"ns",
			"keySeparator",
			"nsSeparator",
			"returnObjects",
			"returnDetails",
			"joinArrays",
			"postProcess",
			"interpolation"
		];
		const useOptionsReplaceForData = options.replace && !isString$1(options.replace);
		let data = useOptionsReplaceForData ? options.replace : options;
		if (useOptionsReplaceForData && typeof options.count !== "undefined") data.count = options.count;
		if (this.options.interpolation.defaultVariables) data = {
			...this.options.interpolation.defaultVariables,
			...data
		};
		if (!useOptionsReplaceForData) {
			data = { ...data };
			for (const key of optionsKeys) delete data[key];
		}
		return data;
	}
	static hasDefaultValue(options) {
		const prefix = "defaultValue";
		for (const option in options) if (Object.prototype.hasOwnProperty.call(options, option) && prefix === option.substring(0, 12) && void 0 !== options[option]) return true;
		return false;
	}
};
var LanguageUtil = class {
	constructor(options) {
		this.options = options;
		this.supportedLngs = this.options.supportedLngs || false;
		this.logger = baseLogger.create("languageUtils");
	}
	getScriptPartFromCode(code) {
		code = getCleanedCode(code);
		if (!code || code.indexOf("-") < 0) return null;
		const p = code.split("-");
		if (p.length === 2) return null;
		p.pop();
		if (p[p.length - 1].toLowerCase() === "x") return null;
		return this.formatLanguageCode(p.join("-"));
	}
	getLanguagePartFromCode(code) {
		code = getCleanedCode(code);
		if (!code || code.indexOf("-") < 0) return code;
		const p = code.split("-");
		return this.formatLanguageCode(p[0]);
	}
	formatLanguageCode(code) {
		if (isString$1(code) && code.indexOf("-") > -1) {
			let formattedCode;
			try {
				formattedCode = Intl.getCanonicalLocales(code)[0];
			} catch (e) {}
			if (formattedCode && this.options.lowerCaseLng) formattedCode = formattedCode.toLowerCase();
			if (formattedCode) return formattedCode;
			if (this.options.lowerCaseLng) return code.toLowerCase();
			return code;
		}
		return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
	}
	isSupportedCode(code) {
		if (this.options.load === "languageOnly" || this.options.nonExplicitSupportedLngs) code = this.getLanguagePartFromCode(code);
		return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.indexOf(code) > -1;
	}
	getBestMatchFromCodes(codes) {
		if (!codes) return null;
		let found;
		codes.forEach((code) => {
			if (found) return;
			const cleanedLng = this.formatLanguageCode(code);
			if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
		});
		if (!found && this.options.supportedLngs) codes.forEach((code) => {
			if (found) return;
			const lngScOnly = this.getScriptPartFromCode(code);
			if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
			const lngOnly = this.getLanguagePartFromCode(code);
			if (this.isSupportedCode(lngOnly)) return found = lngOnly;
			found = this.options.supportedLngs.find((supportedLng) => {
				if (supportedLng === lngOnly) return supportedLng;
				if (supportedLng.indexOf("-") < 0 && lngOnly.indexOf("-") < 0) return;
				if (supportedLng.indexOf("-") > 0 && lngOnly.indexOf("-") < 0 && supportedLng.substring(0, supportedLng.indexOf("-")) === lngOnly) return supportedLng;
				if (supportedLng.indexOf(lngOnly) === 0 && lngOnly.length > 1) return supportedLng;
			});
		});
		if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
		return found;
	}
	getFallbackCodes(fallbacks, code) {
		if (!fallbacks) return [];
		if (typeof fallbacks === "function") fallbacks = fallbacks(code);
		if (isString$1(fallbacks)) fallbacks = [fallbacks];
		if (Array.isArray(fallbacks)) return fallbacks;
		if (!code) return fallbacks.default || [];
		let found = fallbacks[code];
		if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
		if (!found) found = fallbacks[this.formatLanguageCode(code)];
		if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
		if (!found) found = fallbacks.default;
		return found || [];
	}
	toResolveHierarchy(code, fallbackCode) {
		const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
		const codes = [];
		const addCode = (c) => {
			if (!c) return;
			if (this.isSupportedCode(c)) codes.push(c);
			else this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
		};
		if (isString$1(code) && (code.indexOf("-") > -1 || code.indexOf("_") > -1)) {
			if (this.options.load !== "languageOnly") addCode(this.formatLanguageCode(code));
			if (this.options.load !== "languageOnly" && this.options.load !== "currentOnly") addCode(this.getScriptPartFromCode(code));
			if (this.options.load !== "currentOnly") addCode(this.getLanguagePartFromCode(code));
		} else if (isString$1(code)) addCode(this.formatLanguageCode(code));
		fallbackCodes.forEach((fc) => {
			if (codes.indexOf(fc) < 0) addCode(this.formatLanguageCode(fc));
		});
		return codes;
	}
};
var suffixesOrder = {
	zero: 0,
	one: 1,
	two: 2,
	few: 3,
	many: 4,
	other: 5
};
var dummyRule = {
	select: (count) => count === 1 ? "one" : "other",
	resolvedOptions: () => ({ pluralCategories: ["one", "other"] })
};
var PluralResolver = class {
	constructor(languageUtils, options = {}) {
		this.languageUtils = languageUtils;
		this.options = options;
		this.logger = baseLogger.create("pluralResolver");
		this.pluralRulesCache = {};
	}
	clearCache() {
		this.pluralRulesCache = {};
	}
	getRule(code, options = {}) {
		const cleanedCode = getCleanedCode(code === "dev" ? "en" : code);
		const type = options.ordinal ? "ordinal" : "cardinal";
		const cacheKey = JSON.stringify({
			cleanedCode,
			type
		});
		if (cacheKey in this.pluralRulesCache) return this.pluralRulesCache[cacheKey];
		let rule;
		try {
			rule = new Intl.PluralRules(cleanedCode, { type });
		} catch (err) {
			if (typeof Intl === "undefined") {
				this.logger.error("No Intl support, please use an Intl polyfill!");
				return dummyRule;
			}
			if (!code.match(/-|_/)) return dummyRule;
			const lngPart = this.languageUtils.getLanguagePartFromCode(code);
			rule = this.getRule(lngPart, options);
		}
		this.pluralRulesCache[cacheKey] = rule;
		return rule;
	}
	needsPlural(code, options = {}) {
		let rule = this.getRule(code, options);
		if (!rule) rule = this.getRule("dev", options);
		return rule?.resolvedOptions().pluralCategories.length > 1;
	}
	getPluralFormsOfKey(code, key, options = {}) {
		return this.getSuffixes(code, options).map((suffix) => `${key}${suffix}`);
	}
	getSuffixes(code, options = {}) {
		let rule = this.getRule(code, options);
		if (!rule) rule = this.getRule("dev", options);
		if (!rule) return [];
		return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map((pluralCategory) => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${pluralCategory}`);
	}
	getSuffix(code, count, options = {}) {
		const rule = this.getRule(code, options);
		if (rule) return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${rule.select(count)}`;
		this.logger.warn(`no plural rule found for: ${code}`);
		return this.getSuffix("dev", count, options);
	}
};
var deepFindWithDefaults = (data, defaultData, key, keySeparator = ".", ignoreJSONStructure = true) => {
	let path = getPathWithDefaults(data, defaultData, key);
	if (!path && ignoreJSONStructure && isString$1(key)) {
		path = deepFind(data, key, keySeparator);
		if (path === void 0) path = deepFind(defaultData, key, keySeparator);
	}
	return path;
};
var regexSafe = (val) => val.replace(/\$/g, "$$$$");
var Interpolator = class {
	constructor(options = {}) {
		this.logger = baseLogger.create("interpolator");
		this.options = options;
		this.format = options?.interpolation?.format || ((value) => value);
		this.init(options);
	}
	init(options = {}) {
		if (!options.interpolation) options.interpolation = { escapeValue: true };
		const { escape: escape$1, escapeValue, useRawValueToEscape, prefix, prefixEscaped, suffix, suffixEscaped, formatSeparator, unescapeSuffix, unescapePrefix, nestingPrefix, nestingPrefixEscaped, nestingSuffix, nestingSuffixEscaped, nestingOptionsSeparator, maxReplaces, alwaysFormat } = options.interpolation;
		this.escape = escape$1 !== void 0 ? escape$1 : escape;
		this.escapeValue = escapeValue !== void 0 ? escapeValue : true;
		this.useRawValueToEscape = useRawValueToEscape !== void 0 ? useRawValueToEscape : false;
		this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || "{{";
		this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || "}}";
		this.formatSeparator = formatSeparator || ",";
		this.unescapePrefix = unescapeSuffix ? "" : unescapePrefix || "-";
		this.unescapeSuffix = this.unescapePrefix ? "" : unescapeSuffix || "";
		this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape("$t(");
		this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(")");
		this.nestingOptionsSeparator = nestingOptionsSeparator || ",";
		this.maxReplaces = maxReplaces || 1e3;
		this.alwaysFormat = alwaysFormat !== void 0 ? alwaysFormat : false;
		this.resetRegExp();
	}
	reset() {
		if (this.options) this.init(this.options);
	}
	resetRegExp() {
		const getOrResetRegExp = (existingRegExp, pattern) => {
			if (existingRegExp?.source === pattern) {
				existingRegExp.lastIndex = 0;
				return existingRegExp;
			}
			return new RegExp(pattern, "g");
		};
		this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
		this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
		this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
	}
	interpolate(str, data, lng, options) {
		let match;
		let value;
		let replaces;
		const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
		const handleFormat = (key) => {
			if (key.indexOf(this.formatSeparator) < 0) {
				const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
				return this.alwaysFormat ? this.format(path, void 0, lng, {
					...options,
					...data,
					interpolationkey: key
				}) : path;
			}
			const p = key.split(this.formatSeparator);
			const k = p.shift().trim();
			const f = p.join(this.formatSeparator).trim();
			return this.format(deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure), f, lng, {
				...options,
				...data,
				interpolationkey: k
			});
		};
		this.resetRegExp();
		const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
		const skipOnVariables = options?.interpolation?.skipOnVariables !== void 0 ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
		[{
			regex: this.regexpUnescape,
			safeValue: (val) => regexSafe(val)
		}, {
			regex: this.regexp,
			safeValue: (val) => this.escapeValue ? regexSafe(this.escape(val)) : regexSafe(val)
		}].forEach((todo) => {
			replaces = 0;
			while (match = todo.regex.exec(str)) {
				const matchedVar = match[1].trim();
				value = handleFormat(matchedVar);
				if (value === void 0) if (typeof missingInterpolationHandler === "function") {
					const temp = missingInterpolationHandler(str, match, options);
					value = isString$1(temp) ? temp : "";
				} else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) value = "";
				else if (skipOnVariables) {
					value = match[0];
					continue;
				} else {
					this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
					value = "";
				}
				else if (!isString$1(value) && !this.useRawValueToEscape) value = makeString(value);
				const safeValue = todo.safeValue(value);
				str = str.replace(match[0], safeValue);
				if (skipOnVariables) {
					todo.regex.lastIndex += value.length;
					todo.regex.lastIndex -= match[0].length;
				} else todo.regex.lastIndex = 0;
				replaces++;
				if (replaces >= this.maxReplaces) break;
			}
		});
		return str;
	}
	nest(str, fc, options = {}) {
		let match;
		let value;
		let clonedOptions;
		const handleHasOptions = (key, inheritedOptions) => {
			const sep = this.nestingOptionsSeparator;
			if (key.indexOf(sep) < 0) return key;
			const c = key.split(new RegExp(`${regexEscape(sep)}[ ]*{`));
			let optionsString = `{${c[1]}`;
			key = c[0];
			optionsString = this.interpolate(optionsString, clonedOptions);
			const matchedSingleQuotes = optionsString.match(/'/g);
			const matchedDoubleQuotes = optionsString.match(/"/g);
			if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || (matchedDoubleQuotes?.length ?? 0) % 2 !== 0) optionsString = optionsString.replace(/'/g, "\"");
			try {
				clonedOptions = JSON.parse(optionsString);
				if (inheritedOptions) clonedOptions = {
					...inheritedOptions,
					...clonedOptions
				};
			} catch (e) {
				this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
				return `${key}${sep}${optionsString}`;
			}
			if (clonedOptions.defaultValue && clonedOptions.defaultValue.indexOf(this.prefix) > -1) delete clonedOptions.defaultValue;
			return key;
		};
		while (match = this.nestingRegexp.exec(str)) {
			let formatters = [];
			clonedOptions = { ...options };
			clonedOptions = clonedOptions.replace && !isString$1(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
			clonedOptions.applyPostProcessor = false;
			delete clonedOptions.defaultValue;
			const keyEndIndex = /{.*}/.test(match[1]) ? match[1].lastIndexOf("}") + 1 : match[1].indexOf(this.formatSeparator);
			if (keyEndIndex !== -1) {
				formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map((elem) => elem.trim()).filter(Boolean);
				match[1] = match[1].slice(0, keyEndIndex);
			}
			value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
			if (value && match[0] === str && !isString$1(value)) return value;
			if (!isString$1(value)) value = makeString(value);
			if (!value) {
				this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
				value = "";
			}
			if (formatters.length) value = formatters.reduce((v, f) => this.format(v, f, options.lng, {
				...options,
				interpolationkey: match[1].trim()
			}), value.trim());
			str = str.replace(match[0], value);
			this.regexp.lastIndex = 0;
		}
		return str;
	}
};
var parseFormatStr = (formatStr) => {
	let formatName = formatStr.toLowerCase().trim();
	const formatOptions = {};
	if (formatStr.indexOf("(") > -1) {
		const p = formatStr.split("(");
		formatName = p[0].toLowerCase().trim();
		const optStr = p[1].substring(0, p[1].length - 1);
		if (formatName === "currency" && optStr.indexOf(":") < 0) {
			if (!formatOptions.currency) formatOptions.currency = optStr.trim();
		} else if (formatName === "relativetime" && optStr.indexOf(":") < 0) {
			if (!formatOptions.range) formatOptions.range = optStr.trim();
		} else optStr.split(";").forEach((opt) => {
			if (opt) {
				const [key, ...rest] = opt.split(":");
				const val = rest.join(":").trim().replace(/^'+|'+$/g, "");
				const trimmedKey = key.trim();
				if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
				if (val === "false") formatOptions[trimmedKey] = false;
				if (val === "true") formatOptions[trimmedKey] = true;
				if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
			}
		});
	}
	return {
		formatName,
		formatOptions
	};
};
var createCachedFormatter = (fn) => {
	const cache = {};
	return (v, l, o) => {
		let optForCache = o;
		if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) optForCache = {
			...optForCache,
			[o.interpolationkey]: void 0
		};
		const key = l + JSON.stringify(optForCache);
		let frm = cache[key];
		if (!frm) {
			frm = fn(getCleanedCode(l), o);
			cache[key] = frm;
		}
		return frm(v);
	};
};
var createNonCachedFormatter = (fn) => (v, l, o) => fn(getCleanedCode(l), o)(v);
var Formatter = class {
	constructor(options = {}) {
		this.logger = baseLogger.create("formatter");
		this.options = options;
		this.init(options);
	}
	init(services, options = { interpolation: {} }) {
		this.formatSeparator = options.interpolation.formatSeparator || ",";
		const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
		this.formats = {
			number: cf((lng, opt) => {
				const formatter = new Intl.NumberFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			}),
			currency: cf((lng, opt) => {
				const formatter = new Intl.NumberFormat(lng, {
					...opt,
					style: "currency"
				});
				return (val) => formatter.format(val);
			}),
			datetime: cf((lng, opt) => {
				const formatter = new Intl.DateTimeFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			}),
			relativetime: cf((lng, opt) => {
				const formatter = new Intl.RelativeTimeFormat(lng, { ...opt });
				return (val) => formatter.format(val, opt.range || "day");
			}),
			list: cf((lng, opt) => {
				const formatter = new Intl.ListFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			})
		};
	}
	add(name, fc) {
		this.formats[name.toLowerCase().trim()] = fc;
	}
	addCached(name, fc) {
		this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
	}
	format(value, format, lng, options = {}) {
		const formats = format.split(this.formatSeparator);
		if (formats.length > 1 && formats[0].indexOf("(") > 1 && formats[0].indexOf(")") < 0 && formats.find((f) => f.indexOf(")") > -1)) {
			const lastIndex = formats.findIndex((f) => f.indexOf(")") > -1);
			formats[0] = [formats[0], ...formats.splice(1, lastIndex)].join(this.formatSeparator);
		}
		return formats.reduce((mem, f) => {
			const { formatName, formatOptions } = parseFormatStr(f);
			if (this.formats[formatName]) {
				let formatted = mem;
				try {
					const valOptions = options?.formatParams?.[options.interpolationkey] || {};
					const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
					formatted = this.formats[formatName](mem, l, {
						...formatOptions,
						...options,
						...valOptions
					});
				} catch (error) {
					this.logger.warn(error);
				}
				return formatted;
			} else this.logger.warn(`there was no format function for ${formatName}`);
			return mem;
		}, value);
	}
};
var removePending = (q, name) => {
	if (q.pending[name] !== void 0) {
		delete q.pending[name];
		q.pendingCount--;
	}
};
var Connector = class extends EventEmitter {
	constructor(backend, store, services, options = {}) {
		super();
		this.backend = backend;
		this.store = store;
		this.services = services;
		this.languageUtils = services.languageUtils;
		this.options = options;
		this.logger = baseLogger.create("backendConnector");
		this.waitingReads = [];
		this.maxParallelReads = options.maxParallelReads || 10;
		this.readingCalls = 0;
		this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
		this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
		this.state = {};
		this.queue = [];
		this.backend?.init?.(services, options.backend, options);
	}
	queueLoad(languages, namespaces, options, callback) {
		const toLoad = {};
		const pending = {};
		const toLoadLanguages = {};
		const toLoadNamespaces = {};
		languages.forEach((lng) => {
			let hasAllNamespaces = true;
			namespaces.forEach((ns) => {
				const name = `${lng}|${ns}`;
				if (!options.reload && this.store.hasResourceBundle(lng, ns)) this.state[name] = 2;
				else if (this.state[name] < 0);
				else if (this.state[name] === 1) {
					if (pending[name] === void 0) pending[name] = true;
				} else {
					this.state[name] = 1;
					hasAllNamespaces = false;
					if (pending[name] === void 0) pending[name] = true;
					if (toLoad[name] === void 0) toLoad[name] = true;
					if (toLoadNamespaces[ns] === void 0) toLoadNamespaces[ns] = true;
				}
			});
			if (!hasAllNamespaces) toLoadLanguages[lng] = true;
		});
		if (Object.keys(toLoad).length || Object.keys(pending).length) this.queue.push({
			pending,
			pendingCount: Object.keys(pending).length,
			loaded: {},
			errors: [],
			callback
		});
		return {
			toLoad: Object.keys(toLoad),
			pending: Object.keys(pending),
			toLoadLanguages: Object.keys(toLoadLanguages),
			toLoadNamespaces: Object.keys(toLoadNamespaces)
		};
	}
	loaded(name, err, data) {
		const s = name.split("|");
		const lng = s[0];
		const ns = s[1];
		if (err) this.emit("failedLoading", lng, ns, err);
		if (!err && data) this.store.addResourceBundle(lng, ns, data, void 0, void 0, { skipCopy: true });
		this.state[name] = err ? -1 : 2;
		if (err && data) this.state[name] = 0;
		const loaded = {};
		this.queue.forEach((q) => {
			pushPath(q.loaded, [lng], ns);
			removePending(q, name);
			if (err) q.errors.push(err);
			if (q.pendingCount === 0 && !q.done) {
				Object.keys(q.loaded).forEach((l) => {
					if (!loaded[l]) loaded[l] = {};
					const loadedKeys = q.loaded[l];
					if (loadedKeys.length) loadedKeys.forEach((n) => {
						if (loaded[l][n] === void 0) loaded[l][n] = true;
					});
				});
				q.done = true;
				if (q.errors.length) q.callback(q.errors);
				else q.callback();
			}
		});
		this.emit("loaded", loaded);
		this.queue = this.queue.filter((q) => !q.done);
	}
	read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
		if (!lng.length) return callback(null, {});
		if (this.readingCalls >= this.maxParallelReads) {
			this.waitingReads.push({
				lng,
				ns,
				fcName,
				tried,
				wait,
				callback
			});
			return;
		}
		this.readingCalls++;
		const resolver = (err, data) => {
			this.readingCalls--;
			if (this.waitingReads.length > 0) {
				const next = this.waitingReads.shift();
				this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
			}
			if (err && data && tried < this.maxRetries) {
				setTimeout(() => {
					this.read.call(this, lng, ns, fcName, tried + 1, wait * 2, callback);
				}, wait);
				return;
			}
			callback(err, data);
		};
		const fc = this.backend[fcName].bind(this.backend);
		if (fc.length === 2) {
			try {
				const r = fc(lng, ns);
				if (r && typeof r.then === "function") r.then((data) => resolver(null, data)).catch(resolver);
				else resolver(null, r);
			} catch (err) {
				resolver(err);
			}
			return;
		}
		return fc(lng, ns, resolver);
	}
	prepareLoading(languages, namespaces, options = {}, callback) {
		if (!this.backend) {
			this.logger.warn("No backend was added via i18next.use. Will not load resources.");
			return callback && callback();
		}
		if (isString$1(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
		if (isString$1(namespaces)) namespaces = [namespaces];
		const toLoad = this.queueLoad(languages, namespaces, options, callback);
		if (!toLoad.toLoad.length) {
			if (!toLoad.pending.length) callback();
			return null;
		}
		toLoad.toLoad.forEach((name) => {
			this.loadOne(name);
		});
	}
	load(languages, namespaces, callback) {
		this.prepareLoading(languages, namespaces, {}, callback);
	}
	reload(languages, namespaces, callback) {
		this.prepareLoading(languages, namespaces, { reload: true }, callback);
	}
	loadOne(name, prefix = "") {
		const s = name.split("|");
		const lng = s[0];
		const ns = s[1];
		this.read(lng, ns, "read", void 0, void 0, (err, data) => {
			if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
			if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
			this.loaded(name, err, data);
		});
	}
	saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {}) {
		if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
			this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
			return;
		}
		if (key === void 0 || key === null || key === "") return;
		if (this.backend?.create) {
			const opts = {
				...options,
				isUpdate
			};
			const fc = this.backend.create.bind(this.backend);
			if (fc.length < 6) try {
				let r;
				if (fc.length === 5) r = fc(languages, namespace, key, fallbackValue, opts);
				else r = fc(languages, namespace, key, fallbackValue);
				if (r && typeof r.then === "function") r.then((data) => clb(null, data)).catch(clb);
				else clb(null, r);
			} catch (err) {
				clb(err);
			}
			else fc(languages, namespace, key, fallbackValue, clb, opts);
		}
		if (!languages || !languages[0]) return;
		this.store.addResource(languages[0], namespace, key, fallbackValue);
	}
};
var get = () => ({
	debug: false,
	initAsync: true,
	ns: ["translation"],
	defaultNS: ["translation"],
	fallbackLng: ["dev"],
	fallbackNS: false,
	supportedLngs: false,
	nonExplicitSupportedLngs: false,
	load: "all",
	preload: false,
	simplifyPluralSuffix: true,
	keySeparator: ".",
	nsSeparator: ":",
	pluralSeparator: "_",
	contextSeparator: "_",
	partialBundledLanguages: false,
	saveMissing: false,
	updateMissing: false,
	saveMissingTo: "fallback",
	saveMissingPlurals: true,
	missingKeyHandler: false,
	missingInterpolationHandler: false,
	postProcess: false,
	postProcessPassResolved: false,
	returnNull: false,
	returnEmptyString: true,
	returnObjects: false,
	joinArrays: false,
	returnedObjectHandler: false,
	parseMissingKeyHandler: false,
	appendNamespaceToMissingKey: false,
	appendNamespaceToCIMode: false,
	overloadTranslationOptionHandler: (args) => {
		let ret = {};
		if (typeof args[1] === "object") ret = args[1];
		if (isString$1(args[1])) ret.defaultValue = args[1];
		if (isString$1(args[2])) ret.tDescription = args[2];
		if (typeof args[2] === "object" || typeof args[3] === "object") {
			const options = args[3] || args[2];
			Object.keys(options).forEach((key) => {
				ret[key] = options[key];
			});
		}
		return ret;
	},
	interpolation: {
		escapeValue: true,
		format: (value) => value,
		prefix: "{{",
		suffix: "}}",
		formatSeparator: ",",
		unescapePrefix: "-",
		nestingPrefix: "$t(",
		nestingSuffix: ")",
		nestingOptionsSeparator: ",",
		maxReplaces: 1e3,
		skipOnVariables: true
	},
	cacheInBuiltFormats: true
});
var transformOptions = (options) => {
	if (isString$1(options.ns)) options.ns = [options.ns];
	if (isString$1(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
	if (isString$1(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
	if (options.supportedLngs?.indexOf?.("cimode") < 0) options.supportedLngs = options.supportedLngs.concat(["cimode"]);
	if (typeof options.initImmediate === "boolean") options.initAsync = options.initImmediate;
	return options;
};
var noop = () => {};
var bindMemberFunctions = (inst) => {
	Object.getOwnPropertyNames(Object.getPrototypeOf(inst)).forEach((mem) => {
		if (typeof inst[mem] === "function") inst[mem] = inst[mem].bind(inst);
	});
};
var SUPPORT_NOTICE_KEY = "__i18next_supportNoticeShown";
var getSupportNoticeShown = () => {
	if (typeof globalThis !== "undefined" && !!globalThis[SUPPORT_NOTICE_KEY]) return true;
	if (typeof process !== "undefined" && process.env && process.env.I18NEXT_NO_SUPPORT_NOTICE) return true;
	if (typeof process !== "undefined" && process.env && process.env.NODE_ENV === "production") return true;
	return false;
};
var setSupportNoticeShown = () => {
	if (typeof globalThis !== "undefined") globalThis[SUPPORT_NOTICE_KEY] = true;
};
var usesLocize = (inst) => {
	if (inst?.modules?.backend?.name?.indexOf("Locize") > 0) return true;
	if (inst?.modules?.backend?.constructor?.name?.indexOf("Locize") > 0) return true;
	if (inst?.options?.backend?.backends) {
		if (inst.options.backend.backends.some((b) => b?.name?.indexOf("Locize") > 0 || b?.constructor?.name?.indexOf("Locize") > 0)) return true;
	}
	if (inst?.options?.backend?.projectId) return true;
	if (inst?.options?.backend?.backendOptions) {
		if (inst.options.backend.backendOptions.some((b) => b?.projectId)) return true;
	}
	return false;
};
var instance = class I18n extends EventEmitter {
	constructor(options = {}, callback) {
		super();
		this.options = transformOptions(options);
		this.services = {};
		this.logger = baseLogger;
		this.modules = { external: [] };
		bindMemberFunctions(this);
		if (callback && !this.isInitialized && !options.isClone) {
			if (!this.options.initAsync) {
				this.init(options, callback);
				return this;
			}
			setTimeout(() => {
				this.init(options, callback);
			}, 0);
		}
	}
	init(options = {}, callback) {
		this.isInitializing = true;
		if (typeof options === "function") {
			callback = options;
			options = {};
		}
		if (options.defaultNS == null && options.ns) {
			if (isString$1(options.ns)) options.defaultNS = options.ns;
			else if (options.ns.indexOf("translation") < 0) options.defaultNS = options.ns[0];
		}
		const defOpts = get();
		this.options = {
			...defOpts,
			...this.options,
			...transformOptions(options)
		};
		this.options.interpolation = {
			...defOpts.interpolation,
			...this.options.interpolation
		};
		if (options.keySeparator !== void 0) this.options.userDefinedKeySeparator = options.keySeparator;
		if (options.nsSeparator !== void 0) this.options.userDefinedNsSeparator = options.nsSeparator;
		if (typeof this.options.overloadTranslationOptionHandler !== "function") this.options.overloadTranslationOptionHandler = defOpts.overloadTranslationOptionHandler;
		if (this.options.showSupportNotice !== false && !usesLocize(this) && !getSupportNoticeShown()) {
			if (typeof console !== "undefined" && typeof console.info !== "undefined") console.info("🌐 i18next is made possible by our own product, Locize — consider powering your project with managed localization (AI, CDN, integrations): https://locize.com 💙");
			setSupportNoticeShown();
		}
		const createClassOnDemand = (ClassOrObject) => {
			if (!ClassOrObject) return null;
			if (typeof ClassOrObject === "function") return new ClassOrObject();
			return ClassOrObject;
		};
		if (!this.options.isClone) {
			if (this.modules.logger) baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
			else baseLogger.init(null, this.options);
			let formatter;
			if (this.modules.formatter) formatter = this.modules.formatter;
			else formatter = Formatter;
			const lu = new LanguageUtil(this.options);
			this.store = new ResourceStore(this.options.resources, this.options);
			const s = this.services;
			s.logger = baseLogger;
			s.resourceStore = this.store;
			s.languageUtils = lu;
			s.pluralResolver = new PluralResolver(lu, {
				prepend: this.options.pluralSeparator,
				simplifyPluralSuffix: this.options.simplifyPluralSuffix
			});
			if (this.options.interpolation.format && this.options.interpolation.format !== defOpts.interpolation.format) this.logger.deprecate(`init: you are still using the legacy format function, please use the new approach: https://www.i18next.com/translation-function/formatting`);
			if (formatter && (!this.options.interpolation.format || this.options.interpolation.format === defOpts.interpolation.format)) {
				s.formatter = createClassOnDemand(formatter);
				if (s.formatter.init) s.formatter.init(s, this.options);
				this.options.interpolation.format = s.formatter.format.bind(s.formatter);
			}
			s.interpolator = new Interpolator(this.options);
			s.utils = { hasLoadedNamespace: this.hasLoadedNamespace.bind(this) };
			s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
			s.backendConnector.on("*", (event, ...args) => {
				this.emit(event, ...args);
			});
			if (this.modules.languageDetector) {
				s.languageDetector = createClassOnDemand(this.modules.languageDetector);
				if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
			}
			if (this.modules.i18nFormat) {
				s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
				if (s.i18nFormat.init) s.i18nFormat.init(this);
			}
			this.translator = new Translator(this.services, this.options);
			this.translator.on("*", (event, ...args) => {
				this.emit(event, ...args);
			});
			this.modules.external.forEach((m) => {
				if (m.init) m.init(this);
			});
		}
		this.format = this.options.interpolation.format;
		if (!callback) callback = noop;
		if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
			const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
			if (codes.length > 0 && codes[0] !== "dev") this.options.lng = codes[0];
		}
		if (!this.services.languageDetector && !this.options.lng) this.logger.warn("init: no languageDetector is used and no lng is defined");
		[
			"getResource",
			"hasResourceBundle",
			"getResourceBundle",
			"getDataByLanguage"
		].forEach((fcName) => {
			this[fcName] = (...args) => this.store[fcName](...args);
		});
		[
			"addResource",
			"addResources",
			"addResourceBundle",
			"removeResourceBundle"
		].forEach((fcName) => {
			this[fcName] = (...args) => {
				this.store[fcName](...args);
				return this;
			};
		});
		const deferred = defer();
		const load = () => {
			const finish = (err, t) => {
				this.isInitializing = false;
				if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn("init: i18next is already initialized. You should call init just once!");
				this.isInitialized = true;
				if (!this.options.isClone) this.logger.log("initialized", this.options);
				this.emit("initialized", this.options);
				deferred.resolve(t);
				callback(err, t);
			};
			if (this.languages && !this.isInitialized) return finish(null, this.t.bind(this));
			this.changeLanguage(this.options.lng, finish);
		};
		if (this.options.resources || !this.options.initAsync) load();
		else setTimeout(load, 0);
		return deferred;
	}
	loadResources(language, callback = noop) {
		let usedCallback = callback;
		const usedLng = isString$1(language) ? language : this.language;
		if (typeof language === "function") usedCallback = language;
		if (!this.options.resources || this.options.partialBundledLanguages) {
			if (usedLng?.toLowerCase() === "cimode" && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
			const toLoad = [];
			const append = (lng) => {
				if (!lng) return;
				if (lng === "cimode") return;
				this.services.languageUtils.toResolveHierarchy(lng).forEach((l) => {
					if (l === "cimode") return;
					if (toLoad.indexOf(l) < 0) toLoad.push(l);
				});
			};
			if (!usedLng) this.services.languageUtils.getFallbackCodes(this.options.fallbackLng).forEach((l) => append(l));
			else append(usedLng);
			this.options.preload?.forEach?.((l) => append(l));
			this.services.backendConnector.load(toLoad, this.options.ns, (e) => {
				if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
				usedCallback(e);
			});
		} else usedCallback(null);
	}
	reloadResources(lngs, ns, callback) {
		const deferred = defer();
		if (typeof lngs === "function") {
			callback = lngs;
			lngs = void 0;
		}
		if (typeof ns === "function") {
			callback = ns;
			ns = void 0;
		}
		if (!lngs) lngs = this.languages;
		if (!ns) ns = this.options.ns;
		if (!callback) callback = noop;
		this.services.backendConnector.reload(lngs, ns, (err) => {
			deferred.resolve();
			callback(err);
		});
		return deferred;
	}
	use(module) {
		if (!module) throw new Error("You are passing an undefined module! Please check the object you are passing to i18next.use()");
		if (!module.type) throw new Error("You are passing a wrong module! Please check the object you are passing to i18next.use()");
		if (module.type === "backend") this.modules.backend = module;
		if (module.type === "logger" || module.log && module.warn && module.error) this.modules.logger = module;
		if (module.type === "languageDetector") this.modules.languageDetector = module;
		if (module.type === "i18nFormat") this.modules.i18nFormat = module;
		if (module.type === "postProcessor") postProcessor.addPostProcessor(module);
		if (module.type === "formatter") this.modules.formatter = module;
		if (module.type === "3rdParty") this.modules.external.push(module);
		return this;
	}
	setResolvedLanguage(l) {
		if (!l || !this.languages) return;
		if (["cimode", "dev"].indexOf(l) > -1) return;
		for (let li = 0; li < this.languages.length; li++) {
			const lngInLngs = this.languages[li];
			if (["cimode", "dev"].indexOf(lngInLngs) > -1) continue;
			if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
				this.resolvedLanguage = lngInLngs;
				break;
			}
		}
		if (!this.resolvedLanguage && this.languages.indexOf(l) < 0 && this.store.hasLanguageSomeTranslations(l)) {
			this.resolvedLanguage = l;
			this.languages.unshift(l);
		}
	}
	changeLanguage(lng, callback) {
		this.isLanguageChangingTo = lng;
		const deferred = defer();
		this.emit("languageChanging", lng);
		const setLngProps = (l) => {
			this.language = l;
			this.languages = this.services.languageUtils.toResolveHierarchy(l);
			this.resolvedLanguage = void 0;
			this.setResolvedLanguage(l);
		};
		const done = (err, l) => {
			if (l) {
				if (this.isLanguageChangingTo === lng) {
					setLngProps(l);
					this.translator.changeLanguage(l);
					this.isLanguageChangingTo = void 0;
					this.emit("languageChanged", l);
					this.logger.log("languageChanged", l);
				}
			} else this.isLanguageChangingTo = void 0;
			deferred.resolve((...args) => this.t(...args));
			if (callback) callback(err, (...args) => this.t(...args));
		};
		const setLng = (lngs) => {
			if (!lng && !lngs && this.services.languageDetector) lngs = [];
			const fl = isString$1(lngs) ? lngs : lngs && lngs[0];
			const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString$1(lngs) ? [lngs] : lngs);
			if (l) {
				if (!this.language) setLngProps(l);
				if (!this.translator.language) this.translator.changeLanguage(l);
				this.services.languageDetector?.cacheUserLanguage?.(l);
			}
			this.loadResources(l, (err) => {
				done(err, l);
			});
		};
		if (!lng && this.services.languageDetector && !this.services.languageDetector.async) setLng(this.services.languageDetector.detect());
		else if (!lng && this.services.languageDetector && this.services.languageDetector.async) if (this.services.languageDetector.detect.length === 0) this.services.languageDetector.detect().then(setLng);
		else this.services.languageDetector.detect(setLng);
		else setLng(lng);
		return deferred;
	}
	getFixedT(lng, ns, keyPrefix) {
		const fixedT = (key, opts, ...rest) => {
			let o;
			if (typeof opts !== "object") o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
			else o = { ...opts };
			o.lng = o.lng || fixedT.lng;
			o.lngs = o.lngs || fixedT.lngs;
			o.ns = o.ns || fixedT.ns;
			if (o.keyPrefix !== "") o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
			const selectorOpts = {
				...this.options,
				...o
			};
			if (typeof o.keyPrefix === "function") o.keyPrefix = keysFromSelector(o.keyPrefix, selectorOpts);
			const keySeparator = this.options.keySeparator || ".";
			let resultKey;
			if (o.keyPrefix && Array.isArray(key)) resultKey = key.map((k) => {
				if (typeof k === "function") k = keysFromSelector(k, selectorOpts);
				return `${o.keyPrefix}${keySeparator}${k}`;
			});
			else {
				if (typeof key === "function") key = keysFromSelector(key, selectorOpts);
				resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
			}
			return this.t(resultKey, o);
		};
		if (isString$1(lng)) fixedT.lng = lng;
		else fixedT.lngs = lng;
		fixedT.ns = ns;
		fixedT.keyPrefix = keyPrefix;
		return fixedT;
	}
	t(...args) {
		return this.translator?.translate(...args);
	}
	exists(...args) {
		return this.translator?.exists(...args);
	}
	setDefaultNamespace(ns) {
		this.options.defaultNS = ns;
	}
	hasLoadedNamespace(ns, options = {}) {
		if (!this.isInitialized) {
			this.logger.warn("hasLoadedNamespace: i18next was not initialized", this.languages);
			return false;
		}
		if (!this.languages || !this.languages.length) {
			this.logger.warn("hasLoadedNamespace: i18n.languages were undefined or empty", this.languages);
			return false;
		}
		const lng = options.lng || this.resolvedLanguage || this.languages[0];
		const fallbackLng = this.options ? this.options.fallbackLng : false;
		const lastLng = this.languages[this.languages.length - 1];
		if (lng.toLowerCase() === "cimode") return true;
		const loadNotPending = (l, n) => {
			const loadState = this.services.backendConnector.state[`${l}|${n}`];
			return loadState === -1 || loadState === 0 || loadState === 2;
		};
		if (options.precheck) {
			const preResult = options.precheck(this, loadNotPending);
			if (preResult !== void 0) return preResult;
		}
		if (this.hasResourceBundle(lng, ns)) return true;
		if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
		if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
		return false;
	}
	loadNamespaces(ns, callback) {
		const deferred = defer();
		if (!this.options.ns) {
			if (callback) callback();
			return Promise.resolve();
		}
		if (isString$1(ns)) ns = [ns];
		ns.forEach((n) => {
			if (this.options.ns.indexOf(n) < 0) this.options.ns.push(n);
		});
		this.loadResources((err) => {
			deferred.resolve();
			if (callback) callback(err);
		});
		return deferred;
	}
	loadLanguages(lngs, callback) {
		const deferred = defer();
		if (isString$1(lngs)) lngs = [lngs];
		const preloaded = this.options.preload || [];
		const newLngs = lngs.filter((lng) => preloaded.indexOf(lng) < 0 && this.services.languageUtils.isSupportedCode(lng));
		if (!newLngs.length) {
			if (callback) callback();
			return Promise.resolve();
		}
		this.options.preload = preloaded.concat(newLngs);
		this.loadResources((err) => {
			deferred.resolve();
			if (callback) callback(err);
		});
		return deferred;
	}
	dir(lng) {
		if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
		if (!lng) return "rtl";
		try {
			const l = new Intl.Locale(lng);
			if (l && l.getTextInfo) {
				const ti = l.getTextInfo();
				if (ti && ti.direction) return ti.direction;
			}
		} catch (e) {}
		const rtlLngs = [
			"ar",
			"shu",
			"sqr",
			"ssh",
			"xaa",
			"yhd",
			"yud",
			"aao",
			"abh",
			"abv",
			"acm",
			"acq",
			"acw",
			"acx",
			"acy",
			"adf",
			"ads",
			"aeb",
			"aec",
			"afb",
			"ajp",
			"apc",
			"apd",
			"arb",
			"arq",
			"ars",
			"ary",
			"arz",
			"auz",
			"avl",
			"ayh",
			"ayl",
			"ayn",
			"ayp",
			"bbz",
			"pga",
			"he",
			"iw",
			"ps",
			"pbt",
			"pbu",
			"pst",
			"prp",
			"prd",
			"ug",
			"ur",
			"ydd",
			"yds",
			"yih",
			"ji",
			"yi",
			"hbo",
			"men",
			"xmn",
			"fa",
			"jpr",
			"peo",
			"pes",
			"prs",
			"dv",
			"sam",
			"ckb"
		];
		const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
		if (lng.toLowerCase().indexOf("-latn") > 1) return "ltr";
		return rtlLngs.indexOf(languageUtils.getLanguagePartFromCode(lng)) > -1 || lng.toLowerCase().indexOf("-arab") > 1 ? "rtl" : "ltr";
	}
	static createInstance(options = {}, callback) {
		const instance = new I18n(options, callback);
		instance.createInstance = I18n.createInstance;
		return instance;
	}
	cloneInstance(options = {}, callback = noop) {
		const forkResourceStore = options.forkResourceStore;
		if (forkResourceStore) delete options.forkResourceStore;
		const mergedOptions = {
			...this.options,
			...options,
			isClone: true
		};
		const clone = new I18n(mergedOptions);
		if (options.debug !== void 0 || options.prefix !== void 0) clone.logger = clone.logger.clone(options);
		[
			"store",
			"services",
			"language"
		].forEach((m) => {
			clone[m] = this[m];
		});
		clone.services = { ...this.services };
		clone.services.utils = { hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone) };
		if (forkResourceStore) {
			clone.store = new ResourceStore(Object.keys(this.store.data).reduce((prev, l) => {
				prev[l] = { ...this.store.data[l] };
				prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
					acc[n] = { ...prev[l][n] };
					return acc;
				}, prev[l]);
				return prev;
			}, {}), mergedOptions);
			clone.services.resourceStore = clone.store;
		}
		if (options.interpolation) {
			const mergedInterpolation = {
				...get().interpolation,
				...this.options.interpolation,
				...options.interpolation
			};
			const mergedForInterpolator = {
				...mergedOptions,
				interpolation: mergedInterpolation
			};
			clone.services.interpolator = new Interpolator(mergedForInterpolator);
		}
		clone.translator = new Translator(clone.services, mergedOptions);
		clone.translator.on("*", (event, ...args) => {
			clone.emit(event, ...args);
		});
		clone.init(mergedOptions, callback);
		clone.translator.options = mergedOptions;
		clone.translator.backendConnector.services.utils = { hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone) };
		return clone;
	}
	toJSON() {
		return {
			options: this.options,
			store: this.store,
			language: this.language,
			languages: this.languages,
			resolvedLanguage: this.resolvedLanguage
		};
	}
}.createInstance();
instance.createInstance;
instance.dir;
instance.init;
instance.loadResources;
instance.reloadResources;
instance.use;
instance.changeLanguage;
instance.getFixedT;
instance.t;
instance.exists;
instance.setDefaultNamespace;
instance.hasLoadedNamespace;
instance.loadNamespaces;
instance.loadLanguages;
//#endregion
//#region ../../node_modules/html-parse-stringify/dist/html-parse-stringify.module.js
var import_void_elements = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* This file automatically generated from `pre-publish.js`.
	* Do not manually edit.
	*/
	module.exports = {
		"area": true,
		"base": true,
		"br": true,
		"col": true,
		"embed": true,
		"hr": true,
		"img": true,
		"input": true,
		"link": true,
		"meta": true,
		"param": true,
		"source": true,
		"track": true,
		"wbr": true
	};
})))());
var t = /\s([^'"/\s><]+?)[\s/>]|([^\s=]+)=\s?(".*?"|'.*?')/g;
function n(n) {
	var r = {
		type: "tag",
		name: "",
		voidElement: !1,
		attrs: {},
		children: []
	}, i = n.match(/<\/?([^\s]+?)[/\s>]/);
	if (i && (r.name = i[1], (import_void_elements.default[i[1]] || "/" === n.charAt(n.length - 2)) && (r.voidElement = !0), r.name.startsWith("!--"))) {
		var s = n.indexOf("-->");
		return {
			type: "comment",
			comment: -1 !== s ? n.slice(4, s) : ""
		};
	}
	for (var a = new RegExp(t), c = null; null !== (c = a.exec(n));) if (c[0].trim()) if (c[1]) {
		var o = c[1].trim(), l = [o, ""];
		o.indexOf("=") > -1 && (l = o.split("=")), r.attrs[l[0]] = l[1], a.lastIndex--;
	} else c[2] && (r.attrs[c[2]] = c[3].trim().substring(1, c[3].length - 1));
	return r;
}
var r = /<[a-zA-Z0-9\-\!\/](?:"[^"]*"|'[^']*'|[^'">])*>/g, i = /^\s*$/, s = Object.create(null);
function a(e, t) {
	switch (t.type) {
		case "text": return e + t.content;
		case "tag": return e += "<" + t.name + (t.attrs ? function(e) {
			var t = [];
			for (var n in e) t.push(n + "=\"" + e[n] + "\"");
			return t.length ? " " + t.join(" ") : "";
		}(t.attrs) : "") + (t.voidElement ? "/>" : ">"), t.voidElement ? e : e + t.children.reduce(a, "") + "</" + t.name + ">";
		case "comment": return e + "<!--" + t.comment + "-->";
	}
}
var c = {
	parse: function(e, t) {
		t || (t = {}), t.components || (t.components = s);
		var a, c = [], o = [], l = -1, m = !1;
		if (0 !== e.indexOf("<")) {
			var u = e.indexOf("<");
			c.push({
				type: "text",
				content: -1 === u ? e : e.substring(0, u)
			});
		}
		return e.replace(r, function(r, s) {
			if (m) {
				if (r !== "</" + a.name + ">") return;
				m = !1;
			}
			var u, f = "/" !== r.charAt(1), h = r.startsWith("<!--"), p = s + r.length, d = e.charAt(p);
			if (h) {
				var v = n(r);
				return l < 0 ? (c.push(v), c) : ((u = o[l]).children.push(v), c);
			}
			if (f && (l++, "tag" === (a = n(r)).type && t.components[a.name] && (a.type = "component", m = !0), a.voidElement || m || !d || "<" === d || a.children.push({
				type: "text",
				content: e.slice(p, e.indexOf("<", p))
			}), 0 === l && c.push(a), (u = o[l - 1]) && u.children.push(a), o[l] = a), (!f || a.voidElement) && (l > -1 && (a.voidElement || a.name === r.slice(2, -1)) && (l--, a = -1 === l ? c : o[l]), !m && "<" !== d && d)) {
				u = -1 === l ? c : o[l].children;
				var x = e.indexOf("<", p), g = e.slice(p, -1 === x ? void 0 : x);
				i.test(g) && (g = " "), (x > -1 && l + u.length >= 0 || " " !== g) && u.push({
					type: "text",
					content: g
				});
			}
		}), c;
	},
	stringify: function(e) {
		return e.reduce(function(e, t) {
			return e + a("", t);
		}, "");
	}
};
//#endregion
//#region ../../node_modules/react-i18next/dist/es/utils.js
var warn = (i18n, code, msg, rest) => {
	const args = [msg, {
		code,
		...rest || {}
	}];
	if (i18n?.services?.logger?.forward) return i18n.services.logger.forward(args, "warn", "react-i18next::", true);
	if (isString(args[0])) args[0] = `react-i18next:: ${args[0]}`;
	if (i18n?.services?.logger?.warn) i18n.services.logger.warn(...args);
	else if (console?.warn) console.warn(...args);
};
var alreadyWarned = {};
var warnOnce = (i18n, code, msg, rest) => {
	if (isString(msg) && alreadyWarned[msg]) return;
	if (isString(msg)) alreadyWarned[msg] = /* @__PURE__ */ new Date();
	warn(i18n, code, msg, rest);
};
var loadedClb = (i18n, cb) => () => {
	if (i18n.isInitialized) cb();
	else {
		const initialized = () => {
			setTimeout(() => {
				i18n.off("initialized", initialized);
			}, 0);
			cb();
		};
		i18n.on("initialized", initialized);
	}
};
var loadNamespaces = (i18n, ns, cb) => {
	i18n.loadNamespaces(ns, loadedClb(i18n, cb));
};
var loadLanguages = (i18n, lng, ns, cb) => {
	if (isString(ns)) ns = [ns];
	if (i18n.options.preload && i18n.options.preload.indexOf(lng) > -1) return loadNamespaces(i18n, ns, cb);
	ns.forEach((n) => {
		if (i18n.options.ns.indexOf(n) < 0) i18n.options.ns.push(n);
	});
	i18n.loadLanguages(lng, loadedClb(i18n, cb));
};
var hasLoadedNamespace = (ns, i18n, options = {}) => {
	if (!i18n.languages || !i18n.languages.length) {
		warnOnce(i18n, "NO_LANGUAGES", "i18n.languages were undefined or empty", { languages: i18n.languages });
		return true;
	}
	return i18n.hasLoadedNamespace(ns, {
		lng: options.lng,
		precheck: (i18nInstance, loadNotPending) => {
			if (options.bindI18n && options.bindI18n.indexOf("languageChanging") > -1 && i18nInstance.services.backendConnector.backend && i18nInstance.isLanguageChangingTo && !loadNotPending(i18nInstance.isLanguageChangingTo, ns)) return false;
		}
	});
};
var isString = (obj) => typeof obj === "string";
var isObject = (obj) => typeof obj === "object" && obj !== null;
//#endregion
//#region ../../node_modules/react-i18next/dist/es/unescape.js
var matchHtmlEntity = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g;
var htmlEntities = {
	"&amp;": "&",
	"&#38;": "&",
	"&lt;": "<",
	"&#60;": "<",
	"&gt;": ">",
	"&#62;": ">",
	"&apos;": "'",
	"&#39;": "'",
	"&quot;": "\"",
	"&#34;": "\"",
	"&nbsp;": " ",
	"&#160;": " ",
	"&copy;": "©",
	"&#169;": "©",
	"&reg;": "®",
	"&#174;": "®",
	"&hellip;": "…",
	"&#8230;": "…",
	"&#x2F;": "/",
	"&#47;": "/"
};
var unescapeHtmlEntity = (m) => htmlEntities[m];
var unescape = (text) => text.replace(matchHtmlEntity, unescapeHtmlEntity);
//#endregion
//#region ../../node_modules/react-i18next/dist/es/defaults.js
var defaultOptions = {
	bindI18n: "languageChanged",
	bindI18nStore: "",
	transEmptyNodeValue: "",
	transSupportBasicHtmlNodes: true,
	transWrapTextNodes: "",
	transKeepBasicHtmlNodesFor: [
		"br",
		"strong",
		"i",
		"p"
	],
	useSuspense: true,
	unescape,
	transDefaultProps: void 0
};
var getDefaults = () => defaultOptions;
//#endregion
//#region ../../node_modules/react-i18next/dist/es/i18nInstance.js
var i18nInstance;
var getI18n = () => i18nInstance;
//#endregion
//#region ../../node_modules/react-i18next/dist/es/TransWithoutContext.js
var hasChildren = (node, checkLength) => {
	if (!node) return false;
	const base = node.props?.children ?? node.children;
	if (checkLength) return base.length > 0;
	return !!base;
};
var getChildren = (node) => {
	if (!node) return [];
	const children = node.props?.children ?? node.children;
	return node.props?.i18nIsDynamicList ? getAsArray(children) : children;
};
var hasValidReactChildren = (children) => Array.isArray(children) && children.every(isValidElement);
var getAsArray = (data) => Array.isArray(data) ? data : [data];
var mergeProps$1 = (source, target) => {
	const newTarget = { ...target };
	newTarget.props = {
		...target.props,
		...source.props
	};
	return newTarget;
};
var getValuesFromChildren = (children) => {
	const values = {};
	if (!children) return values;
	const getData = (childs) => {
		getAsArray(childs).forEach((child) => {
			if (isString(child)) return;
			if (hasChildren(child)) getData(getChildren(child));
			else if (isObject(child) && !isValidElement(child)) Object.assign(values, child);
		});
	};
	getData(children);
	return values;
};
var nodesToString = (children, i18nOptions, i18n, i18nKey) => {
	if (!children) return "";
	let stringNode = "";
	const childrenArray = getAsArray(children);
	const keepArray = i18nOptions?.transSupportBasicHtmlNodes ? i18nOptions.transKeepBasicHtmlNodesFor ?? [] : [];
	childrenArray.forEach((child, childIndex) => {
		if (isString(child)) {
			stringNode += `${child}`;
			return;
		}
		if (isValidElement(child)) {
			const { props, type } = child;
			const childPropsCount = Object.keys(props).length;
			const shouldKeepChild = keepArray.indexOf(type) > -1;
			const childChildren = props.children;
			if (!childChildren && shouldKeepChild && !childPropsCount) {
				stringNode += `<${type}/>`;
				return;
			}
			if (!childChildren && (!shouldKeepChild || childPropsCount) || props.i18nIsDynamicList) {
				stringNode += `<${childIndex}></${childIndex}>`;
				return;
			}
			if (shouldKeepChild && childPropsCount === 1 && isString(childChildren)) {
				stringNode += `<${type}>${childChildren}</${type}>`;
				return;
			}
			const content = nodesToString(childChildren, i18nOptions, i18n, i18nKey);
			stringNode += `<${childIndex}>${content}</${childIndex}>`;
			return;
		}
		if (child === null) {
			warn(i18n, "TRANS_NULL_VALUE", `Passed in a null value as child`, { i18nKey });
			return;
		}
		if (isObject(child)) {
			const { format, ...clone } = child;
			const keys = Object.keys(clone);
			if (keys.length === 1) {
				const value = format ? `${keys[0]}, ${format}` : keys[0];
				stringNode += `{{${value}}}`;
				return;
			}
			warn(i18n, "TRANS_INVALID_OBJ", `Invalid child - Object should only have keys {{ value, format }} (format is optional).`, {
				i18nKey,
				child
			});
			return;
		}
		warn(i18n, "TRANS_INVALID_VAR", `Passed in a variable like {number} - pass variables for interpolation as full objects like {{number}}.`, {
			i18nKey,
			child
		});
	});
	return stringNode;
};
var escapeLiteralLessThan = (str, keepArray = [], knownComponentsMap = {}) => {
	if (!str) return str;
	const knownNames = Object.keys(knownComponentsMap);
	const allValidNames = [...keepArray, ...knownNames];
	let result = "";
	let i = 0;
	while (i < str.length) if (str[i] === "<") {
		let isValidTag = false;
		const closingMatch = str.slice(i).match(/^<\/(\d+|[a-zA-Z][a-zA-Z0-9_-]*)>/);
		if (closingMatch) {
			const tagName = closingMatch[1];
			if (/^\d+$/.test(tagName) || allValidNames.includes(tagName)) {
				isValidTag = true;
				result += closingMatch[0];
				i += closingMatch[0].length;
			}
		}
		if (!isValidTag) {
			const openingMatch = str.slice(i).match(/^<(\d+|[a-zA-Z][a-zA-Z0-9_-]*)(\s+[\w-]+(?:=(?:"[^"]*"|'[^']*'|[^\s>]+))?)*\s*(\/)?>/);
			if (openingMatch) {
				const tagName = openingMatch[1];
				if (/^\d+$/.test(tagName) || allValidNames.includes(tagName)) {
					isValidTag = true;
					result += openingMatch[0];
					i += openingMatch[0].length;
				}
			}
		}
		if (!isValidTag) {
			result += "&lt;";
			i += 1;
		}
	} else {
		result += str[i];
		i += 1;
	}
	return result;
};
var renderNodes = (children, knownComponentsMap, targetString, i18n, i18nOptions, combinedTOpts, shouldUnescape) => {
	if (targetString === "") return [];
	const keepArray = i18nOptions.transKeepBasicHtmlNodesFor || [];
	const emptyChildrenButNeedsHandling = targetString && new RegExp(keepArray.map((keep) => `<${keep}`).join("|")).test(targetString);
	if (!children && !knownComponentsMap && !emptyChildrenButNeedsHandling && !shouldUnescape) return [targetString];
	const data = knownComponentsMap ?? {};
	const getData = (childs) => {
		getAsArray(childs).forEach((child) => {
			if (isString(child)) return;
			if (hasChildren(child)) getData(getChildren(child));
			else if (isObject(child) && !isValidElement(child)) Object.assign(data, child);
		});
	};
	getData(children);
	const escapedString = escapeLiteralLessThan(targetString, keepArray, data);
	const ast = c.parse(`<0>${escapedString}</0>`);
	const opts = {
		...data,
		...combinedTOpts
	};
	const renderInner = (child, node, rootReactNode) => {
		const childs = getChildren(child);
		const mappedChildren = mapAST(childs, node.children, rootReactNode);
		return hasValidReactChildren(childs) && mappedChildren.length === 0 || child.props?.i18nIsDynamicList ? childs : mappedChildren;
	};
	const pushTranslatedJSX = (child, inner, mem, i, isVoid) => {
		if (child.dummy) {
			child.children = inner;
			mem.push(cloneElement(child, { key: i }, isVoid ? void 0 : inner));
		} else mem.push(...Children.map([child], (c) => {
			const INTERNAL_DYNAMIC_MARKER = "data-i18n-is-dynamic-list";
			const override = {
				key: i,
				[INTERNAL_DYNAMIC_MARKER]: void 0
			};
			if (c && c.props) Object.keys(c.props).forEach((k) => {
				if (k === "ref" || k === "children" || k === "i18nIsDynamicList" || k === INTERNAL_DYNAMIC_MARKER) return;
				override[k] = c.props[k];
			});
			return cloneElement(c, override, isVoid ? null : inner);
		}));
	};
	const mapAST = (reactNode, astNode, rootReactNode) => {
		const reactNodes = getAsArray(reactNode);
		return getAsArray(astNode).reduce((mem, node, i) => {
			const translationContent = node.children?.[0]?.content && i18n.services.interpolator.interpolate(node.children[0].content, opts, i18n.language);
			if (node.type === "tag") {
				let tmp = reactNodes[parseInt(node.name, 10)];
				if (!tmp && knownComponentsMap) tmp = knownComponentsMap[node.name];
				if (rootReactNode.length === 1 && !tmp) tmp = rootReactNode[0][node.name];
				if (!tmp) tmp = {};
				const props = { ...node.attrs };
				if (shouldUnescape) Object.keys(props).forEach((p) => {
					const val = props[p];
					if (isString(val)) props[p] = unescape(val);
				});
				const child = Object.keys(props).length !== 0 ? mergeProps$1({ props }, tmp) : tmp;
				const isElement = isValidElement(child);
				const isValidTranslationWithChildren = isElement && hasChildren(node, true) && !node.voidElement;
				const isEmptyTransWithHTML = emptyChildrenButNeedsHandling && isObject(child) && child.dummy && !isElement;
				const isKnownComponent = isObject(knownComponentsMap) && Object.hasOwnProperty.call(knownComponentsMap, node.name);
				if (isString(child)) {
					const value = i18n.services.interpolator.interpolate(child, opts, i18n.language);
					mem.push(value);
				} else if (hasChildren(child) || isValidTranslationWithChildren) pushTranslatedJSX(child, renderInner(child, node, rootReactNode), mem, i);
				else if (isEmptyTransWithHTML) pushTranslatedJSX(child, mapAST(reactNodes, node.children, rootReactNode), mem, i);
				else if (Number.isNaN(parseFloat(node.name))) if (isKnownComponent) pushTranslatedJSX(child, renderInner(child, node, rootReactNode), mem, i, node.voidElement);
				else if (i18nOptions.transSupportBasicHtmlNodes && keepArray.indexOf(node.name) > -1) if (node.voidElement) mem.push(createElement(node.name, { key: `${node.name}-${i}` }));
				else {
					const inner = mapAST(reactNodes, node.children, rootReactNode);
					mem.push(createElement(node.name, { key: `${node.name}-${i}` }, inner));
				}
				else if (node.voidElement) mem.push(`<${node.name} />`);
				else {
					const inner = mapAST(reactNodes, node.children, rootReactNode);
					mem.push(`<${node.name}>${inner}</${node.name}>`);
				}
				else if (isObject(child) && !isElement) {
					const content = node.children[0] ? translationContent : null;
					if (content) mem.push(content);
				} else pushTranslatedJSX(child, translationContent, mem, i, node.children.length !== 1 || !translationContent);
			} else if (node.type === "text") {
				const wrapTextNodes = i18nOptions.transWrapTextNodes;
				const unescapeFn = typeof i18nOptions.unescape === "function" ? i18nOptions.unescape : getDefaults().unescape;
				const content = shouldUnescape ? unescapeFn(i18n.services.interpolator.interpolate(node.content, opts, i18n.language)) : i18n.services.interpolator.interpolate(node.content, opts, i18n.language);
				if (wrapTextNodes) mem.push(createElement(wrapTextNodes, { key: `${node.name}-${i}` }, content));
				else mem.push(content);
			}
			return mem;
		}, []);
	};
	return getChildren(mapAST([{
		dummy: true,
		children: children || []
	}], ast, getAsArray(children || []))[0]);
};
var fixComponentProps = (component, index, translation) => {
	const componentKey = component.key || index;
	const comp = cloneElement(component, { key: componentKey });
	if (!comp.props || !comp.props.children || translation.indexOf(`${index}/>`) < 0 && translation.indexOf(`${index} />`) < 0) return comp;
	function Componentized() {
		return createElement(Fragment, null, comp);
	}
	return createElement(Componentized, { key: componentKey });
};
var generateArrayComponents = (components, translation) => components.map((c, index) => fixComponentProps(c, index, translation));
var generateObjectComponents = (components, translation) => {
	const componentMap = {};
	Object.keys(components).forEach((c) => {
		Object.assign(componentMap, { [c]: fixComponentProps(components[c], c, translation) });
	});
	return componentMap;
};
var generateComponents = (components, translation, i18n, i18nKey) => {
	if (!components) return null;
	if (Array.isArray(components)) return generateArrayComponents(components, translation);
	if (isObject(components)) return generateObjectComponents(components, translation);
	warnOnce(i18n, "TRANS_INVALID_COMPONENTS", `<Trans /> "components" prop expects an object or array`, { i18nKey });
	return null;
};
var isComponentsMap = (object) => {
	if (!isObject(object)) return false;
	if (Array.isArray(object)) return false;
	return Object.keys(object).reduce((acc, key) => acc && Number.isNaN(Number.parseFloat(key)), true);
};
function Trans$1({ children, count, parent, i18nKey, context, tOptions = {}, values, defaults, components, ns, i18n: i18nFromProps, t: tFromProps, shouldUnescape, ...additionalProps }) {
	const i18n = i18nFromProps || getI18n();
	if (!i18n) {
		warnOnce(i18n, "NO_I18NEXT_INSTANCE", `Trans: You need to pass in an i18next instance using i18nextReactModule`, { i18nKey });
		return children;
	}
	const t = tFromProps || i18n.t.bind(i18n) || ((k) => k);
	const reactI18nextOptions = {
		...getDefaults(),
		...i18n.options?.react
	};
	let namespaces = ns || t.ns || i18n.options?.defaultNS;
	namespaces = isString(namespaces) ? [namespaces] : namespaces || ["translation"];
	const { transDefaultProps } = reactI18nextOptions;
	const mergedTOptions = transDefaultProps?.tOptions ? {
		...transDefaultProps.tOptions,
		...tOptions
	} : tOptions;
	const mergedShouldUnescape = shouldUnescape ?? transDefaultProps?.shouldUnescape;
	const mergedValues = transDefaultProps?.values ? {
		...transDefaultProps.values,
		...values
	} : values;
	const mergedComponents = transDefaultProps?.components ? {
		...transDefaultProps.components,
		...components
	} : components;
	const nodeAsString = nodesToString(children, reactI18nextOptions, i18n, i18nKey);
	const defaultValue = defaults || mergedTOptions?.defaultValue || nodeAsString || reactI18nextOptions.transEmptyNodeValue || (typeof i18nKey === "function" ? keysFromSelector(i18nKey) : i18nKey);
	const { hashTransKey } = reactI18nextOptions;
	const key = i18nKey || (hashTransKey ? hashTransKey(nodeAsString || defaultValue) : nodeAsString || defaultValue);
	if (i18n.options?.interpolation?.defaultVariables) values = mergedValues && Object.keys(mergedValues).length > 0 ? {
		...mergedValues,
		...i18n.options.interpolation.defaultVariables
	} : { ...i18n.options.interpolation.defaultVariables };
	else values = mergedValues;
	const valuesFromChildren = getValuesFromChildren(children);
	if (valuesFromChildren && typeof valuesFromChildren.count === "number" && count === void 0) count = valuesFromChildren.count;
	const interpolationOverride = values || count !== void 0 && !i18n.options?.interpolation?.alwaysFormat || !children ? mergedTOptions.interpolation : { interpolation: {
		...mergedTOptions.interpolation,
		prefix: "#$?",
		suffix: "?$#"
	} };
	const combinedTOpts = {
		...mergedTOptions,
		context: context || mergedTOptions.context,
		count,
		...values,
		...interpolationOverride,
		defaultValue,
		ns: namespaces
	};
	let translation = key ? t(key, combinedTOpts) : defaultValue;
	if (translation === key && defaultValue) translation = defaultValue;
	const generatedComponents = generateComponents(mergedComponents, translation, i18n, i18nKey);
	let indexedChildren = generatedComponents || children;
	let componentsMap = null;
	if (isComponentsMap(generatedComponents)) {
		componentsMap = generatedComponents;
		indexedChildren = children;
	}
	const content = renderNodes(indexedChildren, componentsMap, translation, i18n, reactI18nextOptions, combinedTOpts, mergedShouldUnescape);
	const useAsParent = parent ?? reactI18nextOptions.defaultTransParent;
	return useAsParent ? createElement(useAsParent, additionalProps, content) : content;
}
//#endregion
//#region ../../node_modules/react-i18next/dist/es/context.js
var I18nContext = createContext();
var ReportNamespaces = class {
	constructor() {
		this.usedNamespaces = {};
	}
	addUsedNamespaces(namespaces) {
		namespaces.forEach((ns) => {
			if (!this.usedNamespaces[ns]) this.usedNamespaces[ns] = true;
		});
	}
	getUsedNamespaces() {
		return Object.keys(this.usedNamespaces);
	}
};
//#endregion
//#region ../../node_modules/react-i18next/dist/es/Trans.js
function Trans({ children, count, parent, i18nKey, context, tOptions = {}, values, defaults, components, ns, i18n: i18nFromProps, t: tFromProps, shouldUnescape, ...additionalProps }) {
	const { i18n: i18nFromContext, defaultNS: defaultNSFromContext } = useContext(I18nContext) || {};
	const i18n = i18nFromProps || i18nFromContext || getI18n();
	const t = tFromProps || i18n?.t.bind(i18n);
	return Trans$1({
		children,
		count,
		parent,
		i18nKey,
		context,
		tOptions,
		values,
		defaults,
		components,
		ns: ns || t?.ns || defaultNSFromContext || i18n?.options?.defaultNS,
		i18n,
		t: tFromProps,
		shouldUnescape,
		...additionalProps
	});
}
//#endregion
//#region ../../node_modules/react-i18next/dist/es/useTranslation.js
var import_shim = require_shim();
var notReadyT = (k, optsOrDefaultValue) => {
	if (isString(optsOrDefaultValue)) return optsOrDefaultValue;
	if (isObject(optsOrDefaultValue) && isString(optsOrDefaultValue.defaultValue)) return optsOrDefaultValue.defaultValue;
	if (typeof k === "function") return "";
	if (Array.isArray(k)) {
		const last = k[k.length - 1];
		return typeof last === "function" ? "" : last;
	}
	return k;
};
var notReadySnapshot = {
	t: notReadyT,
	ready: false
};
var dummySubscribe = () => () => {};
var useTranslation = (ns, props = {}) => {
	const { i18n: i18nFromProps } = props;
	const { i18n: i18nFromContext, defaultNS: defaultNSFromContext } = useContext(I18nContext) || {};
	const i18n = i18nFromProps || i18nFromContext || getI18n();
	if (i18n && !i18n.reportNamespaces) i18n.reportNamespaces = new ReportNamespaces();
	if (!i18n) warnOnce(i18n, "NO_I18NEXT_INSTANCE", "useTranslation: You will need to pass in an i18next instance by using initReactI18next");
	const i18nOptions = useMemo(() => ({
		...getDefaults(),
		...i18n?.options?.react,
		...props
	}), [i18n, props]);
	const { useSuspense, keyPrefix } = i18nOptions;
	const nsOrContext = ns || defaultNSFromContext || i18n?.options?.defaultNS;
	const unstableNamespaces = isString(nsOrContext) ? [nsOrContext] : nsOrContext || ["translation"];
	const namespaces = useMemo(() => unstableNamespaces, unstableNamespaces);
	i18n?.reportNamespaces?.addUsedNamespaces?.(namespaces);
	const revisionRef = useRef(0);
	const subscribe = useCallback((callback) => {
		if (!i18n) return dummySubscribe;
		const { bindI18n, bindI18nStore } = i18nOptions;
		const wrappedCallback = () => {
			revisionRef.current += 1;
			callback();
		};
		if (bindI18n) i18n.on(bindI18n, wrappedCallback);
		if (bindI18nStore) i18n.store.on(bindI18nStore, wrappedCallback);
		return () => {
			if (bindI18n) bindI18n.split(" ").forEach((e) => i18n.off(e, wrappedCallback));
			if (bindI18nStore) bindI18nStore.split(" ").forEach((e) => i18n.store.off(e, wrappedCallback));
		};
	}, [i18n, i18nOptions]);
	const snapshotRef = useRef();
	const getSnapshot = useCallback(() => {
		if (!i18n) return notReadySnapshot;
		const calculatedReady = !!(i18n.isInitialized || i18n.initializedStoreOnce) && namespaces.every((n) => hasLoadedNamespace(n, i18n, i18nOptions));
		const currentLng = props.lng || i18n.language;
		const currentRevision = revisionRef.current;
		const lastSnapshot = snapshotRef.current;
		if (lastSnapshot && lastSnapshot.ready === calculatedReady && lastSnapshot.lng === currentLng && lastSnapshot.keyPrefix === keyPrefix && lastSnapshot.revision === currentRevision) return lastSnapshot;
		const newSnapshot = {
			t: i18n.getFixedT(currentLng, i18nOptions.nsMode === "fallback" ? namespaces : namespaces[0], keyPrefix),
			ready: calculatedReady,
			lng: currentLng,
			keyPrefix,
			revision: currentRevision
		};
		snapshotRef.current = newSnapshot;
		return newSnapshot;
	}, [
		i18n,
		namespaces,
		keyPrefix,
		i18nOptions,
		props.lng
	]);
	const [loadCount, setLoadCount] = useState(0);
	const { t, ready } = (0, import_shim.useSyncExternalStore)(subscribe, getSnapshot, getSnapshot);
	useEffect(() => {
		if (i18n && !ready && !useSuspense) {
			const onLoaded = () => setLoadCount((c) => c + 1);
			if (props.lng) loadLanguages(i18n, props.lng, namespaces, onLoaded);
			else loadNamespaces(i18n, namespaces, onLoaded);
		}
	}, [
		i18n,
		props.lng,
		namespaces,
		ready,
		useSuspense,
		loadCount
	]);
	const finalI18n = i18n || {};
	const wrapperRef = useRef(null);
	const wrapperLangRef = useRef();
	const createI18nWrapper = (original) => {
		const descriptors = Object.getOwnPropertyDescriptors(original);
		if (descriptors.__original) delete descriptors.__original;
		const wrapper = Object.create(Object.getPrototypeOf(original), descriptors);
		if (!Object.prototype.hasOwnProperty.call(wrapper, "__original")) try {
			Object.defineProperty(wrapper, "__original", {
				value: original,
				writable: false,
				enumerable: false,
				configurable: false
			});
		} catch (_) {}
		return wrapper;
	};
	const ret = useMemo(() => {
		const original = finalI18n;
		const lang = original?.language;
		let i18nWrapper = original;
		if (original) if (wrapperRef.current && wrapperRef.current.__original === original) if (wrapperLangRef.current !== lang) {
			i18nWrapper = createI18nWrapper(original);
			wrapperRef.current = i18nWrapper;
			wrapperLangRef.current = lang;
		} else i18nWrapper = wrapperRef.current;
		else {
			i18nWrapper = createI18nWrapper(original);
			wrapperRef.current = i18nWrapper;
			wrapperLangRef.current = lang;
		}
		const effectiveT = !ready && !useSuspense ? (...args) => {
			warnOnce(i18n, "USE_T_BEFORE_READY", "useTranslation: t was called before ready. When using useSuspense: false, make sure to check the ready flag before using t.");
			return t(...args);
		} : t;
		const arr = [
			effectiveT,
			i18nWrapper,
			ready
		];
		arr.t = effectiveT;
		arr.i18n = i18nWrapper;
		arr.ready = ready;
		return arr;
	}, [
		t,
		finalI18n,
		ready,
		finalI18n.resolvedLanguage,
		finalI18n.language,
		finalI18n.languages
	]);
	if (i18n && useSuspense && !ready) throw new Promise((resolve) => {
		const onLoaded = () => resolve();
		if (props.lng) loadLanguages(i18n, props.lng, namespaces, onLoaded);
		else loadNamespaces(i18n, namespaces, onLoaded);
	});
	return ret;
};
//#endregion
//#region ../../resources/scripts/components/elements/Translate.tsx
function Translate({ ns, children, ...props }) {
	const { t } = useTranslation(ns);
	return /* @__PURE__ */ jsx(Trans, {
		t,
		...props,
		children
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/PageHeading.tsx
function CorePageHeading({ title, description, actions, className }) {
	const ui = useSkin("PageHeading", {});
	return /* @__PURE__ */ jsxs("header", {
		...ui("root", className),
		children: [/* @__PURE__ */ jsxs("div", {
			...ui("text"),
			children: [/* @__PURE__ */ jsx("h1", {
				...ui("title"),
				children: title
			}), description && /* @__PURE__ */ jsx("p", {
				...ui("description"),
				children: description
			})]
		}), actions && /* @__PURE__ */ jsx("div", {
			...ui("actions"),
			children: actions
		})]
	});
}
var PageHeading = replaceable("PageHeading", CorePageHeading);
//#endregion
//#region ../../resources/scripts/components/elements/NewButton.tsx
/** The panel's "create" action: a Plus icon and a sentence-case label such as "New node". */
function NewButton({ icon = Plus, className, children, ...props }) {
	const ui = useSkin("NewButton", { link: false });
	return /* @__PURE__ */ jsx(ButtonWithVariants, {
		className: ui.classes("root", className),
		...props,
		children: /* @__PURE__ */ jsxs("span", {
			...ui("content"),
			children: [/* @__PURE__ */ jsx(Icon, {
				icon,
				"aria-hidden": true,
				...ui("icon")
			}), children]
		})
	});
}
/** `NewButton` for actions that navigate to a create page. */
function NewLinkButton({ icon = Plus, className, children, ...props }) {
	const ui = useSkin("NewButton", { link: true });
	return /* @__PURE__ */ jsxs(RouterLinkButton, {
		className: ui.classes("root", className),
		...props,
		children: [/* @__PURE__ */ jsx(Icon, {
			icon,
			"aria-hidden": true,
			...ui("icon")
		}), children]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/InputSpinner.tsx
var InputSpinner = ({ visible, children }) => /* @__PURE__ */ jsxs("div", {
	className: cn$1("relative", visible && "[&_select]:bg-none"),
	children: [visible && /* @__PURE__ */ jsx("div", {
		className: "absolute right-0 h-full flex items-center justify-end pr-3",
		children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
	}), children]
});
//#endregion
//#region ../../resources/scripts/components/elements/dropdown/DropdownMenu.tsx
var MenuItemContext = React.createContext(Menu$1.Item);
var ContextMenuItem = (props) => /* @__PURE__ */ jsx(ContextMenu.Item, { ...props });
function DropdownMenu({ triggerContent, triggerClassName, openOnHover, children, className }) {
	const ui = useSkin("DropdownMenu", { context: false });
	return /* @__PURE__ */ jsxs(Menu$1.Root, { children: [/* @__PURE__ */ jsx(Menu$1.Trigger, {
		...ui("trigger", triggerClassName),
		openOnHover,
		closeDelay: openOnHover ? 150 : 0,
		children: triggerContent
	}), /* @__PURE__ */ jsx(Menu$1.Portal, { children: /* @__PURE__ */ jsx(Menu$1.Positioner, {
		...ui("positioner"),
		sideOffset: 4,
		align: "end",
		children: /* @__PURE__ */ jsx(Menu$1.Popup, {
			...ui("root", className),
			children: /* @__PURE__ */ jsx(MenuItemContext.Provider, {
				value: Menu$1.Item,
				children
			})
		})
	}) })] });
}
/** Opens `items` at the cursor on right-click or long-press over `children`. */
function ContextDropdownMenu({ className, menuClassName, children, items }) {
	const ui = useSkin("DropdownMenu", { context: true });
	return /* @__PURE__ */ jsxs(ContextMenu.Root, { children: [/* @__PURE__ */ jsx(ContextMenu.Trigger, {
		...ui("trigger", className),
		children
	}), /* @__PURE__ */ jsx(ContextMenu.Portal, { children: /* @__PURE__ */ jsx(ContextMenu.Positioner, {
		...ui("positioner"),
		children: /* @__PURE__ */ jsx(ContextMenu.Popup, {
			...ui("root", menuClassName),
			children: /* @__PURE__ */ jsx(MenuItemContext.Provider, {
				value: ContextMenuItem,
				children: items
			})
		})
	}) })] });
}
/** An item for either DropdownMenu or ContextDropdownMenu. */
function DropdownMenuItem({ icon, danger, description, destination, checked, className, children, ...props }) {
	const Item = use(MenuItemContext);
	const ui = useSkin("DropdownMenuItem", {
		danger: !!danger,
		described: !!description,
		checked: !!checked
	});
	const content = /* @__PURE__ */ jsxs(Fragment$1, { children: [icon && /* @__PURE__ */ jsx("span", {
		...ui("icon"),
		children: /* @__PURE__ */ jsx(Icon, {
			icon,
			...ui("glyph")
		})
	}), /* @__PURE__ */ jsxs("span", {
		...ui("text"),
		children: [/* @__PURE__ */ jsx("span", {
			...ui("label"),
			children
		}), description && /* @__PURE__ */ jsx("span", {
			...ui("description"),
			children: description
		})]
	})] });
	if (destination) return /* @__PURE__ */ jsx(Menu$1.LinkItem, {
		...ui("root", className),
		id: props.id,
		label: props.label,
		closeOnClick: true,
		render: /* @__PURE__ */ jsx(PanelLink, { destination }),
		children: content
	});
	if (checked !== void 0) return /* @__PURE__ */ jsx(Menu$1.CheckboxItem, {
		closeOnClick: true,
		...ui("root", className),
		...props,
		checked,
		children: content
	});
	return /* @__PURE__ */ jsx(Item, {
		...ui("root", className),
		...props,
		children: content
	});
}
var DropdownMenuWithItems = DropdownMenu;
DropdownMenuWithItems.Item = DropdownMenuItem;
//#endregion
//#region ../../resources/scripts/extensions/NavigationLabel.tsx
/** A navigation item's icon, label and badge. */
function NavigationLabel({ label, group, icon, badge }) {
	return /* @__PURE__ */ jsxs("span", {
		className: "inline-flex items-center gap-2 align-top",
		title: group ?? void 0,
		children: [
			icon && /* @__PURE__ */ jsx(NamedIcon, {
				name: icon,
				size: 16,
				className: "shrink-0",
				"aria-hidden": true
			}),
			/* @__PURE__ */ jsx("span", { children: label }),
			badge
		]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/SubNavigation.tsx
var subNavigationClass = [
	"w-full bg-card shadow-sm overflow-x-auto scrollbar-none [&::-webkit-scrollbar]:hidden",
	"[&>div]:mx-auto [&>div]:flex [&>div]:max-w-panel [&>div]:items-center [&>div]:px-2 [&>div]:text-sm",
	"[&>div>a]:inline-block [&>div>a]:py-3 [&>div>a]:px-4 [&>div>a]:text-muted-foreground [&>div>a]:no-underline [&>div>a]:whitespace-nowrap [&>div>a]:transition-colors [&>div>a]:duration-150",
	"[&>div>div]:inline-block [&>div>div]:py-3 [&>div>div]:px-4 [&>div>div]:text-muted-foreground [&>div>div]:no-underline [&>div>div]:whitespace-nowrap [&>div>div]:transition-colors [&>div>div]:duration-150",
	"[&>div>a:not(:first-of-type)]:ml-2 [&>div>div:not(:first-of-type)]:ml-2",
	"[&>div>a:hover]:text-foreground [&>div>div:hover]:text-foreground",
	"[&>div>a:active]:text-foreground [&>div>a.active]:text-foreground [&>div>a[data-status=active]]:text-foreground",
	"[&>div>div:active]:text-foreground [&>div>div.active]:text-foreground [&>div>div[data-status=active]]:text-foreground",
	"[&>div>a:active]:shadow-navigation-active [&>div>a.active]:shadow-navigation-active [&>div>a[data-status=active]]:shadow-navigation-active",
	"[&>div>div:active]:shadow-navigation-active [&>div>div.active]:shadow-navigation-active [&>div>div[data-status=active]]:shadow-navigation-active",
	"[&>div>[data-overflowed]]:hidden"
].join(" ");
var sideNavigationClass = [
	"side-navigation:sticky side-navigation:top-0 side-navigation:max-h-dvh side-navigation:w-sidebar side-navigation:shrink-0",
	"side-navigation:overflow-x-visible side-navigation:overflow-y-auto side-navigation:bg-transparent side-navigation:px-4 side-navigation:py-6 side-navigation:shadow-none",
	"side-navigation:[&>div]:flex-col side-navigation:[&>div]:items-stretch side-navigation:[&>div]:gap-0.5 side-navigation:[&>div]:px-0",
	"side-navigation:[&>div>a]:block side-navigation:[&>div>a]:rounded-md side-navigation:[&>div>a]:px-3 side-navigation:[&>div>a]:py-2",
	"side-navigation:[&>div>div]:block side-navigation:[&>div>div]:rounded-md side-navigation:[&>div>div]:px-3 side-navigation:[&>div>div]:py-2",
	"side-navigation:[&>div>a:not(:first-of-type)]:ml-0 side-navigation:[&>div>div:not(:first-of-type)]:ml-0",
	"side-navigation:[&>div>a:hover]:bg-card side-navigation:[&>div>div:hover]:bg-card",
	"side-navigation:[&>div>a:active]:bg-popover side-navigation:[&>div>a.active]:bg-popover side-navigation:[&>div>a[data-status=active]]:bg-popover",
	"side-navigation:[&>div>div:active]:bg-popover side-navigation:[&>div>div.active]:bg-popover side-navigation:[&>div>div[data-status=active]]:bg-popover",
	"side-navigation:[&>div>a:hover]:shadow-none side-navigation:[&>div>a:active]:shadow-none side-navigation:[&>div>a.active]:shadow-none side-navigation:[&>div>a[data-status=active]]:shadow-none",
	"side-navigation:[&>div>div:hover]:shadow-none side-navigation:[&>div>div:active]:shadow-none side-navigation:[&>div>div.active]:shadow-none side-navigation:[&>div>div[data-status=active]]:shadow-none"
].join(" ");
var collapsedNavigationClass = [
	"[&[data-collapsed]>button]:flex [&[data-collapsed]:not([data-open])>div]:hidden",
	"[&[data-collapsed]>div]:flex-col [&[data-collapsed]>div]:items-stretch [&[data-collapsed]>div]:gap-0.5 [&[data-collapsed]>div]:pb-2",
	"[&[data-collapsed]>div>a]:block! [&[data-collapsed]>div>a]:ml-0! [&[data-collapsed]>div>a]:rounded-md [&[data-collapsed]>div>a]:px-4 [&[data-collapsed]>div>a]:py-2 [&[data-collapsed]>div>a]:shadow-none!",
	"[&[data-collapsed]>div>div]:block! [&[data-collapsed]>div>div]:ml-0! [&[data-collapsed]>div>div]:rounded-md [&[data-collapsed]>div>div]:px-4 [&[data-collapsed]>div>div]:py-2 [&[data-collapsed]>div>div]:shadow-none!",
	"[&[data-collapsed]>div>a:hover]:bg-popover/60 [&[data-collapsed]>div>div:hover]:bg-popover/60",
	"[&[data-collapsed]>div>a[data-status=active]]:bg-popover [&[data-collapsed]>div>div[data-status=active]]:bg-popover"
].join(" ");
var itemKeyOf = (element) => element.dataset.navItem;
var defaultOverflow = (item) => item.extensionId !== void 0;
var defaultRender = (item, state) => /* @__PURE__ */ jsx(NavigationLabel, {
	label: item.label,
	group: item.group,
	icon: item.icon,
	badge: state.badge
});
/** Each child's width including the gap before it, so the widths add up to the row's used space. */
var measureWidths = (row, children, style) => {
	const rect = row.getBoundingClientRect();
	const available = rect.width - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
	let edge = rect.left + parseFloat(style.paddingLeft);
	return {
		available,
		widths: children.map((child) => {
			const right = child.getBoundingClientRect().right;
			const width = Math.max(0, right - edge);
			edge = Math.max(edge, right);
			return width;
		})
	};
};
/**
* Pinned children (core items and slot content) always stay; the active item claims the budget
* next, then the rest in order until it runs out.
*/
var fitWithinBudget = (children, widths, budget, policy) => {
	const isMovable = (child) => policy.movable.has(itemKeyOf(child) ?? "");
	const visible = new Set(children.filter((child) => !isMovable(child)));
	let used = children.reduce((sum, child, index) => sum + (visible.has(child) ? widths[index] : 0), 0);
	if (used > budget) return {
		collapsed: true,
		overflowed: []
	};
	const active = children.findIndex((child) => !visible.has(child) && itemKeyOf(child) === policy.active);
	if (active !== -1 && used + widths[active] <= budget) {
		visible.add(children[active]);
		used += widths[active];
	}
	for (const [index, child] of children.entries()) {
		if (visible.has(child)) continue;
		if (used + widths[index] > budget) break;
		visible.add(child);
		used += widths[index];
	}
	return {
		collapsed: false,
		overflowed: children.filter((child) => !visible.has(child))
	};
};
/** Shows the "more" toggle while measuring its width when the row overflows. */
var overflowLayout = (row, children, more, policy) => {
	const style = getComputedStyle(row);
	if (style.flexDirection === "column") return {
		collapsed: false,
		overflowed: []
	};
	const { available, widths } = measureWidths(row, children, style);
	if (widths.reduce((sum, width) => sum + width, 0) <= available) return {
		collapsed: false,
		overflowed: []
	};
	more.hidden = false;
	return fitWithinBudget(children, widths, available - more.getBoundingClientRect().width - parseFloat(getComputedStyle(more).marginLeft), policy);
};
var sameState = (previous, next) => previous.collapsed === next.collapsed && previous.overflowed.join("\n") === next.overflowed.join("\n");
/**
* Measures the rendered row and marks what does not fit with `data-overflowed` (or the whole
* navigation with `data-collapsed`). Gated items render nothing, so the row is what counts; the
* menu is then built from the model.
*/
function useOverflowNavigation(rootRef, rowRef, moreRef, policy) {
	const [state, setState] = useState({
		overflowed: [],
		collapsed: false
	});
	const policyRef = useRef(policy);
	const updateRef = useRef(void 0);
	policyRef.current = policy;
	useLayoutEffect(() => {
		const root = rootRef.current;
		const row = rowRef.current;
		const more = moreRef.current;
		if (!root || !row || !more) return;
		let mounted = true;
		const update = () => {
			const children = [...row.children].filter((child) => child !== more && child instanceof HTMLElement);
			for (const child of children) delete child.dataset.overflowed;
			delete root.dataset.collapsed;
			more.hidden = true;
			const { collapsed, overflowed } = overflowLayout(row, children, more, policyRef.current);
			if (collapsed) root.dataset.collapsed = "";
			for (const child of overflowed) child.dataset.overflowed = "";
			more.hidden = overflowed.length === 0;
			const next = {
				collapsed,
				overflowed: overflowed.flatMap((child) => itemKeyOf(child) ?? [])
			};
			setState((previous) => sameState(previous, next) ? previous : next);
		};
		updateRef.current = update;
		update();
		const mutationObserver = new MutationObserver(update);
		mutationObserver.observe(row, {
			childList: true,
			subtree: true,
			characterData: true,
			attributeFilter: [
				"class",
				"data-status",
				"aria-current"
			]
		});
		const resizeObserver = new ResizeObserver(update);
		resizeObserver.observe(root);
		document.fonts?.ready.then(() => mounted && update());
		return () => {
			mounted = false;
			updateRef.current = void 0;
			mutationObserver.disconnect();
			resizeObserver.disconnect();
		};
	}, [
		rootRef,
		rowRef,
		moreRef
	]);
	useLayoutEffect(() => updateRef.current?.(), [[...policy.movable].join("\n"), policy.active]);
	return state;
}
function MenuEntry({ item, render }) {
	const navigate = usePanelNavigate();
	const active = useNavItemActive()(item);
	return /* @__PURE__ */ jsx(DropdownMenuWithItems.Item, {
		className: cn$1(active && "bg-muted"),
		onClick: () => void navigate(item.destination),
		children: /* @__PURE__ */ jsx("span", {
			className: "inline-flex items-center gap-2",
			children: render(item, {
				active,
				badge: navItemBadge(item),
				placement: "menu"
			})
		})
	});
}
/**
* An area's horizontal navigation. Items that do not fit move into a "More" menu, and when even
* the pinned ones do not, the row collapses behind a toggle. `<html data-sub-navigation="side">`
* turns it into a sidebar.
*/
var SubNavigation = ({ items, before, after, canOverflow = defaultOverflow, renderItem = defaultRender, className, ...props }) => {
	const rootRef = useRef(null);
	const rowRef = useRef(null);
	const moreRef = useRef(null);
	const rowId = useId();
	const [open, setOpen] = useState(false);
	const isActive = useNavItemActive();
	const current = useActiveNavItem(items);
	const { overflowed, collapsed } = useOverflowNavigation(rootRef, rowRef, moreRef, {
		movable: new Set(items.filter(canOverflow).map(navItemKey)),
		active: current && navItemKey(current)
	});
	const expanded = collapsed && open;
	const menu = items.filter((item) => overflowed.includes(navItemKey(item)));
	return /* @__PURE__ */ jsxs("div", {
		ref: rootRef,
		className: cn$1(subNavigationClass, sideNavigationClass, collapsedNavigationClass, className),
		"data-open": expanded ? "" : void 0,
		...props,
		children: [/* @__PURE__ */ jsxs("button", {
			type: "button",
			onClick: () => setOpen((value) => !value),
			"aria-expanded": expanded,
			"aria-controls": rowId,
			className: "mx-auto hidden w-full max-w-panel cursor-pointer items-center gap-3 px-6 py-3 text-sm text-foreground",
			children: [
				/* @__PURE__ */ jsx(Icon, {
					icon: Menu,
					className: "h-4 w-4 shrink-0",
					"aria-hidden": true
				}),
				/* @__PURE__ */ jsx("span", {
					className: "min-w-0 flex-1 truncate text-left",
					children: current?.label || "Navigation"
				}),
				/* @__PURE__ */ jsx(Icon, {
					icon: ChevronDown,
					className: cn$1("h-4 w-4 shrink-0 transition-transform", expanded && "rotate-180"),
					"aria-hidden": true
				})
			]
		}), /* @__PURE__ */ jsxs("div", {
			ref: rowRef,
			id: rowId,
			onClick: () => setOpen(false),
			children: [
				before,
				/* @__PURE__ */ jsx(Navigation, {
					items,
					children: (item, state) => /* @__PURE__ */ jsx(NavigationLink, {
						item,
						"data-nav-item": navItemKey(item),
						children: renderItem(item, {
							...state,
							placement: "row"
						})
					})
				}),
				after,
				/* @__PURE__ */ jsx("span", {
					ref: moreRef,
					className: "ml-2 shrink-0",
					children: /* @__PURE__ */ jsx(DropdownMenuWithItems, {
						openOnHover: true,
						triggerClassName: cn$1("inline-flex cursor-pointer items-center gap-1 whitespace-nowrap px-4 py-3 text-muted-foreground transition-colors duration-150 hover:text-foreground", menu.some(isActive) && "text-foreground shadow-navigation-active"),
						triggerContent: /* @__PURE__ */ jsxs(Fragment$1, { children: ["More", /* @__PURE__ */ jsx(Icon, {
							icon: ChevronDown,
							"aria-hidden": true
						})] }),
						children: menu.map((item) => /* @__PURE__ */ jsx(MenuEntry, {
							item,
							render: renderItem
						}, navItemKey(item)))
					})
				})
			]
		})]
	});
};
SubNavigation.displayName = "SubNavigation";
//#endregion
//#region ../../resources/scripts/components/elements/SubNavigationLayout.tsx
/** Stacked by default; a sidebar row when `<html data-sub-navigation="side">` is set. */
var SubNavigationLayout = ({ navigation, className, children }) => /* @__PURE__ */ jsxs("div", {
	className: cn$1("side-navigation:mx-auto side-navigation:flex side-navigation:w-full side-navigation:max-w-panel side-navigation:items-start", className),
	children: [navigation, /* @__PURE__ */ jsx("div", {
		className: "side-navigation:min-w-0 side-navigation:flex-1",
		children
	})]
});
//#endregion
//#region ../../resources/scripts/components/elements/alert/Alert.tsx
var icons$1 = {
	success: CheckCircle2,
	info: Info,
	warning: TriangleAlert,
	danger: ShieldAlert
};
function CoreAlert({ type, title, className, children }) {
	const ui = useSkin("Alert", { type });
	const AlertIcon = icons$1[type];
	return /* @__PURE__ */ jsxs("div", {
		role: "alert",
		...ui("root", className),
		children: [/* @__PURE__ */ jsx(AlertIcon, {
			"aria-hidden": true,
			...ui("icon")
		}), /* @__PURE__ */ jsxs("div", {
			...ui("body"),
			children: [title && /* @__PURE__ */ jsx("p", {
				...ui("title"),
				children: title
			}), /* @__PURE__ */ jsx("div", {
				...ui("content"),
				children
			})]
		})]
	});
}
var Alert = replaceable("Alert", CoreAlert);
//#endregion
//#region ../../resources/scripts/components/elements/Pagination.tsx
var PageButton$1 = ({ ui, current, ...props }) => /* @__PURE__ */ jsx(ButtonWithVariants, {
	type: "button",
	className: ui.classes("page", void 0, { current }),
	isSecondary: !current,
	color: "primary",
	...props
});
var normalizeGeneratedPagination = (pagination) => ({
	total: pagination.total,
	count: pagination.count,
	perPage: pagination.per_page,
	currentPage: pagination.current_page,
	totalPages: pagination.total_pages
});
function Pagination({ data, onPageSelect, children }) {
	const ui = useSkin("Pagination", {});
	const items = data.data;
	const pagination = normalizeGeneratedPagination(data.meta.pagination);
	const isFirstPage = pagination.currentPage === 1;
	const isLastPage = pagination.currentPage >= pagination.totalPages;
	const pages = [];
	const start = Math.max(pagination.currentPage - 2, 1);
	const end = Math.min(pagination.totalPages, pagination.currentPage + 5);
	for (let i = start; i <= end; i++) pages.push(i);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [children({
		items,
		isFirstPage,
		isLastPage
	}), pages.length > 1 && /* @__PURE__ */ jsxs("div", {
		...ui("root"),
		children: [
			pages[0] > 1 && !isFirstPage && /* @__PURE__ */ jsx(PageButton$1, {
				ui,
				current: false,
				onClick: () => onPageSelect(1),
				children: /* @__PURE__ */ jsx(Icon, { icon: ChevronsLeft })
			}),
			pages.map((page) => /* @__PURE__ */ jsx(PageButton$1, {
				ui,
				current: pagination.currentPage === page,
				onClick: () => onPageSelect(page),
				children: page
			}, `block_page_${page}`)),
			pages[4] < pagination.totalPages && !isLastPage && /* @__PURE__ */ jsx(PageButton$1, {
				ui,
				current: false,
				onClick: () => onPageSelect(pagination.totalPages),
				children: /* @__PURE__ */ jsx(Icon, { icon: ChevronsRight })
			})
		]
	})] });
}
//#endregion
//#region ../../resources/scripts/components/ui/empty.tsx
var EmptySizeContext = React$1.createContext("default");
var usePartSkin = () => useSkin("Empty", { size: React$1.use(EmptySizeContext) });
function CoreEmpty({ className, size = "default", ...props }) {
	const ui = useSkin("Empty", { size });
	return /* @__PURE__ */ jsx(EmptySizeContext.Provider, {
		value: size,
		children: /* @__PURE__ */ jsx("div", {
			...ui("root", className),
			...props
		})
	});
}
var Empty = replaceable("Empty", CoreEmpty);
function EmptyHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		...usePartSkin()("header", className),
		...props
	});
}
/** `icon` frames a single icon in a tile; `default` leaves the media unframed. */
function EmptyMedia({ className, variant = "default", ...props }) {
	return /* @__PURE__ */ jsx("div", {
		...usePartSkin()("media", className, { variant }),
		...props
	});
}
function EmptyTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		...usePartSkin()("title", className),
		...props
	});
}
function EmptyDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		...usePartSkin()("description", className),
		...props
	});
}
function EmptyContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		...usePartSkin()("content", className),
		...props
	});
}
//#endregion
//#region ../../resources/scripts/components/Avatar.tsx
var import_build = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		if ("object" === typeof exports && "object" === typeof module) module.exports = t(require_builtin_esm_external_require_react());
		else if ("function" === typeof define && define.amd) define(["react"], t);
		else {
			var r = "object" === typeof exports ? t(require_builtin_esm_external_require_react()) : t(e.react);
			for (var l in r) ("object" === typeof exports ? exports : e)[l] = r[l];
		}
	})(exports, (function(e) {
		return function(e) {
			var t = {};
			function r(l) {
				if (t[l]) return t[l].exports;
				var i = t[l] = {
					i: l,
					l: !1,
					exports: {}
				};
				return e[l].call(i.exports, i, i.exports, r), i.l = !0, i.exports;
			}
			return r.m = e, r.c = t, r.d = function(e, t, l) {
				r.o(e, t) || Object.defineProperty(e, t, {
					enumerable: !0,
					get: l
				});
			}, r.r = function(e) {
				"undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
			}, r.t = function(e, t) {
				if (1 & t && (e = r(e)), 8 & t) return e;
				if (4 & t && "object" === typeof e && e && e.__esModule) return e;
				var l = Object.create(null);
				if (r.r(l), Object.defineProperty(l, "default", {
					enumerable: !0,
					value: e
				}), 2 & t && "string" != typeof e) for (var i in e) r.d(l, i, function(t) {
					return e[t];
				}.bind(null, i));
				return l;
			}, r.n = function(e) {
				var t = e && e.__esModule ? function() {
					return e.default;
				} : function() {
					return e;
				};
				return r.d(t, "a", t), t;
			}, r.o = function(e, t) {
				return Object.prototype.hasOwnProperty.call(e, t);
			}, r.p = "/", r(r.s = 1);
		}([
			function(t, r) {
				t.exports = e;
			},
			function(e, t, r) {
				e.exports = r(2);
			},
			function(e, t, r) {
				"use strict";
				function l(e, t) {
					if (null == e) return {};
					var r, l, i = function(e, t) {
						if (null == e) return {};
						var r, l, i = {}, a = Object.keys(e);
						for (l = 0; l < a.length; l++) r = a[l], t.indexOf(r) >= 0 || (i[r] = e[r]);
						return i;
					}(e, t);
					if (Object.getOwnPropertySymbols) {
						var a = Object.getOwnPropertySymbols(e);
						for (l = 0; l < a.length; l++) r = a[l], t.indexOf(r) >= 0 || Object.prototype.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
					}
					return i;
				}
				r.r(t);
				var i = r(0), a = r.n(i), n = function(e) {
					for (var t = 0, r = 0; r < e.length; r++) t = (t << 5) - t + e.charCodeAt(r), t &= t;
					return Math.abs(t);
				}, c = function(e, t) {
					return Math.floor(e / Math.pow(10, t) % 10);
				}, h = function(e, t) {
					return !(c(e, t) % 2);
				}, o = function(e, t, r) {
					var l = e % t;
					return r && c(e, r) % 2 === 0 ? -l : l;
				}, s = function(e, t, r) {
					return t[e % r];
				};
				var f = function(e) {
					var t = e.name, r = e.colors, a = e.title, c = e.square, h = e.size, f = l(e, [
						"name",
						"colors",
						"title",
						"square",
						"size"
					]), m = function(e, t) {
						var r = n(e), l = t && t.length;
						return Array.from({ length: 3 }, (function(e, i) {
							return {
								color: s(r + i, t, l),
								translateX: o(r * (i + 1), 8, 1),
								translateY: o(r * (i + 1), 8, 2),
								scale: 1.2 + o(r * (i + 1), 4) / 10,
								rotate: o(r * (i + 1), 360, 1)
							};
						}));
					}(t, r), d = i.useId();
					return i.createElement("svg", Object.assign({
						viewBox: "0 0 80 80",
						fill: "none",
						role: "img",
						xmlns: "http://www.w3.org/2000/svg",
						width: h,
						height: h
					}, f), a && i.createElement("title", null, t), i.createElement("mask", {
						id: d,
						maskUnits: "userSpaceOnUse",
						x: 0,
						y: 0,
						width: 80,
						height: 80
					}, i.createElement("rect", {
						width: 80,
						height: 80,
						rx: c ? void 0 : 160,
						fill: "#FFFFFF"
					})), i.createElement("g", { mask: "url(#".concat(d, ")") }, i.createElement("rect", {
						width: 80,
						height: 80,
						fill: m[0].color
					}), i.createElement("path", {
						filter: "url(#filter_".concat(d, ")"),
						d: "M32.414 59.35L50.376 70.5H72.5v-71H33.728L26.5 13.381l19.057 27.08L32.414 59.35z",
						fill: m[1].color,
						transform: "translate(" + m[1].translateX + " " + m[1].translateY + ") rotate(" + m[1].rotate + " 40 40) scale(" + m[2].scale + ")"
					}), i.createElement("path", {
						filter: "url(#filter_".concat(d, ")"),
						style: { mixBlendMode: "overlay" },
						d: "M22.216 24L0 46.75l14.108 38.129L78 86l-3.081-59.276-22.378 4.005 12.972 20.186-23.35 27.395L22.215 24z",
						fill: m[2].color,
						transform: "translate(" + m[2].translateX + " " + m[2].translateY + ") rotate(" + m[2].rotate + " 40 40) scale(" + m[2].scale + ")"
					})), i.createElement("defs", null, i.createElement("filter", {
						id: "filter_".concat(d),
						filterUnits: "userSpaceOnUse",
						colorInterpolationFilters: "sRGB"
					}, i.createElement("feFlood", {
						floodOpacity: 0,
						result: "BackgroundImageFix"
					}), i.createElement("feBlend", {
						in: "SourceGraphic",
						in2: "BackgroundImageFix",
						result: "shape"
					}), i.createElement("feGaussianBlur", {
						stdDeviation: 7,
						result: "effect1_foregroundBlur"
					}))));
				}, m = {
					pixel: function(e) {
						var t = e.name, r = e.colors, a = e.title, c = e.square, h = e.size, o = l(e, [
							"name",
							"colors",
							"title",
							"square",
							"size"
						]), f = function(e, t) {
							var r = n(e), l = t && t.length;
							return Array.from({ length: 64 }, (function(e, i) {
								return s(r % (i + 1), t, l);
							}));
						}(t, r), m = i.useId();
						return i.createElement("svg", Object.assign({
							viewBox: "0 0 80 80",
							fill: "none",
							role: "img",
							xmlns: "http://www.w3.org/2000/svg",
							width: h,
							height: h
						}, o), a && i.createElement("title", null, t), i.createElement("mask", {
							id: m,
							"mask-type": "alpha",
							maskUnits: "userSpaceOnUse",
							x: 0,
							y: 0,
							width: 80,
							height: 80
						}, i.createElement("rect", {
							width: 80,
							height: 80,
							rx: c ? void 0 : 160,
							fill: "#FFFFFF"
						})), i.createElement("g", { mask: "url(#".concat(m, ")") }, i.createElement("rect", {
							width: 10,
							height: 10,
							fill: f[0]
						}), i.createElement("rect", {
							x: 20,
							width: 10,
							height: 10,
							fill: f[1]
						}), i.createElement("rect", {
							x: 40,
							width: 10,
							height: 10,
							fill: f[2]
						}), i.createElement("rect", {
							x: 60,
							width: 10,
							height: 10,
							fill: f[3]
						}), i.createElement("rect", {
							x: 10,
							width: 10,
							height: 10,
							fill: f[4]
						}), i.createElement("rect", {
							x: 30,
							width: 10,
							height: 10,
							fill: f[5]
						}), i.createElement("rect", {
							x: 50,
							width: 10,
							height: 10,
							fill: f[6]
						}), i.createElement("rect", {
							x: 70,
							width: 10,
							height: 10,
							fill: f[7]
						}), i.createElement("rect", {
							y: 10,
							width: 10,
							height: 10,
							fill: f[8]
						}), i.createElement("rect", {
							y: 20,
							width: 10,
							height: 10,
							fill: f[9]
						}), i.createElement("rect", {
							y: 30,
							width: 10,
							height: 10,
							fill: f[10]
						}), i.createElement("rect", {
							y: 40,
							width: 10,
							height: 10,
							fill: f[11]
						}), i.createElement("rect", {
							y: 50,
							width: 10,
							height: 10,
							fill: f[12]
						}), i.createElement("rect", {
							y: 60,
							width: 10,
							height: 10,
							fill: f[13]
						}), i.createElement("rect", {
							y: 70,
							width: 10,
							height: 10,
							fill: f[14]
						}), i.createElement("rect", {
							x: 20,
							y: 10,
							width: 10,
							height: 10,
							fill: f[15]
						}), i.createElement("rect", {
							x: 20,
							y: 20,
							width: 10,
							height: 10,
							fill: f[16]
						}), i.createElement("rect", {
							x: 20,
							y: 30,
							width: 10,
							height: 10,
							fill: f[17]
						}), i.createElement("rect", {
							x: 20,
							y: 40,
							width: 10,
							height: 10,
							fill: f[18]
						}), i.createElement("rect", {
							x: 20,
							y: 50,
							width: 10,
							height: 10,
							fill: f[19]
						}), i.createElement("rect", {
							x: 20,
							y: 60,
							width: 10,
							height: 10,
							fill: f[20]
						}), i.createElement("rect", {
							x: 20,
							y: 70,
							width: 10,
							height: 10,
							fill: f[21]
						}), i.createElement("rect", {
							x: 40,
							y: 10,
							width: 10,
							height: 10,
							fill: f[22]
						}), i.createElement("rect", {
							x: 40,
							y: 20,
							width: 10,
							height: 10,
							fill: f[23]
						}), i.createElement("rect", {
							x: 40,
							y: 30,
							width: 10,
							height: 10,
							fill: f[24]
						}), i.createElement("rect", {
							x: 40,
							y: 40,
							width: 10,
							height: 10,
							fill: f[25]
						}), i.createElement("rect", {
							x: 40,
							y: 50,
							width: 10,
							height: 10,
							fill: f[26]
						}), i.createElement("rect", {
							x: 40,
							y: 60,
							width: 10,
							height: 10,
							fill: f[27]
						}), i.createElement("rect", {
							x: 40,
							y: 70,
							width: 10,
							height: 10,
							fill: f[28]
						}), i.createElement("rect", {
							x: 60,
							y: 10,
							width: 10,
							height: 10,
							fill: f[29]
						}), i.createElement("rect", {
							x: 60,
							y: 20,
							width: 10,
							height: 10,
							fill: f[30]
						}), i.createElement("rect", {
							x: 60,
							y: 30,
							width: 10,
							height: 10,
							fill: f[31]
						}), i.createElement("rect", {
							x: 60,
							y: 40,
							width: 10,
							height: 10,
							fill: f[32]
						}), i.createElement("rect", {
							x: 60,
							y: 50,
							width: 10,
							height: 10,
							fill: f[33]
						}), i.createElement("rect", {
							x: 60,
							y: 60,
							width: 10,
							height: 10,
							fill: f[34]
						}), i.createElement("rect", {
							x: 60,
							y: 70,
							width: 10,
							height: 10,
							fill: f[35]
						}), i.createElement("rect", {
							x: 10,
							y: 10,
							width: 10,
							height: 10,
							fill: f[36]
						}), i.createElement("rect", {
							x: 10,
							y: 20,
							width: 10,
							height: 10,
							fill: f[37]
						}), i.createElement("rect", {
							x: 10,
							y: 30,
							width: 10,
							height: 10,
							fill: f[38]
						}), i.createElement("rect", {
							x: 10,
							y: 40,
							width: 10,
							height: 10,
							fill: f[39]
						}), i.createElement("rect", {
							x: 10,
							y: 50,
							width: 10,
							height: 10,
							fill: f[40]
						}), i.createElement("rect", {
							x: 10,
							y: 60,
							width: 10,
							height: 10,
							fill: f[41]
						}), i.createElement("rect", {
							x: 10,
							y: 70,
							width: 10,
							height: 10,
							fill: f[42]
						}), i.createElement("rect", {
							x: 30,
							y: 10,
							width: 10,
							height: 10,
							fill: f[43]
						}), i.createElement("rect", {
							x: 30,
							y: 20,
							width: 10,
							height: 10,
							fill: f[44]
						}), i.createElement("rect", {
							x: 30,
							y: 30,
							width: 10,
							height: 10,
							fill: f[45]
						}), i.createElement("rect", {
							x: 30,
							y: 40,
							width: 10,
							height: 10,
							fill: f[46]
						}), i.createElement("rect", {
							x: 30,
							y: 50,
							width: 10,
							height: 10,
							fill: f[47]
						}), i.createElement("rect", {
							x: 30,
							y: 60,
							width: 10,
							height: 10,
							fill: f[48]
						}), i.createElement("rect", {
							x: 30,
							y: 70,
							width: 10,
							height: 10,
							fill: f[49]
						}), i.createElement("rect", {
							x: 50,
							y: 10,
							width: 10,
							height: 10,
							fill: f[50]
						}), i.createElement("rect", {
							x: 50,
							y: 20,
							width: 10,
							height: 10,
							fill: f[51]
						}), i.createElement("rect", {
							x: 50,
							y: 30,
							width: 10,
							height: 10,
							fill: f[52]
						}), i.createElement("rect", {
							x: 50,
							y: 40,
							width: 10,
							height: 10,
							fill: f[53]
						}), i.createElement("rect", {
							x: 50,
							y: 50,
							width: 10,
							height: 10,
							fill: f[54]
						}), i.createElement("rect", {
							x: 50,
							y: 60,
							width: 10,
							height: 10,
							fill: f[55]
						}), i.createElement("rect", {
							x: 50,
							y: 70,
							width: 10,
							height: 10,
							fill: f[56]
						}), i.createElement("rect", {
							x: 70,
							y: 10,
							width: 10,
							height: 10,
							fill: f[57]
						}), i.createElement("rect", {
							x: 70,
							y: 20,
							width: 10,
							height: 10,
							fill: f[58]
						}), i.createElement("rect", {
							x: 70,
							y: 30,
							width: 10,
							height: 10,
							fill: f[59]
						}), i.createElement("rect", {
							x: 70,
							y: 40,
							width: 10,
							height: 10,
							fill: f[60]
						}), i.createElement("rect", {
							x: 70,
							y: 50,
							width: 10,
							height: 10,
							fill: f[61]
						}), i.createElement("rect", {
							x: 70,
							y: 60,
							width: 10,
							height: 10,
							fill: f[62]
						}), i.createElement("rect", {
							x: 70,
							y: 70,
							width: 10,
							height: 10,
							fill: f[63]
						})));
					},
					bauhaus: function(e) {
						var t = e.name, r = e.colors, a = e.title, c = e.square, f = e.size, m = l(e, [
							"name",
							"colors",
							"title",
							"square",
							"size"
						]), d = function(e, t) {
							var r = n(e), l = t && t.length;
							return Array.from({ length: 4 }, (function(e, i) {
								return {
									color: s(r + i, t, l),
									translateX: o(r * (i + 1), 40 - (i + 17), 1),
									translateY: o(r * (i + 1), 40 - (i + 17), 2),
									rotate: o(r * (i + 1), 360),
									isSquare: h(r, 2)
								};
							}));
						}(t, r), u = i.useId();
						return i.createElement("svg", Object.assign({
							viewBox: "0 0 80 80",
							fill: "none",
							role: "img",
							xmlns: "http://www.w3.org/2000/svg",
							width: f,
							height: f
						}, m), a && i.createElement("title", null, t), i.createElement("mask", {
							id: u,
							maskUnits: "userSpaceOnUse",
							x: 0,
							y: 0,
							width: 80,
							height: 80
						}, i.createElement("rect", {
							width: 80,
							height: 80,
							rx: c ? void 0 : 160,
							fill: "#FFFFFF"
						})), i.createElement("g", { mask: "url(#".concat(u, ")") }, i.createElement("rect", {
							width: 80,
							height: 80,
							fill: d[0].color
						}), i.createElement("rect", {
							x: 10,
							y: 30,
							width: 80,
							height: d[1].isSquare ? 80 : 10,
							fill: d[1].color,
							transform: "translate(" + d[1].translateX + " " + d[1].translateY + ") rotate(" + d[1].rotate + " 40 40)"
						}), i.createElement("circle", {
							cx: 40,
							cy: 40,
							fill: d[2].color,
							r: 16,
							transform: "translate(" + d[2].translateX + " " + d[2].translateY + ")"
						}), i.createElement("line", {
							x1: 0,
							y1: 40,
							x2: 80,
							y2: 40,
							strokeWidth: 2,
							stroke: d[3].color,
							transform: "translate(" + d[3].translateX + " " + d[3].translateY + ") rotate(" + d[3].rotate + " 40 40)"
						})));
					},
					ring: function(e) {
						var t = e.name, r = e.colors, i = e.title, c = e.square, h = e.size, o = l(e, [
							"name",
							"colors",
							"title",
							"square",
							"size"
						]), f = function(e, t) {
							var r = n(t), l = e && e.length, i = Array.from({ length: 5 }, (function(t, i) {
								return s(r + i, e, l);
							})), a = [];
							return a[0] = i[0], a[1] = i[1], a[2] = i[1], a[3] = i[2], a[4] = i[2], a[5] = i[3], a[6] = i[3], a[7] = i[0], a[8] = i[4], a;
						}(r, t), m = a.a.useId();
						return a.a.createElement("svg", Object.assign({
							viewBox: "0 0 90 90",
							fill: "none",
							role: "img",
							xmlns: "http://www.w3.org/2000/svg",
							width: h,
							height: h
						}, o), i && a.a.createElement("title", null, t), a.a.createElement("mask", {
							id: m,
							maskUnits: "userSpaceOnUse",
							x: 0,
							y: 0,
							width: 90,
							height: 90
						}, a.a.createElement("rect", {
							width: 90,
							height: 90,
							rx: c ? void 0 : 180,
							fill: "#FFFFFF"
						})), a.a.createElement("g", { mask: "url(#".concat(m, ")") }, a.a.createElement("path", {
							d: "M0 0h90v45H0z",
							fill: f[0]
						}), a.a.createElement("path", {
							d: "M0 45h90v45H0z",
							fill: f[1]
						}), a.a.createElement("path", {
							d: "M83 45a38 38 0 00-76 0h76z",
							fill: f[2]
						}), a.a.createElement("path", {
							d: "M83 45a38 38 0 01-76 0h76z",
							fill: f[3]
						}), a.a.createElement("path", {
							d: "M77 45a32 32 0 10-64 0h64z",
							fill: f[4]
						}), a.a.createElement("path", {
							d: "M77 45a32 32 0 11-64 0h64z",
							fill: f[5]
						}), a.a.createElement("path", {
							d: "M71 45a26 26 0 00-52 0h52z",
							fill: f[6]
						}), a.a.createElement("path", {
							d: "M71 45a26 26 0 01-52 0h52z",
							fill: f[7]
						}), a.a.createElement("circle", {
							cx: 45,
							cy: 45,
							r: 23,
							fill: f[8]
						})));
					},
					beam: function(e) {
						var t = e.name, r = e.colors, a = e.title, c = e.square, f = e.size, m = l(e, [
							"name",
							"colors",
							"title",
							"square",
							"size"
						]), d = function(e, t) {
							var r, l = n(e), i = t && t.length, a = s(l, t, i), c = o(l, 10, 1), f = c < 5 ? c + 4 : c, m = o(l, 10, 2), d = m < 5 ? m + 4 : m;
							return {
								wrapperColor: a,
								faceColor: (r = a, "#" === r.slice(0, 1) && (r = r.slice(1)), (299 * parseInt(r.substr(0, 2), 16) + 587 * parseInt(r.substr(2, 2), 16) + 114 * parseInt(r.substr(4, 2), 16)) / 1e3 >= 128 ? "#000000" : "#FFFFFF"),
								backgroundColor: s(l + 13, t, i),
								wrapperTranslateX: f,
								wrapperTranslateY: d,
								wrapperRotate: o(l, 360),
								wrapperScale: 1 + o(l, 3) / 10,
								isMouthOpen: h(l, 2),
								isCircle: h(l, 1),
								eyeSpread: o(l, 5),
								mouthSpread: o(l, 3),
								faceRotate: o(l, 10, 3),
								faceTranslateX: f > 6 ? f / 2 : o(l, 8, 1),
								faceTranslateY: d > 6 ? d / 2 : o(l, 7, 2)
							};
						}(t, r), u = i.useId();
						return i.createElement("svg", Object.assign({
							viewBox: "0 0 36 36",
							fill: "none",
							role: "img",
							xmlns: "http://www.w3.org/2000/svg",
							width: f,
							height: f
						}, m), a && i.createElement("title", null, t), i.createElement("mask", {
							id: u,
							maskUnits: "userSpaceOnUse",
							x: 0,
							y: 0,
							width: 36,
							height: 36
						}, i.createElement("rect", {
							width: 36,
							height: 36,
							rx: c ? void 0 : 72,
							fill: "#FFFFFF"
						})), i.createElement("g", { mask: "url(#".concat(u, ")") }, i.createElement("rect", {
							width: 36,
							height: 36,
							fill: d.backgroundColor
						}), i.createElement("rect", {
							x: "0",
							y: "0",
							width: 36,
							height: 36,
							transform: "translate(" + d.wrapperTranslateX + " " + d.wrapperTranslateY + ") rotate(" + d.wrapperRotate + " 18 18) scale(" + d.wrapperScale + ")",
							fill: d.wrapperColor,
							rx: d.isCircle ? 36 : 6
						}), i.createElement("g", { transform: "translate(" + d.faceTranslateX + " " + d.faceTranslateY + ") rotate(" + d.faceRotate + " 18 18)" }, d.isMouthOpen ? i.createElement("path", {
							d: "M15 " + (19 + d.mouthSpread) + "c2 1 4 1 6 0",
							stroke: d.faceColor,
							fill: "none",
							strokeLinecap: "round"
						}) : i.createElement("path", {
							d: "M13," + (19 + d.mouthSpread) + " a1,0.75 0 0,0 10,0",
							fill: d.faceColor
						}), i.createElement("rect", {
							x: 14 - d.eyeSpread,
							y: 14,
							width: 1.5,
							height: 2,
							rx: 1,
							stroke: "none",
							fill: d.faceColor
						}), i.createElement("rect", {
							x: 20 + d.eyeSpread,
							y: 14,
							width: 1.5,
							height: 2,
							rx: 1,
							stroke: "none",
							fill: d.faceColor
						}))));
					},
					sunset: function(e) {
						var t = e.name, r = e.colors, a = e.title, c = e.square, h = e.size, o = l(e, [
							"name",
							"colors",
							"title",
							"square",
							"size"
						]), f = function(e, t) {
							var r = n(e), l = t && t.length;
							return Array.from({ length: 4 }, (function(e, i) {
								return s(r + i, t, l);
							}));
						}(t, r), m = t.replace(/\s/g, ""), d = i.useId();
						return i.createElement("svg", Object.assign({
							viewBox: "0 0 80 80",
							fill: "none",
							role: "img",
							xmlns: "http://www.w3.org/2000/svg",
							width: h,
							height: h
						}, o), a && i.createElement("title", null, t), i.createElement("mask", {
							id: d,
							maskUnits: "userSpaceOnUse",
							x: 0,
							y: 0,
							width: 80,
							height: 80
						}, i.createElement("rect", {
							width: 80,
							height: 80,
							rx: c ? void 0 : 160,
							fill: "#FFFFFF"
						})), i.createElement("g", { mask: "url(#".concat(d, ")") }, i.createElement("path", {
							fill: "url(#gradient_paint0_linear_" + m + ")",
							d: "M0 0h80v40H0z"
						}), i.createElement("path", {
							fill: "url(#gradient_paint1_linear_" + m + ")",
							d: "M0 40h80v40H0z"
						})), i.createElement("defs", null, i.createElement("linearGradient", {
							id: "gradient_paint0_linear_" + m,
							x1: 40,
							y1: 0,
							x2: 40,
							y2: 40,
							gradientUnits: "userSpaceOnUse"
						}, i.createElement("stop", { stopColor: f[0] }), i.createElement("stop", {
							offset: 1,
							stopColor: f[1]
						})), i.createElement("linearGradient", {
							id: "gradient_paint1_linear_" + m,
							x1: 40,
							y1: 40,
							x2: 40,
							y2: 80,
							gradientUnits: "userSpaceOnUse"
						}, i.createElement("stop", { stopColor: f[2] }), i.createElement("stop", {
							offset: 1,
							stopColor: f[3]
						}))));
					},
					marble: f
				}, d = {
					geometric: "beam",
					abstract: "bauhaus"
				}, u = function(e) {
					var t = e.variant, r = void 0 === t ? "marble" : t, i = e.colors, n = void 0 === i ? [
						"#92A1C6",
						"#146A7C",
						"#F0AB3D",
						"#C271B4",
						"#C20D90"
					] : i, c = e.name, h = void 0 === c ? "Clara Barton" : c, o = e.title, s = void 0 !== o && o, u = e.size, g = e.square, w = void 0 !== g && g, E = l(e, [
						"variant",
						"colors",
						"name",
						"title",
						"size",
						"square"
					]), p = m[d[r] || r] || f;
					return a.a.createElement(p, Object.assign({
						colors: n,
						name: h,
						title: s,
						size: u,
						square: w
					}, E));
				};
				t.default = u;
			}
		]);
	}));
})))());
var palette = [
	"var(--chart-1)",
	"var(--chart-2)",
	"var(--chart-3)",
	"var(--chart-4)",
	"var(--chart-5)"
];
function CoreAvatar({ variant = "beam", className, ...props }) {
	const ui = useSkin("Avatar", { variant });
	return /* @__PURE__ */ jsx(import_build.default, {
		colors: palette,
		variant,
		...props,
		...ui("root", className)
	});
}
var _Avatar = replaceable("Avatar", CoreAvatar);
var UserAvatar = (props) => /* @__PURE__ */ jsx(_Avatar, {
	name: useCurrentUser$1().uuid,
	...props
});
UserAvatar.displayName = "Avatar.User";
var Avatar = Object.assign(_Avatar, { User: UserAvatar });
//#endregion
//#region ../../resources/scripts/components/elements/ListToolbar.tsx
/** The row above a list holding its summary and primary actions. */
function ListToolbar({ summary, children, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn$1("mb-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between", className),
		children: [summary && /* @__PURE__ */ jsx("p", {
			className: "text-sm text-muted-foreground",
			children: summary
		}), children && /* @__PURE__ */ jsx("div", {
			className: "flex flex-col gap-2 sm:ml-auto sm:flex-row sm:items-center",
			children
		})]
	});
}
//#endregion
//#region ../../node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function hasWindow() {
	return typeof window !== "undefined";
}
function getNodeName(node) {
	if (isNode(node)) return (node.nodeName || "").toLowerCase();
	return "#document";
}
function getWindow(node) {
	var _node$ownerDocument;
	return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
	var _ref;
	return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
	if (!hasWindow()) return false;
	return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
	if (!hasWindow()) return false;
	return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
	if (!hasWindow()) return false;
	return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
	if (!hasWindow() || typeof ShadowRoot === "undefined") return false;
	return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
function isOverflowElement(element) {
	const { overflow, overflowX, overflowY, display } = getComputedStyle$1(element);
	return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== "inline" && display !== "contents";
}
function isTableElement(element) {
	return /^(table|td|th)$/.test(getNodeName(element));
}
function isTopLayer(element) {
	try {
		if (element.matches(":popover-open")) return true;
	} catch (_e) {}
	try {
		return element.matches(":modal");
	} catch (_e) {
		return false;
	}
}
var willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
var containRe = /paint|layout|strict|content/;
var isNotNone = (value) => !!value && value !== "none";
var isWebKitValue;
function isContainingBlock(elementOrCss) {
	const css = isElement(elementOrCss) ? getComputedStyle$1(elementOrCss) : elementOrCss;
	return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || "") || containRe.test(css.contain || "");
}
function getContainingBlock(element) {
	let currentNode = getParentNode(element);
	while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
		if (isContainingBlock(currentNode)) return currentNode;
		else if (isTopLayer(currentNode)) return null;
		currentNode = getParentNode(currentNode);
	}
	return null;
}
function isWebKit() {
	if (isWebKitValue == null) isWebKitValue = typeof CSS !== "undefined" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none");
	return isWebKitValue;
}
function isLastTraversableNode(node) {
	return /^(html|body|#document)$/.test(getNodeName(node));
}
function getComputedStyle$1(element) {
	return getWindow(element).getComputedStyle(element);
}
function getNodeScroll(element) {
	if (isElement(element)) return {
		scrollLeft: element.scrollLeft,
		scrollTop: element.scrollTop
	};
	return {
		scrollLeft: element.scrollX,
		scrollTop: element.scrollY
	};
}
function getParentNode(node) {
	if (getNodeName(node) === "html") return node;
	const result = node.assignedSlot || node.parentNode || isShadowRoot(node) && node.host || getDocumentElement(node);
	return isShadowRoot(result) ? result.host : result;
}
function getNearestOverflowAncestor(node) {
	const parentNode = getParentNode(node);
	if (isLastTraversableNode(parentNode)) return node.ownerDocument ? node.ownerDocument.body : node.body;
	if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) return parentNode;
	return getNearestOverflowAncestor(parentNode);
}
function getOverflowAncestors(node, list, traverseIframes) {
	var _node$ownerDocument2;
	if (list === void 0) list = [];
	if (traverseIframes === void 0) traverseIframes = true;
	const scrollableAncestor = getNearestOverflowAncestor(node);
	const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
	const win = getWindow(scrollableAncestor);
	if (isBody) {
		const frameElement = getFrameElement(win);
		return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
	} else return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
}
function getFrameElement(win) {
	return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
}
//#endregion
//#region ../../node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
var min$1 = Math.min;
var max$1 = Math.max;
var round = Math.round;
var floor = Math.floor;
var createCoords = (v) => ({
	x: v,
	y: v
});
var oppositeSideMap = {
	left: "right",
	right: "left",
	bottom: "top",
	top: "bottom"
};
function clamp(start, value, end) {
	return max$1(start, min$1(value, end));
}
function evaluate(value, param) {
	return typeof value === "function" ? value(param) : value;
}
function getSide(placement) {
	return placement.split("-")[0];
}
function getAlignment(placement) {
	return placement.split("-")[1];
}
function getOppositeAxis(axis) {
	return axis === "x" ? "y" : "x";
}
function getAxisLength(axis) {
	return axis === "y" ? "height" : "width";
}
function getSideAxis(placement) {
	const firstChar = placement[0];
	return firstChar === "t" || firstChar === "b" ? "y" : "x";
}
function getAlignmentAxis(placement) {
	return getOppositeAxis(getSideAxis(placement));
}
function getAlignmentSides(placement, rects, rtl) {
	if (rtl === void 0) rtl = false;
	const alignment = getAlignment(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const length = getAxisLength(alignmentAxis);
	let mainAlignmentSide = alignmentAxis === "x" ? alignment === (rtl ? "end" : "start") ? "right" : "left" : alignment === "start" ? "bottom" : "top";
	if (rects.reference[length] > rects.floating[length]) mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
	return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
}
function getExpandedPlacements(placement) {
	const oppositePlacement = getOppositePlacement(placement);
	return [
		getOppositeAlignmentPlacement(placement),
		oppositePlacement,
		getOppositeAlignmentPlacement(oppositePlacement)
	];
}
function getOppositeAlignmentPlacement(placement) {
	return placement.includes("start") ? placement.replace("start", "end") : placement.replace("end", "start");
}
var lrPlacement = ["left", "right"];
var rlPlacement = ["right", "left"];
var tbPlacement = ["top", "bottom"];
var btPlacement = ["bottom", "top"];
function getSideList(side, isStart, rtl) {
	switch (side) {
		case "top":
		case "bottom":
			if (rtl) return isStart ? rlPlacement : lrPlacement;
			return isStart ? lrPlacement : rlPlacement;
		case "left":
		case "right": return isStart ? tbPlacement : btPlacement;
		default: return [];
	}
}
function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
	const alignment = getAlignment(placement);
	let list = getSideList(getSide(placement), direction === "start", rtl);
	if (alignment) {
		list = list.map((side) => side + "-" + alignment);
		if (flipAlignment) list = list.concat(list.map(getOppositeAlignmentPlacement));
	}
	return list;
}
function getOppositePlacement(placement) {
	const side = getSide(placement);
	return oppositeSideMap[side] + placement.slice(side.length);
}
function expandPaddingObject(padding) {
	return {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		...padding
	};
}
function getPaddingObject(padding) {
	return typeof padding !== "number" ? expandPaddingObject(padding) : {
		top: padding,
		right: padding,
		bottom: padding,
		left: padding
	};
}
function rectToClientRect(rect) {
	const { x, y, width, height } = rect;
	return {
		width,
		height,
		top: y,
		left: x,
		right: x + width,
		bottom: y + height,
		x,
		y
	};
}
/*!
* tabbable 6.4.0
* @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
*/
var candidateSelector = /* #__PURE__ */ [
	"input:not([inert]):not([inert] *)",
	"select:not([inert]):not([inert] *)",
	"textarea:not([inert]):not([inert] *)",
	"a[href]:not([inert]):not([inert] *)",
	"button:not([inert]):not([inert] *)",
	"[tabindex]:not(slot):not([inert]):not([inert] *)",
	"audio[controls]:not([inert]):not([inert] *)",
	"video[controls]:not([inert]):not([inert] *)",
	"[contenteditable]:not([contenteditable=\"false\"]):not([inert]):not([inert] *)",
	"details>summary:first-of-type:not([inert]):not([inert] *)",
	"details:not([inert]):not([inert] *)"
].join(",");
var NoElement = typeof Element === "undefined";
var matches = NoElement ? function() {} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
var getRootNode = !NoElement && Element.prototype.getRootNode ? function(element) {
	var _element$getRootNode;
	return element === null || element === void 0 ? void 0 : (_element$getRootNode = element.getRootNode) === null || _element$getRootNode === void 0 ? void 0 : _element$getRootNode.call(element);
} : function(element) {
	return element === null || element === void 0 ? void 0 : element.ownerDocument;
};
/**
* Determines if a node is inert or in an inert ancestor.
* @param {Node} [node]
* @param {boolean} [lookUp] If true and `node` is not inert, looks up at ancestors to
*  see if any of them are inert. If false, only `node` itself is considered.
* @returns {boolean} True if inert itself or by way of being in an inert ancestor.
*  False if `node` is falsy.
*/
var _isInert = function isInert(node, lookUp) {
	var _node$getAttribute;
	if (lookUp === void 0) lookUp = true;
	var inertAtt = node === null || node === void 0 ? void 0 : (_node$getAttribute = node.getAttribute) === null || _node$getAttribute === void 0 ? void 0 : _node$getAttribute.call(node, "inert");
	return inertAtt === "" || inertAtt === "true" || lookUp && node && (typeof node.closest === "function" ? node.closest("[inert]") : _isInert(node.parentNode));
};
/**
* Determines if a node's content is editable.
* @param {Element} [node]
* @returns True if it's content-editable; false if it's not or `node` is falsy.
*/
var isContentEditable = function isContentEditable(node) {
	var _node$getAttribute2;
	var attValue = node === null || node === void 0 ? void 0 : (_node$getAttribute2 = node.getAttribute) === null || _node$getAttribute2 === void 0 ? void 0 : _node$getAttribute2.call(node, "contenteditable");
	return attValue === "" || attValue === "true";
};
/**
* @param {Element} el container to check in
* @param {boolean} includeContainer add container to check
* @param {(node: Element) => boolean} filter filter candidates
* @returns {Element[]}
*/
var getCandidates = function getCandidates(el, includeContainer, filter) {
	if (_isInert(el)) return [];
	var candidates = Array.prototype.slice.apply(el.querySelectorAll(candidateSelector));
	if (includeContainer && matches.call(el, candidateSelector)) candidates.unshift(el);
	candidates = candidates.filter(filter);
	return candidates;
};
/**
* @callback GetShadowRoot
* @param {Element} element to check for shadow root
* @returns {ShadowRoot|boolean} ShadowRoot if available or boolean indicating if a shadowRoot is attached but not available.
*/
/**
* @callback ShadowRootFilter
* @param {Element} shadowHostNode the element which contains shadow content
* @returns {boolean} true if a shadow root could potentially contain valid candidates.
*/
/**
* @typedef {Object} CandidateScope
* @property {Element} scopeParent contains inner candidates
* @property {Element[]} candidates list of candidates found in the scope parent
*/
/**
* @typedef {Object} IterativeOptions
* @property {GetShadowRoot|boolean} getShadowRoot true if shadow support is enabled; falsy if not;
*  if a function, implies shadow support is enabled and either returns the shadow root of an element
*  or a boolean stating if it has an undisclosed shadow root
* @property {(node: Element) => boolean} filter filter candidates
* @property {boolean} flatten if true then result will flatten any CandidateScope into the returned list
* @property {ShadowRootFilter} shadowRootFilter filter shadow roots;
*/
/**
* @param {Element[]} elements list of element containers to match candidates from
* @param {boolean} includeContainer add container list to check
* @param {IterativeOptions} options
* @returns {Array.<Element|CandidateScope>}
*/
var _getCandidatesIteratively = function getCandidatesIteratively(elements, includeContainer, options) {
	var candidates = [];
	var elementsToCheck = Array.from(elements);
	while (elementsToCheck.length) {
		var element = elementsToCheck.shift();
		if (_isInert(element, false)) continue;
		if (element.tagName === "SLOT") {
			var assigned = element.assignedElements();
			var nestedCandidates = _getCandidatesIteratively(assigned.length ? assigned : element.children, true, options);
			if (options.flatten) candidates.push.apply(candidates, nestedCandidates);
			else candidates.push({
				scopeParent: element,
				candidates: nestedCandidates
			});
		} else {
			if (matches.call(element, candidateSelector) && options.filter(element) && (includeContainer || !elements.includes(element))) candidates.push(element);
			var shadowRoot = element.shadowRoot || typeof options.getShadowRoot === "function" && options.getShadowRoot(element);
			var validShadowRoot = !_isInert(shadowRoot, false) && (!options.shadowRootFilter || options.shadowRootFilter(element));
			if (shadowRoot && validShadowRoot) {
				var _nestedCandidates = _getCandidatesIteratively(shadowRoot === true ? element.children : shadowRoot.children, true, options);
				if (options.flatten) candidates.push.apply(candidates, _nestedCandidates);
				else candidates.push({
					scopeParent: element,
					candidates: _nestedCandidates
				});
			} else elementsToCheck.unshift.apply(elementsToCheck, element.children);
		}
	}
	return candidates;
};
/**
* @private
* Determines if the node has an explicitly specified `tabindex` attribute.
* @param {HTMLElement} node
* @returns {boolean} True if so; false if not.
*/
var hasTabIndex = function hasTabIndex(node) {
	return !isNaN(parseInt(node.getAttribute("tabindex"), 10));
};
/**
* Determine the tab index of a given node.
* @param {HTMLElement} node
* @returns {number} Tab order (negative, 0, or positive number).
* @throws {Error} If `node` is falsy.
*/
var getTabIndex = function getTabIndex(node) {
	if (!node) throw new Error("No node provided");
	if (node.tabIndex < 0) {
		if ((/^(AUDIO|VIDEO|DETAILS)$/.test(node.tagName) || isContentEditable(node)) && !hasTabIndex(node)) return 0;
	}
	return node.tabIndex;
};
/**
* Determine the tab index of a given node __for sort order purposes__.
* @param {HTMLElement} node
* @param {boolean} [isScope] True for a custom element with shadow root or slot that, by default,
*  has tabIndex -1, but needs to be sorted by document order in order for its content to be
*  inserted into the correct sort position.
* @returns {number} Tab order (negative, 0, or positive number).
*/
var getSortOrderTabIndex = function getSortOrderTabIndex(node, isScope) {
	var tabIndex = getTabIndex(node);
	if (tabIndex < 0 && isScope && !hasTabIndex(node)) return 0;
	return tabIndex;
};
var sortOrderedTabbables = function sortOrderedTabbables(a, b) {
	return a.tabIndex === b.tabIndex ? a.documentOrder - b.documentOrder : a.tabIndex - b.tabIndex;
};
var isInput = function isInput(node) {
	return node.tagName === "INPUT";
};
var isHiddenInput = function isHiddenInput(node) {
	return isInput(node) && node.type === "hidden";
};
var isDetailsWithSummary = function isDetailsWithSummary(node) {
	return node.tagName === "DETAILS" && Array.prototype.slice.apply(node.children).some(function(child) {
		return child.tagName === "SUMMARY";
	});
};
var getCheckedRadio = function getCheckedRadio(nodes, form) {
	for (var i = 0; i < nodes.length; i++) if (nodes[i].checked && nodes[i].form === form) return nodes[i];
};
var isTabbableRadio = function isTabbableRadio(node) {
	if (!node.name) return true;
	var radioScope = node.form || getRootNode(node);
	var queryRadios = function queryRadios(name) {
		return radioScope.querySelectorAll("input[type=\"radio\"][name=\"" + name + "\"]");
	};
	var radioSet;
	if (typeof window !== "undefined" && typeof window.CSS !== "undefined" && typeof window.CSS.escape === "function") radioSet = queryRadios(window.CSS.escape(node.name));
	else try {
		radioSet = queryRadios(node.name);
	} catch (err) {
		console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", err.message);
		return false;
	}
	var checked = getCheckedRadio(radioSet, node.form);
	return !checked || checked === node;
};
var isRadio = function isRadio(node) {
	return isInput(node) && node.type === "radio";
};
var isNonTabbableRadio = function isNonTabbableRadio(node) {
	return isRadio(node) && !isTabbableRadio(node);
};
var isNodeAttached = function isNodeAttached(node) {
	var _nodeRoot;
	var nodeRoot = node && getRootNode(node);
	var nodeRootHost = (_nodeRoot = nodeRoot) === null || _nodeRoot === void 0 ? void 0 : _nodeRoot.host;
	var attached = false;
	if (nodeRoot && nodeRoot !== node) {
		var _nodeRootHost, _nodeRootHost$ownerDo, _node$ownerDocument;
		attached = !!((_nodeRootHost = nodeRootHost) !== null && _nodeRootHost !== void 0 && (_nodeRootHost$ownerDo = _nodeRootHost.ownerDocument) !== null && _nodeRootHost$ownerDo !== void 0 && _nodeRootHost$ownerDo.contains(nodeRootHost) || node !== null && node !== void 0 && (_node$ownerDocument = node.ownerDocument) !== null && _node$ownerDocument !== void 0 && _node$ownerDocument.contains(node));
		while (!attached && nodeRootHost) {
			var _nodeRoot2, _nodeRootHost2, _nodeRootHost2$ownerD;
			nodeRoot = getRootNode(nodeRootHost);
			nodeRootHost = (_nodeRoot2 = nodeRoot) === null || _nodeRoot2 === void 0 ? void 0 : _nodeRoot2.host;
			attached = !!((_nodeRootHost2 = nodeRootHost) !== null && _nodeRootHost2 !== void 0 && (_nodeRootHost2$ownerD = _nodeRootHost2.ownerDocument) !== null && _nodeRootHost2$ownerD !== void 0 && _nodeRootHost2$ownerD.contains(nodeRootHost));
		}
	}
	return attached;
};
var isZeroArea = function isZeroArea(node) {
	var _node$getBoundingClie = node.getBoundingClientRect(), width = _node$getBoundingClie.width, height = _node$getBoundingClie.height;
	return width === 0 && height === 0;
};
var isHidden = function isHidden(node, _ref) {
	var displayCheck = _ref.displayCheck, getShadowRoot = _ref.getShadowRoot;
	if (displayCheck === "full-native") {
		if ("checkVisibility" in node) return !node.checkVisibility({
			checkOpacity: false,
			opacityProperty: false,
			contentVisibilityAuto: true,
			visibilityProperty: true,
			checkVisibilityCSS: true
		});
	}
	if (getComputedStyle(node).visibility === "hidden") return true;
	var nodeUnderDetails = matches.call(node, "details>summary:first-of-type") ? node.parentElement : node;
	if (matches.call(nodeUnderDetails, "details:not([open]) *")) return true;
	if (!displayCheck || displayCheck === "full" || displayCheck === "full-native" || displayCheck === "legacy-full") {
		if (typeof getShadowRoot === "function") {
			var originalNode = node;
			while (node) {
				var parentElement = node.parentElement;
				var rootNode = getRootNode(node);
				if (parentElement && !parentElement.shadowRoot && getShadowRoot(parentElement) === true) return isZeroArea(node);
				else if (node.assignedSlot) node = node.assignedSlot;
				else if (!parentElement && rootNode !== node.ownerDocument) node = rootNode.host;
				else node = parentElement;
			}
			node = originalNode;
		}
		if (isNodeAttached(node)) return !node.getClientRects().length;
		if (displayCheck !== "legacy-full") return true;
	} else if (displayCheck === "non-zero-area") return isZeroArea(node);
	return false;
};
var isDisabledFromFieldset = function isDisabledFromFieldset(node) {
	if (/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(node.tagName)) {
		var parentNode = node.parentElement;
		while (parentNode) {
			if (parentNode.tagName === "FIELDSET" && parentNode.disabled) {
				for (var i = 0; i < parentNode.children.length; i++) {
					var child = parentNode.children.item(i);
					if (child.tagName === "LEGEND") return matches.call(parentNode, "fieldset[disabled] *") ? true : !child.contains(node);
				}
				return true;
			}
			parentNode = parentNode.parentElement;
		}
	}
	return false;
};
var isNodeMatchingSelectorFocusable = function isNodeMatchingSelectorFocusable(options, node) {
	if (node.disabled || isHiddenInput(node) || isHidden(node, options) || isDetailsWithSummary(node) || isDisabledFromFieldset(node)) return false;
	return true;
};
var isNodeMatchingSelectorTabbable = function isNodeMatchingSelectorTabbable(options, node) {
	if (isNonTabbableRadio(node) || getTabIndex(node) < 0 || !isNodeMatchingSelectorFocusable(options, node)) return false;
	return true;
};
var isShadowRootTabbable = function isShadowRootTabbable(shadowHostNode) {
	var tabIndex = parseInt(shadowHostNode.getAttribute("tabindex"), 10);
	if (isNaN(tabIndex) || tabIndex >= 0) return true;
	return false;
};
/**
* @param {Array.<Element|CandidateScope>} candidates
* @returns Element[]
*/
var _sortByOrder = function sortByOrder(candidates) {
	var regularTabbables = [];
	var orderedTabbables = [];
	candidates.forEach(function(item, i) {
		var isScope = !!item.scopeParent;
		var element = isScope ? item.scopeParent : item;
		var candidateTabindex = getSortOrderTabIndex(element, isScope);
		var elements = isScope ? _sortByOrder(item.candidates) : element;
		if (candidateTabindex === 0) isScope ? regularTabbables.push.apply(regularTabbables, elements) : regularTabbables.push(element);
		else orderedTabbables.push({
			documentOrder: i,
			tabIndex: candidateTabindex,
			item,
			isScope,
			content: elements
		});
	});
	return orderedTabbables.sort(sortOrderedTabbables).reduce(function(acc, sortable) {
		sortable.isScope ? acc.push.apply(acc, sortable.content) : acc.push(sortable.content);
		return acc;
	}, []).concat(regularTabbables);
};
var tabbable = function tabbable(container, options) {
	options = options || {};
	var candidates;
	if (options.getShadowRoot) candidates = _getCandidatesIteratively([container], options.includeContainer, {
		filter: isNodeMatchingSelectorTabbable.bind(null, options),
		flatten: false,
		getShadowRoot: options.getShadowRoot,
		shadowRootFilter: isShadowRootTabbable
	});
	else candidates = getCandidates(container, options.includeContainer, isNodeMatchingSelectorTabbable.bind(null, options));
	return _sortByOrder(candidates);
};
//#endregion
//#region ../../node_modules/@floating-ui/react/dist/floating-ui.react.utils.mjs
function getPlatform() {
	const uaData = navigator.userAgentData;
	if (uaData != null && uaData.platform) return uaData.platform;
	return navigator.platform;
}
function getUserAgent() {
	const uaData = navigator.userAgentData;
	if (uaData && Array.isArray(uaData.brands)) return uaData.brands.map((_ref) => {
		let { brand, version } = _ref;
		return brand + "/" + version;
	}).join(" ");
	return navigator.userAgent;
}
function isSafari() {
	return /apple/i.test(navigator.vendor);
}
function isMac() {
	return getPlatform().toLowerCase().startsWith("mac") && !navigator.maxTouchPoints;
}
function isJSDOM() {
	return getUserAgent().includes("jsdom/");
}
var FOCUSABLE_ATTRIBUTE$1 = "data-floating-ui-focusable";
var TYPEABLE_SELECTOR = "input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])";
function activeElement(doc) {
	let activeElement = doc.activeElement;
	while (((_activeElement = activeElement) == null || (_activeElement = _activeElement.shadowRoot) == null ? void 0 : _activeElement.activeElement) != null) {
		var _activeElement;
		activeElement = activeElement.shadowRoot.activeElement;
	}
	return activeElement;
}
function contains(parent, child) {
	if (!parent || !child) return false;
	const rootNode = child.getRootNode == null ? void 0 : child.getRootNode();
	if (parent.contains(child)) return true;
	if (rootNode && isShadowRoot(rootNode)) {
		let next = child;
		while (next) {
			if (parent === next) return true;
			next = next.parentNode || next.host;
		}
	}
	return false;
}
function getTarget(event) {
	if ("composedPath" in event) return event.composedPath()[0];
	return event.target;
}
function isEventTargetWithin(event, node) {
	if (node == null) return false;
	if ("composedPath" in event) return event.composedPath().includes(node);
	const e = event;
	return e.target != null && node.contains(e.target);
}
function isRootElement(element) {
	return element.matches("html,body");
}
function getDocument(node) {
	return (node == null ? void 0 : node.ownerDocument) || document;
}
function isTypeableElement(element) {
	return isHTMLElement(element) && element.matches(TYPEABLE_SELECTOR);
}
function matchesFocusVisible(element) {
	if (!element || isJSDOM()) return true;
	try {
		return element.matches(":focus-visible");
	} catch (_e) {
		return true;
	}
}
function getFloatingFocusElement(floatingElement) {
	if (!floatingElement) return null;
	return floatingElement.hasAttribute(FOCUSABLE_ATTRIBUTE$1) ? floatingElement : floatingElement.querySelector("[data-floating-ui-focusable]") || floatingElement;
}
function getNodeChildren(nodes, id, onlyOpenChildren) {
	if (onlyOpenChildren === void 0) onlyOpenChildren = true;
	return nodes.filter((node) => {
		var _node$context;
		return node.parentId === id && (!onlyOpenChildren || ((_node$context = node.context) == null ? void 0 : _node$context.open));
	}).flatMap((child) => [child, ...getNodeChildren(nodes, child.id, onlyOpenChildren)]);
}
function isReactEvent(event) {
	return "nativeEvent" in event;
}
function isMouseLikePointerType(pointerType, strict) {
	const values = ["mouse", "pen"];
	if (!strict) values.push("", void 0);
	return values.includes(pointerType);
}
var index$1 = typeof document !== "undefined" ? useLayoutEffect : function noop() {};
var SafeReact$1 = { ...React$1 };
function useLatestRef$1(value) {
	const ref = React$1.useRef(value);
	index$1(() => {
		ref.current = value;
	});
	return ref;
}
var useSafeInsertionEffect = SafeReact$1.useInsertionEffect || ((fn) => fn());
function useEffectEvent$1(callback) {
	const ref = React$1.useRef(() => {
		if (process.env.NODE_ENV !== "production") throw new Error("Cannot call an event handler while rendering.");
	});
	useSafeInsertionEffect(() => {
		ref.current = callback;
	});
	return React$1.useCallback(function() {
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		return ref.current == null ? void 0 : ref.current(...args);
	}, []);
}
var getTabbableOptions = () => ({
	getShadowRoot: true,
	displayCheck: typeof ResizeObserver === "function" && ResizeObserver.toString().includes("[native code]") ? "full" : "none"
});
function getTabbableIn(container, dir) {
	const list = tabbable(container, getTabbableOptions());
	const len = list.length;
	if (len === 0) return;
	const active = activeElement(getDocument(container));
	const index = list.indexOf(active);
	return list[index === -1 ? dir === 1 ? 0 : len - 1 : index + dir];
}
function getNextTabbable(referenceElement) {
	return getTabbableIn(getDocument(referenceElement).body, 1) || referenceElement;
}
function getPreviousTabbable(referenceElement) {
	return getTabbableIn(getDocument(referenceElement).body, -1) || referenceElement;
}
function isOutsideEvent(event, container) {
	const containerElement = container || event.currentTarget;
	const relatedTarget = event.relatedTarget;
	return !relatedTarget || !contains(containerElement, relatedTarget);
}
function disableFocusInside(container) {
	tabbable(container, getTabbableOptions()).forEach((element) => {
		element.dataset.tabindex = element.getAttribute("tabindex") || "";
		element.setAttribute("tabindex", "-1");
	});
}
function enableFocusInside(container) {
	container.querySelectorAll("[data-tabindex]").forEach((element) => {
		const tabindex = element.dataset.tabindex;
		delete element.dataset.tabindex;
		if (tabindex) element.setAttribute("tabindex", tabindex);
		else element.removeAttribute("tabindex");
	});
}
//#endregion
//#region ../../node_modules/@floating-ui/core/dist/floating-ui.core.mjs
function computeCoordsFromPlacement(_ref, placement, rtl) {
	let { reference, floating } = _ref;
	const sideAxis = getSideAxis(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const alignLength = getAxisLength(alignmentAxis);
	const side = getSide(placement);
	const isVertical = sideAxis === "y";
	const commonX = reference.x + reference.width / 2 - floating.width / 2;
	const commonY = reference.y + reference.height / 2 - floating.height / 2;
	const commonAlign = reference[alignLength] / 2 - floating[alignLength] / 2;
	let coords;
	switch (side) {
		case "top":
			coords = {
				x: commonX,
				y: reference.y - floating.height
			};
			break;
		case "bottom":
			coords = {
				x: commonX,
				y: reference.y + reference.height
			};
			break;
		case "right":
			coords = {
				x: reference.x + reference.width,
				y: commonY
			};
			break;
		case "left":
			coords = {
				x: reference.x - floating.width,
				y: commonY
			};
			break;
		default: coords = {
			x: reference.x,
			y: reference.y
		};
	}
	switch (getAlignment(placement)) {
		case "start":
			coords[alignmentAxis] -= commonAlign * (rtl && isVertical ? -1 : 1);
			break;
		case "end":
			coords[alignmentAxis] += commonAlign * (rtl && isVertical ? -1 : 1);
			break;
	}
	return coords;
}
/**
* Resolves with an object of overflow side offsets that determine how much the
* element is overflowing a given clipping boundary on each side.
* - positive = overflowing the boundary by that number of pixels
* - negative = how many pixels left before it will overflow
* - 0 = lies flush with the boundary
* @see https://floating-ui.com/docs/detectOverflow
*/
async function detectOverflow(state, options) {
	var _await$platform$isEle;
	if (options === void 0) options = {};
	const { x, y, platform, rects, elements, strategy } = state;
	const { boundary = "clippingAncestors", rootBoundary = "viewport", elementContext = "floating", altBoundary = false, padding = 0 } = evaluate(options, state);
	const paddingObject = getPaddingObject(padding);
	const element = elements[altBoundary ? elementContext === "floating" ? "reference" : "floating" : elementContext];
	const clippingClientRect = rectToClientRect(await platform.getClippingRect({
		element: ((_await$platform$isEle = await (platform.isElement == null ? void 0 : platform.isElement(element))) != null ? _await$platform$isEle : true) ? element : element.contextElement || await (platform.getDocumentElement == null ? void 0 : platform.getDocumentElement(elements.floating)),
		boundary,
		rootBoundary,
		strategy
	}));
	const rect = elementContext === "floating" ? {
		x,
		y,
		width: rects.floating.width,
		height: rects.floating.height
	} : rects.reference;
	const offsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(elements.floating));
	const offsetScale = await (platform.isElement == null ? void 0 : platform.isElement(offsetParent)) ? await (platform.getScale == null ? void 0 : platform.getScale(offsetParent)) || {
		x: 1,
		y: 1
	} : {
		x: 1,
		y: 1
	};
	const elementClientRect = rectToClientRect(platform.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform.convertOffsetParentRelativeRectToViewportRelativeRect({
		elements,
		rect,
		offsetParent,
		strategy
	}) : rect);
	return {
		top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
		bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
		left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
		right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
	};
}
var MAX_RESET_COUNT = 50;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*
* This export does not have any `platform` interface logic. You will need to
* write one for the platform you are using Floating UI with.
*/
var computePosition$1 = async (reference, floating, config) => {
	const { placement = "bottom", strategy = "absolute", middleware = [], platform } = config;
	const platformWithDetectOverflow = platform.detectOverflow ? platform : {
		...platform,
		detectOverflow
	};
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(floating));
	let rects = await platform.getElementRects({
		reference,
		floating,
		strategy
	});
	let { x, y } = computeCoordsFromPlacement(rects, placement, rtl);
	let statefulPlacement = placement;
	let resetCount = 0;
	const middlewareData = {};
	for (let i = 0; i < middleware.length; i++) {
		const currentMiddleware = middleware[i];
		if (!currentMiddleware) continue;
		const { name, fn } = currentMiddleware;
		const { x: nextX, y: nextY, data, reset } = await fn({
			x,
			y,
			initialPlacement: placement,
			placement: statefulPlacement,
			strategy,
			middlewareData,
			rects,
			platform: platformWithDetectOverflow,
			elements: {
				reference,
				floating
			}
		});
		x = nextX != null ? nextX : x;
		y = nextY != null ? nextY : y;
		middlewareData[name] = {
			...middlewareData[name],
			...data
		};
		if (reset && resetCount < MAX_RESET_COUNT) {
			resetCount++;
			if (typeof reset === "object") {
				if (reset.placement) statefulPlacement = reset.placement;
				if (reset.rects) rects = reset.rects === true ? await platform.getElementRects({
					reference,
					floating,
					strategy
				}) : reset.rects;
				({x, y} = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
			}
			i = -1;
		}
	}
	return {
		x,
		y,
		placement: statefulPlacement,
		strategy,
		middlewareData
	};
};
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$3 = (options) => ({
	name: "arrow",
	options,
	async fn(state) {
		const { x, y, placement, rects, platform, elements, middlewareData } = state;
		const { element, padding = 0 } = evaluate(options, state) || {};
		if (element == null) return {};
		const paddingObject = getPaddingObject(padding);
		const coords = {
			x,
			y
		};
		const axis = getAlignmentAxis(placement);
		const length = getAxisLength(axis);
		const arrowDimensions = await platform.getDimensions(element);
		const isYAxis = axis === "y";
		const minProp = isYAxis ? "top" : "left";
		const maxProp = isYAxis ? "bottom" : "right";
		const clientProp = isYAxis ? "clientHeight" : "clientWidth";
		const endDiff = rects.reference[length] + rects.reference[axis] - coords[axis] - rects.floating[length];
		const startDiff = coords[axis] - rects.reference[axis];
		const arrowOffsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(element));
		let clientSize = arrowOffsetParent ? arrowOffsetParent[clientProp] : 0;
		if (!clientSize || !await (platform.isElement == null ? void 0 : platform.isElement(arrowOffsetParent))) clientSize = elements.floating[clientProp] || rects.floating[length];
		const centerToReference = endDiff / 2 - startDiff / 2;
		const largestPossiblePadding = clientSize / 2 - arrowDimensions[length] / 2 - 1;
		const minPadding = min$1(paddingObject[minProp], largestPossiblePadding);
		const maxPadding = min$1(paddingObject[maxProp], largestPossiblePadding);
		const min$1$1 = minPadding;
		const max = clientSize - arrowDimensions[length] - maxPadding;
		const center = clientSize / 2 - arrowDimensions[length] / 2 + centerToReference;
		const offset = clamp(min$1$1, center, max);
		const shouldAddOffset = !middlewareData.arrow && getAlignment(placement) != null && center !== offset && rects.reference[length] / 2 - (center < min$1$1 ? minPadding : maxPadding) - arrowDimensions[length] / 2 < 0;
		const alignmentOffset = shouldAddOffset ? center < min$1$1 ? center - min$1$1 : center - max : 0;
		return {
			[axis]: coords[axis] + alignmentOffset,
			data: {
				[axis]: offset,
				centerOffset: center - offset - alignmentOffset,
				...shouldAddOffset && { alignmentOffset }
			},
			reset: shouldAddOffset
		};
	}
});
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "flip",
		options,
		async fn(state) {
			var _middlewareData$arrow, _middlewareData$flip;
			const { placement, middlewareData, rects, initialPlacement, platform, elements } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true, fallbackPlacements: specifiedFallbackPlacements, fallbackStrategy = "bestFit", fallbackAxisSideDirection = "none", flipAlignment = true, ...detectOverflowOptions } = evaluate(options, state);
			if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			const side = getSide(placement);
			const initialSideAxis = getSideAxis(initialPlacement);
			const isBasePlacement = getSide(initialPlacement) === initialPlacement;
			const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
			const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [getOppositePlacement(initialPlacement)] : getExpandedPlacements(initialPlacement));
			const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== "none";
			if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) fallbackPlacements.push(...getOppositeAxisPlacements(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
			const placements = [initialPlacement, ...fallbackPlacements];
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const overflows = [];
			let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
			if (checkMainAxis) overflows.push(overflow[side]);
			if (checkCrossAxis) {
				const sides = getAlignmentSides(placement, rects, rtl);
				overflows.push(overflow[sides[0]], overflow[sides[1]]);
			}
			overflowsData = [...overflowsData, {
				placement,
				overflows
			}];
			if (!overflows.every((side) => side <= 0)) {
				var _middlewareData$flip2, _overflowsData$filter;
				const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
				const nextPlacement = placements[nextIndex];
				if (nextPlacement) {
					if (!(checkCrossAxis === "alignment" ? initialSideAxis !== getSideAxis(nextPlacement) : false) || overflowsData.every((d) => getSideAxis(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) return {
						data: {
							index: nextIndex,
							overflows: overflowsData
						},
						reset: { placement: nextPlacement }
					};
				}
				let resetPlacement = (_overflowsData$filter = overflowsData.filter((d) => d.overflows[0] <= 0).sort((a, b) => a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
				if (!resetPlacement) switch (fallbackStrategy) {
					case "bestFit": {
						var _overflowsData$filter2;
						const placement = (_overflowsData$filter2 = overflowsData.filter((d) => {
							if (hasFallbackAxisSideDirection) {
								const currentSideAxis = getSideAxis(d.placement);
								return currentSideAxis === initialSideAxis || currentSideAxis === "y";
							}
							return true;
						}).map((d) => [d.placement, d.overflows.filter((overflow) => overflow > 0).reduce((acc, overflow) => acc + overflow, 0)]).sort((a, b) => a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
						if (placement) resetPlacement = placement;
						break;
					}
					case "initialPlacement":
						resetPlacement = initialPlacement;
						break;
				}
				if (placement !== resetPlacement) return { reset: { placement: resetPlacement } };
			}
			return {};
		}
	};
};
var originSides = /*#__PURE__*/ new Set(["left", "top"]);
async function convertValueToCoords(state, options) {
	const { placement, platform, elements } = state;
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
	const side = getSide(placement);
	const alignment = getAlignment(placement);
	const isVertical = getSideAxis(placement) === "y";
	const mainAxisMulti = originSides.has(side) ? -1 : 1;
	const crossAxisMulti = rtl && isVertical ? -1 : 1;
	const rawValue = evaluate(options, state);
	let { mainAxis, crossAxis, alignmentAxis } = typeof rawValue === "number" ? {
		mainAxis: rawValue,
		crossAxis: 0,
		alignmentAxis: null
	} : {
		mainAxis: rawValue.mainAxis || 0,
		crossAxis: rawValue.crossAxis || 0,
		alignmentAxis: rawValue.alignmentAxis
	};
	if (alignment && typeof alignmentAxis === "number") crossAxis = alignment === "end" ? alignmentAxis * -1 : alignmentAxis;
	return isVertical ? {
		x: crossAxis * crossAxisMulti,
		y: mainAxis * mainAxisMulti
	} : {
		x: mainAxis * mainAxisMulti,
		y: crossAxis * crossAxisMulti
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$2 = function(options) {
	if (options === void 0) options = 0;
	return {
		name: "offset",
		options,
		async fn(state) {
			var _middlewareData$offse, _middlewareData$arrow;
			const { x, y, placement, middlewareData } = state;
			const diffCoords = await convertValueToCoords(state, options);
			if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			return {
				x: x + diffCoords.x,
				y: y + diffCoords.y,
				data: {
					...diffCoords,
					placement
				}
			};
		}
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "shift",
		options,
		async fn(state) {
			const { x, y, placement, platform } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = false, limiter = { fn: (_ref) => {
				let { x, y } = _ref;
				return {
					x,
					y
				};
			} }, ...detectOverflowOptions } = evaluate(options, state);
			const coords = {
				x,
				y
			};
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const crossAxis = getSideAxis(getSide(placement));
			const mainAxis = getOppositeAxis(crossAxis);
			let mainAxisCoord = coords[mainAxis];
			let crossAxisCoord = coords[crossAxis];
			if (checkMainAxis) {
				const minSide = mainAxis === "y" ? "top" : "left";
				const maxSide = mainAxis === "y" ? "bottom" : "right";
				const min = mainAxisCoord + overflow[minSide];
				const max = mainAxisCoord - overflow[maxSide];
				mainAxisCoord = clamp(min, mainAxisCoord, max);
			}
			if (checkCrossAxis) {
				const minSide = crossAxis === "y" ? "top" : "left";
				const maxSide = crossAxis === "y" ? "bottom" : "right";
				const min = crossAxisCoord + overflow[minSide];
				const max = crossAxisCoord - overflow[maxSide];
				crossAxisCoord = clamp(min, crossAxisCoord, max);
			}
			const limitedCoords = limiter.fn({
				...state,
				[mainAxis]: mainAxisCoord,
				[crossAxis]: crossAxisCoord
			});
			return {
				...limitedCoords,
				data: {
					x: limitedCoords.x - x,
					y: limitedCoords.y - y,
					enabled: {
						[mainAxis]: checkMainAxis,
						[crossAxis]: checkCrossAxis
					}
				}
			};
		}
	};
};
//#endregion
//#region ../../node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
function getCssDimensions(element) {
	const css = getComputedStyle$1(element);
	let width = parseFloat(css.width) || 0;
	let height = parseFloat(css.height) || 0;
	const hasOffset = isHTMLElement(element);
	const offsetWidth = hasOffset ? element.offsetWidth : width;
	const offsetHeight = hasOffset ? element.offsetHeight : height;
	const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
	if (shouldFallback) {
		width = offsetWidth;
		height = offsetHeight;
	}
	return {
		width,
		height,
		$: shouldFallback
	};
}
function unwrapElement(element) {
	return !isElement(element) ? element.contextElement : element;
}
function getScale(element) {
	const domElement = unwrapElement(element);
	if (!isHTMLElement(domElement)) return createCoords(1);
	const rect = domElement.getBoundingClientRect();
	const { width, height, $ } = getCssDimensions(domElement);
	let x = ($ ? round(rect.width) : rect.width) / width;
	let y = ($ ? round(rect.height) : rect.height) / height;
	if (!x || !Number.isFinite(x)) x = 1;
	if (!y || !Number.isFinite(y)) y = 1;
	return {
		x,
		y
	};
}
var noOffsets = /*#__PURE__*/ createCoords(0);
function getVisualOffsets(element) {
	const win = getWindow(element);
	if (!isWebKit() || !win.visualViewport) return noOffsets;
	return {
		x: win.visualViewport.offsetLeft,
		y: win.visualViewport.offsetTop
	};
}
function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
	if (isFixed === void 0) isFixed = false;
	if (!floatingOffsetParent || isFixed && floatingOffsetParent !== getWindow(element)) return false;
	return isFixed;
}
function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
	if (includeScale === void 0) includeScale = false;
	if (isFixedStrategy === void 0) isFixedStrategy = false;
	const clientRect = element.getBoundingClientRect();
	const domElement = unwrapElement(element);
	let scale = createCoords(1);
	if (includeScale) if (offsetParent) {
		if (isElement(offsetParent)) scale = getScale(offsetParent);
	} else scale = getScale(element);
	const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
	let x = (clientRect.left + visualOffsets.x) / scale.x;
	let y = (clientRect.top + visualOffsets.y) / scale.y;
	let width = clientRect.width / scale.x;
	let height = clientRect.height / scale.y;
	if (domElement) {
		const win = getWindow(domElement);
		const offsetWin = offsetParent && isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
		let currentWin = win;
		let currentIFrame = getFrameElement(currentWin);
		while (currentIFrame && offsetParent && offsetWin !== currentWin) {
			const iframeScale = getScale(currentIFrame);
			const iframeRect = currentIFrame.getBoundingClientRect();
			const css = getComputedStyle$1(currentIFrame);
			const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
			const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
			x *= iframeScale.x;
			y *= iframeScale.y;
			width *= iframeScale.x;
			height *= iframeScale.y;
			x += left;
			y += top;
			currentWin = getWindow(currentIFrame);
			currentIFrame = getFrameElement(currentWin);
		}
	}
	return rectToClientRect({
		width,
		height,
		x,
		y
	});
}
function getWindowScrollBarX(element, rect) {
	const leftScroll = getNodeScroll(element).scrollLeft;
	if (!rect) return getBoundingClientRect(getDocumentElement(element)).left + leftScroll;
	return rect.left + leftScroll;
}
function getHTMLOffset(documentElement, scroll) {
	const htmlRect = documentElement.getBoundingClientRect();
	return {
		x: htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect),
		y: htmlRect.top + scroll.scrollTop
	};
}
function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
	let { elements, rect, offsetParent, strategy } = _ref;
	const isFixed = strategy === "fixed";
	const documentElement = getDocumentElement(offsetParent);
	const topLayer = elements ? isTopLayer(elements.floating) : false;
	if (offsetParent === documentElement || topLayer && isFixed) return rect;
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	let scale = createCoords(1);
	const offsets = createCoords(0);
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent);
			scale = getScale(offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		}
	}
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		width: rect.width * scale.x,
		height: rect.height * scale.y,
		x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
		y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
	};
}
function getClientRects(element) {
	return Array.from(element.getClientRects());
}
function getDocumentRect(element) {
	const html = getDocumentElement(element);
	const scroll = getNodeScroll(element);
	const body = element.ownerDocument.body;
	const width = max$1(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
	const height = max$1(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
	let x = -scroll.scrollLeft + getWindowScrollBarX(element);
	const y = -scroll.scrollTop;
	if (getComputedStyle$1(body).direction === "rtl") x += max$1(html.clientWidth, body.clientWidth) - width;
	return {
		width,
		height,
		x,
		y
	};
}
var SCROLLBAR_MAX = 25;
function getViewportRect(element, strategy) {
	const win = getWindow(element);
	const html = getDocumentElement(element);
	const visualViewport = win.visualViewport;
	let width = html.clientWidth;
	let height = html.clientHeight;
	let x = 0;
	let y = 0;
	if (visualViewport) {
		width = visualViewport.width;
		height = visualViewport.height;
		const visualViewportBased = isWebKit();
		if (!visualViewportBased || visualViewportBased && strategy === "fixed") {
			x = visualViewport.offsetLeft;
			y = visualViewport.offsetTop;
		}
	}
	const windowScrollbarX = getWindowScrollBarX(html);
	if (windowScrollbarX <= 0) {
		const doc = html.ownerDocument;
		const body = doc.body;
		const bodyStyles = getComputedStyle(body);
		const bodyMarginInline = doc.compatMode === "CSS1Compat" ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
		const clippingStableScrollbarWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
		if (clippingStableScrollbarWidth <= SCROLLBAR_MAX) width -= clippingStableScrollbarWidth;
	} else if (windowScrollbarX <= SCROLLBAR_MAX) width += windowScrollbarX;
	return {
		width,
		height,
		x,
		y
	};
}
function getInnerBoundingClientRect(element, strategy) {
	const clientRect = getBoundingClientRect(element, true, strategy === "fixed");
	const top = clientRect.top + element.clientTop;
	const left = clientRect.left + element.clientLeft;
	const scale = isHTMLElement(element) ? getScale(element) : createCoords(1);
	return {
		width: element.clientWidth * scale.x,
		height: element.clientHeight * scale.y,
		x: left * scale.x,
		y: top * scale.y
	};
}
function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
	let rect;
	if (clippingAncestor === "viewport") rect = getViewportRect(element, strategy);
	else if (clippingAncestor === "document") rect = getDocumentRect(getDocumentElement(element));
	else if (isElement(clippingAncestor)) rect = getInnerBoundingClientRect(clippingAncestor, strategy);
	else {
		const visualOffsets = getVisualOffsets(element);
		rect = {
			x: clippingAncestor.x - visualOffsets.x,
			y: clippingAncestor.y - visualOffsets.y,
			width: clippingAncestor.width,
			height: clippingAncestor.height
		};
	}
	return rectToClientRect(rect);
}
function hasFixedPositionAncestor(element, stopNode) {
	const parentNode = getParentNode(element);
	if (parentNode === stopNode || !isElement(parentNode) || isLastTraversableNode(parentNode)) return false;
	return getComputedStyle$1(parentNode).position === "fixed" || hasFixedPositionAncestor(parentNode, stopNode);
}
function getClippingElementAncestors(element, cache) {
	const cachedResult = cache.get(element);
	if (cachedResult) return cachedResult;
	let result = getOverflowAncestors(element, [], false).filter((el) => isElement(el) && getNodeName(el) !== "body");
	let currentContainingBlockComputedStyle = null;
	const elementIsFixed = getComputedStyle$1(element).position === "fixed";
	let currentNode = elementIsFixed ? getParentNode(element) : element;
	while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
		const computedStyle = getComputedStyle$1(currentNode);
		const currentNodeIsContaining = isContainingBlock(currentNode);
		if (!currentNodeIsContaining && computedStyle.position === "fixed") currentContainingBlockComputedStyle = null;
		if (elementIsFixed ? !currentNodeIsContaining && !currentContainingBlockComputedStyle : !currentNodeIsContaining && computedStyle.position === "static" && !!currentContainingBlockComputedStyle && (currentContainingBlockComputedStyle.position === "absolute" || currentContainingBlockComputedStyle.position === "fixed") || isOverflowElement(currentNode) && !currentNodeIsContaining && hasFixedPositionAncestor(element, currentNode)) result = result.filter((ancestor) => ancestor !== currentNode);
		else currentContainingBlockComputedStyle = computedStyle;
		currentNode = getParentNode(currentNode);
	}
	cache.set(element, result);
	return result;
}
function getClippingRect(_ref) {
	let { element, boundary, rootBoundary, strategy } = _ref;
	const clippingAncestors = [...boundary === "clippingAncestors" ? isTopLayer(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary), rootBoundary];
	const firstRect = getClientRectFromClippingAncestor(element, clippingAncestors[0], strategy);
	let top = firstRect.top;
	let right = firstRect.right;
	let bottom = firstRect.bottom;
	let left = firstRect.left;
	for (let i = 1; i < clippingAncestors.length; i++) {
		const rect = getClientRectFromClippingAncestor(element, clippingAncestors[i], strategy);
		top = max$1(rect.top, top);
		right = min$1(rect.right, right);
		bottom = min$1(rect.bottom, bottom);
		left = max$1(rect.left, left);
	}
	return {
		width: right - left,
		height: bottom - top,
		x: left,
		y: top
	};
}
function getDimensions(element) {
	const { width, height } = getCssDimensions(element);
	return {
		width,
		height
	};
}
function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	const documentElement = getDocumentElement(offsetParent);
	const isFixed = strategy === "fixed";
	const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	const offsets = createCoords(0);
	function setLeftRTLScrollbarOffset() {
		offsets.x = getWindowScrollBarX(documentElement);
	}
	if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		} else if (documentElement) setLeftRTLScrollbarOffset();
	}
	if (isFixed && !isOffsetParentAnElement && documentElement) setLeftRTLScrollbarOffset();
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		x: rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x,
		y: rect.top + scroll.scrollTop - offsets.y - htmlOffset.y,
		width: rect.width,
		height: rect.height
	};
}
function isStaticPositioned(element) {
	return getComputedStyle$1(element).position === "static";
}
function getTrueOffsetParent(element, polyfill) {
	if (!isHTMLElement(element) || getComputedStyle$1(element).position === "fixed") return null;
	if (polyfill) return polyfill(element);
	let rawOffsetParent = element.offsetParent;
	if (getDocumentElement(element) === rawOffsetParent) rawOffsetParent = rawOffsetParent.ownerDocument.body;
	return rawOffsetParent;
}
function getOffsetParent(element, polyfill) {
	const win = getWindow(element);
	if (isTopLayer(element)) return win;
	if (!isHTMLElement(element)) {
		let svgOffsetParent = getParentNode(element);
		while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
			if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) return svgOffsetParent;
			svgOffsetParent = getParentNode(svgOffsetParent);
		}
		return win;
	}
	let offsetParent = getTrueOffsetParent(element, polyfill);
	while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) offsetParent = getTrueOffsetParent(offsetParent, polyfill);
	if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) return win;
	return offsetParent || getContainingBlock(element) || win;
}
var getElementRects = async function(data) {
	const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
	const getDimensionsFn = this.getDimensions;
	const floatingDimensions = await getDimensionsFn(data.floating);
	return {
		reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
		floating: {
			x: 0,
			y: 0,
			width: floatingDimensions.width,
			height: floatingDimensions.height
		}
	};
};
function isRTL(element) {
	return getComputedStyle$1(element).direction === "rtl";
}
var platform = {
	convertOffsetParentRelativeRectToViewportRelativeRect,
	getDocumentElement,
	getClippingRect,
	getOffsetParent,
	getElementRects,
	getClientRects,
	getDimensions,
	getScale,
	isElement,
	isRTL
};
function rectsAreEqual(a, b) {
	return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}
function observeMove(element, onMove) {
	let io = null;
	let timeoutId;
	const root = getDocumentElement(element);
	function cleanup() {
		var _io;
		clearTimeout(timeoutId);
		(_io = io) == null || _io.disconnect();
		io = null;
	}
	function refresh(skip, threshold) {
		if (skip === void 0) skip = false;
		if (threshold === void 0) threshold = 1;
		cleanup();
		const elementRectForRootMargin = element.getBoundingClientRect();
		const { left, top, width, height } = elementRectForRootMargin;
		if (!skip) onMove();
		if (!width || !height) return;
		const insetTop = floor(top);
		const insetRight = floor(root.clientWidth - (left + width));
		const insetBottom = floor(root.clientHeight - (top + height));
		const insetLeft = floor(left);
		const options = {
			rootMargin: -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px",
			threshold: max$1(0, min$1(1, threshold)) || 1
		};
		let isFirstUpdate = true;
		function handleObserve(entries) {
			const ratio = entries[0].intersectionRatio;
			if (ratio !== threshold) {
				if (!isFirstUpdate) return refresh();
				if (!ratio) timeoutId = setTimeout(() => {
					refresh(false, 1e-7);
				}, 1e3);
				else refresh(false, ratio);
			}
			if (ratio === 1 && !rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) refresh();
			isFirstUpdate = false;
		}
		try {
			io = new IntersectionObserver(handleObserve, {
				...options,
				root: root.ownerDocument
			});
		} catch (_e) {
			io = new IntersectionObserver(handleObserve, options);
		}
		io.observe(element);
	}
	refresh(true);
	return cleanup;
}
/**
* Automatically updates the position of the floating element when necessary.
* Should only be called when the floating element is mounted on the DOM or
* visible on the screen.
* @returns cleanup function that should be invoked when the floating element is
* removed from the DOM or hidden from the screen.
* @see https://floating-ui.com/docs/autoUpdate
*/
function autoUpdate(reference, floating, update, options) {
	if (options === void 0) options = {};
	const { ancestorScroll = true, ancestorResize = true, elementResize = typeof ResizeObserver === "function", layoutShift = typeof IntersectionObserver === "function", animationFrame = false } = options;
	const referenceEl = unwrapElement(reference);
	const ancestors = ancestorScroll || ancestorResize ? [...referenceEl ? getOverflowAncestors(referenceEl) : [], ...floating ? getOverflowAncestors(floating) : []] : [];
	ancestors.forEach((ancestor) => {
		ancestorScroll && ancestor.addEventListener("scroll", update, { passive: true });
		ancestorResize && ancestor.addEventListener("resize", update);
	});
	const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update) : null;
	let reobserveFrame = -1;
	let resizeObserver = null;
	if (elementResize) {
		resizeObserver = new ResizeObserver((_ref) => {
			let [firstEntry] = _ref;
			if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating) {
				resizeObserver.unobserve(floating);
				cancelAnimationFrame(reobserveFrame);
				reobserveFrame = requestAnimationFrame(() => {
					var _resizeObserver;
					(_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
				});
			}
			update();
		});
		if (referenceEl && !animationFrame) resizeObserver.observe(referenceEl);
		if (floating) resizeObserver.observe(floating);
	}
	let frameId;
	let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
	if (animationFrame) frameLoop();
	function frameLoop() {
		const nextRefRect = getBoundingClientRect(reference);
		if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) update();
		prevRefRect = nextRefRect;
		frameId = requestAnimationFrame(frameLoop);
	}
	update();
	return () => {
		var _resizeObserver2;
		ancestors.forEach((ancestor) => {
			ancestorScroll && ancestor.removeEventListener("scroll", update);
			ancestorResize && ancestor.removeEventListener("resize", update);
		});
		cleanupIo?.();
		(_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
		resizeObserver = null;
		if (animationFrame) cancelAnimationFrame(frameId);
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$1 = offset$2;
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$1 = shift$2;
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$1 = flip$2;
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$2 = arrow$3;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*/
var computePosition = (reference, floating, options) => {
	const cache = /* @__PURE__ */ new Map();
	const mergedOptions = {
		platform,
		...options
	};
	const platformWithCache = {
		...mergedOptions.platform,
		_c: cache
	};
	return computePosition$1(reference, floating, {
		...mergedOptions,
		platform: platformWithCache
	});
};
//#endregion
//#region ../../node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
var index = typeof document !== "undefined" ? useLayoutEffect : function noop() {};
function deepEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (typeof a === "function" && a.toString() === b.toString()) return true;
	let length;
	let i;
	let keys;
	if (a && b && typeof a === "object") {
		if (Array.isArray(a)) {
			length = a.length;
			if (length !== b.length) return false;
			for (i = length; i-- !== 0;) if (!deepEqual(a[i], b[i])) return false;
			return true;
		}
		keys = Object.keys(a);
		length = keys.length;
		if (length !== Object.keys(b).length) return false;
		for (i = length; i-- !== 0;) if (!{}.hasOwnProperty.call(b, keys[i])) return false;
		for (i = length; i-- !== 0;) {
			const key = keys[i];
			if (key === "_owner" && a.$$typeof) continue;
			if (!deepEqual(a[key], b[key])) return false;
		}
		return true;
	}
	return a !== a && b !== b;
}
function getDPR(element) {
	if (typeof window === "undefined") return 1;
	return (element.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function roundByDPR(element, value) {
	const dpr = getDPR(element);
	return Math.round(value * dpr) / dpr;
}
function useLatestRef(value) {
	const ref = React$1.useRef(value);
	index(() => {
		ref.current = value;
	});
	return ref;
}
/**
* Provides data to position a floating element.
* @see https://floating-ui.com/docs/useFloating
*/
function useFloating$1(options) {
	if (options === void 0) options = {};
	const { placement = "bottom", strategy = "absolute", middleware = [], platform, elements: { reference: externalReference, floating: externalFloating } = {}, transform = true, whileElementsMounted, open } = options;
	const [data, setData] = React$1.useState({
		x: 0,
		y: 0,
		strategy,
		placement,
		middlewareData: {},
		isPositioned: false
	});
	const [latestMiddleware, setLatestMiddleware] = React$1.useState(middleware);
	if (!deepEqual(latestMiddleware, middleware)) setLatestMiddleware(middleware);
	const [_reference, _setReference] = React$1.useState(null);
	const [_floating, _setFloating] = React$1.useState(null);
	const setReference = React$1.useCallback((node) => {
		if (node !== referenceRef.current) {
			referenceRef.current = node;
			_setReference(node);
		}
	}, []);
	const setFloating = React$1.useCallback((node) => {
		if (node !== floatingRef.current) {
			floatingRef.current = node;
			_setFloating(node);
		}
	}, []);
	const referenceEl = externalReference || _reference;
	const floatingEl = externalFloating || _floating;
	const referenceRef = React$1.useRef(null);
	const floatingRef = React$1.useRef(null);
	const dataRef = React$1.useRef(data);
	const hasWhileElementsMounted = whileElementsMounted != null;
	const whileElementsMountedRef = useLatestRef(whileElementsMounted);
	const platformRef = useLatestRef(platform);
	const openRef = useLatestRef(open);
	const update = React$1.useCallback(() => {
		if (!referenceRef.current || !floatingRef.current) return;
		const config = {
			placement,
			strategy,
			middleware: latestMiddleware
		};
		if (platformRef.current) config.platform = platformRef.current;
		computePosition(referenceRef.current, floatingRef.current, config).then((data) => {
			const fullData = {
				...data,
				isPositioned: openRef.current !== false
			};
			if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
				dataRef.current = fullData;
				ReactDOM.flushSync(() => {
					setData(fullData);
				});
			}
		});
	}, [
		latestMiddleware,
		placement,
		strategy,
		platformRef,
		openRef
	]);
	index(() => {
		if (open === false && dataRef.current.isPositioned) {
			dataRef.current.isPositioned = false;
			setData((data) => ({
				...data,
				isPositioned: false
			}));
		}
	}, [open]);
	const isMountedRef = React$1.useRef(false);
	index(() => {
		isMountedRef.current = true;
		return () => {
			isMountedRef.current = false;
		};
	}, []);
	index(() => {
		if (referenceEl) referenceRef.current = referenceEl;
		if (floatingEl) floatingRef.current = floatingEl;
		if (referenceEl && floatingEl) {
			if (whileElementsMountedRef.current) return whileElementsMountedRef.current(referenceEl, floatingEl, update);
			update();
		}
	}, [
		referenceEl,
		floatingEl,
		update,
		whileElementsMountedRef,
		hasWhileElementsMounted
	]);
	const refs = React$1.useMemo(() => ({
		reference: referenceRef,
		floating: floatingRef,
		setReference,
		setFloating
	}), [setReference, setFloating]);
	const elements = React$1.useMemo(() => ({
		reference: referenceEl,
		floating: floatingEl
	}), [referenceEl, floatingEl]);
	const floatingStyles = React$1.useMemo(() => {
		const initialStyles = {
			position: strategy,
			left: 0,
			top: 0
		};
		if (!elements.floating) return initialStyles;
		const x = roundByDPR(elements.floating, data.x);
		const y = roundByDPR(elements.floating, data.y);
		if (transform) return {
			...initialStyles,
			transform: "translate(" + x + "px, " + y + "px)",
			...getDPR(elements.floating) >= 1.5 && { willChange: "transform" }
		};
		return {
			position: strategy,
			left: x,
			top: y
		};
	}, [
		strategy,
		transform,
		elements.floating,
		data.x,
		data.y
	]);
	return React$1.useMemo(() => ({
		...data,
		update,
		refs,
		elements,
		floatingStyles
	}), [
		data,
		update,
		refs,
		elements,
		floatingStyles
	]);
}
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$1 = (options) => {
	function isRef(value) {
		return {}.hasOwnProperty.call(value, "current");
	}
	return {
		name: "arrow",
		options,
		fn(state) {
			const { element, padding } = typeof options === "function" ? options(state) : options;
			if (element && isRef(element)) {
				if (element.current != null) return arrow$2({
					element: element.current,
					padding
				}).fn(state);
				return {};
			}
			if (element) return arrow$2({
				element,
				padding
			}).fn(state);
			return {};
		}
	};
};
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset = (options, deps) => {
	const result = offset$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift = (options, deps) => {
	const result = shift$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip = (options, deps) => {
	const result = flip$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow = (options, deps) => {
	const result = arrow$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
//#endregion
//#region ../../node_modules/@floating-ui/react/dist/floating-ui.react.mjs
/**
* Merges an array of refs into a single memoized callback ref or `null`.
* @see https://floating-ui.com/docs/react-utils#usemergerefs
*/
function useMergeRefs(refs) {
	const cleanupRef = React$1.useRef(void 0);
	const refEffect = React$1.useCallback((instance) => {
		const cleanups = refs.map((ref) => {
			if (ref == null) return;
			if (typeof ref === "function") {
				const refCallback = ref;
				const refCleanup = refCallback(instance);
				return typeof refCleanup === "function" ? refCleanup : () => {
					refCallback(null);
				};
			}
			ref.current = instance;
			return () => {
				ref.current = null;
			};
		});
		return () => {
			cleanups.forEach((refCleanup) => refCleanup == null ? void 0 : refCleanup());
		};
	}, refs);
	return React$1.useMemo(() => {
		if (refs.every((ref) => ref == null)) return null;
		return (value) => {
			if (cleanupRef.current) {
				cleanupRef.current();
				cleanupRef.current = void 0;
			}
			if (value != null) cleanupRef.current = refEffect(value);
		};
	}, refs);
}
var FOCUSABLE_ATTRIBUTE = "data-floating-ui-focusable";
var ACTIVE_KEY = "active";
var SELECTED_KEY = "selected";
var ARROW_LEFT = "ArrowLeft";
var ARROW_RIGHT = "ArrowRight";
var ARROW_UP = "ArrowUp";
var ARROW_DOWN = "ArrowDown";
var horizontalKeys = [ARROW_LEFT, ARROW_RIGHT];
var verticalKeys = [ARROW_UP, ARROW_DOWN];
[...horizontalKeys, ...verticalKeys];
var SafeReact = { ...React$1 };
var serverHandoffComplete = false;
var count$1 = 0;
var genId = () => "floating-ui-" + Math.random().toString(36).slice(2, 6) + count$1++;
function useFloatingId() {
	const [id, setId] = React$1.useState(() => serverHandoffComplete ? genId() : void 0);
	index$1(() => {
		if (id == null) setId(genId());
	}, []);
	React$1.useEffect(() => {
		serverHandoffComplete = true;
	}, []);
	return id;
}
/**
* Uses React 18's built-in `useId()` when available, or falls back to a
* slightly less performant (requiring a double render) implementation for
* earlier React versions.
* @see https://floating-ui.com/docs/react-utils#useid
*/
var useId$1 = SafeReact.useId || useFloatingId;
var devMessageSet;
if (process.env.NODE_ENV !== "production") devMessageSet = /*#__PURE__*/ new Set();
function error() {
	var _devMessageSet3;
	for (var _len2 = arguments.length, messages = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) messages[_key2] = arguments[_key2];
	const message = "Floating UI: " + messages.join(" ");
	if (!((_devMessageSet3 = devMessageSet) != null && _devMessageSet3.has(message))) {
		var _devMessageSet4;
		(_devMessageSet4 = devMessageSet) == null || _devMessageSet4.add(message);
		console.error(message);
	}
}
function createEventEmitter() {
	const map = /* @__PURE__ */ new Map();
	return {
		emit(event, data) {
			var _map$get;
			(_map$get = map.get(event)) == null || _map$get.forEach((listener) => listener(data));
		},
		on(event, listener) {
			if (!map.has(event)) map.set(event, /* @__PURE__ */ new Set());
			map.get(event).add(listener);
		},
		off(event, listener) {
			var _map$get2;
			(_map$get2 = map.get(event)) == null || _map$get2.delete(listener);
		}
	};
}
var FloatingNodeContext = /*#__PURE__*/ React$1.createContext(null);
var FloatingTreeContext = /*#__PURE__*/ React$1.createContext(null);
/**
* Returns the parent node id for nested floating elements, if available.
* Returns `null` for top-level floating elements.
*/
var useFloatingParentNodeId = () => {
	var _React$useContext;
	return ((_React$useContext = React$1.useContext(FloatingNodeContext)) == null ? void 0 : _React$useContext.id) || null;
};
/**
* Returns the nearest floating tree context, if available.
*/
var useFloatingTree = () => React$1.useContext(FloatingTreeContext);
function createAttribute(name) {
	return "data-floating-ui-" + name;
}
function clearTimeoutIfSet(timeoutRef) {
	if (timeoutRef.current !== -1) {
		clearTimeout(timeoutRef.current);
		timeoutRef.current = -1;
	}
}
var safePolygonIdentifier = /*#__PURE__*/ createAttribute("safe-polygon");
function getDelay(value, prop, pointerType) {
	if (pointerType && !isMouseLikePointerType(pointerType)) return 0;
	if (typeof value === "number") return value;
	if (typeof value === "function") {
		const result = value();
		if (typeof result === "number") return result;
		return result == null ? void 0 : result[prop];
	}
	return value == null ? void 0 : value[prop];
}
function getRestMs(value) {
	if (typeof value === "function") return value();
	return value;
}
/**
* Opens the floating element while hovering over the reference element, like
* CSS `:hover`.
* @see https://floating-ui.com/docs/useHover
*/
function useHover(context, props) {
	if (props === void 0) props = {};
	const { open, onOpenChange, dataRef, events, elements } = context;
	const { enabled = true, delay = 0, handleClose = null, mouseOnly = false, restMs = 0, move = true } = props;
	const tree = useFloatingTree();
	const parentId = useFloatingParentNodeId();
	const handleCloseRef = useLatestRef$1(handleClose);
	const delayRef = useLatestRef$1(delay);
	const openRef = useLatestRef$1(open);
	const restMsRef = useLatestRef$1(restMs);
	const pointerTypeRef = React$1.useRef();
	const timeoutRef = React$1.useRef(-1);
	const handlerRef = React$1.useRef();
	const restTimeoutRef = React$1.useRef(-1);
	const blockMouseMoveRef = React$1.useRef(true);
	const performedPointerEventsMutationRef = React$1.useRef(false);
	const unbindMouseMoveRef = React$1.useRef(() => {});
	const restTimeoutPendingRef = React$1.useRef(false);
	const isHoverOpen = useEffectEvent$1(() => {
		var _dataRef$current$open;
		const type = (_dataRef$current$open = dataRef.current.openEvent) == null ? void 0 : _dataRef$current$open.type;
		return (type == null ? void 0 : type.includes("mouse")) && type !== "mousedown";
	});
	React$1.useEffect(() => {
		if (!enabled) return;
		function onOpenChange(_ref) {
			let { open } = _ref;
			if (!open) {
				clearTimeoutIfSet(timeoutRef);
				clearTimeoutIfSet(restTimeoutRef);
				blockMouseMoveRef.current = true;
				restTimeoutPendingRef.current = false;
			}
		}
		events.on("openchange", onOpenChange);
		return () => {
			events.off("openchange", onOpenChange);
		};
	}, [enabled, events]);
	React$1.useEffect(() => {
		if (!enabled) return;
		if (!handleCloseRef.current) return;
		if (!open) return;
		function onLeave(event) {
			if (isHoverOpen()) onOpenChange(false, event, "hover");
		}
		const html = getDocument(elements.floating).documentElement;
		html.addEventListener("mouseleave", onLeave);
		return () => {
			html.removeEventListener("mouseleave", onLeave);
		};
	}, [
		elements.floating,
		open,
		onOpenChange,
		enabled,
		handleCloseRef,
		isHoverOpen
	]);
	const closeWithDelay = React$1.useCallback(function(event, runElseBranch, reason) {
		if (runElseBranch === void 0) runElseBranch = true;
		if (reason === void 0) reason = "hover";
		const closeDelay = getDelay(delayRef.current, "close", pointerTypeRef.current);
		if (closeDelay && !handlerRef.current) {
			clearTimeoutIfSet(timeoutRef);
			timeoutRef.current = window.setTimeout(() => onOpenChange(false, event, reason), closeDelay);
		} else if (runElseBranch) {
			clearTimeoutIfSet(timeoutRef);
			onOpenChange(false, event, reason);
		}
	}, [delayRef, onOpenChange]);
	const cleanupMouseMoveHandler = useEffectEvent$1(() => {
		unbindMouseMoveRef.current();
		handlerRef.current = void 0;
	});
	const clearPointerEvents = useEffectEvent$1(() => {
		if (performedPointerEventsMutationRef.current) {
			const body = getDocument(elements.floating).body;
			body.style.pointerEvents = "";
			body.removeAttribute(safePolygonIdentifier);
			performedPointerEventsMutationRef.current = false;
		}
	});
	const isClickLikeOpenEvent = useEffectEvent$1(() => {
		return dataRef.current.openEvent ? ["click", "mousedown"].includes(dataRef.current.openEvent.type) : false;
	});
	React$1.useEffect(() => {
		if (!enabled) return;
		function onReferenceMouseEnter(event) {
			clearTimeoutIfSet(timeoutRef);
			blockMouseMoveRef.current = false;
			if (mouseOnly && !isMouseLikePointerType(pointerTypeRef.current) || getRestMs(restMsRef.current) > 0 && !getDelay(delayRef.current, "open")) return;
			const openDelay = getDelay(delayRef.current, "open", pointerTypeRef.current);
			if (openDelay) timeoutRef.current = window.setTimeout(() => {
				if (!openRef.current) onOpenChange(true, event, "hover");
			}, openDelay);
			else if (!open) onOpenChange(true, event, "hover");
		}
		function onReferenceMouseLeave(event) {
			if (isClickLikeOpenEvent()) {
				clearPointerEvents();
				return;
			}
			unbindMouseMoveRef.current();
			const doc = getDocument(elements.floating);
			clearTimeoutIfSet(restTimeoutRef);
			restTimeoutPendingRef.current = false;
			if (handleCloseRef.current && dataRef.current.floatingContext) {
				if (!open) clearTimeoutIfSet(timeoutRef);
				handlerRef.current = handleCloseRef.current({
					...dataRef.current.floatingContext,
					tree,
					x: event.clientX,
					y: event.clientY,
					onClose() {
						clearPointerEvents();
						cleanupMouseMoveHandler();
						if (!isClickLikeOpenEvent()) closeWithDelay(event, true, "safe-polygon");
					}
				});
				const handler = handlerRef.current;
				doc.addEventListener("mousemove", handler);
				unbindMouseMoveRef.current = () => {
					doc.removeEventListener("mousemove", handler);
				};
				return;
			}
			if (pointerTypeRef.current === "touch" ? !contains(elements.floating, event.relatedTarget) : true) closeWithDelay(event);
		}
		function onScrollMouseLeave(event) {
			if (isClickLikeOpenEvent()) return;
			if (!dataRef.current.floatingContext) return;
			handleCloseRef.current == null || handleCloseRef.current({
				...dataRef.current.floatingContext,
				tree,
				x: event.clientX,
				y: event.clientY,
				onClose() {
					clearPointerEvents();
					cleanupMouseMoveHandler();
					if (!isClickLikeOpenEvent()) closeWithDelay(event);
				}
			})(event);
		}
		function onFloatingMouseEnter() {
			clearTimeoutIfSet(timeoutRef);
		}
		function onFloatingMouseLeave(event) {
			if (!isClickLikeOpenEvent()) closeWithDelay(event, false);
		}
		if (isElement(elements.domReference)) {
			const reference = elements.domReference;
			const floating = elements.floating;
			if (open) reference.addEventListener("mouseleave", onScrollMouseLeave);
			if (move) reference.addEventListener("mousemove", onReferenceMouseEnter, { once: true });
			reference.addEventListener("mouseenter", onReferenceMouseEnter);
			reference.addEventListener("mouseleave", onReferenceMouseLeave);
			if (floating) {
				floating.addEventListener("mouseleave", onScrollMouseLeave);
				floating.addEventListener("mouseenter", onFloatingMouseEnter);
				floating.addEventListener("mouseleave", onFloatingMouseLeave);
			}
			return () => {
				if (open) reference.removeEventListener("mouseleave", onScrollMouseLeave);
				if (move) reference.removeEventListener("mousemove", onReferenceMouseEnter);
				reference.removeEventListener("mouseenter", onReferenceMouseEnter);
				reference.removeEventListener("mouseleave", onReferenceMouseLeave);
				if (floating) {
					floating.removeEventListener("mouseleave", onScrollMouseLeave);
					floating.removeEventListener("mouseenter", onFloatingMouseEnter);
					floating.removeEventListener("mouseleave", onFloatingMouseLeave);
				}
			};
		}
	}, [
		elements,
		enabled,
		context,
		mouseOnly,
		move,
		closeWithDelay,
		cleanupMouseMoveHandler,
		clearPointerEvents,
		onOpenChange,
		open,
		openRef,
		tree,
		delayRef,
		handleCloseRef,
		dataRef,
		isClickLikeOpenEvent,
		restMsRef
	]);
	index$1(() => {
		var _handleCloseRef$curre;
		if (!enabled) return;
		if (open && (_handleCloseRef$curre = handleCloseRef.current) != null && (_handleCloseRef$curre = _handleCloseRef$curre.__options) != null && _handleCloseRef$curre.blockPointerEvents && isHoverOpen()) {
			performedPointerEventsMutationRef.current = true;
			const floatingEl = elements.floating;
			if (isElement(elements.domReference) && floatingEl) {
				var _tree$nodesRef$curren;
				const body = getDocument(elements.floating).body;
				body.setAttribute(safePolygonIdentifier, "");
				const ref = elements.domReference;
				const parentFloating = tree == null || (_tree$nodesRef$curren = tree.nodesRef.current.find((node) => node.id === parentId)) == null || (_tree$nodesRef$curren = _tree$nodesRef$curren.context) == null ? void 0 : _tree$nodesRef$curren.elements.floating;
				if (parentFloating) parentFloating.style.pointerEvents = "";
				body.style.pointerEvents = "none";
				ref.style.pointerEvents = "auto";
				floatingEl.style.pointerEvents = "auto";
				return () => {
					body.style.pointerEvents = "";
					ref.style.pointerEvents = "";
					floatingEl.style.pointerEvents = "";
				};
			}
		}
	}, [
		enabled,
		open,
		parentId,
		elements,
		tree,
		handleCloseRef,
		isHoverOpen
	]);
	index$1(() => {
		if (!open) {
			pointerTypeRef.current = void 0;
			restTimeoutPendingRef.current = false;
			cleanupMouseMoveHandler();
			clearPointerEvents();
		}
	}, [
		open,
		cleanupMouseMoveHandler,
		clearPointerEvents
	]);
	React$1.useEffect(() => {
		return () => {
			cleanupMouseMoveHandler();
			clearTimeoutIfSet(timeoutRef);
			clearTimeoutIfSet(restTimeoutRef);
			clearPointerEvents();
		};
	}, [
		enabled,
		elements.domReference,
		cleanupMouseMoveHandler,
		clearPointerEvents
	]);
	const reference = React$1.useMemo(() => {
		function setPointerRef(event) {
			pointerTypeRef.current = event.pointerType;
		}
		return {
			onPointerDown: setPointerRef,
			onPointerEnter: setPointerRef,
			onMouseMove(event) {
				const { nativeEvent } = event;
				function handleMouseMove() {
					if (!blockMouseMoveRef.current && !openRef.current) onOpenChange(true, nativeEvent, "hover");
				}
				if (mouseOnly && !isMouseLikePointerType(pointerTypeRef.current)) return;
				if (open || getRestMs(restMsRef.current) === 0) return;
				if (restTimeoutPendingRef.current && event.movementX ** 2 + event.movementY ** 2 < 2) return;
				clearTimeoutIfSet(restTimeoutRef);
				if (pointerTypeRef.current === "touch") handleMouseMove();
				else {
					restTimeoutPendingRef.current = true;
					restTimeoutRef.current = window.setTimeout(handleMouseMove, getRestMs(restMsRef.current));
				}
			}
		};
	}, [
		mouseOnly,
		onOpenChange,
		open,
		openRef,
		restMsRef
	]);
	return React$1.useMemo(() => enabled ? { reference } : {}, [enabled, reference]);
}
var HIDDEN_STYLES = {
	border: 0,
	clip: "rect(0 0 0 0)",
	height: "1px",
	margin: "-1px",
	overflow: "hidden",
	padding: 0,
	position: "fixed",
	whiteSpace: "nowrap",
	width: "1px",
	top: 0,
	left: 0
};
var FocusGuard = /*#__PURE__*/ React$1.forwardRef(function FocusGuard(props, ref) {
	const [role, setRole] = React$1.useState();
	index$1(() => {
		if (isSafari()) setRole("button");
	}, []);
	const restProps = {
		ref,
		tabIndex: 0,
		role,
		"aria-hidden": role ? void 0 : true,
		[createAttribute("focus-guard")]: "",
		style: HIDDEN_STYLES
	};
	return /*#__PURE__*/ jsx("span", {
		...props,
		...restProps
	});
});
var HIDDEN_OWNER_STYLES = {
	clipPath: "inset(50%)",
	position: "fixed",
	top: 0,
	left: 0
};
var PortalContext = /*#__PURE__*/ React$1.createContext(null);
var attr = /*#__PURE__*/ createAttribute("portal");
/**
* @see https://floating-ui.com/docs/FloatingPortal#usefloatingportalnode
*/
function useFloatingPortalNode(props) {
	if (props === void 0) props = {};
	const { id, root } = props;
	const uniqueId = useId$1();
	const portalContext = usePortalContext();
	const [portalNode, setPortalNode] = React$1.useState(null);
	const portalNodeRef = React$1.useRef(null);
	index$1(() => {
		return () => {
			portalNode?.remove();
			queueMicrotask(() => {
				portalNodeRef.current = null;
			});
		};
	}, [portalNode]);
	index$1(() => {
		if (!uniqueId) return;
		if (portalNodeRef.current) return;
		const existingIdRoot = id ? document.getElementById(id) : null;
		if (!existingIdRoot) return;
		const subRoot = document.createElement("div");
		subRoot.id = uniqueId;
		subRoot.setAttribute(attr, "");
		existingIdRoot.appendChild(subRoot);
		portalNodeRef.current = subRoot;
		setPortalNode(subRoot);
	}, [id, uniqueId]);
	index$1(() => {
		if (root === null) return;
		if (!uniqueId) return;
		if (portalNodeRef.current) return;
		let container = root || (portalContext == null ? void 0 : portalContext.portalNode);
		if (container && !isNode(container)) container = container.current;
		container = container || document.body;
		let idWrapper = null;
		if (id) {
			idWrapper = document.createElement("div");
			idWrapper.id = id;
			container.appendChild(idWrapper);
		}
		const subRoot = document.createElement("div");
		subRoot.id = uniqueId;
		subRoot.setAttribute(attr, "");
		container = idWrapper || container;
		container.appendChild(subRoot);
		portalNodeRef.current = subRoot;
		setPortalNode(subRoot);
	}, [
		id,
		root,
		uniqueId,
		portalContext
	]);
	return portalNode;
}
/**
* Portals the floating element into a given container element — by default,
* outside of the app root and into the body.
* This is necessary to ensure the floating element can appear outside any
* potential parent containers that cause clipping (such as `overflow: hidden`),
* while retaining its location in the React tree.
* @see https://floating-ui.com/docs/FloatingPortal
*/
function FloatingPortal(props) {
	const { children, id, root, preserveTabOrder = true } = props;
	const portalNode = useFloatingPortalNode({
		id,
		root
	});
	const [focusManagerState, setFocusManagerState] = React$1.useState(null);
	const beforeOutsideRef = React$1.useRef(null);
	const afterOutsideRef = React$1.useRef(null);
	const beforeInsideRef = React$1.useRef(null);
	const afterInsideRef = React$1.useRef(null);
	const modal = focusManagerState == null ? void 0 : focusManagerState.modal;
	const open = focusManagerState == null ? void 0 : focusManagerState.open;
	const shouldRenderGuards = !!focusManagerState && !focusManagerState.modal && focusManagerState.open && preserveTabOrder && !!(root || portalNode);
	React$1.useEffect(() => {
		if (!portalNode || !preserveTabOrder || modal) return;
		function onFocus(event) {
			if (portalNode && isOutsideEvent(event)) (event.type === "focusin" ? enableFocusInside : disableFocusInside)(portalNode);
		}
		portalNode.addEventListener("focusin", onFocus, true);
		portalNode.addEventListener("focusout", onFocus, true);
		return () => {
			portalNode.removeEventListener("focusin", onFocus, true);
			portalNode.removeEventListener("focusout", onFocus, true);
		};
	}, [
		portalNode,
		preserveTabOrder,
		modal
	]);
	React$1.useEffect(() => {
		if (!portalNode) return;
		if (open) return;
		enableFocusInside(portalNode);
	}, [open, portalNode]);
	return /*#__PURE__*/ jsxs(PortalContext.Provider, {
		value: React$1.useMemo(() => ({
			preserveTabOrder,
			beforeOutsideRef,
			afterOutsideRef,
			beforeInsideRef,
			afterInsideRef,
			portalNode,
			setFocusManagerState
		}), [preserveTabOrder, portalNode]),
		children: [
			shouldRenderGuards && portalNode && /*#__PURE__*/ jsx(FocusGuard, {
				"data-type": "outside",
				ref: beforeOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) {
						var _beforeInsideRef$curr;
						(_beforeInsideRef$curr = beforeInsideRef.current) == null || _beforeInsideRef$curr.focus();
					} else getPreviousTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
				}
			}),
			shouldRenderGuards && portalNode && /*#__PURE__*/ jsx("span", {
				"aria-owns": portalNode.id,
				style: HIDDEN_OWNER_STYLES
			}),
			portalNode && /*#__PURE__*/ ReactDOM.createPortal(children, portalNode),
			shouldRenderGuards && portalNode && /*#__PURE__*/ jsx(FocusGuard, {
				"data-type": "outside",
				ref: afterOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) {
						var _afterInsideRef$curre;
						(_afterInsideRef$curre = afterInsideRef.current) == null || _afterInsideRef$curre.focus();
					} else {
						getNextTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
						focusManagerState != null && focusManagerState.closeOnFocusOut && focusManagerState?.onOpenChange(false, event.nativeEvent, "focus-out");
					}
				}
			})
		]
	});
}
var usePortalContext = () => React$1.useContext(PortalContext);
function isButtonTarget(event) {
	return isHTMLElement(event.target) && event.target.tagName === "BUTTON";
}
function isAnchorTarget(event) {
	return isHTMLElement(event.target) && event.target.tagName === "A";
}
function isSpaceIgnored(element) {
	return isTypeableElement(element);
}
/**
* Opens or closes the floating element when clicking the reference element.
* @see https://floating-ui.com/docs/useClick
*/
function useClick(context, props) {
	if (props === void 0) props = {};
	const { open, onOpenChange, dataRef, elements: { domReference } } = context;
	const { enabled = true, event: eventOption = "click", toggle = true, ignoreMouse = false, keyboardHandlers = true, stickIfOpen = true } = props;
	const pointerTypeRef = React$1.useRef();
	const didKeyDownRef = React$1.useRef(false);
	const reference = React$1.useMemo(() => ({
		onPointerDown(event) {
			pointerTypeRef.current = event.pointerType;
		},
		onMouseDown(event) {
			const pointerType = pointerTypeRef.current;
			if (event.button !== 0) return;
			if (eventOption === "click") return;
			if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
			if (open && toggle && (dataRef.current.openEvent && stickIfOpen ? dataRef.current.openEvent.type === "mousedown" : true)) onOpenChange(false, event.nativeEvent, "click");
			else {
				event.preventDefault();
				onOpenChange(true, event.nativeEvent, "click");
			}
		},
		onClick(event) {
			const pointerType = pointerTypeRef.current;
			if (eventOption === "mousedown" && pointerTypeRef.current) {
				pointerTypeRef.current = void 0;
				return;
			}
			if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
			if (open && toggle && (dataRef.current.openEvent && stickIfOpen ? dataRef.current.openEvent.type === "click" : true)) onOpenChange(false, event.nativeEvent, "click");
			else onOpenChange(true, event.nativeEvent, "click");
		},
		onKeyDown(event) {
			pointerTypeRef.current = void 0;
			if (event.defaultPrevented || !keyboardHandlers || isButtonTarget(event)) return;
			if (event.key === " " && !isSpaceIgnored(domReference)) {
				event.preventDefault();
				didKeyDownRef.current = true;
			}
			if (isAnchorTarget(event)) return;
			if (event.key === "Enter") if (open && toggle) onOpenChange(false, event.nativeEvent, "click");
			else onOpenChange(true, event.nativeEvent, "click");
		},
		onKeyUp(event) {
			if (event.defaultPrevented || !keyboardHandlers || isButtonTarget(event) || isSpaceIgnored(domReference)) return;
			if (event.key === " " && didKeyDownRef.current) {
				didKeyDownRef.current = false;
				if (open && toggle) onOpenChange(false, event.nativeEvent, "click");
				else onOpenChange(true, event.nativeEvent, "click");
			}
		}
	}), [
		dataRef,
		domReference,
		eventOption,
		ignoreMouse,
		keyboardHandlers,
		onOpenChange,
		open,
		stickIfOpen,
		toggle
	]);
	return React$1.useMemo(() => enabled ? { reference } : {}, [enabled, reference]);
}
var bubbleHandlerKeys = {
	pointerdown: "onPointerDown",
	mousedown: "onMouseDown",
	click: "onClick"
};
var captureHandlerKeys = {
	pointerdown: "onPointerDownCapture",
	mousedown: "onMouseDownCapture",
	click: "onClickCapture"
};
var normalizeProp = (normalizable) => {
	var _normalizable$escapeK, _normalizable$outside;
	return {
		escapeKey: typeof normalizable === "boolean" ? normalizable : (_normalizable$escapeK = normalizable == null ? void 0 : normalizable.escapeKey) != null ? _normalizable$escapeK : false,
		outsidePress: typeof normalizable === "boolean" ? normalizable : (_normalizable$outside = normalizable == null ? void 0 : normalizable.outsidePress) != null ? _normalizable$outside : true
	};
};
/**
* Closes the floating element when a dismissal is requested — by default, when
* the user presses the `escape` key or outside of the floating element.
* @see https://floating-ui.com/docs/useDismiss
*/
function useDismiss(context, props) {
	if (props === void 0) props = {};
	const { open, onOpenChange, elements, dataRef } = context;
	const { enabled = true, escapeKey = true, outsidePress: unstable_outsidePress = true, outsidePressEvent = "pointerdown", referencePress = false, referencePressEvent = "pointerdown", ancestorScroll = false, bubbles, capture } = props;
	const tree = useFloatingTree();
	const outsidePressFn = useEffectEvent$1(typeof unstable_outsidePress === "function" ? unstable_outsidePress : () => false);
	const outsidePress = typeof unstable_outsidePress === "function" ? outsidePressFn : unstable_outsidePress;
	const endedOrStartedInsideRef = React$1.useRef(false);
	const { escapeKey: escapeKeyBubbles, outsidePress: outsidePressBubbles } = normalizeProp(bubbles);
	const { escapeKey: escapeKeyCapture, outsidePress: outsidePressCapture } = normalizeProp(capture);
	const isComposingRef = React$1.useRef(false);
	const closeOnEscapeKeyDown = useEffectEvent$1((event) => {
		var _dataRef$current$floa;
		if (!open || !enabled || !escapeKey || event.key !== "Escape") return;
		if (isComposingRef.current) return;
		const nodeId = (_dataRef$current$floa = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa.nodeId;
		const children = tree ? getNodeChildren(tree.nodesRef.current, nodeId) : [];
		if (!escapeKeyBubbles) {
			event.stopPropagation();
			if (children.length > 0) {
				let shouldDismiss = true;
				children.forEach((child) => {
					var _child$context;
					if ((_child$context = child.context) != null && _child$context.open && !child.context.dataRef.current.__escapeKeyBubbles) {
						shouldDismiss = false;
						return;
					}
				});
				if (!shouldDismiss) return;
			}
		}
		onOpenChange(false, isReactEvent(event) ? event.nativeEvent : event, "escape-key");
	});
	const closeOnEscapeKeyDownCapture = useEffectEvent$1((event) => {
		var _getTarget2;
		const callback = () => {
			var _getTarget;
			closeOnEscapeKeyDown(event);
			(_getTarget = getTarget(event)) == null || _getTarget.removeEventListener("keydown", callback);
		};
		(_getTarget2 = getTarget(event)) == null || _getTarget2.addEventListener("keydown", callback);
	});
	const closeOnPressOutside = useEffectEvent$1((event) => {
		var _dataRef$current$floa2;
		const insideReactTree = dataRef.current.insideReactTree;
		dataRef.current.insideReactTree = false;
		const endedOrStartedInside = endedOrStartedInsideRef.current;
		endedOrStartedInsideRef.current = false;
		if (outsidePressEvent === "click" && endedOrStartedInside) return;
		if (insideReactTree) return;
		if (typeof outsidePress === "function" && !outsidePress(event)) return;
		const target = getTarget(event);
		const inertSelector = "[" + createAttribute("inert") + "]";
		const markers = getDocument(elements.floating).querySelectorAll(inertSelector);
		let targetRootAncestor = isElement(target) ? target : null;
		while (targetRootAncestor && !isLastTraversableNode(targetRootAncestor)) {
			const nextParent = getParentNode(targetRootAncestor);
			if (isLastTraversableNode(nextParent) || !isElement(nextParent)) break;
			targetRootAncestor = nextParent;
		}
		if (markers.length && isElement(target) && !isRootElement(target) && !contains(target, elements.floating) && Array.from(markers).every((marker) => !contains(targetRootAncestor, marker))) return;
		if (isHTMLElement(target) && floating) {
			const lastTraversableNode = isLastTraversableNode(target);
			const style = getComputedStyle$1(target);
			const scrollRe = /auto|scroll/;
			const isScrollableX = lastTraversableNode || scrollRe.test(style.overflowX);
			const isScrollableY = lastTraversableNode || scrollRe.test(style.overflowY);
			const canScrollX = isScrollableX && target.clientWidth > 0 && target.scrollWidth > target.clientWidth;
			const canScrollY = isScrollableY && target.clientHeight > 0 && target.scrollHeight > target.clientHeight;
			const isRTL = style.direction === "rtl";
			const pressedVerticalScrollbar = canScrollY && (isRTL ? event.offsetX <= target.offsetWidth - target.clientWidth : event.offsetX > target.clientWidth);
			const pressedHorizontalScrollbar = canScrollX && event.offsetY > target.clientHeight;
			if (pressedVerticalScrollbar || pressedHorizontalScrollbar) return;
		}
		const nodeId = (_dataRef$current$floa2 = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa2.nodeId;
		const targetIsInsideChildren = tree && getNodeChildren(tree.nodesRef.current, nodeId).some((node) => {
			var _node$context;
			return isEventTargetWithin(event, (_node$context = node.context) == null ? void 0 : _node$context.elements.floating);
		});
		if (isEventTargetWithin(event, elements.floating) || isEventTargetWithin(event, elements.domReference) || targetIsInsideChildren) return;
		const children = tree ? getNodeChildren(tree.nodesRef.current, nodeId) : [];
		if (children.length > 0) {
			let shouldDismiss = true;
			children.forEach((child) => {
				var _child$context2;
				if ((_child$context2 = child.context) != null && _child$context2.open && !child.context.dataRef.current.__outsidePressBubbles) {
					shouldDismiss = false;
					return;
				}
			});
			if (!shouldDismiss) return;
		}
		onOpenChange(false, event, "outside-press");
	});
	const closeOnPressOutsideCapture = useEffectEvent$1((event) => {
		var _getTarget4;
		const callback = () => {
			var _getTarget3;
			closeOnPressOutside(event);
			(_getTarget3 = getTarget(event)) == null || _getTarget3.removeEventListener(outsidePressEvent, callback);
		};
		(_getTarget4 = getTarget(event)) == null || _getTarget4.addEventListener(outsidePressEvent, callback);
	});
	React$1.useEffect(() => {
		if (!open || !enabled) return;
		dataRef.current.__escapeKeyBubbles = escapeKeyBubbles;
		dataRef.current.__outsidePressBubbles = outsidePressBubbles;
		let compositionTimeout = -1;
		function onScroll(event) {
			onOpenChange(false, event, "ancestor-scroll");
		}
		function handleCompositionStart() {
			window.clearTimeout(compositionTimeout);
			isComposingRef.current = true;
		}
		function handleCompositionEnd() {
			compositionTimeout = window.setTimeout(() => {
				isComposingRef.current = false;
			}, isWebKit() ? 5 : 0);
		}
		const doc = getDocument(elements.floating);
		if (escapeKey) {
			doc.addEventListener("keydown", escapeKeyCapture ? closeOnEscapeKeyDownCapture : closeOnEscapeKeyDown, escapeKeyCapture);
			doc.addEventListener("compositionstart", handleCompositionStart);
			doc.addEventListener("compositionend", handleCompositionEnd);
		}
		outsidePress && doc.addEventListener(outsidePressEvent, outsidePressCapture ? closeOnPressOutsideCapture : closeOnPressOutside, outsidePressCapture);
		let ancestors = [];
		if (ancestorScroll) {
			if (isElement(elements.domReference)) ancestors = getOverflowAncestors(elements.domReference);
			if (isElement(elements.floating)) ancestors = ancestors.concat(getOverflowAncestors(elements.floating));
			if (!isElement(elements.reference) && elements.reference && elements.reference.contextElement) ancestors = ancestors.concat(getOverflowAncestors(elements.reference.contextElement));
		}
		ancestors = ancestors.filter((ancestor) => {
			var _doc$defaultView;
			return ancestor !== ((_doc$defaultView = doc.defaultView) == null ? void 0 : _doc$defaultView.visualViewport);
		});
		ancestors.forEach((ancestor) => {
			ancestor.addEventListener("scroll", onScroll, { passive: true });
		});
		return () => {
			if (escapeKey) {
				doc.removeEventListener("keydown", escapeKeyCapture ? closeOnEscapeKeyDownCapture : closeOnEscapeKeyDown, escapeKeyCapture);
				doc.removeEventListener("compositionstart", handleCompositionStart);
				doc.removeEventListener("compositionend", handleCompositionEnd);
			}
			outsidePress && doc.removeEventListener(outsidePressEvent, outsidePressCapture ? closeOnPressOutsideCapture : closeOnPressOutside, outsidePressCapture);
			ancestors.forEach((ancestor) => {
				ancestor.removeEventListener("scroll", onScroll);
			});
			window.clearTimeout(compositionTimeout);
		};
	}, [
		dataRef,
		elements,
		escapeKey,
		outsidePress,
		outsidePressEvent,
		open,
		onOpenChange,
		ancestorScroll,
		enabled,
		escapeKeyBubbles,
		outsidePressBubbles,
		closeOnEscapeKeyDown,
		escapeKeyCapture,
		closeOnEscapeKeyDownCapture,
		closeOnPressOutside,
		outsidePressCapture,
		closeOnPressOutsideCapture
	]);
	React$1.useEffect(() => {
		dataRef.current.insideReactTree = false;
	}, [
		dataRef,
		outsidePress,
		outsidePressEvent
	]);
	const reference = React$1.useMemo(() => ({
		onKeyDown: closeOnEscapeKeyDown,
		...referencePress && {
			[bubbleHandlerKeys[referencePressEvent]]: (event) => {
				onOpenChange(false, event.nativeEvent, "reference-press");
			},
			...referencePressEvent !== "click" && { onClick(event) {
				onOpenChange(false, event.nativeEvent, "reference-press");
			} }
		}
	}), [
		closeOnEscapeKeyDown,
		onOpenChange,
		referencePress,
		referencePressEvent
	]);
	const floating = React$1.useMemo(() => {
		function setMouseDownOrUpInside(event) {
			if (event.button !== 0) return;
			endedOrStartedInsideRef.current = true;
		}
		return {
			onKeyDown: closeOnEscapeKeyDown,
			onMouseDown: setMouseDownOrUpInside,
			onMouseUp: setMouseDownOrUpInside,
			[captureHandlerKeys[outsidePressEvent]]: () => {
				dataRef.current.insideReactTree = true;
			}
		};
	}, [
		closeOnEscapeKeyDown,
		outsidePressEvent,
		dataRef
	]);
	return React$1.useMemo(() => enabled ? {
		reference,
		floating
	} : {}, [
		enabled,
		reference,
		floating
	]);
}
function useFloatingRootContext(options) {
	const { open = false, onOpenChange: onOpenChangeProp, elements: elementsProp } = options;
	const floatingId = useId$1();
	const dataRef = React$1.useRef({});
	const [events] = React$1.useState(() => createEventEmitter());
	const nested = useFloatingParentNodeId() != null;
	if (process.env.NODE_ENV !== "production") {
		const optionDomReference = elementsProp.reference;
		if (optionDomReference && !isElement(optionDomReference)) error("Cannot pass a virtual element to the `elements.reference` option,", "as it must be a real DOM element. Use `refs.setPositionReference()`", "instead.");
	}
	const [positionReference, setPositionReference] = React$1.useState(elementsProp.reference);
	const onOpenChange = useEffectEvent$1((open, event, reason) => {
		dataRef.current.openEvent = open ? event : void 0;
		events.emit("openchange", {
			open,
			event,
			reason,
			nested
		});
		onOpenChangeProp?.(open, event, reason);
	});
	const refs = React$1.useMemo(() => ({ setPositionReference }), []);
	const elements = React$1.useMemo(() => ({
		reference: positionReference || elementsProp.reference || null,
		floating: elementsProp.floating || null,
		domReference: elementsProp.reference
	}), [
		positionReference,
		elementsProp.reference,
		elementsProp.floating
	]);
	return React$1.useMemo(() => ({
		dataRef,
		open,
		onOpenChange,
		elements,
		events,
		floatingId,
		refs
	}), [
		open,
		onOpenChange,
		elements,
		events,
		floatingId,
		refs
	]);
}
/**
* Provides data to position a floating element and context to add interactions.
* @see https://floating-ui.com/docs/useFloating
*/
function useFloating(options) {
	if (options === void 0) options = {};
	const { nodeId } = options;
	const internalRootContext = useFloatingRootContext({
		...options,
		elements: {
			reference: null,
			floating: null,
			...options.elements
		}
	});
	const rootContext = options.rootContext || internalRootContext;
	const computedElements = rootContext.elements;
	const [_domReference, setDomReference] = React$1.useState(null);
	const [positionReference, _setPositionReference] = React$1.useState(null);
	const domReference = (computedElements == null ? void 0 : computedElements.domReference) || _domReference;
	const domReferenceRef = React$1.useRef(null);
	const tree = useFloatingTree();
	index$1(() => {
		if (domReference) domReferenceRef.current = domReference;
	}, [domReference]);
	const position = useFloating$1({
		...options,
		elements: {
			...computedElements,
			...positionReference && { reference: positionReference }
		}
	});
	const setPositionReference = React$1.useCallback((node) => {
		const computedPositionReference = isElement(node) ? {
			getBoundingClientRect: () => node.getBoundingClientRect(),
			getClientRects: () => node.getClientRects(),
			contextElement: node
		} : node;
		_setPositionReference(computedPositionReference);
		position.refs.setReference(computedPositionReference);
	}, [position.refs]);
	const setReference = React$1.useCallback((node) => {
		if (isElement(node) || node === null) {
			domReferenceRef.current = node;
			setDomReference(node);
		}
		if (isElement(position.refs.reference.current) || position.refs.reference.current === null || node !== null && !isElement(node)) position.refs.setReference(node);
	}, [position.refs]);
	const refs = React$1.useMemo(() => ({
		...position.refs,
		setReference,
		setPositionReference,
		domReference: domReferenceRef
	}), [
		position.refs,
		setReference,
		setPositionReference
	]);
	const elements = React$1.useMemo(() => ({
		...position.elements,
		domReference
	}), [position.elements, domReference]);
	const context = React$1.useMemo(() => ({
		...position,
		...rootContext,
		refs,
		elements,
		nodeId
	}), [
		position,
		refs,
		elements,
		nodeId,
		rootContext
	]);
	index$1(() => {
		rootContext.dataRef.current.floatingContext = context;
		const node = tree == null ? void 0 : tree.nodesRef.current.find((node) => node.id === nodeId);
		if (node) node.context = context;
	});
	return React$1.useMemo(() => ({
		...position,
		context,
		refs,
		elements
	}), [
		position,
		refs,
		elements,
		context
	]);
}
function isMacSafari() {
	return isMac() && isSafari();
}
/**
* Opens the floating element while the reference element has focus, like CSS
* `:focus`.
* @see https://floating-ui.com/docs/useFocus
*/
function useFocus(context, props) {
	if (props === void 0) props = {};
	const { open, onOpenChange, events, dataRef, elements } = context;
	const { enabled = true, visibleOnly = true } = props;
	const blockFocusRef = React$1.useRef(false);
	const timeoutRef = React$1.useRef(-1);
	const keyboardModalityRef = React$1.useRef(true);
	React$1.useEffect(() => {
		if (!enabled) return;
		const win = getWindow(elements.domReference);
		function onBlur() {
			if (!open && isHTMLElement(elements.domReference) && elements.domReference === activeElement(getDocument(elements.domReference))) blockFocusRef.current = true;
		}
		function onKeyDown() {
			keyboardModalityRef.current = true;
		}
		function onPointerDown() {
			keyboardModalityRef.current = false;
		}
		win.addEventListener("blur", onBlur);
		if (isMacSafari()) {
			win.addEventListener("keydown", onKeyDown, true);
			win.addEventListener("pointerdown", onPointerDown, true);
		}
		return () => {
			win.removeEventListener("blur", onBlur);
			if (isMacSafari()) {
				win.removeEventListener("keydown", onKeyDown, true);
				win.removeEventListener("pointerdown", onPointerDown, true);
			}
		};
	}, [
		elements.domReference,
		open,
		enabled
	]);
	React$1.useEffect(() => {
		if (!enabled) return;
		function onOpenChange(_ref) {
			let { reason } = _ref;
			if (reason === "reference-press" || reason === "escape-key") blockFocusRef.current = true;
		}
		events.on("openchange", onOpenChange);
		return () => {
			events.off("openchange", onOpenChange);
		};
	}, [events, enabled]);
	React$1.useEffect(() => {
		return () => {
			clearTimeoutIfSet(timeoutRef);
		};
	}, []);
	const reference = React$1.useMemo(() => ({
		onMouseLeave() {
			blockFocusRef.current = false;
		},
		onFocus(event) {
			if (blockFocusRef.current) return;
			const target = getTarget(event.nativeEvent);
			if (visibleOnly && isElement(target)) {
				if (isMacSafari() && !event.relatedTarget) {
					if (!keyboardModalityRef.current && !isTypeableElement(target)) return;
				} else if (!matchesFocusVisible(target)) return;
			}
			onOpenChange(true, event.nativeEvent, "focus");
		},
		onBlur(event) {
			blockFocusRef.current = false;
			const relatedTarget = event.relatedTarget;
			const nativeEvent = event.nativeEvent;
			const movedToFocusGuard = isElement(relatedTarget) && relatedTarget.hasAttribute(createAttribute("focus-guard")) && relatedTarget.getAttribute("data-type") === "outside";
			timeoutRef.current = window.setTimeout(() => {
				var _dataRef$current$floa;
				const activeEl = activeElement(elements.domReference ? elements.domReference.ownerDocument : document);
				if (!relatedTarget && activeEl === elements.domReference) return;
				if (contains((_dataRef$current$floa = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa.refs.floating.current, activeEl) || contains(elements.domReference, activeEl) || movedToFocusGuard) return;
				onOpenChange(false, nativeEvent, "focus");
			});
		}
	}), [
		dataRef,
		elements.domReference,
		onOpenChange,
		visibleOnly
	]);
	return React$1.useMemo(() => enabled ? { reference } : {}, [enabled, reference]);
}
function mergeProps(userProps, propsList, elementKey) {
	const map = /* @__PURE__ */ new Map();
	const isItem = elementKey === "item";
	let domUserProps = userProps;
	if (isItem && userProps) {
		const { [ACTIVE_KEY]: _, [SELECTED_KEY]: __, ...validProps } = userProps;
		domUserProps = validProps;
	}
	return {
		...elementKey === "floating" && {
			tabIndex: -1,
			[FOCUSABLE_ATTRIBUTE]: ""
		},
		...domUserProps,
		...propsList.map((value) => {
			const propsOrGetProps = value ? value[elementKey] : null;
			if (typeof propsOrGetProps === "function") return userProps ? propsOrGetProps(userProps) : null;
			return propsOrGetProps;
		}).concat(userProps).reduce((acc, props) => {
			if (!props) return acc;
			Object.entries(props).forEach((_ref) => {
				let [key, value] = _ref;
				if (isItem && [ACTIVE_KEY, SELECTED_KEY].includes(key)) return;
				if (key.indexOf("on") === 0) {
					if (!map.has(key)) map.set(key, []);
					if (typeof value === "function") {
						var _map$get;
						(_map$get = map.get(key)) == null || _map$get.push(value);
						acc[key] = function() {
							var _map$get2;
							for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
							return (_map$get2 = map.get(key)) == null ? void 0 : _map$get2.map((fn) => fn(...args)).find((val) => val !== void 0);
						};
					}
				} else acc[key] = value;
			});
			return acc;
		}, {})
	};
}
/**
* Merges an array of interaction hooks' props into prop getters, allowing
* event handler functions to be composed together without overwriting one
* another.
* @see https://floating-ui.com/docs/useInteractions
*/
function useInteractions(propsList) {
	if (propsList === void 0) propsList = [];
	const referenceDeps = propsList.map((key) => key == null ? void 0 : key.reference);
	const floatingDeps = propsList.map((key) => key == null ? void 0 : key.floating);
	const itemDeps = propsList.map((key) => key == null ? void 0 : key.item);
	const getReferenceProps = React$1.useCallback((userProps) => mergeProps(userProps, propsList, "reference"), referenceDeps);
	const getFloatingProps = React$1.useCallback((userProps) => mergeProps(userProps, propsList, "floating"), floatingDeps);
	const getItemProps = React$1.useCallback((userProps) => mergeProps(userProps, propsList, "item"), itemDeps);
	return React$1.useMemo(() => ({
		getReferenceProps,
		getFloatingProps,
		getItemProps
	}), [
		getReferenceProps,
		getFloatingProps,
		getItemProps
	]);
}
var componentRoleToAriaRoleMap = /*#__PURE__*/ new Map([
	["select", "listbox"],
	["combobox", "listbox"],
	["label", false]
]);
/**
* Adds base screen reader props to the reference and floating elements for a
* given floating element `role`.
* @see https://floating-ui.com/docs/useRole
*/
function useRole(context, props) {
	var _elements$domReferenc, _componentRoleToAriaR;
	if (props === void 0) props = {};
	const { open, elements, floatingId: defaultFloatingId } = context;
	const { enabled = true, role = "dialog" } = props;
	const defaultReferenceId = useId$1();
	const referenceId = ((_elements$domReferenc = elements.domReference) == null ? void 0 : _elements$domReferenc.id) || defaultReferenceId;
	const floatingId = React$1.useMemo(() => {
		var _getFloatingFocusElem;
		return ((_getFloatingFocusElem = getFloatingFocusElement(elements.floating)) == null ? void 0 : _getFloatingFocusElem.id) || defaultFloatingId;
	}, [elements.floating, defaultFloatingId]);
	const ariaRole = (_componentRoleToAriaR = componentRoleToAriaRoleMap.get(role)) != null ? _componentRoleToAriaR : role;
	const isNested = useFloatingParentNodeId() != null;
	const reference = React$1.useMemo(() => {
		if (ariaRole === "tooltip" || role === "label") return { ["aria-" + (role === "label" ? "labelledby" : "describedby")]: open ? floatingId : void 0 };
		return {
			"aria-expanded": open ? "true" : "false",
			"aria-haspopup": ariaRole === "alertdialog" ? "dialog" : ariaRole,
			"aria-controls": open ? floatingId : void 0,
			...ariaRole === "listbox" && { role: "combobox" },
			...ariaRole === "menu" && { id: referenceId },
			...ariaRole === "menu" && isNested && { role: "menuitem" },
			...role === "select" && { "aria-autocomplete": "none" },
			...role === "combobox" && { "aria-autocomplete": "list" }
		};
	}, [
		ariaRole,
		floatingId,
		isNested,
		open,
		referenceId,
		role
	]);
	const floating = React$1.useMemo(() => {
		const floatingProps = {
			id: floatingId,
			...ariaRole && { role: ariaRole }
		};
		if (ariaRole === "tooltip" || role === "label") return floatingProps;
		return {
			...floatingProps,
			...ariaRole === "menu" && { "aria-labelledby": referenceId }
		};
	}, [
		ariaRole,
		floatingId,
		referenceId,
		role
	]);
	const item = React$1.useCallback((_ref) => {
		let { active, selected } = _ref;
		const commonProps = {
			role: "option",
			...active && { id: floatingId + "-fui-option" }
		};
		switch (role) {
			case "select":
			case "combobox": return {
				...commonProps,
				"aria-selected": selected
			};
		}
		return {};
	}, [floatingId, role]);
	return React$1.useMemo(() => enabled ? {
		reference,
		floating,
		item
	} : {}, [
		enabled,
		reference,
		floating,
		item
	]);
}
var camelCaseToKebabCase = (str) => str.replace(/[A-Z]+(?![a-z])|[A-Z]/g, ($, ofs) => (ofs ? "-" : "") + $.toLowerCase());
function execWithArgsOrReturn(valueOrFn, args) {
	return typeof valueOrFn === "function" ? valueOrFn(args) : valueOrFn;
}
function useDelayUnmount(open, durationMs) {
	const [isMounted, setIsMounted] = React$1.useState(open);
	if (open && !isMounted) setIsMounted(true);
	React$1.useEffect(() => {
		if (!open && isMounted) {
			const timeout = setTimeout(() => setIsMounted(false), durationMs);
			return () => clearTimeout(timeout);
		}
	}, [
		open,
		isMounted,
		durationMs
	]);
	return isMounted;
}
/**
* Provides a status string to apply CSS transitions to a floating element,
* correctly handling placement-aware transitions.
* @see https://floating-ui.com/docs/useTransition#usetransitionstatus
*/
function useTransitionStatus(context, props) {
	if (props === void 0) props = {};
	const { open, elements: { floating } } = context;
	const { duration = 250 } = props;
	const closeDuration = (typeof duration === "number" ? duration : duration.close) || 0;
	const [status, setStatus] = React$1.useState("unmounted");
	const isMounted = useDelayUnmount(open, closeDuration);
	if (!isMounted && status === "close") setStatus("unmounted");
	index$1(() => {
		if (!floating) return;
		if (open) {
			setStatus("initial");
			const frame = requestAnimationFrame(() => {
				ReactDOM.flushSync(() => {
					setStatus("open");
				});
			});
			return () => {
				cancelAnimationFrame(frame);
			};
		}
		setStatus("close");
	}, [open, floating]);
	return {
		isMounted,
		status
	};
}
/**
* Provides styles to apply CSS transitions to a floating element, correctly
* handling placement-aware transitions. Wrapper around `useTransitionStatus`.
* @see https://floating-ui.com/docs/useTransition#usetransitionstyles
*/
function useTransitionStyles(context, props) {
	if (props === void 0) props = {};
	const { initial: unstable_initial = { opacity: 0 }, open: unstable_open, close: unstable_close, common: unstable_common, duration = 250 } = props;
	const placement = context.placement;
	const side = placement.split("-")[0];
	const fnArgs = React$1.useMemo(() => ({
		side,
		placement
	}), [side, placement]);
	const isNumberDuration = typeof duration === "number";
	const openDuration = (isNumberDuration ? duration : duration.open) || 0;
	const closeDuration = (isNumberDuration ? duration : duration.close) || 0;
	const [styles, setStyles] = React$1.useState(() => ({
		...execWithArgsOrReturn(unstable_common, fnArgs),
		...execWithArgsOrReturn(unstable_initial, fnArgs)
	}));
	const { isMounted, status } = useTransitionStatus(context, { duration });
	const initialRef = useLatestRef$1(unstable_initial);
	const openRef = useLatestRef$1(unstable_open);
	const closeRef = useLatestRef$1(unstable_close);
	const commonRef = useLatestRef$1(unstable_common);
	index$1(() => {
		const initialStyles = execWithArgsOrReturn(initialRef.current, fnArgs);
		const closeStyles = execWithArgsOrReturn(closeRef.current, fnArgs);
		const commonStyles = execWithArgsOrReturn(commonRef.current, fnArgs);
		const openStyles = execWithArgsOrReturn(openRef.current, fnArgs) || Object.keys(initialStyles).reduce((acc, key) => {
			acc[key] = "";
			return acc;
		}, {});
		if (status === "initial") setStyles((styles) => ({
			transitionProperty: styles.transitionProperty,
			...commonStyles,
			...initialStyles
		}));
		if (status === "open") setStyles({
			transitionProperty: Object.keys(openStyles).map(camelCaseToKebabCase).join(","),
			transitionDuration: openDuration + "ms",
			...commonStyles,
			...openStyles
		});
		if (status === "close") {
			const styles = closeStyles || initialStyles;
			setStyles({
				transitionProperty: Object.keys(styles).map(camelCaseToKebabCase).join(","),
				transitionDuration: closeDuration + "ms",
				...commonStyles,
				...styles
			});
		}
	}, [
		closeDuration,
		closeRef,
		initialRef,
		openRef,
		commonRef,
		openDuration,
		status,
		fnArgs
	]);
	return {
		isMounted,
		styles
	};
}
//#endregion
//#region ../../resources/scripts/components/elements/tooltip/Tooltip.tsx
function useTooltipInteractions(context, enabled, { interactions = ["hover", "focus"], rest = 30, delay = 0 }) {
	return useInteractions([
		useHover(context, {
			restMs: rest,
			delay,
			mouseOnly: true,
			enabled: enabled && interactions.includes("hover")
		}),
		useFocus(context, { enabled: enabled && interactions.includes("focus") }),
		useClick(context, { enabled: enabled && interactions.includes("click") }),
		useRole(context, {
			role: "tooltip",
			enabled
		}),
		useDismiss(context, { enabled })
	]);
}
function TooltipArrow({ ref, ui, position }) {
	return /* @__PURE__ */ jsx("div", {
		ref,
		style: { transform: `translate(${Math.round(position?.x || 0)}px, ${Math.round(position?.y || 0)}px) rotate(45deg)` },
		...ui("arrow")
	});
}
function Tooltip$1({ children, ...props }) {
	const arrowEl = useRef(null);
	const [open, setOpen] = useState(false);
	const enabled = !props.disabled;
	if (!enabled && open) setOpen(false);
	const { refs, floatingStyles, middlewareData, context, placement } = useFloating({
		open: open && enabled,
		strategy: "fixed",
		transform: false,
		placement: props.placement || "top",
		middleware: [
			offset(props.arrow ? 10 : 6),
			flip(),
			shift({ padding: 6 }),
			arrow({
				element: arrowEl,
				padding: 6
			})
		],
		onOpenChange: setOpen,
		whileElementsMounted: autoUpdate
	});
	const { getReferenceProps, getFloatingProps } = useTooltipInteractions(context, enabled, props);
	const { isMounted, styles: transitionStyles } = useTransitionStyles(context, {
		duration: {
			open: 100,
			close: 75
		},
		initial: {
			opacity: 0,
			transform: "scale(0.85)"
		},
		open: {
			opacity: 1,
			transform: "scale(1)"
		},
		close: { opacity: 0 }
	});
	const referenceRef = useMergeRefs([refs.setReference, children.props.ref]);
	const ui = useSkin("Tooltip", {
		side: placement.split("-")[0],
		arrow: !!props.arrow
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [cloneElement(children, getReferenceProps({
		...children.props,
		ref: referenceRef
	})), isMounted && /* @__PURE__ */ jsx(FloatingPortal, { children: /* @__PURE__ */ jsxs("div", {
		...getFloatingProps({
			ref: refs.setFloating,
			...ui("root", props.className),
			style: {
				...floatingStyles,
				...transitionStyles
			}
		}),
		children: [props.content, props.arrow && /* @__PURE__ */ jsx(TooltipArrow, {
			ref: arrowEl,
			ui,
			position: middlewareData.arrow
		})]
	}) })] });
}
//#endregion
//#region ../../resources/scripts/components/elements/SecretInput.tsx
var SecretInput = ({ id, value, label }) => {
	const [visible, setVisible] = useState(false);
	const toggleLabel = `${visible ? "Hide" : "Show"} ${label.toLowerCase()}`;
	const copyLabel = `Copy ${label.toLowerCase()}`;
	return /* @__PURE__ */ jsxs("div", {
		className: "relative",
		children: [/* @__PURE__ */ jsx(TextInput, {
			id,
			type: visible ? "text" : "password",
			readOnly: true,
			autoComplete: "off",
			spellCheck: false,
			value: value ?? "",
			className: "pr-20 font-mono"
		}), /* @__PURE__ */ jsxs("div", {
			className: "absolute inset-y-0 right-2 flex items-center gap-1",
			children: [/* @__PURE__ */ jsx(Tooltip$1, {
				content: toggleLabel,
				children: /* @__PURE__ */ jsx("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
						type: "button",
						size: "xsmall",
						isSecondary: true,
						"aria-label": toggleLabel,
						"aria-pressed": visible,
						disabled: !value,
						onClick: () => setVisible((current) => !current),
						children: /* @__PURE__ */ jsx(Icon, {
							icon: visible ? EyeOff : Eye,
							className: "h-3.5 w-3.5"
						})
					})
				})
			}), /* @__PURE__ */ jsx(Tooltip$1, {
				content: copyLabel,
				children: /* @__PURE__ */ jsx("span", {
					className: "inline-flex",
					children: /* @__PURE__ */ jsx(CopyOnClick, {
						text: value,
						showInNotification: false,
						children: /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
							type: "button",
							size: "xsmall",
							isSecondary: true,
							"aria-label": copyLabel,
							disabled: !value,
							children: /* @__PURE__ */ jsx(Icon, {
								icon: Copy,
								className: "h-3.5 w-3.5"
							})
						})
					})
				})
			})]
		})]
	});
};
//#endregion
//#region ../../node_modules/@tanstack/table-core/build/lib/index.mjs
/**
* table-core
*
* Copyright (c) TanStack
*
* This source code is licensed under the MIT license found in the
* LICENSE.md file in the root directory of this source tree.
*
* @license MIT
*/
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
function makeStateUpdater(key, instance) {
	return (updater) => {
		instance.setState((old) => {
			return {
				...old,
				[key]: functionalUpdate(updater, old[key])
			};
		});
	};
}
function isFunction(d) {
	return d instanceof Function;
}
function isNumberArray(d) {
	return Array.isArray(d) && d.every((val) => typeof val === "number");
}
function flattenBy(arr, getChildren) {
	const flat = [];
	const recurse = (subArr) => {
		subArr.forEach((item) => {
			flat.push(item);
			const children = getChildren(item);
			if (children != null && children.length) recurse(children);
		});
	};
	recurse(arr);
	return flat;
}
function memo$1(getDeps, fn, opts) {
	let deps = [];
	let result;
	return (depArgs) => {
		let depTime;
		if (opts.key && opts.debug) depTime = Date.now();
		const newDeps = getDeps(depArgs);
		if (!(newDeps.length !== deps.length || newDeps.some((dep, index) => deps[index] !== dep))) return result;
		deps = newDeps;
		let resultTime;
		if (opts.key && opts.debug) resultTime = Date.now();
		result = fn(...newDeps);
		opts == null || opts.onChange == null || opts.onChange(result);
		if (opts.key && opts.debug) {
			if (opts != null && opts.debug()) {
				const depEndTime = Math.round((Date.now() - depTime) * 100) / 100;
				const resultEndTime = Math.round((Date.now() - resultTime) * 100) / 100;
				const resultFpsPercentage = resultEndTime / 16;
				const pad = (str, num) => {
					str = String(str);
					while (str.length < num) str = " " + str;
					return str;
				};
				console.info(`%c⏱ ${pad(resultEndTime, 5)} /${pad(depEndTime, 5)} ms`, `
            font-size: .6rem;
            font-weight: bold;
            color: hsl(${Math.max(0, Math.min(120 - 120 * resultFpsPercentage, 120))}deg 100% 31%);`, opts == null ? void 0 : opts.key);
			}
		}
		return result;
	};
}
function getMemoOptions(tableOptions, debugLevel, key, onChange) {
	return {
		debug: () => {
			var _tableOptions$debugAl;
			return (_tableOptions$debugAl = tableOptions == null ? void 0 : tableOptions.debugAll) != null ? _tableOptions$debugAl : tableOptions[debugLevel];
		},
		key: process.env.NODE_ENV === "development" && key,
		onChange
	};
}
function createCell(table, row, column, columnId) {
	const getRenderValue = () => {
		var _cell$getValue;
		return (_cell$getValue = cell.getValue()) != null ? _cell$getValue : table.options.renderFallbackValue;
	};
	const cell = {
		id: `${row.id}_${column.id}`,
		row,
		column,
		getValue: () => row.getValue(columnId),
		renderValue: getRenderValue,
		getContext: memo$1(() => [
			table,
			column,
			row,
			cell
		], (table, column, row, cell) => ({
			table,
			column,
			row,
			cell,
			getValue: cell.getValue,
			renderValue: cell.renderValue
		}), getMemoOptions(table.options, "debugCells", "cell.getContext"))
	};
	table._features.forEach((feature) => {
		feature.createCell == null || feature.createCell(cell, column, row, table);
	}, {});
	return cell;
}
function createColumn(table, columnDef, depth, parent) {
	var _ref, _resolvedColumnDef$id;
	const resolvedColumnDef = {
		...table._getDefaultColumnDef(),
		...columnDef
	};
	const accessorKey = resolvedColumnDef.accessorKey;
	let id = (_ref = (_resolvedColumnDef$id = resolvedColumnDef.id) != null ? _resolvedColumnDef$id : accessorKey ? typeof String.prototype.replaceAll === "function" ? accessorKey.replaceAll(".", "_") : accessorKey.replace(/\./g, "_") : void 0) != null ? _ref : typeof resolvedColumnDef.header === "string" ? resolvedColumnDef.header : void 0;
	let accessorFn;
	if (resolvedColumnDef.accessorFn) accessorFn = resolvedColumnDef.accessorFn;
	else if (accessorKey) if (accessorKey.includes(".")) accessorFn = (originalRow) => {
		let result = originalRow;
		for (const key of accessorKey.split(".")) {
			var _result;
			result = (_result = result) == null ? void 0 : _result[key];
			if (process.env.NODE_ENV !== "production" && result === void 0) console.warn(`"${key}" in deeply nested key "${accessorKey}" returned undefined.`);
		}
		return result;
	};
	else accessorFn = (originalRow) => originalRow[resolvedColumnDef.accessorKey];
	if (!id) {
		if (process.env.NODE_ENV !== "production") throw new Error(resolvedColumnDef.accessorFn ? `Columns require an id when using an accessorFn` : `Columns require an id when using a non-string header`);
		throw new Error();
	}
	let column = {
		id: `${String(id)}`,
		accessorFn,
		parent,
		depth,
		columnDef: resolvedColumnDef,
		columns: [],
		getFlatColumns: memo$1(() => [true], () => {
			var _column$columns;
			return [column, ...(_column$columns = column.columns) == null ? void 0 : _column$columns.flatMap((d) => d.getFlatColumns())];
		}, getMemoOptions(table.options, "debugColumns", "column.getFlatColumns")),
		getLeafColumns: memo$1(() => [table._getOrderColumnsFn()], (orderColumns) => {
			var _column$columns2;
			if ((_column$columns2 = column.columns) != null && _column$columns2.length) return orderColumns(column.columns.flatMap((column) => column.getLeafColumns()));
			return [column];
		}, getMemoOptions(table.options, "debugColumns", "column.getLeafColumns"))
	};
	for (const feature of table._features) feature.createColumn == null || feature.createColumn(column, table);
	return column;
}
var debug = "debugHeaders";
function createHeader(table, column, options) {
	var _options$id;
	let header = {
		id: (_options$id = options.id) != null ? _options$id : column.id,
		column,
		index: options.index,
		isPlaceholder: !!options.isPlaceholder,
		placeholderId: options.placeholderId,
		depth: options.depth,
		subHeaders: [],
		colSpan: 0,
		rowSpan: 0,
		headerGroup: null,
		getLeafHeaders: () => {
			const leafHeaders = [];
			const recurseHeader = (h) => {
				if (h.subHeaders && h.subHeaders.length) h.subHeaders.map(recurseHeader);
				leafHeaders.push(h);
			};
			recurseHeader(header);
			return leafHeaders;
		},
		getContext: () => ({
			table,
			header,
			column
		})
	};
	table._features.forEach((feature) => {
		feature.createHeader == null || feature.createHeader(header, table);
	});
	return header;
}
var Headers = { createTable: (table) => {
	table.getHeaderGroups = memo$1(() => [
		table.getAllColumns(),
		table.getVisibleLeafColumns(),
		table.getState().columnPinning.left,
		table.getState().columnPinning.right
	], (allColumns, leafColumns, left, right) => {
		var _left$map$filter, _right$map$filter;
		const leftColumns = (_left$map$filter = left == null ? void 0 : left.map((columnId) => leafColumns.find((d) => d.id === columnId)).filter(Boolean)) != null ? _left$map$filter : [];
		const rightColumns = (_right$map$filter = right == null ? void 0 : right.map((columnId) => leafColumns.find((d) => d.id === columnId)).filter(Boolean)) != null ? _right$map$filter : [];
		const centerColumns = leafColumns.filter((column) => !(left != null && left.includes(column.id)) && !(right != null && right.includes(column.id)));
		return buildHeaderGroups(allColumns, [
			...leftColumns,
			...centerColumns,
			...rightColumns
		], table);
	}, getMemoOptions(table.options, debug, "getHeaderGroups"));
	table.getCenterHeaderGroups = memo$1(() => [
		table.getAllColumns(),
		table.getVisibleLeafColumns(),
		table.getState().columnPinning.left,
		table.getState().columnPinning.right
	], (allColumns, leafColumns, left, right) => {
		leafColumns = leafColumns.filter((column) => !(left != null && left.includes(column.id)) && !(right != null && right.includes(column.id)));
		return buildHeaderGroups(allColumns, leafColumns, table, "center");
	}, getMemoOptions(table.options, debug, "getCenterHeaderGroups"));
	table.getLeftHeaderGroups = memo$1(() => [
		table.getAllColumns(),
		table.getVisibleLeafColumns(),
		table.getState().columnPinning.left
	], (allColumns, leafColumns, left) => {
		var _left$map$filter2;
		return buildHeaderGroups(allColumns, (_left$map$filter2 = left == null ? void 0 : left.map((columnId) => leafColumns.find((d) => d.id === columnId)).filter(Boolean)) != null ? _left$map$filter2 : [], table, "left");
	}, getMemoOptions(table.options, debug, "getLeftHeaderGroups"));
	table.getRightHeaderGroups = memo$1(() => [
		table.getAllColumns(),
		table.getVisibleLeafColumns(),
		table.getState().columnPinning.right
	], (allColumns, leafColumns, right) => {
		var _right$map$filter2;
		return buildHeaderGroups(allColumns, (_right$map$filter2 = right == null ? void 0 : right.map((columnId) => leafColumns.find((d) => d.id === columnId)).filter(Boolean)) != null ? _right$map$filter2 : [], table, "right");
	}, getMemoOptions(table.options, debug, "getRightHeaderGroups"));
	table.getFooterGroups = memo$1(() => [table.getHeaderGroups()], (headerGroups) => {
		return [...headerGroups].reverse();
	}, getMemoOptions(table.options, debug, "getFooterGroups"));
	table.getLeftFooterGroups = memo$1(() => [table.getLeftHeaderGroups()], (headerGroups) => {
		return [...headerGroups].reverse();
	}, getMemoOptions(table.options, debug, "getLeftFooterGroups"));
	table.getCenterFooterGroups = memo$1(() => [table.getCenterHeaderGroups()], (headerGroups) => {
		return [...headerGroups].reverse();
	}, getMemoOptions(table.options, debug, "getCenterFooterGroups"));
	table.getRightFooterGroups = memo$1(() => [table.getRightHeaderGroups()], (headerGroups) => {
		return [...headerGroups].reverse();
	}, getMemoOptions(table.options, debug, "getRightFooterGroups"));
	table.getFlatHeaders = memo$1(() => [table.getHeaderGroups()], (headerGroups) => {
		return headerGroups.map((headerGroup) => {
			return headerGroup.headers;
		}).flat();
	}, getMemoOptions(table.options, debug, "getFlatHeaders"));
	table.getLeftFlatHeaders = memo$1(() => [table.getLeftHeaderGroups()], (left) => {
		return left.map((headerGroup) => {
			return headerGroup.headers;
		}).flat();
	}, getMemoOptions(table.options, debug, "getLeftFlatHeaders"));
	table.getCenterFlatHeaders = memo$1(() => [table.getCenterHeaderGroups()], (left) => {
		return left.map((headerGroup) => {
			return headerGroup.headers;
		}).flat();
	}, getMemoOptions(table.options, debug, "getCenterFlatHeaders"));
	table.getRightFlatHeaders = memo$1(() => [table.getRightHeaderGroups()], (left) => {
		return left.map((headerGroup) => {
			return headerGroup.headers;
		}).flat();
	}, getMemoOptions(table.options, debug, "getRightFlatHeaders"));
	table.getCenterLeafHeaders = memo$1(() => [table.getCenterFlatHeaders()], (flatHeaders) => {
		return flatHeaders.filter((header) => {
			var _header$subHeaders;
			return !((_header$subHeaders = header.subHeaders) != null && _header$subHeaders.length);
		});
	}, getMemoOptions(table.options, debug, "getCenterLeafHeaders"));
	table.getLeftLeafHeaders = memo$1(() => [table.getLeftFlatHeaders()], (flatHeaders) => {
		return flatHeaders.filter((header) => {
			var _header$subHeaders2;
			return !((_header$subHeaders2 = header.subHeaders) != null && _header$subHeaders2.length);
		});
	}, getMemoOptions(table.options, debug, "getLeftLeafHeaders"));
	table.getRightLeafHeaders = memo$1(() => [table.getRightFlatHeaders()], (flatHeaders) => {
		return flatHeaders.filter((header) => {
			var _header$subHeaders3;
			return !((_header$subHeaders3 = header.subHeaders) != null && _header$subHeaders3.length);
		});
	}, getMemoOptions(table.options, debug, "getRightLeafHeaders"));
	table.getLeafHeaders = memo$1(() => [
		table.getLeftHeaderGroups(),
		table.getCenterHeaderGroups(),
		table.getRightHeaderGroups()
	], (left, center, right) => {
		var _left$0$headers, _left$, _center$0$headers, _center$, _right$0$headers, _right$;
		return [
			...(_left$0$headers = (_left$ = left[0]) == null ? void 0 : _left$.headers) != null ? _left$0$headers : [],
			...(_center$0$headers = (_center$ = center[0]) == null ? void 0 : _center$.headers) != null ? _center$0$headers : [],
			...(_right$0$headers = (_right$ = right[0]) == null ? void 0 : _right$.headers) != null ? _right$0$headers : []
		].map((header) => {
			return header.getLeafHeaders();
		}).flat();
	}, getMemoOptions(table.options, debug, "getLeafHeaders"));
} };
function buildHeaderGroups(allColumns, columnsToGroup, table, headerFamily) {
	var _headerGroups$0$heade, _headerGroups$;
	let maxDepth = 0;
	const findMaxDepth = function(columns, depth) {
		if (depth === void 0) depth = 1;
		maxDepth = Math.max(maxDepth, depth);
		columns.filter((column) => column.getIsVisible()).forEach((column) => {
			var _column$columns;
			if ((_column$columns = column.columns) != null && _column$columns.length) findMaxDepth(column.columns, depth + 1);
		}, 0);
	};
	findMaxDepth(allColumns);
	let headerGroups = [];
	const createHeaderGroup = (headersToGroup, depth) => {
		const headerGroup = {
			depth,
			id: [headerFamily, `${depth}`].filter(Boolean).join("_"),
			headers: []
		};
		const pendingParentHeaders = [];
		headersToGroup.forEach((headerToGroup) => {
			const latestPendingParentHeader = [...pendingParentHeaders].reverse()[0];
			const isLeafHeader = headerToGroup.column.depth === headerGroup.depth;
			let column;
			let isPlaceholder = false;
			if (isLeafHeader && headerToGroup.column.parent) column = headerToGroup.column.parent;
			else {
				column = headerToGroup.column;
				isPlaceholder = true;
			}
			if (latestPendingParentHeader && (latestPendingParentHeader == null ? void 0 : latestPendingParentHeader.column) === column) latestPendingParentHeader.subHeaders.push(headerToGroup);
			else {
				const header = createHeader(table, column, {
					id: [
						headerFamily,
						depth,
						column.id,
						headerToGroup == null ? void 0 : headerToGroup.id
					].filter(Boolean).join("_"),
					isPlaceholder,
					placeholderId: isPlaceholder ? `${pendingParentHeaders.filter((d) => d.column === column).length}` : void 0,
					depth,
					index: pendingParentHeaders.length
				});
				header.subHeaders.push(headerToGroup);
				pendingParentHeaders.push(header);
			}
			headerGroup.headers.push(headerToGroup);
			headerToGroup.headerGroup = headerGroup;
		});
		headerGroups.push(headerGroup);
		if (depth > 0) createHeaderGroup(pendingParentHeaders, depth - 1);
	};
	createHeaderGroup(columnsToGroup.map((column, index) => createHeader(table, column, {
		depth: maxDepth,
		index
	})), maxDepth - 1);
	headerGroups.reverse();
	const recurseHeadersForSpans = (headers) => {
		return headers.filter((header) => header.column.getIsVisible()).map((header) => {
			let colSpan = 0;
			let rowSpan = 0;
			let childRowSpans = [0];
			if (header.subHeaders && header.subHeaders.length) {
				childRowSpans = [];
				recurseHeadersForSpans(header.subHeaders).forEach((_ref) => {
					let { colSpan: childColSpan, rowSpan: childRowSpan } = _ref;
					colSpan += childColSpan;
					childRowSpans.push(childRowSpan);
				});
			} else colSpan = 1;
			const minChildRowSpan = Math.min(...childRowSpans);
			rowSpan = rowSpan + minChildRowSpan;
			header.colSpan = colSpan;
			header.rowSpan = rowSpan;
			return {
				colSpan,
				rowSpan
			};
		});
	};
	recurseHeadersForSpans((_headerGroups$0$heade = (_headerGroups$ = headerGroups[0]) == null ? void 0 : _headerGroups$.headers) != null ? _headerGroups$0$heade : []);
	return headerGroups;
}
var createRow = (table, id, original, rowIndex, depth, subRows, parentId) => {
	let row = {
		id,
		index: rowIndex,
		original,
		depth,
		parentId,
		_valuesCache: {},
		_uniqueValuesCache: {},
		getValue: (columnId) => {
			if (row._valuesCache.hasOwnProperty(columnId)) return row._valuesCache[columnId];
			const column = table.getColumn(columnId);
			if (!(column != null && column.accessorFn)) return;
			row._valuesCache[columnId] = column.accessorFn(row.original, rowIndex);
			return row._valuesCache[columnId];
		},
		getUniqueValues: (columnId) => {
			if (row._uniqueValuesCache.hasOwnProperty(columnId)) return row._uniqueValuesCache[columnId];
			const column = table.getColumn(columnId);
			if (!(column != null && column.accessorFn)) return;
			if (!column.columnDef.getUniqueValues) {
				row._uniqueValuesCache[columnId] = [row.getValue(columnId)];
				return row._uniqueValuesCache[columnId];
			}
			row._uniqueValuesCache[columnId] = column.columnDef.getUniqueValues(row.original, rowIndex);
			return row._uniqueValuesCache[columnId];
		},
		renderValue: (columnId) => {
			var _row$getValue;
			return (_row$getValue = row.getValue(columnId)) != null ? _row$getValue : table.options.renderFallbackValue;
		},
		subRows: subRows != null ? subRows : [],
		getLeafRows: () => flattenBy(row.subRows, (d) => d.subRows),
		getParentRow: () => row.parentId ? table.getRow(row.parentId, true) : void 0,
		getParentRows: () => {
			let parentRows = [];
			let currentRow = row;
			while (true) {
				const parentRow = currentRow.getParentRow();
				if (!parentRow) break;
				parentRows.push(parentRow);
				currentRow = parentRow;
			}
			return parentRows.reverse();
		},
		getAllCells: memo$1(() => [table.getAllLeafColumns()], (leafColumns) => {
			return leafColumns.map((column) => {
				return createCell(table, row, column, column.id);
			});
		}, getMemoOptions(table.options, "debugRows", "getAllCells")),
		_getAllCellsByColumnId: memo$1(() => [row.getAllCells()], (allCells) => {
			return allCells.reduce((acc, cell) => {
				acc[cell.column.id] = cell;
				return acc;
			}, {});
		}, getMemoOptions(table.options, "debugRows", "getAllCellsByColumnId"))
	};
	for (let i = 0; i < table._features.length; i++) {
		const feature = table._features[i];
		feature == null || feature.createRow == null || feature.createRow(row, table);
	}
	return row;
};
var ColumnFaceting = { createColumn: (column, table) => {
	column._getFacetedRowModel = table.options.getFacetedRowModel && table.options.getFacetedRowModel(table, column.id);
	column.getFacetedRowModel = () => {
		if (!column._getFacetedRowModel) return table.getPreFilteredRowModel();
		return column._getFacetedRowModel();
	};
	column._getFacetedUniqueValues = table.options.getFacetedUniqueValues && table.options.getFacetedUniqueValues(table, column.id);
	column.getFacetedUniqueValues = () => {
		if (!column._getFacetedUniqueValues) return /* @__PURE__ */ new Map();
		return column._getFacetedUniqueValues();
	};
	column._getFacetedMinMaxValues = table.options.getFacetedMinMaxValues && table.options.getFacetedMinMaxValues(table, column.id);
	column.getFacetedMinMaxValues = () => {
		if (!column._getFacetedMinMaxValues) return;
		return column._getFacetedMinMaxValues();
	};
} };
var includesString = (row, columnId, filterValue) => {
	var _filterValue$toString, _row$getValue;
	const search = filterValue == null || (_filterValue$toString = filterValue.toString()) == null ? void 0 : _filterValue$toString.toLowerCase();
	return Boolean((_row$getValue = row.getValue(columnId)) == null || (_row$getValue = _row$getValue.toString()) == null || (_row$getValue = _row$getValue.toLowerCase()) == null ? void 0 : _row$getValue.includes(search));
};
includesString.autoRemove = (val) => testFalsey(val);
var includesStringSensitive = (row, columnId, filterValue) => {
	var _row$getValue2;
	return Boolean((_row$getValue2 = row.getValue(columnId)) == null || (_row$getValue2 = _row$getValue2.toString()) == null ? void 0 : _row$getValue2.includes(filterValue));
};
includesStringSensitive.autoRemove = (val) => testFalsey(val);
var equalsString = (row, columnId, filterValue) => {
	var _row$getValue3;
	return ((_row$getValue3 = row.getValue(columnId)) == null || (_row$getValue3 = _row$getValue3.toString()) == null ? void 0 : _row$getValue3.toLowerCase()) === (filterValue == null ? void 0 : filterValue.toLowerCase());
};
equalsString.autoRemove = (val) => testFalsey(val);
var arrIncludes = (row, columnId, filterValue) => {
	var _row$getValue4;
	return (_row$getValue4 = row.getValue(columnId)) == null ? void 0 : _row$getValue4.includes(filterValue);
};
arrIncludes.autoRemove = (val) => testFalsey(val);
var arrIncludesAll = (row, columnId, filterValue) => {
	return !filterValue.some((val) => {
		var _row$getValue5;
		return !((_row$getValue5 = row.getValue(columnId)) != null && _row$getValue5.includes(val));
	});
};
arrIncludesAll.autoRemove = (val) => testFalsey(val) || !(val != null && val.length);
var arrIncludesSome = (row, columnId, filterValue) => {
	return filterValue.some((val) => {
		var _row$getValue6;
		return (_row$getValue6 = row.getValue(columnId)) == null ? void 0 : _row$getValue6.includes(val);
	});
};
arrIncludesSome.autoRemove = (val) => testFalsey(val) || !(val != null && val.length);
var equals = (row, columnId, filterValue) => {
	return row.getValue(columnId) === filterValue;
};
equals.autoRemove = (val) => testFalsey(val);
var weakEquals = (row, columnId, filterValue) => {
	return row.getValue(columnId) == filterValue;
};
weakEquals.autoRemove = (val) => testFalsey(val);
var inNumberRange = (row, columnId, filterValue) => {
	let [min, max] = filterValue;
	const rowValue = row.getValue(columnId);
	return rowValue >= min && rowValue <= max;
};
inNumberRange.resolveFilterValue = (val) => {
	let [unsafeMin, unsafeMax] = val;
	let parsedMin = typeof unsafeMin !== "number" ? parseFloat(unsafeMin) : unsafeMin;
	let parsedMax = typeof unsafeMax !== "number" ? parseFloat(unsafeMax) : unsafeMax;
	let min = unsafeMin === null || Number.isNaN(parsedMin) ? -Infinity : parsedMin;
	let max = unsafeMax === null || Number.isNaN(parsedMax) ? Infinity : parsedMax;
	if (min > max) {
		const temp = min;
		min = max;
		max = temp;
	}
	return [min, max];
};
inNumberRange.autoRemove = (val) => testFalsey(val) || testFalsey(val[0]) && testFalsey(val[1]);
var filterFns = {
	includesString,
	includesStringSensitive,
	equalsString,
	arrIncludes,
	arrIncludesAll,
	arrIncludesSome,
	equals,
	weakEquals,
	inNumberRange
};
function testFalsey(val) {
	return val === void 0 || val === null || val === "";
}
var ColumnFiltering = {
	getDefaultColumnDef: () => {
		return { filterFn: "auto" };
	},
	getInitialState: (state) => {
		return {
			columnFilters: [],
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onColumnFiltersChange: makeStateUpdater("columnFilters", table),
			filterFromLeafRows: false,
			maxLeafRowFilterDepth: 100
		};
	},
	createColumn: (column, table) => {
		column.getAutoFilterFn = () => {
			const firstRow = table.getCoreRowModel().flatRows[0];
			const value = firstRow == null ? void 0 : firstRow.getValue(column.id);
			if (typeof value === "string") return filterFns.includesString;
			if (typeof value === "number") return filterFns.inNumberRange;
			if (typeof value === "boolean") return filterFns.equals;
			if (value !== null && typeof value === "object") return filterFns.equals;
			if (Array.isArray(value)) return filterFns.arrIncludes;
			return filterFns.weakEquals;
		};
		column.getFilterFn = () => {
			var _table$options$filter, _table$options$filter2;
			return isFunction(column.columnDef.filterFn) ? column.columnDef.filterFn : column.columnDef.filterFn === "auto" ? column.getAutoFilterFn() : (_table$options$filter = (_table$options$filter2 = table.options.filterFns) == null ? void 0 : _table$options$filter2[column.columnDef.filterFn]) != null ? _table$options$filter : filterFns[column.columnDef.filterFn];
		};
		column.getCanFilter = () => {
			var _column$columnDef$ena, _table$options$enable, _table$options$enable2;
			return ((_column$columnDef$ena = column.columnDef.enableColumnFilter) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableColumnFilters) != null ? _table$options$enable : true) && ((_table$options$enable2 = table.options.enableFilters) != null ? _table$options$enable2 : true) && !!column.accessorFn;
		};
		column.getIsFiltered = () => column.getFilterIndex() > -1;
		column.getFilterValue = () => {
			var _table$getState$colum;
			return (_table$getState$colum = table.getState().columnFilters) == null || (_table$getState$colum = _table$getState$colum.find((d) => d.id === column.id)) == null ? void 0 : _table$getState$colum.value;
		};
		column.getFilterIndex = () => {
			var _table$getState$colum2, _table$getState$colum3;
			return (_table$getState$colum2 = (_table$getState$colum3 = table.getState().columnFilters) == null ? void 0 : _table$getState$colum3.findIndex((d) => d.id === column.id)) != null ? _table$getState$colum2 : -1;
		};
		column.setFilterValue = (value) => {
			table.setColumnFilters((old) => {
				const filterFn = column.getFilterFn();
				const previousFilter = old == null ? void 0 : old.find((d) => d.id === column.id);
				const newFilter = functionalUpdate(value, previousFilter ? previousFilter.value : void 0);
				if (shouldAutoRemoveFilter(filterFn, newFilter, column)) {
					var _old$filter;
					return (_old$filter = old == null ? void 0 : old.filter((d) => d.id !== column.id)) != null ? _old$filter : [];
				}
				const newFilterObj = {
					id: column.id,
					value: newFilter
				};
				if (previousFilter) {
					var _old$map;
					return (_old$map = old == null ? void 0 : old.map((d) => {
						if (d.id === column.id) return newFilterObj;
						return d;
					})) != null ? _old$map : [];
				}
				if (old != null && old.length) return [...old, newFilterObj];
				return [newFilterObj];
			});
		};
	},
	createRow: (row, _table) => {
		row.columnFilters = {};
		row.columnFiltersMeta = {};
	},
	createTable: (table) => {
		table.setColumnFilters = (updater) => {
			const leafColumns = table.getAllLeafColumns();
			const updateFn = (old) => {
				var _functionalUpdate;
				return (_functionalUpdate = functionalUpdate(updater, old)) == null ? void 0 : _functionalUpdate.filter((filter) => {
					const column = leafColumns.find((d) => d.id === filter.id);
					if (column) {
						if (shouldAutoRemoveFilter(column.getFilterFn(), filter.value, column)) return false;
					}
					return true;
				});
			};
			table.options.onColumnFiltersChange == null || table.options.onColumnFiltersChange(updateFn);
		};
		table.resetColumnFilters = (defaultState) => {
			var _table$initialState$c, _table$initialState;
			table.setColumnFilters(defaultState ? [] : (_table$initialState$c = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.columnFilters) != null ? _table$initialState$c : []);
		};
		table.getPreFilteredRowModel = () => table.getCoreRowModel();
		table.getFilteredRowModel = () => {
			if (!table._getFilteredRowModel && table.options.getFilteredRowModel) table._getFilteredRowModel = table.options.getFilteredRowModel(table);
			if (table.options.manualFiltering || !table._getFilteredRowModel) return table.getPreFilteredRowModel();
			return table._getFilteredRowModel();
		};
	}
};
function shouldAutoRemoveFilter(filterFn, value, column) {
	return (filterFn && filterFn.autoRemove ? filterFn.autoRemove(value, column) : false) || typeof value === "undefined" || typeof value === "string" && !value;
}
var sum = (columnId, _leafRows, childRows) => {
	return childRows.reduce((sum, next) => {
		const nextValue = next.getValue(columnId);
		return sum + (typeof nextValue === "number" ? nextValue : 0);
	}, 0);
};
var min = (columnId, _leafRows, childRows) => {
	let min;
	childRows.forEach((row) => {
		const value = row.getValue(columnId);
		if (value != null && (min > value || min === void 0 && value >= value)) min = value;
	});
	return min;
};
var max = (columnId, _leafRows, childRows) => {
	let max;
	childRows.forEach((row) => {
		const value = row.getValue(columnId);
		if (value != null && (max < value || max === void 0 && value >= value)) max = value;
	});
	return max;
};
var extent = (columnId, _leafRows, childRows) => {
	let min;
	let max;
	childRows.forEach((row) => {
		const value = row.getValue(columnId);
		if (value != null) if (min === void 0) {
			if (value >= value) min = max = value;
		} else {
			if (min > value) min = value;
			if (max < value) max = value;
		}
	});
	return [min, max];
};
var mean = (columnId, leafRows) => {
	let count = 0;
	let sum = 0;
	leafRows.forEach((row) => {
		let value = row.getValue(columnId);
		if (value != null && (value = +value) >= value) ++count, sum += value;
	});
	if (count) return sum / count;
};
var median = (columnId, leafRows) => {
	if (!leafRows.length) return;
	const values = leafRows.map((row) => row.getValue(columnId));
	if (!isNumberArray(values)) return;
	if (values.length === 1) return values[0];
	const mid = Math.floor(values.length / 2);
	const nums = values.sort((a, b) => a - b);
	return values.length % 2 !== 0 ? nums[mid] : (nums[mid - 1] + nums[mid]) / 2;
};
var unique = (columnId, leafRows) => {
	return Array.from(new Set(leafRows.map((d) => d.getValue(columnId))).values());
};
var uniqueCount = (columnId, leafRows) => {
	return new Set(leafRows.map((d) => d.getValue(columnId))).size;
};
var count = (_columnId, leafRows) => {
	return leafRows.length;
};
var aggregationFns = {
	sum,
	min,
	max,
	extent,
	mean,
	median,
	unique,
	uniqueCount,
	count
};
var ColumnGrouping = {
	getDefaultColumnDef: () => {
		return {
			aggregatedCell: (props) => {
				var _toString, _props$getValue;
				return (_toString = (_props$getValue = props.getValue()) == null || _props$getValue.toString == null ? void 0 : _props$getValue.toString()) != null ? _toString : null;
			},
			aggregationFn: "auto"
		};
	},
	getInitialState: (state) => {
		return {
			grouping: [],
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onGroupingChange: makeStateUpdater("grouping", table),
			groupedColumnMode: "reorder"
		};
	},
	createColumn: (column, table) => {
		column.toggleGrouping = () => {
			table.setGrouping((old) => {
				if (old != null && old.includes(column.id)) return old.filter((d) => d !== column.id);
				return [...old != null ? old : [], column.id];
			});
		};
		column.getCanGroup = () => {
			var _column$columnDef$ena, _table$options$enable;
			return ((_column$columnDef$ena = column.columnDef.enableGrouping) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableGrouping) != null ? _table$options$enable : true) && (!!column.accessorFn || !!column.columnDef.getGroupingValue);
		};
		column.getIsGrouped = () => {
			var _table$getState$group;
			return (_table$getState$group = table.getState().grouping) == null ? void 0 : _table$getState$group.includes(column.id);
		};
		column.getGroupedIndex = () => {
			var _table$getState$group2;
			return (_table$getState$group2 = table.getState().grouping) == null ? void 0 : _table$getState$group2.indexOf(column.id);
		};
		column.getToggleGroupingHandler = () => {
			const canGroup = column.getCanGroup();
			return () => {
				if (!canGroup) return;
				column.toggleGrouping();
			};
		};
		column.getAutoAggregationFn = () => {
			const firstRow = table.getCoreRowModel().flatRows[0];
			const value = firstRow == null ? void 0 : firstRow.getValue(column.id);
			if (typeof value === "number") return aggregationFns.sum;
			if (Object.prototype.toString.call(value) === "[object Date]") return aggregationFns.extent;
		};
		column.getAggregationFn = () => {
			var _table$options$aggreg, _table$options$aggreg2;
			if (!column) throw new Error();
			return isFunction(column.columnDef.aggregationFn) ? column.columnDef.aggregationFn : column.columnDef.aggregationFn === "auto" ? column.getAutoAggregationFn() : (_table$options$aggreg = (_table$options$aggreg2 = table.options.aggregationFns) == null ? void 0 : _table$options$aggreg2[column.columnDef.aggregationFn]) != null ? _table$options$aggreg : aggregationFns[column.columnDef.aggregationFn];
		};
	},
	createTable: (table) => {
		table.setGrouping = (updater) => table.options.onGroupingChange == null ? void 0 : table.options.onGroupingChange(updater);
		table.resetGrouping = (defaultState) => {
			var _table$initialState$g, _table$initialState;
			table.setGrouping(defaultState ? [] : (_table$initialState$g = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.grouping) != null ? _table$initialState$g : []);
		};
		table.getPreGroupedRowModel = () => table.getFilteredRowModel();
		table.getGroupedRowModel = () => {
			if (!table._getGroupedRowModel && table.options.getGroupedRowModel) table._getGroupedRowModel = table.options.getGroupedRowModel(table);
			if (table.options.manualGrouping || !table._getGroupedRowModel) return table.getPreGroupedRowModel();
			return table._getGroupedRowModel();
		};
	},
	createRow: (row, table) => {
		row.getIsGrouped = () => !!row.groupingColumnId;
		row.getGroupingValue = (columnId) => {
			if (row._groupingValuesCache.hasOwnProperty(columnId)) return row._groupingValuesCache[columnId];
			const column = table.getColumn(columnId);
			if (!(column != null && column.columnDef.getGroupingValue)) return row.getValue(columnId);
			row._groupingValuesCache[columnId] = column.columnDef.getGroupingValue(row.original);
			return row._groupingValuesCache[columnId];
		};
		row._groupingValuesCache = {};
	},
	createCell: (cell, column, row, table) => {
		cell.getIsGrouped = () => column.getIsGrouped() && column.id === row.groupingColumnId;
		cell.getIsPlaceholder = () => !cell.getIsGrouped() && column.getIsGrouped();
		cell.getIsAggregated = () => {
			var _row$subRows;
			return !cell.getIsGrouped() && !cell.getIsPlaceholder() && !!((_row$subRows = row.subRows) != null && _row$subRows.length);
		};
	}
};
function orderColumns(leafColumns, grouping, groupedColumnMode) {
	if (!(grouping != null && grouping.length) || !groupedColumnMode) return leafColumns;
	const nonGroupingColumns = leafColumns.filter((col) => !grouping.includes(col.id));
	if (groupedColumnMode === "remove") return nonGroupingColumns;
	return [...grouping.map((g) => leafColumns.find((col) => col.id === g)).filter(Boolean), ...nonGroupingColumns];
}
var ColumnOrdering = {
	getInitialState: (state) => {
		return {
			columnOrder: [],
			...state
		};
	},
	getDefaultOptions: (table) => {
		return { onColumnOrderChange: makeStateUpdater("columnOrder", table) };
	},
	createColumn: (column, table) => {
		column.getIndex = memo$1((position) => [_getVisibleLeafColumns(table, position)], (columns) => columns.findIndex((d) => d.id === column.id), getMemoOptions(table.options, "debugColumns", "getIndex"));
		column.getIsFirstColumn = (position) => {
			var _columns$;
			return ((_columns$ = _getVisibleLeafColumns(table, position)[0]) == null ? void 0 : _columns$.id) === column.id;
		};
		column.getIsLastColumn = (position) => {
			var _columns;
			const columns = _getVisibleLeafColumns(table, position);
			return ((_columns = columns[columns.length - 1]) == null ? void 0 : _columns.id) === column.id;
		};
	},
	createTable: (table) => {
		table.setColumnOrder = (updater) => table.options.onColumnOrderChange == null ? void 0 : table.options.onColumnOrderChange(updater);
		table.resetColumnOrder = (defaultState) => {
			var _table$initialState$c;
			table.setColumnOrder(defaultState ? [] : (_table$initialState$c = table.initialState.columnOrder) != null ? _table$initialState$c : []);
		};
		table._getOrderColumnsFn = memo$1(() => [
			table.getState().columnOrder,
			table.getState().grouping,
			table.options.groupedColumnMode
		], (columnOrder, grouping, groupedColumnMode) => (columns) => {
			let orderedColumns = [];
			if (!(columnOrder != null && columnOrder.length)) orderedColumns = columns;
			else {
				const columnOrderCopy = [...columnOrder];
				const columnsCopy = [...columns];
				while (columnsCopy.length && columnOrderCopy.length) {
					const targetColumnId = columnOrderCopy.shift();
					const foundIndex = columnsCopy.findIndex((d) => d.id === targetColumnId);
					if (foundIndex > -1) orderedColumns.push(columnsCopy.splice(foundIndex, 1)[0]);
				}
				orderedColumns = [...orderedColumns, ...columnsCopy];
			}
			return orderColumns(orderedColumns, grouping, groupedColumnMode);
		}, getMemoOptions(table.options, "debugTable", "_getOrderColumnsFn"));
	}
};
var getDefaultColumnPinningState = () => ({
	left: [],
	right: []
});
var ColumnPinning = {
	getInitialState: (state) => {
		return {
			columnPinning: getDefaultColumnPinningState(),
			...state
		};
	},
	getDefaultOptions: (table) => {
		return { onColumnPinningChange: makeStateUpdater("columnPinning", table) };
	},
	createColumn: (column, table) => {
		column.pin = (position) => {
			const columnIds = column.getLeafColumns().map((d) => d.id).filter(Boolean);
			table.setColumnPinning((old) => {
				var _old$left3, _old$right3;
				if (position === "right") {
					var _old$left, _old$right;
					return {
						left: ((_old$left = old == null ? void 0 : old.left) != null ? _old$left : []).filter((d) => !(columnIds != null && columnIds.includes(d))),
						right: [...((_old$right = old == null ? void 0 : old.right) != null ? _old$right : []).filter((d) => !(columnIds != null && columnIds.includes(d))), ...columnIds]
					};
				}
				if (position === "left") {
					var _old$left2, _old$right2;
					return {
						left: [...((_old$left2 = old == null ? void 0 : old.left) != null ? _old$left2 : []).filter((d) => !(columnIds != null && columnIds.includes(d))), ...columnIds],
						right: ((_old$right2 = old == null ? void 0 : old.right) != null ? _old$right2 : []).filter((d) => !(columnIds != null && columnIds.includes(d)))
					};
				}
				return {
					left: ((_old$left3 = old == null ? void 0 : old.left) != null ? _old$left3 : []).filter((d) => !(columnIds != null && columnIds.includes(d))),
					right: ((_old$right3 = old == null ? void 0 : old.right) != null ? _old$right3 : []).filter((d) => !(columnIds != null && columnIds.includes(d)))
				};
			});
		};
		column.getCanPin = () => {
			return column.getLeafColumns().some((d) => {
				var _d$columnDef$enablePi, _ref, _table$options$enable;
				return ((_d$columnDef$enablePi = d.columnDef.enablePinning) != null ? _d$columnDef$enablePi : true) && ((_ref = (_table$options$enable = table.options.enableColumnPinning) != null ? _table$options$enable : table.options.enablePinning) != null ? _ref : true);
			});
		};
		column.getIsPinned = () => {
			const leafColumnIds = column.getLeafColumns().map((d) => d.id);
			const { left, right } = table.getState().columnPinning;
			const isLeft = leafColumnIds.some((d) => left == null ? void 0 : left.includes(d));
			const isRight = leafColumnIds.some((d) => right == null ? void 0 : right.includes(d));
			return isLeft ? "left" : isRight ? "right" : false;
		};
		column.getPinnedIndex = () => {
			var _table$getState$colum, _table$getState$colum2;
			const position = column.getIsPinned();
			return position ? (_table$getState$colum = (_table$getState$colum2 = table.getState().columnPinning) == null || (_table$getState$colum2 = _table$getState$colum2[position]) == null ? void 0 : _table$getState$colum2.indexOf(column.id)) != null ? _table$getState$colum : -1 : 0;
		};
	},
	createRow: (row, table) => {
		row.getCenterVisibleCells = memo$1(() => [
			row._getAllVisibleCells(),
			table.getState().columnPinning.left,
			table.getState().columnPinning.right
		], (allCells, left, right) => {
			const leftAndRight = [...left != null ? left : [], ...right != null ? right : []];
			return allCells.filter((d) => !leftAndRight.includes(d.column.id));
		}, getMemoOptions(table.options, "debugRows", "getCenterVisibleCells"));
		row.getLeftVisibleCells = memo$1(() => [row._getAllVisibleCells(), table.getState().columnPinning.left], (allCells, left) => {
			return (left != null ? left : []).map((columnId) => allCells.find((cell) => cell.column.id === columnId)).filter(Boolean).map((d) => ({
				...d,
				position: "left"
			}));
		}, getMemoOptions(table.options, "debugRows", "getLeftVisibleCells"));
		row.getRightVisibleCells = memo$1(() => [row._getAllVisibleCells(), table.getState().columnPinning.right], (allCells, right) => {
			return (right != null ? right : []).map((columnId) => allCells.find((cell) => cell.column.id === columnId)).filter(Boolean).map((d) => ({
				...d,
				position: "right"
			}));
		}, getMemoOptions(table.options, "debugRows", "getRightVisibleCells"));
	},
	createTable: (table) => {
		table.setColumnPinning = (updater) => table.options.onColumnPinningChange == null ? void 0 : table.options.onColumnPinningChange(updater);
		table.resetColumnPinning = (defaultState) => {
			var _table$initialState$c, _table$initialState;
			return table.setColumnPinning(defaultState ? getDefaultColumnPinningState() : (_table$initialState$c = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.columnPinning) != null ? _table$initialState$c : getDefaultColumnPinningState());
		};
		table.getIsSomeColumnsPinned = (position) => {
			var _pinningState$positio;
			const pinningState = table.getState().columnPinning;
			if (!position) {
				var _pinningState$left, _pinningState$right;
				return Boolean(((_pinningState$left = pinningState.left) == null ? void 0 : _pinningState$left.length) || ((_pinningState$right = pinningState.right) == null ? void 0 : _pinningState$right.length));
			}
			return Boolean((_pinningState$positio = pinningState[position]) == null ? void 0 : _pinningState$positio.length);
		};
		table.getLeftLeafColumns = memo$1(() => [table.getAllLeafColumns(), table.getState().columnPinning.left], (allColumns, left) => {
			return (left != null ? left : []).map((columnId) => allColumns.find((column) => column.id === columnId)).filter(Boolean);
		}, getMemoOptions(table.options, "debugColumns", "getLeftLeafColumns"));
		table.getRightLeafColumns = memo$1(() => [table.getAllLeafColumns(), table.getState().columnPinning.right], (allColumns, right) => {
			return (right != null ? right : []).map((columnId) => allColumns.find((column) => column.id === columnId)).filter(Boolean);
		}, getMemoOptions(table.options, "debugColumns", "getRightLeafColumns"));
		table.getCenterLeafColumns = memo$1(() => [
			table.getAllLeafColumns(),
			table.getState().columnPinning.left,
			table.getState().columnPinning.right
		], (allColumns, left, right) => {
			const leftAndRight = [...left != null ? left : [], ...right != null ? right : []];
			return allColumns.filter((d) => !leftAndRight.includes(d.id));
		}, getMemoOptions(table.options, "debugColumns", "getCenterLeafColumns"));
	}
};
function safelyAccessDocument(_document) {
	return _document || (typeof document !== "undefined" ? document : null);
}
var defaultColumnSizing = {
	size: 150,
	minSize: 20,
	maxSize: Number.MAX_SAFE_INTEGER
};
var getDefaultColumnSizingInfoState = () => ({
	startOffset: null,
	startSize: null,
	deltaOffset: null,
	deltaPercentage: null,
	isResizingColumn: false,
	columnSizingStart: []
});
var ColumnSizing = {
	getDefaultColumnDef: () => {
		return defaultColumnSizing;
	},
	getInitialState: (state) => {
		return {
			columnSizing: {},
			columnSizingInfo: getDefaultColumnSizingInfoState(),
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			columnResizeMode: "onEnd",
			columnResizeDirection: "ltr",
			onColumnSizingChange: makeStateUpdater("columnSizing", table),
			onColumnSizingInfoChange: makeStateUpdater("columnSizingInfo", table)
		};
	},
	createColumn: (column, table) => {
		column.getSize = () => {
			var _column$columnDef$min, _ref, _column$columnDef$max;
			const columnSize = table.getState().columnSizing[column.id];
			return Math.min(Math.max((_column$columnDef$min = column.columnDef.minSize) != null ? _column$columnDef$min : defaultColumnSizing.minSize, (_ref = columnSize != null ? columnSize : column.columnDef.size) != null ? _ref : defaultColumnSizing.size), (_column$columnDef$max = column.columnDef.maxSize) != null ? _column$columnDef$max : defaultColumnSizing.maxSize);
		};
		column.getStart = memo$1((position) => [
			position,
			_getVisibleLeafColumns(table, position),
			table.getState().columnSizing
		], (position, columns) => columns.slice(0, column.getIndex(position)).reduce((sum, column) => sum + column.getSize(), 0), getMemoOptions(table.options, "debugColumns", "getStart"));
		column.getAfter = memo$1((position) => [
			position,
			_getVisibleLeafColumns(table, position),
			table.getState().columnSizing
		], (position, columns) => columns.slice(column.getIndex(position) + 1).reduce((sum, column) => sum + column.getSize(), 0), getMemoOptions(table.options, "debugColumns", "getAfter"));
		column.resetSize = () => {
			table.setColumnSizing((_ref2) => {
				let { [column.id]: _, ...rest } = _ref2;
				return rest;
			});
		};
		column.getCanResize = () => {
			var _column$columnDef$ena, _table$options$enable;
			return ((_column$columnDef$ena = column.columnDef.enableResizing) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableColumnResizing) != null ? _table$options$enable : true);
		};
		column.getIsResizing = () => {
			return table.getState().columnSizingInfo.isResizingColumn === column.id;
		};
	},
	createHeader: (header, table) => {
		header.getSize = () => {
			let sum = 0;
			const recurse = (header) => {
				if (header.subHeaders.length) header.subHeaders.forEach(recurse);
				else {
					var _header$column$getSiz;
					sum += (_header$column$getSiz = header.column.getSize()) != null ? _header$column$getSiz : 0;
				}
			};
			recurse(header);
			return sum;
		};
		header.getStart = () => {
			if (header.index > 0) {
				const prevSiblingHeader = header.headerGroup.headers[header.index - 1];
				return prevSiblingHeader.getStart() + prevSiblingHeader.getSize();
			}
			return 0;
		};
		header.getResizeHandler = (_contextDocument) => {
			const column = table.getColumn(header.column.id);
			const canResize = column == null ? void 0 : column.getCanResize();
			return (e) => {
				if (!column || !canResize) return;
				e.persist == null || e.persist();
				if (isTouchStartEvent(e)) {
					if (e.touches && e.touches.length > 1) return;
				}
				const startSize = header.getSize();
				const columnSizingStart = header ? header.getLeafHeaders().map((d) => [d.column.id, d.column.getSize()]) : [[column.id, column.getSize()]];
				const clientX = isTouchStartEvent(e) ? Math.round(e.touches[0].clientX) : e.clientX;
				const newColumnSizing = {};
				const updateOffset = (eventType, clientXPos) => {
					if (typeof clientXPos !== "number") return;
					table.setColumnSizingInfo((old) => {
						var _old$startOffset, _old$startSize;
						const deltaDirection = table.options.columnResizeDirection === "rtl" ? -1 : 1;
						const deltaOffset = (clientXPos - ((_old$startOffset = old == null ? void 0 : old.startOffset) != null ? _old$startOffset : 0)) * deltaDirection;
						const deltaPercentage = Math.max(deltaOffset / ((_old$startSize = old == null ? void 0 : old.startSize) != null ? _old$startSize : 0), -.999999);
						old.columnSizingStart.forEach((_ref3) => {
							let [columnId, headerSize] = _ref3;
							newColumnSizing[columnId] = Math.round(Math.max(headerSize + headerSize * deltaPercentage, 0) * 100) / 100;
						});
						return {
							...old,
							deltaOffset,
							deltaPercentage
						};
					});
					if (table.options.columnResizeMode === "onChange" || eventType === "end") table.setColumnSizing((old) => ({
						...old,
						...newColumnSizing
					}));
				};
				const onMove = (clientXPos) => updateOffset("move", clientXPos);
				const onEnd = (clientXPos) => {
					updateOffset("end", clientXPos);
					table.setColumnSizingInfo((old) => ({
						...old,
						isResizingColumn: false,
						startOffset: null,
						startSize: null,
						deltaOffset: null,
						deltaPercentage: null,
						columnSizingStart: []
					}));
				};
				const contextDocument = safelyAccessDocument(_contextDocument);
				const mouseEvents = {
					moveHandler: (e) => onMove(e.clientX),
					upHandler: (e) => {
						contextDocument?.removeEventListener("mousemove", mouseEvents.moveHandler);
						contextDocument?.removeEventListener("mouseup", mouseEvents.upHandler);
						onEnd(e.clientX);
					}
				};
				const touchEvents = {
					moveHandler: (e) => {
						if (e.cancelable) {
							e.preventDefault();
							e.stopPropagation();
						}
						onMove(e.touches[0].clientX);
						return false;
					},
					upHandler: (e) => {
						var _e$touches$;
						contextDocument?.removeEventListener("touchmove", touchEvents.moveHandler);
						contextDocument?.removeEventListener("touchend", touchEvents.upHandler);
						if (e.cancelable) {
							e.preventDefault();
							e.stopPropagation();
						}
						onEnd((_e$touches$ = e.touches[0]) == null ? void 0 : _e$touches$.clientX);
					}
				};
				const passiveIfSupported = passiveEventSupported() ? { passive: false } : false;
				if (isTouchStartEvent(e)) {
					contextDocument?.addEventListener("touchmove", touchEvents.moveHandler, passiveIfSupported);
					contextDocument?.addEventListener("touchend", touchEvents.upHandler, passiveIfSupported);
				} else {
					contextDocument?.addEventListener("mousemove", mouseEvents.moveHandler, passiveIfSupported);
					contextDocument?.addEventListener("mouseup", mouseEvents.upHandler, passiveIfSupported);
				}
				table.setColumnSizingInfo((old) => ({
					...old,
					startOffset: clientX,
					startSize,
					deltaOffset: 0,
					deltaPercentage: 0,
					columnSizingStart,
					isResizingColumn: column.id
				}));
			};
		};
	},
	createTable: (table) => {
		table.setColumnSizing = (updater) => table.options.onColumnSizingChange == null ? void 0 : table.options.onColumnSizingChange(updater);
		table.setColumnSizingInfo = (updater) => table.options.onColumnSizingInfoChange == null ? void 0 : table.options.onColumnSizingInfoChange(updater);
		table.resetColumnSizing = (defaultState) => {
			var _table$initialState$c;
			table.setColumnSizing(defaultState ? {} : (_table$initialState$c = table.initialState.columnSizing) != null ? _table$initialState$c : {});
		};
		table.resetHeaderSizeInfo = (defaultState) => {
			var _table$initialState$c2;
			table.setColumnSizingInfo(defaultState ? getDefaultColumnSizingInfoState() : (_table$initialState$c2 = table.initialState.columnSizingInfo) != null ? _table$initialState$c2 : getDefaultColumnSizingInfoState());
		};
		table.getTotalSize = () => {
			var _table$getHeaderGroup, _table$getHeaderGroup2;
			return (_table$getHeaderGroup = (_table$getHeaderGroup2 = table.getHeaderGroups()[0]) == null ? void 0 : _table$getHeaderGroup2.headers.reduce((sum, header) => {
				return sum + header.getSize();
			}, 0)) != null ? _table$getHeaderGroup : 0;
		};
		table.getLeftTotalSize = () => {
			var _table$getLeftHeaderG, _table$getLeftHeaderG2;
			return (_table$getLeftHeaderG = (_table$getLeftHeaderG2 = table.getLeftHeaderGroups()[0]) == null ? void 0 : _table$getLeftHeaderG2.headers.reduce((sum, header) => {
				return sum + header.getSize();
			}, 0)) != null ? _table$getLeftHeaderG : 0;
		};
		table.getCenterTotalSize = () => {
			var _table$getCenterHeade, _table$getCenterHeade2;
			return (_table$getCenterHeade = (_table$getCenterHeade2 = table.getCenterHeaderGroups()[0]) == null ? void 0 : _table$getCenterHeade2.headers.reduce((sum, header) => {
				return sum + header.getSize();
			}, 0)) != null ? _table$getCenterHeade : 0;
		};
		table.getRightTotalSize = () => {
			var _table$getRightHeader, _table$getRightHeader2;
			return (_table$getRightHeader = (_table$getRightHeader2 = table.getRightHeaderGroups()[0]) == null ? void 0 : _table$getRightHeader2.headers.reduce((sum, header) => {
				return sum + header.getSize();
			}, 0)) != null ? _table$getRightHeader : 0;
		};
	}
};
var passiveSupported = null;
function passiveEventSupported() {
	if (typeof passiveSupported === "boolean") return passiveSupported;
	let supported = false;
	try {
		const options = { get passive() {
			supported = true;
			return false;
		} };
		const noop = () => {};
		window.addEventListener("test", noop, options);
		window.removeEventListener("test", noop);
	} catch (err) {
		supported = false;
	}
	passiveSupported = supported;
	return passiveSupported;
}
function isTouchStartEvent(e) {
	return e.type === "touchstart";
}
var ColumnVisibility = {
	getInitialState: (state) => {
		return {
			columnVisibility: {},
			...state
		};
	},
	getDefaultOptions: (table) => {
		return { onColumnVisibilityChange: makeStateUpdater("columnVisibility", table) };
	},
	createColumn: (column, table) => {
		column.toggleVisibility = (value) => {
			if (column.getCanHide()) table.setColumnVisibility((old) => ({
				...old,
				[column.id]: value != null ? value : !column.getIsVisible()
			}));
		};
		column.getIsVisible = () => {
			var _ref, _table$getState$colum;
			const childColumns = column.columns;
			return (_ref = childColumns.length ? childColumns.some((c) => c.getIsVisible()) : (_table$getState$colum = table.getState().columnVisibility) == null ? void 0 : _table$getState$colum[column.id]) != null ? _ref : true;
		};
		column.getCanHide = () => {
			var _column$columnDef$ena, _table$options$enable;
			return ((_column$columnDef$ena = column.columnDef.enableHiding) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableHiding) != null ? _table$options$enable : true);
		};
		column.getToggleVisibilityHandler = () => {
			return (e) => {
				column.toggleVisibility == null || column.toggleVisibility(e.target.checked);
			};
		};
	},
	createRow: (row, table) => {
		row._getAllVisibleCells = memo$1(() => [row.getAllCells(), table.getState().columnVisibility], (cells) => {
			return cells.filter((cell) => cell.column.getIsVisible());
		}, getMemoOptions(table.options, "debugRows", "_getAllVisibleCells"));
		row.getVisibleCells = memo$1(() => [
			row.getLeftVisibleCells(),
			row.getCenterVisibleCells(),
			row.getRightVisibleCells()
		], (left, center, right) => [
			...left,
			...center,
			...right
		], getMemoOptions(table.options, "debugRows", "getVisibleCells"));
	},
	createTable: (table) => {
		const makeVisibleColumnsMethod = (key, getColumns) => {
			return memo$1(() => [getColumns(), getColumns().filter((d) => d.getIsVisible()).map((d) => d.id).join("_")], (columns) => {
				return columns.filter((d) => d.getIsVisible == null ? void 0 : d.getIsVisible());
			}, getMemoOptions(table.options, "debugColumns", key));
		};
		table.getVisibleFlatColumns = makeVisibleColumnsMethod("getVisibleFlatColumns", () => table.getAllFlatColumns());
		table.getVisibleLeafColumns = makeVisibleColumnsMethod("getVisibleLeafColumns", () => table.getAllLeafColumns());
		table.getLeftVisibleLeafColumns = makeVisibleColumnsMethod("getLeftVisibleLeafColumns", () => table.getLeftLeafColumns());
		table.getRightVisibleLeafColumns = makeVisibleColumnsMethod("getRightVisibleLeafColumns", () => table.getRightLeafColumns());
		table.getCenterVisibleLeafColumns = makeVisibleColumnsMethod("getCenterVisibleLeafColumns", () => table.getCenterLeafColumns());
		table.setColumnVisibility = (updater) => table.options.onColumnVisibilityChange == null ? void 0 : table.options.onColumnVisibilityChange(updater);
		table.resetColumnVisibility = (defaultState) => {
			var _table$initialState$c;
			table.setColumnVisibility(defaultState ? {} : (_table$initialState$c = table.initialState.columnVisibility) != null ? _table$initialState$c : {});
		};
		table.toggleAllColumnsVisible = (value) => {
			var _value;
			value = (_value = value) != null ? _value : !table.getIsAllColumnsVisible();
			table.setColumnVisibility(table.getAllLeafColumns().reduce((obj, column) => ({
				...obj,
				[column.id]: !value ? !(column.getCanHide != null && column.getCanHide()) : value
			}), {}));
		};
		table.getIsAllColumnsVisible = () => !table.getAllLeafColumns().some((column) => !(column.getIsVisible != null && column.getIsVisible()));
		table.getIsSomeColumnsVisible = () => table.getAllLeafColumns().some((column) => column.getIsVisible == null ? void 0 : column.getIsVisible());
		table.getToggleAllColumnsVisibilityHandler = () => {
			return (e) => {
				var _target;
				table.toggleAllColumnsVisible((_target = e.target) == null ? void 0 : _target.checked);
			};
		};
	}
};
function _getVisibleLeafColumns(table, position) {
	return !position ? table.getVisibleLeafColumns() : position === "center" ? table.getCenterVisibleLeafColumns() : position === "left" ? table.getLeftVisibleLeafColumns() : table.getRightVisibleLeafColumns();
}
var GlobalFaceting = { createTable: (table) => {
	table._getGlobalFacetedRowModel = table.options.getFacetedRowModel && table.options.getFacetedRowModel(table, "__global__");
	table.getGlobalFacetedRowModel = () => {
		if (table.options.manualFiltering || !table._getGlobalFacetedRowModel) return table.getPreFilteredRowModel();
		return table._getGlobalFacetedRowModel();
	};
	table._getGlobalFacetedUniqueValues = table.options.getFacetedUniqueValues && table.options.getFacetedUniqueValues(table, "__global__");
	table.getGlobalFacetedUniqueValues = () => {
		if (!table._getGlobalFacetedUniqueValues) return /* @__PURE__ */ new Map();
		return table._getGlobalFacetedUniqueValues();
	};
	table._getGlobalFacetedMinMaxValues = table.options.getFacetedMinMaxValues && table.options.getFacetedMinMaxValues(table, "__global__");
	table.getGlobalFacetedMinMaxValues = () => {
		if (!table._getGlobalFacetedMinMaxValues) return;
		return table._getGlobalFacetedMinMaxValues();
	};
} };
var GlobalFiltering = {
	getInitialState: (state) => {
		return {
			globalFilter: void 0,
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onGlobalFilterChange: makeStateUpdater("globalFilter", table),
			globalFilterFn: "auto",
			getColumnCanGlobalFilter: (column) => {
				var _table$getCoreRowMode;
				const value = (_table$getCoreRowMode = table.getCoreRowModel().flatRows[0]) == null || (_table$getCoreRowMode = _table$getCoreRowMode._getAllCellsByColumnId()[column.id]) == null ? void 0 : _table$getCoreRowMode.getValue();
				return typeof value === "string" || typeof value === "number";
			}
		};
	},
	createColumn: (column, table) => {
		column.getCanGlobalFilter = () => {
			var _column$columnDef$ena, _table$options$enable, _table$options$enable2, _table$options$getCol;
			return ((_column$columnDef$ena = column.columnDef.enableGlobalFilter) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableGlobalFilter) != null ? _table$options$enable : true) && ((_table$options$enable2 = table.options.enableFilters) != null ? _table$options$enable2 : true) && ((_table$options$getCol = table.options.getColumnCanGlobalFilter == null ? void 0 : table.options.getColumnCanGlobalFilter(column)) != null ? _table$options$getCol : true) && !!column.accessorFn;
		};
	},
	createTable: (table) => {
		table.getGlobalAutoFilterFn = () => {
			return filterFns.includesString;
		};
		table.getGlobalFilterFn = () => {
			var _table$options$filter, _table$options$filter2;
			const { globalFilterFn } = table.options;
			return isFunction(globalFilterFn) ? globalFilterFn : globalFilterFn === "auto" ? table.getGlobalAutoFilterFn() : (_table$options$filter = (_table$options$filter2 = table.options.filterFns) == null ? void 0 : _table$options$filter2[globalFilterFn]) != null ? _table$options$filter : filterFns[globalFilterFn];
		};
		table.setGlobalFilter = (updater) => {
			table.options.onGlobalFilterChange == null || table.options.onGlobalFilterChange(updater);
		};
		table.resetGlobalFilter = (defaultState) => {
			table.setGlobalFilter(defaultState ? void 0 : table.initialState.globalFilter);
		};
	}
};
var RowExpanding = {
	getInitialState: (state) => {
		return {
			expanded: {},
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onExpandedChange: makeStateUpdater("expanded", table),
			paginateExpandedRows: true
		};
	},
	createTable: (table) => {
		let registered = false;
		let queued = false;
		table._autoResetExpanded = () => {
			var _ref, _table$options$autoRe;
			if (!registered) {
				table._queue(() => {
					registered = true;
				});
				return;
			}
			if ((_ref = (_table$options$autoRe = table.options.autoResetAll) != null ? _table$options$autoRe : table.options.autoResetExpanded) != null ? _ref : !table.options.manualExpanding) {
				if (queued) return;
				queued = true;
				table._queue(() => {
					table.resetExpanded();
					queued = false;
				});
			}
		};
		table.setExpanded = (updater) => table.options.onExpandedChange == null ? void 0 : table.options.onExpandedChange(updater);
		table.toggleAllRowsExpanded = (expanded) => {
			if (expanded != null ? expanded : !table.getIsAllRowsExpanded()) table.setExpanded(true);
			else table.setExpanded({});
		};
		table.resetExpanded = (defaultState) => {
			var _table$initialState$e, _table$initialState;
			table.setExpanded(defaultState ? {} : (_table$initialState$e = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.expanded) != null ? _table$initialState$e : {});
		};
		table.getCanSomeRowsExpand = () => {
			return table.getPrePaginationRowModel().flatRows.some((row) => row.getCanExpand());
		};
		table.getToggleAllRowsExpandedHandler = () => {
			return (e) => {
				e.persist == null || e.persist();
				table.toggleAllRowsExpanded();
			};
		};
		table.getIsSomeRowsExpanded = () => {
			const expanded = table.getState().expanded;
			return expanded === true || Object.values(expanded).some(Boolean);
		};
		table.getIsAllRowsExpanded = () => {
			const expanded = table.getState().expanded;
			if (typeof expanded === "boolean") return expanded === true;
			if (!Object.keys(expanded).length) return false;
			if (table.getRowModel().flatRows.some((row) => !row.getIsExpanded())) return false;
			return true;
		};
		table.getExpandedDepth = () => {
			let maxDepth = 0;
			(table.getState().expanded === true ? Object.keys(table.getRowModel().rowsById) : Object.keys(table.getState().expanded)).forEach((id) => {
				const splitId = id.split(".");
				maxDepth = Math.max(maxDepth, splitId.length);
			});
			return maxDepth;
		};
		table.getPreExpandedRowModel = () => table.getSortedRowModel();
		table.getExpandedRowModel = () => {
			if (!table._getExpandedRowModel && table.options.getExpandedRowModel) table._getExpandedRowModel = table.options.getExpandedRowModel(table);
			if (table.options.manualExpanding || !table._getExpandedRowModel) return table.getPreExpandedRowModel();
			return table._getExpandedRowModel();
		};
	},
	createRow: (row, table) => {
		row.toggleExpanded = (expanded) => {
			table.setExpanded((old) => {
				var _expanded;
				const exists = old === true ? true : !!(old != null && old[row.id]);
				let oldExpanded = {};
				if (old === true) Object.keys(table.getRowModel().rowsById).forEach((rowId) => {
					oldExpanded[rowId] = true;
				});
				else oldExpanded = old;
				expanded = (_expanded = expanded) != null ? _expanded : !exists;
				if (!exists && expanded) return {
					...oldExpanded,
					[row.id]: true
				};
				if (exists && !expanded) {
					const { [row.id]: _, ...rest } = oldExpanded;
					return rest;
				}
				return old;
			});
		};
		row.getIsExpanded = () => {
			var _table$options$getIsR;
			const expanded = table.getState().expanded;
			return !!((_table$options$getIsR = table.options.getIsRowExpanded == null ? void 0 : table.options.getIsRowExpanded(row)) != null ? _table$options$getIsR : expanded === true || (expanded == null ? void 0 : expanded[row.id]));
		};
		row.getCanExpand = () => {
			var _table$options$getRow, _table$options$enable, _row$subRows;
			return (_table$options$getRow = table.options.getRowCanExpand == null ? void 0 : table.options.getRowCanExpand(row)) != null ? _table$options$getRow : ((_table$options$enable = table.options.enableExpanding) != null ? _table$options$enable : true) && !!((_row$subRows = row.subRows) != null && _row$subRows.length);
		};
		row.getIsAllParentsExpanded = () => {
			let isFullyExpanded = true;
			let currentRow = row;
			while (isFullyExpanded && currentRow.parentId) {
				currentRow = table.getRow(currentRow.parentId, true);
				isFullyExpanded = currentRow.getIsExpanded();
			}
			return isFullyExpanded;
		};
		row.getToggleExpandedHandler = () => {
			const canExpand = row.getCanExpand();
			return () => {
				if (!canExpand) return;
				row.toggleExpanded();
			};
		};
	}
};
var defaultPageIndex = 0;
var defaultPageSize = 10;
var getDefaultPaginationState = () => ({
	pageIndex: defaultPageIndex,
	pageSize: defaultPageSize
});
var RowPagination = {
	getInitialState: (state) => {
		return {
			...state,
			pagination: {
				...getDefaultPaginationState(),
				...state == null ? void 0 : state.pagination
			}
		};
	},
	getDefaultOptions: (table) => {
		return { onPaginationChange: makeStateUpdater("pagination", table) };
	},
	createTable: (table) => {
		let registered = false;
		let queued = false;
		table._autoResetPageIndex = () => {
			var _ref, _table$options$autoRe;
			if (!registered) {
				table._queue(() => {
					registered = true;
				});
				return;
			}
			if ((_ref = (_table$options$autoRe = table.options.autoResetAll) != null ? _table$options$autoRe : table.options.autoResetPageIndex) != null ? _ref : !table.options.manualPagination) {
				if (queued) return;
				queued = true;
				table._queue(() => {
					table.resetPageIndex();
					queued = false;
				});
			}
		};
		table.setPagination = (updater) => {
			const safeUpdater = (old) => {
				return functionalUpdate(updater, old);
			};
			return table.options.onPaginationChange == null ? void 0 : table.options.onPaginationChange(safeUpdater);
		};
		table.resetPagination = (defaultState) => {
			var _table$initialState$p;
			table.setPagination(defaultState ? getDefaultPaginationState() : (_table$initialState$p = table.initialState.pagination) != null ? _table$initialState$p : getDefaultPaginationState());
		};
		table.setPageIndex = (updater) => {
			table.setPagination((old) => {
				let pageIndex = functionalUpdate(updater, old.pageIndex);
				const maxPageIndex = typeof table.options.pageCount === "undefined" || table.options.pageCount === -1 ? Number.MAX_SAFE_INTEGER : table.options.pageCount - 1;
				pageIndex = Math.max(0, Math.min(pageIndex, maxPageIndex));
				return {
					...old,
					pageIndex
				};
			});
		};
		table.resetPageIndex = (defaultState) => {
			var _table$initialState$p2, _table$initialState;
			table.setPageIndex(defaultState ? defaultPageIndex : (_table$initialState$p2 = (_table$initialState = table.initialState) == null || (_table$initialState = _table$initialState.pagination) == null ? void 0 : _table$initialState.pageIndex) != null ? _table$initialState$p2 : defaultPageIndex);
		};
		table.resetPageSize = (defaultState) => {
			var _table$initialState$p3, _table$initialState2;
			table.setPageSize(defaultState ? defaultPageSize : (_table$initialState$p3 = (_table$initialState2 = table.initialState) == null || (_table$initialState2 = _table$initialState2.pagination) == null ? void 0 : _table$initialState2.pageSize) != null ? _table$initialState$p3 : defaultPageSize);
		};
		table.setPageSize = (updater) => {
			table.setPagination((old) => {
				const pageSize = Math.max(1, functionalUpdate(updater, old.pageSize));
				const topRowIndex = old.pageSize * old.pageIndex;
				const pageIndex = Math.floor(topRowIndex / pageSize);
				return {
					...old,
					pageIndex,
					pageSize
				};
			});
		};
		table.setPageCount = (updater) => table.setPagination((old) => {
			var _table$options$pageCo;
			let newPageCount = functionalUpdate(updater, (_table$options$pageCo = table.options.pageCount) != null ? _table$options$pageCo : -1);
			if (typeof newPageCount === "number") newPageCount = Math.max(-1, newPageCount);
			return {
				...old,
				pageCount: newPageCount
			};
		});
		table.getPageOptions = memo$1(() => [table.getPageCount()], (pageCount) => {
			let pageOptions = [];
			if (pageCount && pageCount > 0) pageOptions = [...new Array(pageCount)].fill(null).map((_, i) => i);
			return pageOptions;
		}, getMemoOptions(table.options, "debugTable", "getPageOptions"));
		table.getCanPreviousPage = () => table.getState().pagination.pageIndex > 0;
		table.getCanNextPage = () => {
			const { pageIndex } = table.getState().pagination;
			const pageCount = table.getPageCount();
			if (pageCount === -1) return true;
			if (pageCount === 0) return false;
			return pageIndex < pageCount - 1;
		};
		table.previousPage = () => {
			return table.setPageIndex((old) => old - 1);
		};
		table.nextPage = () => {
			return table.setPageIndex((old) => {
				return old + 1;
			});
		};
		table.firstPage = () => {
			return table.setPageIndex(0);
		};
		table.lastPage = () => {
			return table.setPageIndex(table.getPageCount() - 1);
		};
		table.getPrePaginationRowModel = () => table.getExpandedRowModel();
		table.getPaginationRowModel = () => {
			if (!table._getPaginationRowModel && table.options.getPaginationRowModel) table._getPaginationRowModel = table.options.getPaginationRowModel(table);
			if (table.options.manualPagination || !table._getPaginationRowModel) return table.getPrePaginationRowModel();
			return table._getPaginationRowModel();
		};
		table.getPageCount = () => {
			var _table$options$pageCo2;
			return (_table$options$pageCo2 = table.options.pageCount) != null ? _table$options$pageCo2 : Math.ceil(table.getRowCount() / table.getState().pagination.pageSize);
		};
		table.getRowCount = () => {
			var _table$options$rowCou;
			return (_table$options$rowCou = table.options.rowCount) != null ? _table$options$rowCou : table.getPrePaginationRowModel().rows.length;
		};
	}
};
var getDefaultRowPinningState = () => ({
	top: [],
	bottom: []
});
var RowPinning = {
	getInitialState: (state) => {
		return {
			rowPinning: getDefaultRowPinningState(),
			...state
		};
	},
	getDefaultOptions: (table) => {
		return { onRowPinningChange: makeStateUpdater("rowPinning", table) };
	},
	createRow: (row, table) => {
		row.pin = (position, includeLeafRows, includeParentRows) => {
			const leafRowIds = includeLeafRows ? row.getLeafRows().map((_ref) => {
				let { id } = _ref;
				return id;
			}) : [];
			const parentRowIds = includeParentRows ? row.getParentRows().map((_ref2) => {
				let { id } = _ref2;
				return id;
			}) : [];
			const rowIds = new Set([
				...parentRowIds,
				row.id,
				...leafRowIds
			]);
			table.setRowPinning((old) => {
				var _old$top3, _old$bottom3;
				if (position === "bottom") {
					var _old$top, _old$bottom;
					return {
						top: ((_old$top = old == null ? void 0 : old.top) != null ? _old$top : []).filter((d) => !(rowIds != null && rowIds.has(d))),
						bottom: [...((_old$bottom = old == null ? void 0 : old.bottom) != null ? _old$bottom : []).filter((d) => !(rowIds != null && rowIds.has(d))), ...Array.from(rowIds)]
					};
				}
				if (position === "top") {
					var _old$top2, _old$bottom2;
					return {
						top: [...((_old$top2 = old == null ? void 0 : old.top) != null ? _old$top2 : []).filter((d) => !(rowIds != null && rowIds.has(d))), ...Array.from(rowIds)],
						bottom: ((_old$bottom2 = old == null ? void 0 : old.bottom) != null ? _old$bottom2 : []).filter((d) => !(rowIds != null && rowIds.has(d)))
					};
				}
				return {
					top: ((_old$top3 = old == null ? void 0 : old.top) != null ? _old$top3 : []).filter((d) => !(rowIds != null && rowIds.has(d))),
					bottom: ((_old$bottom3 = old == null ? void 0 : old.bottom) != null ? _old$bottom3 : []).filter((d) => !(rowIds != null && rowIds.has(d)))
				};
			});
		};
		row.getCanPin = () => {
			var _ref3;
			const { enableRowPinning, enablePinning } = table.options;
			if (typeof enableRowPinning === "function") return enableRowPinning(row);
			return (_ref3 = enableRowPinning != null ? enableRowPinning : enablePinning) != null ? _ref3 : true;
		};
		row.getIsPinned = () => {
			const rowIds = [row.id];
			const { top, bottom } = table.getState().rowPinning;
			const isTop = rowIds.some((d) => top == null ? void 0 : top.includes(d));
			const isBottom = rowIds.some((d) => bottom == null ? void 0 : bottom.includes(d));
			return isTop ? "top" : isBottom ? "bottom" : false;
		};
		row.getPinnedIndex = () => {
			var _ref4, _visiblePinnedRowIds$;
			const position = row.getIsPinned();
			if (!position) return -1;
			const visiblePinnedRowIds = (_ref4 = position === "top" ? table.getTopRows() : table.getBottomRows()) == null ? void 0 : _ref4.map((_ref5) => {
				let { id } = _ref5;
				return id;
			});
			return (_visiblePinnedRowIds$ = visiblePinnedRowIds == null ? void 0 : visiblePinnedRowIds.indexOf(row.id)) != null ? _visiblePinnedRowIds$ : -1;
		};
	},
	createTable: (table) => {
		table.setRowPinning = (updater) => table.options.onRowPinningChange == null ? void 0 : table.options.onRowPinningChange(updater);
		table.resetRowPinning = (defaultState) => {
			var _table$initialState$r, _table$initialState;
			return table.setRowPinning(defaultState ? getDefaultRowPinningState() : (_table$initialState$r = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.rowPinning) != null ? _table$initialState$r : getDefaultRowPinningState());
		};
		table.getIsSomeRowsPinned = (position) => {
			var _pinningState$positio;
			const pinningState = table.getState().rowPinning;
			if (!position) {
				var _pinningState$top, _pinningState$bottom;
				return Boolean(((_pinningState$top = pinningState.top) == null ? void 0 : _pinningState$top.length) || ((_pinningState$bottom = pinningState.bottom) == null ? void 0 : _pinningState$bottom.length));
			}
			return Boolean((_pinningState$positio = pinningState[position]) == null ? void 0 : _pinningState$positio.length);
		};
		table._getPinnedRows = (visibleRows, pinnedRowIds, position) => {
			var _table$options$keepPi;
			return (((_table$options$keepPi = table.options.keepPinnedRows) != null ? _table$options$keepPi : true) ? (pinnedRowIds != null ? pinnedRowIds : []).map((rowId) => {
				const row = table.getRow(rowId, true);
				return row.getIsAllParentsExpanded() ? row : null;
			}) : (pinnedRowIds != null ? pinnedRowIds : []).map((rowId) => visibleRows.find((row) => row.id === rowId))).filter(Boolean).map((d) => ({
				...d,
				position
			}));
		};
		table.getTopRows = memo$1(() => [table.getRowModel().rows, table.getState().rowPinning.top], (allRows, topPinnedRowIds) => table._getPinnedRows(allRows, topPinnedRowIds, "top"), getMemoOptions(table.options, "debugRows", "getTopRows"));
		table.getBottomRows = memo$1(() => [table.getRowModel().rows, table.getState().rowPinning.bottom], (allRows, bottomPinnedRowIds) => table._getPinnedRows(allRows, bottomPinnedRowIds, "bottom"), getMemoOptions(table.options, "debugRows", "getBottomRows"));
		table.getCenterRows = memo$1(() => [
			table.getRowModel().rows,
			table.getState().rowPinning.top,
			table.getState().rowPinning.bottom
		], (allRows, top, bottom) => {
			const topAndBottom = new Set([...top != null ? top : [], ...bottom != null ? bottom : []]);
			return allRows.filter((d) => !topAndBottom.has(d.id));
		}, getMemoOptions(table.options, "debugRows", "getCenterRows"));
	}
};
var RowSelection = {
	getInitialState: (state) => {
		return {
			rowSelection: {},
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onRowSelectionChange: makeStateUpdater("rowSelection", table),
			enableRowSelection: true,
			enableMultiRowSelection: true,
			enableSubRowSelection: true
		};
	},
	createTable: (table) => {
		table.setRowSelection = (updater) => table.options.onRowSelectionChange == null ? void 0 : table.options.onRowSelectionChange(updater);
		table.resetRowSelection = (defaultState) => {
			var _table$initialState$r;
			return table.setRowSelection(defaultState ? {} : (_table$initialState$r = table.initialState.rowSelection) != null ? _table$initialState$r : {});
		};
		table.toggleAllRowsSelected = (value) => {
			table.setRowSelection((old) => {
				value = typeof value !== "undefined" ? value : !table.getIsAllRowsSelected();
				const rowSelection = { ...old };
				const preGroupedFlatRows = table.getPreGroupedRowModel().flatRows;
				if (value) preGroupedFlatRows.forEach((row) => {
					if (!row.getCanSelect()) return;
					rowSelection[row.id] = true;
				});
				else preGroupedFlatRows.forEach((row) => {
					delete rowSelection[row.id];
				});
				return rowSelection;
			});
		};
		table.toggleAllPageRowsSelected = (value) => table.setRowSelection((old) => {
			const resolvedValue = typeof value !== "undefined" ? value : !table.getIsAllPageRowsSelected();
			const rowSelection = { ...old };
			table.getRowModel().rows.forEach((row) => {
				mutateRowIsSelected(rowSelection, row.id, resolvedValue, true, table);
			});
			return rowSelection;
		});
		table.getPreSelectedRowModel = () => table.getCoreRowModel();
		table.getSelectedRowModel = memo$1(() => [table.getState().rowSelection, table.getCoreRowModel()], (rowSelection, rowModel) => {
			if (!Object.keys(rowSelection).length) return {
				rows: [],
				flatRows: [],
				rowsById: {}
			};
			return selectRowsFn(table, rowModel);
		}, getMemoOptions(table.options, "debugTable", "getSelectedRowModel"));
		table.getFilteredSelectedRowModel = memo$1(() => [table.getState().rowSelection, table.getFilteredRowModel()], (rowSelection, rowModel) => {
			if (!Object.keys(rowSelection).length) return {
				rows: [],
				flatRows: [],
				rowsById: {}
			};
			return selectRowsFn(table, rowModel);
		}, getMemoOptions(table.options, "debugTable", "getFilteredSelectedRowModel"));
		table.getGroupedSelectedRowModel = memo$1(() => [table.getState().rowSelection, table.getSortedRowModel()], (rowSelection, rowModel) => {
			if (!Object.keys(rowSelection).length) return {
				rows: [],
				flatRows: [],
				rowsById: {}
			};
			return selectRowsFn(table, rowModel);
		}, getMemoOptions(table.options, "debugTable", "getGroupedSelectedRowModel"));
		table.getIsAllRowsSelected = () => {
			const preGroupedFlatRows = table.getFilteredRowModel().flatRows;
			const { rowSelection } = table.getState();
			let isAllRowsSelected = Boolean(preGroupedFlatRows.length && Object.keys(rowSelection).length);
			if (isAllRowsSelected) {
				if (preGroupedFlatRows.some((row) => row.getCanSelect() && !rowSelection[row.id])) isAllRowsSelected = false;
			}
			return isAllRowsSelected;
		};
		table.getIsAllPageRowsSelected = () => {
			const paginationFlatRows = table.getPaginationRowModel().flatRows.filter((row) => row.getCanSelect());
			const { rowSelection } = table.getState();
			let isAllPageRowsSelected = !!paginationFlatRows.length;
			if (isAllPageRowsSelected && paginationFlatRows.some((row) => !rowSelection[row.id])) isAllPageRowsSelected = false;
			return isAllPageRowsSelected;
		};
		table.getIsSomeRowsSelected = () => {
			var _table$getState$rowSe;
			const totalSelected = Object.keys((_table$getState$rowSe = table.getState().rowSelection) != null ? _table$getState$rowSe : {}).length;
			return totalSelected > 0 && totalSelected < table.getFilteredRowModel().flatRows.length;
		};
		table.getIsSomePageRowsSelected = () => {
			const paginationFlatRows = table.getPaginationRowModel().flatRows;
			return table.getIsAllPageRowsSelected() ? false : paginationFlatRows.filter((row) => row.getCanSelect()).some((d) => d.getIsSelected() || d.getIsSomeSelected());
		};
		table.getToggleAllRowsSelectedHandler = () => {
			return (e) => {
				table.toggleAllRowsSelected(e.target.checked);
			};
		};
		table.getToggleAllPageRowsSelectedHandler = () => {
			return (e) => {
				table.toggleAllPageRowsSelected(e.target.checked);
			};
		};
	},
	createRow: (row, table) => {
		row.toggleSelected = (value, opts) => {
			const isSelected = row.getIsSelected();
			table.setRowSelection((old) => {
				var _opts$selectChildren;
				value = typeof value !== "undefined" ? value : !isSelected;
				if (row.getCanSelect() && isSelected === value) return old;
				const selectedRowIds = { ...old };
				mutateRowIsSelected(selectedRowIds, row.id, value, (_opts$selectChildren = opts == null ? void 0 : opts.selectChildren) != null ? _opts$selectChildren : true, table);
				return selectedRowIds;
			});
		};
		row.getIsSelected = () => {
			const { rowSelection } = table.getState();
			return isRowSelected(row, rowSelection);
		};
		row.getIsSomeSelected = () => {
			const { rowSelection } = table.getState();
			return isSubRowSelected(row, rowSelection) === "some";
		};
		row.getIsAllSubRowsSelected = () => {
			const { rowSelection } = table.getState();
			return isSubRowSelected(row, rowSelection) === "all";
		};
		row.getCanSelect = () => {
			var _table$options$enable;
			if (typeof table.options.enableRowSelection === "function") return table.options.enableRowSelection(row);
			return (_table$options$enable = table.options.enableRowSelection) != null ? _table$options$enable : true;
		};
		row.getCanSelectSubRows = () => {
			var _table$options$enable2;
			if (typeof table.options.enableSubRowSelection === "function") return table.options.enableSubRowSelection(row);
			return (_table$options$enable2 = table.options.enableSubRowSelection) != null ? _table$options$enable2 : true;
		};
		row.getCanMultiSelect = () => {
			var _table$options$enable3;
			if (typeof table.options.enableMultiRowSelection === "function") return table.options.enableMultiRowSelection(row);
			return (_table$options$enable3 = table.options.enableMultiRowSelection) != null ? _table$options$enable3 : true;
		};
		row.getToggleSelectedHandler = () => {
			const canSelect = row.getCanSelect();
			return (e) => {
				var _target;
				if (!canSelect) return;
				row.toggleSelected((_target = e.target) == null ? void 0 : _target.checked);
			};
		};
	}
};
var mutateRowIsSelected = (selectedRowIds, id, value, includeChildren, table) => {
	var _row$subRows;
	const row = table.getRow(id, true);
	if (value) {
		if (!row.getCanMultiSelect()) Object.keys(selectedRowIds).forEach((key) => delete selectedRowIds[key]);
		if (row.getCanSelect()) selectedRowIds[id] = true;
	} else delete selectedRowIds[id];
	if (includeChildren && (_row$subRows = row.subRows) != null && _row$subRows.length && row.getCanSelectSubRows()) row.subRows.forEach((row) => mutateRowIsSelected(selectedRowIds, row.id, value, includeChildren, table));
};
function selectRowsFn(table, rowModel) {
	const rowSelection = table.getState().rowSelection;
	const newSelectedFlatRows = [];
	const newSelectedRowsById = {};
	const recurseRows = function(rows, depth) {
		return rows.map((row) => {
			var _row$subRows2;
			const isSelected = isRowSelected(row, rowSelection);
			if (isSelected) {
				newSelectedFlatRows.push(row);
				newSelectedRowsById[row.id] = row;
			}
			if ((_row$subRows2 = row.subRows) != null && _row$subRows2.length) row = {
				...row,
				subRows: recurseRows(row.subRows)
			};
			if (isSelected) return row;
		}).filter(Boolean);
	};
	return {
		rows: recurseRows(rowModel.rows),
		flatRows: newSelectedFlatRows,
		rowsById: newSelectedRowsById
	};
}
function isRowSelected(row, selection) {
	var _selection$row$id;
	return (_selection$row$id = selection[row.id]) != null ? _selection$row$id : false;
}
function isSubRowSelected(row, selection, table) {
	var _row$subRows3;
	if (!((_row$subRows3 = row.subRows) != null && _row$subRows3.length)) return false;
	let allChildrenSelected = true;
	let someSelected = false;
	row.subRows.forEach((subRow) => {
		if (someSelected && !allChildrenSelected) return;
		if (subRow.getCanSelect()) if (isRowSelected(subRow, selection)) someSelected = true;
		else allChildrenSelected = false;
		if (subRow.subRows && subRow.subRows.length) {
			const subRowChildrenSelected = isSubRowSelected(subRow, selection);
			if (subRowChildrenSelected === "all") someSelected = true;
			else if (subRowChildrenSelected === "some") {
				someSelected = true;
				allChildrenSelected = false;
			} else allChildrenSelected = false;
		}
	});
	return allChildrenSelected ? "all" : someSelected ? "some" : false;
}
var reSplitAlphaNumeric = /([0-9]+)/gm;
var alphanumeric = (rowA, rowB, columnId) => {
	return compareAlphanumeric(toString(rowA.getValue(columnId)).toLowerCase(), toString(rowB.getValue(columnId)).toLowerCase());
};
var alphanumericCaseSensitive = (rowA, rowB, columnId) => {
	return compareAlphanumeric(toString(rowA.getValue(columnId)), toString(rowB.getValue(columnId)));
};
var text = (rowA, rowB, columnId) => {
	return compareBasic(toString(rowA.getValue(columnId)).toLowerCase(), toString(rowB.getValue(columnId)).toLowerCase());
};
var textCaseSensitive = (rowA, rowB, columnId) => {
	return compareBasic(toString(rowA.getValue(columnId)), toString(rowB.getValue(columnId)));
};
var datetime = (rowA, rowB, columnId) => {
	const a = rowA.getValue(columnId);
	const b = rowB.getValue(columnId);
	return a > b ? 1 : a < b ? -1 : 0;
};
var basic = (rowA, rowB, columnId) => {
	return compareBasic(rowA.getValue(columnId), rowB.getValue(columnId));
};
function compareBasic(a, b) {
	return a === b ? 0 : a > b ? 1 : -1;
}
function toString(a) {
	if (typeof a === "number") {
		if (isNaN(a) || a === Infinity || a === -Infinity) return "";
		return String(a);
	}
	if (typeof a === "string") return a;
	return "";
}
function compareAlphanumeric(aStr, bStr) {
	const a = aStr.split(reSplitAlphaNumeric).filter(Boolean);
	const b = bStr.split(reSplitAlphaNumeric).filter(Boolean);
	while (a.length && b.length) {
		const aa = a.shift();
		const bb = b.shift();
		const an = parseInt(aa, 10);
		const bn = parseInt(bb, 10);
		const combo = [an, bn].sort();
		if (isNaN(combo[0])) {
			if (aa > bb) return 1;
			if (bb > aa) return -1;
			continue;
		}
		if (isNaN(combo[1])) return isNaN(an) ? -1 : 1;
		if (an > bn) return 1;
		if (bn > an) return -1;
	}
	return a.length - b.length;
}
var sortingFns = {
	alphanumeric,
	alphanumericCaseSensitive,
	text,
	textCaseSensitive,
	datetime,
	basic
};
var builtInFeatures = [
	Headers,
	ColumnVisibility,
	ColumnOrdering,
	ColumnPinning,
	ColumnFaceting,
	ColumnFiltering,
	GlobalFaceting,
	GlobalFiltering,
	{
		getInitialState: (state) => {
			return {
				sorting: [],
				...state
			};
		},
		getDefaultColumnDef: () => {
			return {
				sortingFn: "auto",
				sortUndefined: 1
			};
		},
		getDefaultOptions: (table) => {
			return {
				onSortingChange: makeStateUpdater("sorting", table),
				isMultiSortEvent: (e) => {
					return e.shiftKey;
				}
			};
		},
		createColumn: (column, table) => {
			column.getAutoSortingFn = () => {
				const firstRows = table.getFilteredRowModel().flatRows.slice(10);
				let isString = false;
				for (const row of firstRows) {
					const value = row == null ? void 0 : row.getValue(column.id);
					if (Object.prototype.toString.call(value) === "[object Date]") return sortingFns.datetime;
					if (typeof value === "string") {
						isString = true;
						if (value.split(reSplitAlphaNumeric).length > 1) return sortingFns.alphanumeric;
					}
				}
				if (isString) return sortingFns.text;
				return sortingFns.basic;
			};
			column.getAutoSortDir = () => {
				const firstRow = table.getFilteredRowModel().flatRows[0];
				if (typeof (firstRow == null ? void 0 : firstRow.getValue(column.id)) === "string") return "asc";
				return "desc";
			};
			column.getSortingFn = () => {
				var _table$options$sortin, _table$options$sortin2;
				if (!column) throw new Error();
				return isFunction(column.columnDef.sortingFn) ? column.columnDef.sortingFn : column.columnDef.sortingFn === "auto" ? column.getAutoSortingFn() : (_table$options$sortin = (_table$options$sortin2 = table.options.sortingFns) == null ? void 0 : _table$options$sortin2[column.columnDef.sortingFn]) != null ? _table$options$sortin : sortingFns[column.columnDef.sortingFn];
			};
			column.toggleSorting = (desc, multi) => {
				const nextSortingOrder = column.getNextSortingOrder();
				const hasManualValue = typeof desc !== "undefined" && desc !== null;
				table.setSorting((old) => {
					const existingSorting = old == null ? void 0 : old.find((d) => d.id === column.id);
					const existingIndex = old == null ? void 0 : old.findIndex((d) => d.id === column.id);
					let newSorting = [];
					let sortAction;
					let nextDesc = hasManualValue ? desc : nextSortingOrder === "desc";
					if (old != null && old.length && column.getCanMultiSort() && multi) if (existingSorting) sortAction = "toggle";
					else sortAction = "add";
					else if (old != null && old.length && existingIndex !== old.length - 1) sortAction = "replace";
					else if (existingSorting) sortAction = "toggle";
					else sortAction = "replace";
					if (sortAction === "toggle") {
						if (!hasManualValue) {
							if (!nextSortingOrder) sortAction = "remove";
						}
					}
					if (sortAction === "add") {
						var _table$options$maxMul;
						newSorting = [...old, {
							id: column.id,
							desc: nextDesc
						}];
						newSorting.splice(0, newSorting.length - ((_table$options$maxMul = table.options.maxMultiSortColCount) != null ? _table$options$maxMul : Number.MAX_SAFE_INTEGER));
					} else if (sortAction === "toggle") newSorting = old.map((d) => {
						if (d.id === column.id) return {
							...d,
							desc: nextDesc
						};
						return d;
					});
					else if (sortAction === "remove") newSorting = old.filter((d) => d.id !== column.id);
					else newSorting = [{
						id: column.id,
						desc: nextDesc
					}];
					return newSorting;
				});
			};
			column.getFirstSortDir = () => {
				var _ref, _column$columnDef$sor;
				return ((_ref = (_column$columnDef$sor = column.columnDef.sortDescFirst) != null ? _column$columnDef$sor : table.options.sortDescFirst) != null ? _ref : column.getAutoSortDir() === "desc") ? "desc" : "asc";
			};
			column.getNextSortingOrder = (multi) => {
				var _table$options$enable, _table$options$enable2;
				const firstSortDirection = column.getFirstSortDir();
				const isSorted = column.getIsSorted();
				if (!isSorted) return firstSortDirection;
				if (isSorted !== firstSortDirection && ((_table$options$enable = table.options.enableSortingRemoval) != null ? _table$options$enable : true) && (multi ? (_table$options$enable2 = table.options.enableMultiRemove) != null ? _table$options$enable2 : true : true)) return false;
				return isSorted === "desc" ? "asc" : "desc";
			};
			column.getCanSort = () => {
				var _column$columnDef$ena, _table$options$enable3;
				return ((_column$columnDef$ena = column.columnDef.enableSorting) != null ? _column$columnDef$ena : true) && ((_table$options$enable3 = table.options.enableSorting) != null ? _table$options$enable3 : true) && !!column.accessorFn;
			};
			column.getCanMultiSort = () => {
				var _ref2, _column$columnDef$ena2;
				return (_ref2 = (_column$columnDef$ena2 = column.columnDef.enableMultiSort) != null ? _column$columnDef$ena2 : table.options.enableMultiSort) != null ? _ref2 : !!column.accessorFn;
			};
			column.getIsSorted = () => {
				var _table$getState$sorti;
				const columnSort = (_table$getState$sorti = table.getState().sorting) == null ? void 0 : _table$getState$sorti.find((d) => d.id === column.id);
				return !columnSort ? false : columnSort.desc ? "desc" : "asc";
			};
			column.getSortIndex = () => {
				var _table$getState$sorti2, _table$getState$sorti3;
				return (_table$getState$sorti2 = (_table$getState$sorti3 = table.getState().sorting) == null ? void 0 : _table$getState$sorti3.findIndex((d) => d.id === column.id)) != null ? _table$getState$sorti2 : -1;
			};
			column.clearSorting = () => {
				table.setSorting((old) => old != null && old.length ? old.filter((d) => d.id !== column.id) : []);
			};
			column.getToggleSortingHandler = () => {
				const canSort = column.getCanSort();
				return (e) => {
					if (!canSort) return;
					e.persist == null || e.persist();
					column.toggleSorting == null || column.toggleSorting(void 0, column.getCanMultiSort() ? table.options.isMultiSortEvent == null ? void 0 : table.options.isMultiSortEvent(e) : false);
				};
			};
		},
		createTable: (table) => {
			table.setSorting = (updater) => table.options.onSortingChange == null ? void 0 : table.options.onSortingChange(updater);
			table.resetSorting = (defaultState) => {
				var _table$initialState$s, _table$initialState;
				table.setSorting(defaultState ? [] : (_table$initialState$s = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.sorting) != null ? _table$initialState$s : []);
			};
			table.getPreSortedRowModel = () => table.getGroupedRowModel();
			table.getSortedRowModel = () => {
				if (!table._getSortedRowModel && table.options.getSortedRowModel) table._getSortedRowModel = table.options.getSortedRowModel(table);
				if (table.options.manualSorting || !table._getSortedRowModel) return table.getPreSortedRowModel();
				return table._getSortedRowModel();
			};
		}
	},
	ColumnGrouping,
	RowExpanding,
	RowPagination,
	RowPinning,
	RowSelection,
	ColumnSizing
];
function createTable(options) {
	var _options$_features, _options$initialState;
	if (process.env.NODE_ENV !== "production" && (options.debugAll || options.debugTable)) console.info("Creating Table Instance...");
	const _features = [...builtInFeatures, ...(_options$_features = options._features) != null ? _options$_features : []];
	let table = { _features };
	const defaultOptions = table._features.reduce((obj, feature) => {
		return Object.assign(obj, feature.getDefaultOptions == null ? void 0 : feature.getDefaultOptions(table));
	}, {});
	const mergeOptions = (options) => {
		if (table.options.mergeOptions) return table.options.mergeOptions(defaultOptions, options);
		return {
			...defaultOptions,
			...options
		};
	};
	let initialState = { ...(_options$initialState = options.initialState) != null ? _options$initialState : {} };
	table._features.forEach((feature) => {
		var _feature$getInitialSt;
		initialState = (_feature$getInitialSt = feature.getInitialState == null ? void 0 : feature.getInitialState(initialState)) != null ? _feature$getInitialSt : initialState;
	});
	const queued = [];
	let queuedTimeout = false;
	const coreInstance = {
		_features,
		options: {
			...defaultOptions,
			...options
		},
		initialState,
		_queue: (cb) => {
			queued.push(cb);
			if (!queuedTimeout) {
				queuedTimeout = true;
				Promise.resolve().then(() => {
					while (queued.length) queued.shift()();
					queuedTimeout = false;
				}).catch((error) => setTimeout(() => {
					throw error;
				}));
			}
		},
		reset: () => {
			table.setState(table.initialState);
		},
		setOptions: (updater) => {
			table.options = mergeOptions(functionalUpdate(updater, table.options));
		},
		getState: () => {
			return table.options.state;
		},
		setState: (updater) => {
			table.options.onStateChange == null || table.options.onStateChange(updater);
		},
		_getRowId: (row, index, parent) => {
			var _table$options$getRow;
			return (_table$options$getRow = table.options.getRowId == null ? void 0 : table.options.getRowId(row, index, parent)) != null ? _table$options$getRow : `${parent ? [parent.id, index].join(".") : index}`;
		},
		getCoreRowModel: () => {
			if (!table._getCoreRowModel) table._getCoreRowModel = table.options.getCoreRowModel(table);
			return table._getCoreRowModel();
		},
		getRowModel: () => {
			return table.getPaginationRowModel();
		},
		getRow: (id, searchAll) => {
			let row = (searchAll ? table.getPrePaginationRowModel() : table.getRowModel()).rowsById[id];
			if (!row) {
				row = table.getCoreRowModel().rowsById[id];
				if (!row) {
					if (process.env.NODE_ENV !== "production") throw new Error(`getRow could not find row with ID: ${id}`);
					throw new Error();
				}
			}
			return row;
		},
		_getDefaultColumnDef: memo$1(() => [table.options.defaultColumn], (defaultColumn) => {
			var _defaultColumn;
			defaultColumn = (_defaultColumn = defaultColumn) != null ? _defaultColumn : {};
			return {
				header: (props) => {
					const resolvedColumnDef = props.header.column.columnDef;
					if (resolvedColumnDef.accessorKey) return resolvedColumnDef.accessorKey;
					if (resolvedColumnDef.accessorFn) return resolvedColumnDef.id;
					return null;
				},
				cell: (props) => {
					var _props$renderValue$to, _props$renderValue;
					return (_props$renderValue$to = (_props$renderValue = props.renderValue()) == null || _props$renderValue.toString == null ? void 0 : _props$renderValue.toString()) != null ? _props$renderValue$to : null;
				},
				...table._features.reduce((obj, feature) => {
					return Object.assign(obj, feature.getDefaultColumnDef == null ? void 0 : feature.getDefaultColumnDef());
				}, {}),
				...defaultColumn
			};
		}, getMemoOptions(options, "debugColumns", "_getDefaultColumnDef")),
		_getColumnDefs: () => table.options.columns,
		getAllColumns: memo$1(() => [table._getColumnDefs()], (columnDefs) => {
			const recurseColumns = function(columnDefs, parent, depth) {
				if (depth === void 0) depth = 0;
				return columnDefs.map((columnDef) => {
					const column = createColumn(table, columnDef, depth, parent);
					const groupingColumnDef = columnDef;
					column.columns = groupingColumnDef.columns ? recurseColumns(groupingColumnDef.columns, column, depth + 1) : [];
					return column;
				});
			};
			return recurseColumns(columnDefs);
		}, getMemoOptions(options, "debugColumns", "getAllColumns")),
		getAllFlatColumns: memo$1(() => [table.getAllColumns()], (allColumns) => {
			return allColumns.flatMap((column) => {
				return column.getFlatColumns();
			});
		}, getMemoOptions(options, "debugColumns", "getAllFlatColumns")),
		_getAllFlatColumnsById: memo$1(() => [table.getAllFlatColumns()], (flatColumns) => {
			return flatColumns.reduce((acc, column) => {
				acc[column.id] = column;
				return acc;
			}, {});
		}, getMemoOptions(options, "debugColumns", "getAllFlatColumnsById")),
		getAllLeafColumns: memo$1(() => [table.getAllColumns(), table._getOrderColumnsFn()], (allColumns, orderColumns) => {
			return orderColumns(allColumns.flatMap((column) => column.getLeafColumns()));
		}, getMemoOptions(options, "debugColumns", "getAllLeafColumns")),
		getColumn: (columnId) => {
			const column = table._getAllFlatColumnsById()[columnId];
			if (process.env.NODE_ENV !== "production" && !column) console.error(`[Table] Column with id '${columnId}' does not exist.`);
			return column;
		}
	};
	Object.assign(table, coreInstance);
	for (let index = 0; index < table._features.length; index++) {
		const feature = table._features[index];
		feature == null || feature.createTable == null || feature.createTable(table);
	}
	return table;
}
function getCoreRowModel() {
	return (table) => memo$1(() => [table.options.data], (data) => {
		const rowModel = {
			rows: [],
			flatRows: [],
			rowsById: {}
		};
		const accessRows = function(originalRows, depth, parentRow) {
			if (depth === void 0) depth = 0;
			const rows = [];
			for (let i = 0; i < originalRows.length; i++) {
				const row = createRow(table, table._getRowId(originalRows[i], i, parentRow), originalRows[i], i, depth, void 0, parentRow == null ? void 0 : parentRow.id);
				rowModel.flatRows.push(row);
				rowModel.rowsById[row.id] = row;
				rows.push(row);
				if (table.options.getSubRows) {
					var _row$originalSubRows;
					row.originalSubRows = table.options.getSubRows(originalRows[i], i);
					if ((_row$originalSubRows = row.originalSubRows) != null && _row$originalSubRows.length) row.subRows = accessRows(row.originalSubRows, depth + 1, row);
				}
			}
			return rows;
		};
		rowModel.rows = accessRows(data);
		return rowModel;
	}, getMemoOptions(table.options, "debugTable", "getRowModel", () => table._autoResetPageIndex()));
}
function getSortedRowModel() {
	return (table) => memo$1(() => [table.getState().sorting, table.getPreSortedRowModel()], (sorting, rowModel) => {
		if (!rowModel.rows.length || !(sorting != null && sorting.length)) return rowModel;
		const sortingState = table.getState().sorting;
		const sortedFlatRows = [];
		const availableSorting = sortingState.filter((sort) => {
			var _table$getColumn;
			return (_table$getColumn = table.getColumn(sort.id)) == null ? void 0 : _table$getColumn.getCanSort();
		});
		const columnInfoById = {};
		availableSorting.forEach((sortEntry) => {
			const column = table.getColumn(sortEntry.id);
			if (!column) return;
			columnInfoById[sortEntry.id] = {
				sortUndefined: column.columnDef.sortUndefined,
				invertSorting: column.columnDef.invertSorting,
				sortingFn: column.getSortingFn()
			};
		});
		const sortData = (rows) => {
			const sortedData = rows.map((row) => ({ ...row }));
			sortedData.sort((rowA, rowB) => {
				for (let i = 0; i < availableSorting.length; i += 1) {
					var _sortEntry$desc;
					const sortEntry = availableSorting[i];
					const columnInfo = columnInfoById[sortEntry.id];
					const sortUndefined = columnInfo.sortUndefined;
					const isDesc = (_sortEntry$desc = sortEntry == null ? void 0 : sortEntry.desc) != null ? _sortEntry$desc : false;
					let sortInt = 0;
					if (sortUndefined) {
						const aValue = rowA.getValue(sortEntry.id);
						const bValue = rowB.getValue(sortEntry.id);
						const aUndefined = aValue === void 0;
						const bUndefined = bValue === void 0;
						if (aUndefined || bUndefined) {
							if (sortUndefined === "first") return aUndefined ? -1 : 1;
							if (sortUndefined === "last") return aUndefined ? 1 : -1;
							sortInt = aUndefined && bUndefined ? 0 : aUndefined ? sortUndefined : -sortUndefined;
						}
					}
					if (sortInt === 0) sortInt = columnInfo.sortingFn(rowA, rowB, sortEntry.id);
					if (sortInt !== 0) {
						if (isDesc) sortInt *= -1;
						if (columnInfo.invertSorting) sortInt *= -1;
						return sortInt;
					}
				}
				return rowA.index - rowB.index;
			});
			sortedData.forEach((row) => {
				var _row$subRows;
				sortedFlatRows.push(row);
				if ((_row$subRows = row.subRows) != null && _row$subRows.length) row.subRows = sortData(row.subRows);
			});
			return sortedData;
		};
		return {
			rows: sortData(rowModel.rows),
			flatRows: sortedFlatRows,
			rowsById: rowModel.rowsById
		};
	}, getMemoOptions(table.options, "debugTable", "getSortedRowModel", () => table._autoResetPageIndex()));
}
//#endregion
//#region ../../node_modules/@tanstack/react-table/build/lib/index.mjs
/**
* react-table
*
* Copyright (c) TanStack
*
* This source code is licensed under the MIT license found in the
* LICENSE.md file in the root directory of this source tree.
*
* @license MIT
*/
/**
* If rendering headers, cells, or footers with custom markup, use flexRender instead of `cell.getValue()` or `cell.renderValue()`.
*/
function flexRender(Comp, props) {
	return !Comp ? null : isReactComponent(Comp) ? /*#__PURE__*/ React$1.createElement(Comp, props) : Comp;
}
function isReactComponent(component) {
	return isClassComponent(component) || typeof component === "function" || isExoticComponent(component);
}
function isClassComponent(component) {
	return typeof component === "function" && (() => {
		const proto = Object.getPrototypeOf(component);
		return proto.prototype && proto.prototype.isReactComponent;
	})();
}
function isExoticComponent(component) {
	return typeof component === "object" && typeof component.$$typeof === "symbol" && ["react.memo", "react.forward_ref"].includes(component.$$typeof.description);
}
function useReactTable(options) {
	const resolvedOptions = {
		state: {},
		onStateChange: () => {},
		renderFallbackValue: null,
		...options
	};
	const [tableRef] = React$1.useState(() => ({ current: createTable(resolvedOptions) }));
	const [state, setState] = React$1.useState(() => tableRef.current.initialState);
	tableRef.current.setOptions((prev) => ({
		...prev,
		...options,
		state: {
			...state,
			...options.state
		},
		onStateChange: (updater) => {
			setState(updater);
			options.onStateChange == null || options.onStateChange(updater);
		}
	}));
	return tableRef.current;
}
//#endregion
//#region ../../resources/scripts/components/elements/table/DataTable.tsx
var ariaSort = (table, column) => {
	const ids = column.columnDef.meta?.sortColumnIds;
	const direction = ids ? ids.map((id) => table.getColumn(id)?.getIsSorted()).find(Boolean) ?? false : column.getIsSorted();
	if (direction === "asc") return "ascending";
	if (direction === "desc") return "descending";
};
function DataTable({ table, emptyState, className, tableClassName, isFetching = false }) {
	const rows = table.getRowModel().rows;
	const ui = useSkin("Table", { fetching: isFetching });
	return /* @__PURE__ */ jsx("div", {
		"aria-busy": isFetching,
		...ui("root", className),
		children: rows.length === 0 ? /* @__PURE__ */ jsx("div", {
			...ui("empty"),
			children: isString$2(emptyState) ? /* @__PURE__ */ jsx(Empty, {
				size: "compact",
				children: /* @__PURE__ */ jsx(EmptyDescription, { children: emptyState })
			}) : emptyState
		}) : /* @__PURE__ */ jsx("div", {
			...ui("scroller"),
			children: /* @__PURE__ */ jsxs("table", {
				...ui("table", tableClassName),
				children: [/* @__PURE__ */ jsx("thead", {
					...ui("head"),
					children: table.getHeaderGroups().map((headerGroup) => /* @__PURE__ */ jsx("tr", {
						...ui("headerRow"),
						children: headerGroup.headers.map((header) => /* @__PURE__ */ jsx("th", {
							scope: "col",
							"aria-sort": ariaSort(table, header.column),
							...ui("headerCell", header.column.columnDef.meta?.headerClassName),
							children: header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())
						}, header.id))
					}, headerGroup.id))
				}), /* @__PURE__ */ jsx("tbody", {
					...ui("body"),
					children: rows.map((row) => /* @__PURE__ */ jsx("tr", {
						...ui("row"),
						children: row.getVisibleCells().map((cell) => /* @__PURE__ */ jsx("td", {
							...ui("cell", cell.column.columnDef.meta?.cellClassName),
							children: flexRender(cell.column.columnDef.cell, cell.getContext())
						}, cell.id))
					}, row.id))
				})]
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/table/DataTableColumnHeader.tsx
var sortIcons = {
	asc: ArrowUp,
	desc: ArrowDown
};
function DataTableColumnHeader({ column, title, className }) {
	if (!column.getCanSort()) return /* @__PURE__ */ jsx("span", {
		className,
		children: title
	});
	const direction = column.getIsSorted();
	const nextDirection = column.getNextSortingOrder();
	const label = nextDirection ? `Sort ${title} ${nextDirection === "asc" ? "ascending" : "descending"}` : `Clear ${title} sorting`;
	const SortIcon = direction ? sortIcons[direction] : ArrowUpDown;
	return /* @__PURE__ */ jsxs("button", {
		type: "button",
		"aria-label": label,
		onClick: column.getToggleSortingHandler(),
		className: cn$1("group -ml-1 inline-flex h-8 items-center gap-1 rounded-sm px-1 text-left [text-transform:inherit] transition-colors hover:text-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary", direction && "text-foreground", className),
		children: [/* @__PURE__ */ jsx("span", { children: title }), /* @__PURE__ */ jsx(SortIcon, {
			"aria-hidden": "true",
			className: cn$1("h-3 w-3 shrink-0 transition-opacity", direction ? "opacity-100" : "opacity-0 group-hover:opacity-70 group-focus-visible:opacity-70")
		})]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/table/DataTablePagination.tsx
var PageButton = ({ label, children, ...props }) => /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
	type: "button",
	size: "xsmall",
	isSecondary: true,
	"aria-label": label,
	title: label,
	className: "inline-flex h-8 w-8 items-center justify-center p-0",
	...props,
	children
});
function DataTablePagination({ table, total, count, itemLabel = "items", className }) {
	const { pageIndex, pageSize } = table.getState().pagination;
	const pageCount = table.getPageCount();
	const start = total === 0 ? 0 : pageIndex * pageSize + 1;
	const end = total === 0 ? 0 : Math.min(total, start + count - 1);
	const showPager = pageCount > 1 || pageIndex > 0;
	if (total === 0) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: cn$1("mt-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between", className),
		children: [/* @__PURE__ */ jsxs("p", {
			"aria-label": `Showing ${start} to ${end} of ${total} ${itemLabel}`,
			className: "text-xs text-muted-foreground",
			children: [
				"Showing ",
				/* @__PURE__ */ jsx("span", {
					className: "font-medium text-foreground",
					children: start
				}),
				"–",
				/* @__PURE__ */ jsx("span", {
					className: "font-medium text-foreground",
					children: end
				}),
				" of",
				" ",
				/* @__PURE__ */ jsx("span", {
					className: "font-medium text-foreground",
					children: total
				}),
				" ",
				itemLabel
			]
		}), showPager ? /* @__PURE__ */ jsxs("div", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ jsx(PageButton, {
					label: "First page",
					disabled: !table.getCanPreviousPage(),
					onClick: () => table.setPageIndex(0),
					children: /* @__PURE__ */ jsx(ChevronsLeft, {
						"aria-hidden": "true",
						className: "h-3.5 w-3.5"
					})
				}),
				/* @__PURE__ */ jsx(PageButton, {
					label: "Previous page",
					disabled: !table.getCanPreviousPage(),
					onClick: () => table.previousPage(),
					children: /* @__PURE__ */ jsx(ChevronLeft, {
						"aria-hidden": "true",
						className: "h-3.5 w-3.5"
					})
				}),
				/* @__PURE__ */ jsxs("span", {
					"aria-label": `Page ${pageIndex + 1} of ${Math.max(pageCount, 1)}`,
					"aria-live": "polite",
					className: "min-w-24 px-2 text-center text-xs text-muted-foreground",
					children: [
						"Page ",
						/* @__PURE__ */ jsx("span", {
							className: "font-medium text-foreground",
							children: pageIndex + 1
						}),
						" of",
						" ",
						/* @__PURE__ */ jsx("span", {
							className: "font-medium text-foreground",
							children: Math.max(pageCount, 1)
						})
					]
				}),
				/* @__PURE__ */ jsx(PageButton, {
					label: "Next page",
					disabled: !table.getCanNextPage(),
					onClick: () => table.nextPage(),
					children: /* @__PURE__ */ jsx(ChevronRight, {
						"aria-hidden": "true",
						className: "h-3.5 w-3.5"
					})
				}),
				/* @__PURE__ */ jsx(PageButton, {
					label: "Last page",
					disabled: !table.getCanNextPage(),
					onClick: () => table.setPageIndex(Math.max(pageCount - 1, 0)),
					children: /* @__PURE__ */ jsx(ChevronsRight, {
						"aria-hidden": "true",
						className: "h-3.5 w-3.5"
					})
				})
			]
		}) : null]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/table/RowActions.tsx
var iconClassName = "h-3.5 w-3.5";
/** Links and menu triggers look like the row's icon buttons. */
var useActionButton = () => useSkin("Button", {
	color: "grey",
	size: "xsmall",
	secondary: true,
	loading: false
});
var actionWidths = {
	1: "w-14",
	2: "w-24",
	3: "w-32"
};
/** Lays out a row's actions: edit, delete, then any overflow menu. */
function RowActions$1({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: "flex items-center justify-end gap-1",
		children
	});
}
var ActionTooltip = ({ content, children }) => /* @__PURE__ */ jsx(Tooltip$1, {
	content,
	children: /* @__PURE__ */ jsx("span", {
		className: "inline-flex",
		children
	})
});
function RowActionButton$1({ icon, label, danger, disabled, disabledReason, ...props }) {
	return /* @__PURE__ */ jsx(ActionTooltip, {
		content: disabled && disabledReason ? disabledReason : label,
		children: /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
			type: "button",
			size: "xsmall",
			color: danger ? "red" : "grey",
			isSecondary: true,
			disabled,
			...props,
			children: /* @__PURE__ */ jsx(Icon, {
				icon,
				className: iconClassName
			})
		})
	});
}
var EditAction$1 = (props) => /* @__PURE__ */ jsx(RowActionButton$1, {
	icon: Pencil,
	label: "Edit",
	...props
});
var DeleteAction$1 = ({ label = "Delete", ...props }) => /* @__PURE__ */ jsx(RowActionButton$1, {
	icon: Trash2,
	label,
	danger: true,
	...props
});
/** `EditAction` for resources edited on another page. */
function EditLinkAction$1(props) {
	const button = useActionButton();
	return /* @__PURE__ */ jsx(ActionTooltip, {
		content: "Edit",
		children: /* @__PURE__ */ jsx(Link, {
			...props,
			...button("root"),
			children: /* @__PURE__ */ jsx(Icon, {
				icon: Pencil,
				className: iconClassName
			})
		})
	});
}
/** The "…" menu for actions other than edit and delete. */
function RowActionsMenu$1({ label, children }) {
	return /* @__PURE__ */ jsx(DropdownMenuWithItems, {
		triggerClassName: useActionButton().classes("root"),
		triggerContent: /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Icon, {
			icon: MoreHorizontal,
			className: iconClassName
		}), /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: label
		})] }),
		children
	});
}
//#endregion
//#region ../../resources/scripts/sdk/table.tsx
function columnDefinition(column, renderers) {
	const shared = {
		id: column.id,
		cell: renderers.cell,
		meta: {
			headerClassName: column.headerClassName,
			cellClassName: column.cellClassName
		}
	};
	if (column.sortValue === void 0) return {
		...shared,
		header: renderers.header,
		enableSorting: false
	};
	return {
		...shared,
		accessorFn: column.sortValue,
		header: renderers.sortableHeader
	};
}
function useColumnRenderers(columns) {
	const latest = useRef(columns);
	latest.current = columns;
	const [renderers] = useState(() => {
		const find = (id) => latest.current.find((column) => column.id === id);
		return {
			cell: ({ row, column }) => find(column.id)?.cell(row.original),
			header: ({ column }) => find(column.id)?.label,
			sortableHeader: ({ column }) => /* @__PURE__ */ jsx(DataTableColumnHeader, {
				column,
				title: String(find(column.id)?.label)
			})
		};
	});
	return renderers;
}
function Table({ rows, columns, keyOf, pagination, ...props }) {
	const data = useMemo(() => [...rows], [rows]);
	const renderers = useColumnRenderers(columns);
	const definitions = useMemo(() => columns.map((column) => columnDefinition(column, renderers)), [columns, renderers]);
	const page = pagination?.page ?? 1;
	const perPage = pagination?.perPage ?? 1;
	const onPageSelect = pagination?.onPageSelect;
	const state = useMemo(() => ({
		pageIndex: page - 1,
		pageSize: perPage
	}), [page, perPage]);
	const onPaginationChange = useCallback((updater) => {
		const next = updater instanceof Function ? updater(state) : updater;
		if (next.pageIndex !== state.pageIndex) onPageSelect?.(next.pageIndex + 1);
	}, [state, onPageSelect]);
	const table = useReactTable({
		data,
		columns: definitions,
		getRowId: keyOf,
		getCoreRowModel: getCoreRowModel(),
		getSortedRowModel: getSortedRowModel(),
		...pagination && {
			manualPagination: true,
			rowCount: pagination.total,
			state: { pagination: state },
			onPaginationChange
		}
	});
	if (!pagination) return /* @__PURE__ */ jsx(DataTable, {
		table,
		...props
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(DataTable, {
		table,
		...props
	}), /* @__PURE__ */ jsx(DataTablePagination, {
		table,
		total: pagination.total,
		count: pagination.count,
		itemLabel: pagination.itemLabel
	})] });
}
/** Lays out a row's actions: edit, delete, then any `RowActionsMenu`. */
function RowActions({ children }) {
	return /* @__PURE__ */ jsx(RowActions$1, { children });
}
/** An icon button for a table row, labelled by a tooltip. */
function RowActionButton(props) {
	return /* @__PURE__ */ jsx(RowActionButton$1, { ...props });
}
function EditAction(props) {
	return /* @__PURE__ */ jsx(EditAction$1, { ...props });
}
function DeleteAction(props) {
	return /* @__PURE__ */ jsx(DeleteAction$1, { ...props });
}
/** The "…" menu for a row's actions other than edit and delete, holding `DropdownMenuItem`s. */
function RowActionsMenu(props) {
	return /* @__PURE__ */ jsx(RowActionsMenu$1, { ...props });
}
/** The trailing "Actions" column, sized for `actions` icon buttons in a `RowActions`; `width` overrides the size. */
function actionsColumn(actions, cell, width = actionWidths[actions]) {
	const className = `${width} text-right`;
	return {
		id: "actions",
		label: /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "Actions"
		}),
		cell,
		headerClassName: className,
		cellClassName: className
	};
}
/** The row's edit action, for rows edited on another page. */
function EditLinkAction({ destination, ...props }) {
	const { pathname, ...options } = resolvePanelDestination(destination);
	return /* @__PURE__ */ jsx(EditLinkAction$1, {
		to: pathname,
		...options,
		search: options.search,
		...props
	});
}
//#endregion
//#region ../../resources/scripts/sdk/tooltip.tsx
function Tooltip(props) {
	return /* @__PURE__ */ jsx(Tooltip$1, { ...props });
}
//#endregion
//#region ../../resources/scripts/sdk/qrCode.tsx
var QRCodeSVG = lazy(() => import("./esm-BmDzI2x2.js").then(({ QRCodeSVG: Code }) => ({ default: Code })));
/** `value` as a QR code; the renderer loads on first use, with a spinner meanwhile. */
function QrCode({ value, className }) {
	return /* @__PURE__ */ jsx(Suspense, {
		fallback: /* @__PURE__ */ jsx(Spinner, {}),
		children: /* @__PURE__ */ jsx(QRCodeSVG, {
			value,
			className
		})
	});
}
var clampLines = (lines) => Math.min(Math.max(Math.trunc(lines) || 1, 1), 100);
var serverLogsInput = (uuid, lines) => ({
	path: { server_uuid: uuid },
	query: { lines: clampLines(lines) }
});
var serverLogsQueryOptions$1 = (uuid, lines = 100) => clientGetServerLogsOptions(serverLogsInput(uuid, lines));
//#endregion
//#region ../../resources/scripts/api/server/queryDomains.ts
var domainKeys = {
	files: (id) => clientListFilesQueryKey({ path: { server_uuid: id } }),
	fileContent: (id) => {
		const [{ query: _query, ...key }] = clientGetFileContentsQueryKey({
			path: { server_uuid: id },
			query: { file: "" }
		});
		return [key];
	},
	startup: (id) => clientGetStartupConfigurationQueryKey({ path: { server_uuid: id } }),
	backups: (id) => clientListServerBackupsQueryKey({ path: { server_uuid: id } }),
	resources: (id) => clientGetServerResourcesQueryKey({ path: { server_uuid: id } })
};
function serverDomainQueryFilters(id, domain) {
	return domain === "server" ? serverQueryFilters(id) : { queryKey: domainKeys[domain](id) };
}
//#endregion
//#region ../../resources/scripts/sdk/queryOptions.ts
function publicQueryOptions(options, retry) {
	const fetch = options.queryFn;
	if (!fetch || fetch === skipToken) throw new Error("The panel query has no fetcher.");
	const queryFn = (context) => fetch({
		...context,
		queryKey: options.queryKey
	});
	const { queryKey } = queryOptions({
		queryKey: options.queryKey,
		queryFn
	});
	return retry === void 0 ? {
		queryKey,
		queryFn
	} : {
		queryKey,
		queryFn,
		retry
	};
}
//#endregion
//#region ../../resources/scripts/sdk/server.ts
function serverQueryOptions(id) {
	return publicQueryOptions(serverQueryOptions$1(id));
}
function serverFilesQueryOptions(id, directory) {
	return publicQueryOptions(serverFilesQueryOptions$1(id, directory));
}
function serverFileContentQueryOptions(id, file) {
	return publicQueryOptions(serverFileContentQueryOptions$1(id, file));
}
function serverStartupQueryOptions(id) {
	const options = serverStartupQueryOptions$1(id);
	return publicQueryOptions(options, options.retry);
}
function serverBackupsQueryOptions(id, page = 1) {
	return publicQueryOptions(serverBackupsQueryOptions$1(id, page));
}
/** Power state and resource usage of the server with this uuid, in the cache entry the dashboard polls. */
function serverResourcesQueryOptions(uuid) {
	const options = serverResourceUsageQueryOptions(uuid);
	return publicQueryOptions(options, options.retry);
}
/** Recent console output, oldest first; `lines` is clamped to 1-100 and needs `websocket.connect`. */
function serverLogsQueryOptions(id, lines) {
	return publicQueryOptions(serverLogsQueryOptions$1(id, lines));
}
function useServerFiles(id, directory, select) {
	return useQuery({
		...serverFilesQueryOptions(id, directory),
		enabled: !!id,
		select
	});
}
function useServerFileContent(id, file) {
	return useQuery({
		...serverFileContentQueryOptions(id, file),
		enabled: !!id && !!file
	});
}
function useServerStartup(id, select) {
	return useQuery({
		...serverStartupQueryOptions(id),
		enabled: !!id,
		select
	});
}
function useServerBackups(id, page = 1, select) {
	return useQuery({
		...serverBackupsQueryOptions(id, page),
		enabled: !!id,
		select
	});
}
/** Polls like the dashboard. Inside the server area, the "stats" and "status" websocket events are live. */
function useServerResources(uuid, select) {
	return useQuery({
		...serverResourcesQueryOptions(uuid),
		enabled: !!uuid,
		select,
		refetchInterval: serverResourceUsageRefetchInterval
	});
}
/** Return this promise from extension mutation callbacks to await the host's refetches. */
async function invalidateServerData(id, domains) {
	await Promise.all([...new Set(domains)].map((domain) => queryClient.invalidateQueries(serverDomainQueryFilters(id, domain))));
}
//#endregion
//#region ../../resources/scripts/sdk/mutations.ts
/** A panel mutation that takes the SDK's input and resolves with nothing. */
function voidMutation(mutation, toVariables) {
	return {
		...mutation,
		mutateAsync: async (input) => {
			await mutation.mutateAsync(toVariables(input));
		},
		data: void 0
	};
}
function useCreateServerDirectory(uuid) {
	return voidMutation(useCreateDirectory(), ({ directory, name }) => createDirectoryInput(uuid, directory, name));
}
function useRenameServerFiles(uuid) {
	return voidMutation(useRenameFiles(), ({ directory, files }) => renameFilesInput(uuid, directory, files));
}
function useDeleteServerFiles(uuid) {
	return voidMutation(useDeleteFiles(), ({ directory, files }) => deleteFilesInput(uuid, directory, files));
}
function useWriteServerFile(uuid) {
	return voidMutation(useSaveFileContent(), ({ file, content }) => writeFileContentsInput(uuid, file, content));
}
function useUpdateServerStartupVariable(uuid) {
	const mutation = useUpdateStartupVariable(uuid);
	return {
		...mutation,
		mutateAsync: ({ key, value }) => mutation.mutateAsync({
			path: { server_uuid: uuid },
			body: {
				key,
				value
			}
		})
	};
}
function useSetServerDockerImage(uuid) {
	return voidMutation(useSetSelectedDockerImage(uuid), ({ image }) => ({
		path: { server_uuid: uuid },
		body: { docker_image: image }
	}));
}
function useCreateServerBackup(uuid) {
	const mutation = useCreateServerBackup$1();
	return {
		...mutation,
		mutateAsync: (values) => mutation.mutateAsync(createServerBackupInput(uuid, values))
	};
}
/** The API requires the control permission that matches the signal. */
function useSendServerPower(uuid) {
	return voidMutation(useSendPowerAction(), ({ signal }) => sendPowerActionInput(uuid, signal));
}
/** The API requires control.console and a running server. */
function useSendServerCommand(uuid) {
	return voidMutation(useSendServerCommand$1(), ({ command }) => sendServerCommandInput(uuid, command));
}
//#endregion
//#region ../../resources/scripts/sdk/localization.ts
/** resources/lang/<locale>/<group>.php, registered with loadExtensionTranslations(). */
function useExtensionTranslation(group = "messages") {
	const mount = useContext(ExtensionContext);
	if (!mount) throw new Error("Extension translations require an extension mount.");
	if (!/^[a-z][a-z0-9_-]{0,63}$/.test(group)) throw new Error("Invalid extension translation group.");
	const { t, i18n, ready } = useTranslation(`ext-${mount.extensionId}::${group}`, { useSuspense: false });
	return {
		locale: i18n.language,
		ready,
		t: (key, values) => t(key, {
			...values,
			nsSeparator: false
		})
	};
}
//#endregion
//#region ../../resources/scripts/api/extensionProgress.ts
function extensionJobProgressQueryOptions(extension, job, serverUuid) {
	const queryFn = async ({ signal }) => {
		return (serverUuid ? await clientGetServerExtensionJobProgress({
			path: {
				extension,
				job,
				server_uuid: serverUuid
			},
			signal
		}) : await clientGetExtensionJobProgress({
			path: {
				extension,
				job
			},
			signal
		})).data.data;
	};
	return {
		queryKey: queryOptions({
			queryKey: [
				"extension-progress",
				extension,
				serverUuid ?? null,
				job
			],
			queryFn
		}).queryKey,
		queryFn
	};
}
//#endregion
//#region ../../resources/scripts/sdk/progress.ts
/** The key includes both the extension namespace and the subject. */
function extensionProgressQueryOptions(extension, job, serverUuid) {
	return publicQueryOptions(extensionJobProgressQueryOptions(extension, job, serverUuid));
}
/** Poll running jobs, stop terminal/expired jobs, and recover the latest snapshot on reconnect. */
function useExtensionJobProgress(job, options = {}) {
	const mount = useContext(ExtensionContext);
	if (!mount) throw new Error("Extension progress requires an extension mount.");
	return useQuery({
		...extensionProgressQueryOptions(mount.extensionId, job ?? "", options.serverUuid),
		enabled: !!job,
		staleTime: 0,
		refetchOnReconnect: "always",
		refetchInterval: (query) => query.state.error || query.state.data && query.state.data.status !== "running" ? false : 1500,
		retry: retryUnlessClientError(2)
	});
}
//#endregion
//#region ../../node_modules/dayjs/dayjs.min.js
var require_dayjs_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(t, e) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).dayjs = e();
	})(exports, (function() {
		"use strict";
		var t = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", s = "minute", u = "hour", a = "day", o = "week", c = "month", f = "quarter", h = "year", d = "date", l = "Invalid Date", $ = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|YYYY|YY|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, M = {
			name: "en",
			weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
			months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
			ordinal: function(t) {
				var e = [
					"th",
					"st",
					"nd",
					"rd"
				], n = t % 100;
				return "[" + t + (e[(n - 20) % 10] || e[n] || e[0]) + "]";
			}
		}, m = function(t, e, n) {
			var r = String(t);
			return !r || r.length >= e ? t : "" + Array(e + 1 - r.length).join(n) + t;
		}, v = {
			s: m,
			z: function(t) {
				var e = -t.utcOffset(), n = Math.abs(e), r = Math.floor(n / 60), i = n % 60;
				return (e <= 0 ? "+" : "-") + m(r, 2, "0") + ":" + m(i, 2, "0");
			},
			m: function t(e, n) {
				if (e.date() < n.date()) return -t(n, e);
				var r = 12 * (n.year() - e.year()) + (n.month() - e.month()), i = e.clone().add(r, c), s = n - i < 0, u = e.clone().add(r + (s ? -1 : 1), c);
				return +(-(r + (n - i) / (s ? i - u : u - i)) || 0);
			},
			a: function(t) {
				return t < 0 ? Math.ceil(t) || 0 : Math.floor(t);
			},
			p: function(t) {
				return {
					M: c,
					y: h,
					w: o,
					d: a,
					D: d,
					h: u,
					m: s,
					s: i,
					ms: r,
					Q: f
				}[t] || String(t || "").toLowerCase().replace(/s$/, "");
			},
			u: function(t) {
				return void 0 === t;
			}
		}, g = "en", D = {};
		D[g] = M;
		var p = "$isDayjsObject", S = function(t) {
			return t instanceof _ || !(!t || !t[p]);
		}, w = function t(e, n, r) {
			var i;
			if (!e) return g;
			if ("string" == typeof e) {
				var s = e.toLowerCase();
				D[s] && (i = s), n && (D[s] = n, i = s);
				var u = e.split("-");
				if (!i && u.length > 1) return t(u[0]);
			} else {
				var a = e.name;
				D[a] = e, i = a;
			}
			return !r && i && (g = i), i || !r && g;
		}, O = function(t, e) {
			if (S(t)) return t.clone();
			var n = "object" == typeof e ? e : {};
			return n.date = t, n.args = arguments, new _(n);
		}, b = v;
		b.l = w, b.i = S, b.w = function(t, e) {
			return O(t, {
				locale: e.$L,
				utc: e.$u,
				x: e.$x,
				$offset: e.$offset
			});
		};
		var _ = function() {
			function M(t) {
				this.$L = w(t.locale, null, !0), this.parse(t), this.$x = this.$x || t.x || {}, this[p] = !0;
			}
			var m = M.prototype;
			return m.parse = function(t) {
				this.$d = function(t) {
					var e = t.date, n = t.utc;
					if (null === e) return /* @__PURE__ */ new Date(NaN);
					if (b.u(e)) return /* @__PURE__ */ new Date();
					if (e instanceof Date) return new Date(e);
					if ("string" == typeof e && !/Z$/i.test(e)) {
						var r = e.match($);
						if (r) {
							var i = r[2] - 1 || 0, s = (r[7] || "0").substring(0, 3);
							return n ? new Date(Date.UTC(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s)) : new Date(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s);
						}
					}
					return new Date(e);
				}(t), this.init();
			}, m.init = function() {
				var t = this.$d;
				this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds();
			}, m.$utils = function() {
				return b;
			}, m.isValid = function() {
				return !(this.$d.toString() === l);
			}, m.isSame = function(t, e) {
				var n = O(t);
				return this.startOf(e) <= n && n <= this.endOf(e);
			}, m.isAfter = function(t, e) {
				return O(t) < this.startOf(e);
			}, m.isBefore = function(t, e) {
				return this.endOf(e) < O(t);
			}, m.$g = function(t, e, n) {
				return b.u(t) ? this[e] : this.set(n, t);
			}, m.unix = function() {
				return Math.floor(this.valueOf() / 1e3);
			}, m.valueOf = function() {
				return this.$d.getTime();
			}, m.startOf = function(t, e) {
				var n = this, r = !!b.u(e) || e, f = b.p(t), l = function(t, e) {
					var i = b.w(n.$u ? Date.UTC(n.$y, e, t) : new Date(n.$y, e, t), n);
					return r ? i : i.endOf(a);
				}, $ = function(t, e) {
					return b.w(n.toDate()[t].apply(n.toDate("s"), (r ? [
						0,
						0,
						0,
						0
					] : [
						23,
						59,
						59,
						999
					]).slice(e)), n);
				}, y = this.$W, M = this.$M, m = this.$D, v = "set" + (this.$u ? "UTC" : "");
				switch (f) {
					case h: return r ? l(1, 0) : l(31, 11);
					case c: return r ? l(1, M) : l(0, M + 1);
					case o:
						var g = this.$locale().weekStart || 0, D = (y < g ? y + 7 : y) - g;
						return l(r ? m - D : m + (6 - D), M);
					case a:
					case d: return $(v + "Hours", 0);
					case u: return $(v + "Minutes", 1);
					case s: return $(v + "Seconds", 2);
					case i: return $(v + "Milliseconds", 3);
					default: return this.clone();
				}
			}, m.endOf = function(t) {
				return this.startOf(t, !1);
			}, m.$set = function(t, e) {
				var n, o = b.p(t), f = "set" + (this.$u ? "UTC" : ""), l = (n = {}, n[a] = f + "Date", n[d] = f + "Date", n[c] = f + "Month", n[h] = f + "FullYear", n[u] = f + "Hours", n[s] = f + "Minutes", n[i] = f + "Seconds", n[r] = f + "Milliseconds", n)[o], $ = o === a ? this.$D + (e - this.$W) : e;
				if (o === c || o === h) {
					var y = this.clone().set(d, 1);
					y.$d[l]($), y.init(), this.$d = y.set(d, Math.min(this.$D, y.daysInMonth())).$d;
				} else l && this.$d[l]($);
				return this.init(), this;
			}, m.set = function(t, e) {
				return this.clone().$set(t, e);
			}, m.get = function(t) {
				return this[b.p(t)]();
			}, m.add = function(r, f) {
				var d, l = this;
				r = Number(r);
				var $ = b.p(f), y = function(t) {
					var e = O(l);
					return b.w(e.date(e.date() + Math.round(t * r)), l);
				};
				if ($ === c) return this.set(c, this.$M + r);
				if ($ === h) return this.set(h, this.$y + r);
				if ($ === a) return y(1);
				if ($ === o) return y(7);
				var M = (d = {}, d[s] = e, d[u] = n, d[i] = t, d)[$] || 1, m = this.$d.getTime() + r * M;
				return b.w(m, this);
			}, m.subtract = function(t, e) {
				return this.add(-1 * t, e);
			}, m.format = function(t) {
				var e = this, n = this.$locale();
				if (!this.isValid()) return n.invalidDate || l;
				var r = t || "YYYY-MM-DDTHH:mm:ssZ", i = b.z(this), s = this.$H, u = this.$m, a = this.$M, o = n.weekdays, c = n.months, f = n.meridiem, h = function(t, n, i, s) {
					return t && (t[n] || t(e, r)) || i[n].slice(0, s);
				}, d = function(t) {
					return b.s(s % 12 || 12, t, "0");
				}, $ = f || function(t, e, n) {
					var r = t < 12 ? "AM" : "PM";
					return n ? r.toLowerCase() : r;
				};
				return r.replace(y, (function(t, r) {
					return r || function(t) {
						switch (t) {
							case "YY": return String(e.$y).slice(-2);
							case "YYYY": return b.s(e.$y, 4, "0");
							case "M": return a + 1;
							case "MM": return b.s(a + 1, 2, "0");
							case "MMM": return h(n.monthsShort, a, c, 3);
							case "MMMM": return h(c, a);
							case "D": return e.$D;
							case "DD": return b.s(e.$D, 2, "0");
							case "d": return String(e.$W);
							case "dd": return h(n.weekdaysMin, e.$W, o, 2);
							case "ddd": return h(n.weekdaysShort, e.$W, o, 3);
							case "dddd": return o[e.$W];
							case "H": return String(s);
							case "HH": return b.s(s, 2, "0");
							case "h": return d(1);
							case "hh": return d(2);
							case "a": return $(s, u, !0);
							case "A": return $(s, u, !1);
							case "m": return String(u);
							case "mm": return b.s(u, 2, "0");
							case "s": return String(e.$s);
							case "ss": return b.s(e.$s, 2, "0");
							case "SSS": return b.s(e.$ms, 3, "0");
							case "Z": return i;
						}
						return null;
					}(t) || i.replace(":", "");
				}));
			}, m.utcOffset = function() {
				return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
			}, m.diff = function(r, d, l) {
				var $, y = this, M = b.p(d), m = O(r), v = (m.utcOffset() - this.utcOffset()) * e, g = this - m, D = function() {
					return b.m(y, m);
				};
				switch (M) {
					case h:
						$ = D() / 12;
						break;
					case c:
						$ = D();
						break;
					case f:
						$ = D() / 3;
						break;
					case o:
						$ = (g - v) / 6048e5;
						break;
					case a:
						$ = (g - v) / 864e5;
						break;
					case u:
						$ = g / n;
						break;
					case s:
						$ = g / e;
						break;
					case i:
						$ = g / t;
						break;
					default: $ = g;
				}
				return l ? $ : b.a($);
			}, m.daysInMonth = function() {
				return this.endOf(c).$D;
			}, m.$locale = function() {
				return D[this.$L];
			}, m.locale = function(t, e) {
				if (!t) return this.$L;
				var n = this.clone(), r = w(t, e, !0);
				return r && (n.$L = r), n;
			}, m.clone = function() {
				return b.w(this.$d, this);
			}, m.toDate = function() {
				return new Date(this.valueOf());
			}, m.toJSON = function() {
				return this.isValid() ? this.toISOString() : null;
			}, m.toISOString = function() {
				return this.$d.toISOString();
			}, m.toString = function() {
				return this.$d.toUTCString();
			}, M;
		}(), Y = _.prototype;
		return O.prototype = Y, [
			["$ms", r],
			["$s", i],
			["$m", s],
			["$H", u],
			["$W", a],
			["$M", c],
			["$y", h],
			["$D", d]
		].forEach((function(t) {
			Y[t[1]] = function(e) {
				return this.$g(e, t[0], t[1]);
			};
		})), O.extend = function(t, e) {
			return t.$i || (t(e, _, O), t.$i = !0), O;
		}, O.locale = w, O.isDayjs = S, O.unix = function(t) {
			return O(1e3 * t);
		}, O.en = D[g], O.Ls = D, O.p = {}, O;
	}));
}));
//#endregion
//#region ../../node_modules/dayjs/plugin/advancedFormat.js
var require_advancedFormat = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).dayjs_plugin_advancedFormat = t();
	})(exports, (function() {
		"use strict";
		return function(e, t) {
			var r = t.prototype, n = r.format;
			r.format = function(e) {
				var t = this, r = this.$locale();
				if (!this.isValid()) return n.bind(this)(e);
				var s = this.$utils(), a = (e || "YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g, (function(e) {
					switch (e) {
						case "Q": return Math.ceil((t.$M + 1) / 3);
						case "Do": return r.ordinal(t.$D);
						case "gggg": return t.weekYear();
						case "GGGG": return t.isoWeekYear();
						case "wo": return r.ordinal(t.week(), "W");
						case "w":
						case "ww": return s.s(t.week(), "w" === e ? 1 : 2, "0");
						case "W":
						case "WW": return s.s(t.isoWeek(), "W" === e ? 1 : 2, "0");
						case "k":
						case "kk": return s.s(String(0 === t.$H ? 24 : t.$H), "k" === e ? 1 : 2, "0");
						case "X": return Math.floor(t.$d.getTime() / 1e3);
						case "x": return t.$d.getTime();
						case "z": return "[" + t.offsetName() + "]";
						case "zzz": return "[" + t.offsetName("long") + "]";
						default: return e;
					}
				}));
				return n.bind(this)(a);
			};
		};
	}));
}));
//#endregion
//#region ../../node_modules/dayjs/plugin/relativeTime.js
var require_relativeTime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(r, e) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (r = "undefined" != typeof globalThis ? globalThis : r || self).dayjs_plugin_relativeTime = e();
	})(exports, (function() {
		"use strict";
		return function(r, e, t) {
			r = r || {};
			var n = e.prototype, o = {
				future: "in %s",
				past: "%s ago",
				s: "a few seconds",
				m: "a minute",
				mm: "%d minutes",
				h: "an hour",
				hh: "%d hours",
				d: "a day",
				dd: "%d days",
				M: "a month",
				MM: "%d months",
				y: "a year",
				yy: "%d years"
			};
			function i(r, e, t, o) {
				return n.fromToBase(r, e, t, o);
			}
			t.en.relativeTime = o, n.fromToBase = function(e, n, i, d, u) {
				for (var f, a, s, l = i.$locale().relativeTime || o, h = r.thresholds || [
					{
						l: "s",
						r: 44,
						d: "second"
					},
					{
						l: "m",
						r: 89
					},
					{
						l: "mm",
						r: 44,
						d: "minute"
					},
					{
						l: "h",
						r: 89
					},
					{
						l: "hh",
						r: 21,
						d: "hour"
					},
					{
						l: "d",
						r: 35
					},
					{
						l: "dd",
						r: 25,
						d: "day"
					},
					{
						l: "M",
						r: 45
					},
					{
						l: "MM",
						r: 10,
						d: "month"
					},
					{
						l: "y",
						r: 17
					},
					{
						l: "yy",
						d: "year"
					}
				], m = h.length, c = 0; c < m; c += 1) {
					var y = h[c];
					y.d && (f = d ? t(e).diff(i, y.d, !0) : i.diff(e, y.d, !0));
					var p = (r.rounding || Math.round)(Math.abs(f));
					if (s = f > 0, p <= y.r || !y.r) {
						p <= 1 && c > 0 && (y = h[c - 1]);
						var v = l[y.l];
						u && (p = u("" + p)), a = "string" == typeof v ? v.replace("%d", p) : v(p, n, y.l, s);
						break;
					}
				}
				if (n) return a;
				var M = s ? l.future : l.past;
				return "function" == typeof M ? M(a) : M.replace("%s", a);
			}, n.to = function(r, e) {
				return i(r, e, this, !0);
			}, n.from = function(r, e) {
				return i(r, e, this);
			};
			var d = function(r) {
				return r.$u ? t.utc() : t();
			};
			n.toNow = function(r) {
				return this.to(d(this), r);
			}, n.fromNow = function(r) {
				return this.from(d(this), r);
			};
		};
	}));
}));
//#endregion
//#region ../../resources/scripts/lib/dayjs.ts
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
var import_advancedFormat = /* @__PURE__ */ __toESM(require_advancedFormat());
var import_relativeTime = /* @__PURE__ */ __toESM(require_relativeTime());
import_dayjs_min.default.extend(import_advancedFormat.default);
import_dayjs_min.default.extend(import_relativeTime.default);
var dayjs_default = import_dayjs_min.default;
//#endregion
//#region ../../resources/scripts/lib/dates.ts
/** Formats a date with dayjs tokens, advanced ones included, such as `MMM Do [at] h:mmA`. */
function formatDate(date, format) {
	return dayjs_default(date).format(format);
}
/** How long ago a date was, such as "3 hours ago". */
function fromNow(date) {
	return dayjs_default(date).fromNow();
}
//#endregion
//#region ../../resources/scripts/sdk/core.ts
/** Joins class names; a later Tailwind utility replaces an earlier one of the same kind, prefixes included. */
function cn(...classes) {
	return cn$1(...classes);
}
function useCurrentUser() {
	return useCurrentUser$1();
}
function useSiteSettings() {
	return useSiteSettings$1();
}
function useCurrentServer(select) {
	return useCurrentServer$1(select);
}
function useCurrentServerPermissions() {
	return useCurrentServerPermissions$1();
}
/** Identity helper giving extension entrypoints full typing: `export default definePterodactylExtension({...})`. */
function definePterodactylExtension(definition) {
	return definition;
}
/** Like definePterodactylExtension, with `config` decoded by `parseConfig` and typed screen ids. */
function defineConfiguredExtension(parseConfig, definition) {
	return { setup: (context) => definition.setup({
		...context,
		config: parseConfig(context.config)
	}) };
}
/**
* Subscribes to a server websocket event while mounted under /server/$id.
* Only call from server screens, server slots, or components rendered under them.
*/
function useServerWebsocketEvent(event, callback) {
	useWebsocketEvent(event, useExtensionCallback(event, callback));
}
function useCurrentServerUuid() {
	return useCurrentServerUuid$1();
}
function useCurrentServerRequired(message = "This extension screen requires a server context.") {
	const server = useCurrentServer();
	if (!server) throw new Error(message);
	return server;
}
function useServerPermission(permission, matchAny = false) {
	const permissions = useCurrentServerPermissions();
	const matches = (Array.isArray(permission) ? permission : [permission]).map((item) => hasPermission(permissions, item));
	return matchAny ? matches.some(Boolean) : matches.every(Boolean);
}
//#endregion
//#region ../../resources/scripts/components/server/console/AreaChart.tsx
var GRID_COLOR = "var(--border)";
var TICK_COLOR = "var(--muted-foreground)";
var SANS_FONT = "var(--font-sans)";
var Y_AXIS_WIDTH = 64;
var MARGIN = {
	top: 8,
	right: 8,
	bottom: 0,
	left: 0
};
var RIGHT_LAG_MS = 1100;
var SLIDE_MS = 4e3;
var LazyRechartsAreaChart = lazy(async () => {
	const { Area, AreaChart: RechartsAreaChart, CartesianGrid, XAxis, YAxis } = await import("./es6-BOfeCW3F.js");
	return { default: function RechartsAreaChartContent({ data, series, live, uid, width, height, windowMs, yDomain, tickFormatter }) {
		const slider = useRef(null);
		const points = useMemo(() => [...data], [data]);
		const plotWidth = Math.max(0, width - Y_AXIS_WIDTH - MARGIN.right);
		const slideDistance = plotWidth * SLIDE_MS / windowMs;
		const anchor = data.at(-1)?.t;
		const right = (anchor ?? 0) - RIGHT_LAG_MS;
		const xDomain = useMemo(() => [right - windowMs, right + SLIDE_MS], [right, windowMs]);
		useLayoutEffect(() => {
			if (!slider.current || anchor === void 0) return;
			const animation = slider.current.animate([{ transform: "translateX(0)" }, { transform: `translateX(${-slideDistance}px)` }], {
				duration: SLIDE_MS,
				easing: "linear",
				fill: "forwards"
			});
			animation.currentTime = Math.min(SLIDE_MS, Math.max(0, performance.now() - anchor));
			if (!live) animation.pause();
			return () => animation.cancel();
		}, [
			anchor,
			live,
			slideDistance
		]);
		return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
			className: "absolute inset-0",
			children: /* @__PURE__ */ jsxs(RechartsAreaChart, {
				width,
				height,
				data: points,
				margin: MARGIN,
				children: [
					/* @__PURE__ */ jsx(CartesianGrid, {
						stroke: GRID_COLOR,
						strokeDasharray: "0",
						vertical: false
					}),
					/* @__PURE__ */ jsx(XAxis, {
						dataKey: "t",
						type: "number",
						domain: xDomain,
						allowDataOverflow: true,
						hide: true
					}),
					/* @__PURE__ */ jsx(YAxis, {
						width: Y_AXIS_WIDTH,
						tickCount: 3,
						domain: yDomain,
						tickFormatter,
						axisLine: false,
						tickLine: false,
						tick: {
							fill: TICK_COLOR,
							fontFamily: SANS_FONT,
							fontSize: "var(--text-xs)",
							fontWeight: "var(--font-weight-normal)"
						}
					}),
					series.map(({ dataKey }) => /* @__PURE__ */ jsx(Area, {
						dataKey,
						stroke: "none",
						fill: "none",
						isAnimationActive: false,
						dot: false,
						activeDot: false
					}, dataKey))
				]
			})
		}), /* @__PURE__ */ jsx("div", {
			className: "absolute top-0 bottom-0 overflow-hidden",
			style: {
				left: Y_AXIS_WIDTH,
				right: MARGIN.right
			},
			children: /* @__PURE__ */ jsx("div", {
				ref: slider,
				className: "will-change-transform",
				children: /* @__PURE__ */ jsxs(RechartsAreaChart, {
					width: plotWidth + slideDistance,
					height,
					data: points,
					margin: {
						...MARGIN,
						right: 0
					},
					children: [
						/* @__PURE__ */ jsxs("defs", { children: [series.map(({ dataKey, color }) => /* @__PURE__ */ jsxs("linearGradient", {
							id: `${uid}-fill-${dataKey}`,
							x1: "0",
							y1: "0",
							x2: "0",
							y2: "1",
							children: [/* @__PURE__ */ jsx("stop", {
								offset: "0%",
								stopColor: color,
								stopOpacity: .45
							}), /* @__PURE__ */ jsx("stop", {
								offset: "100%",
								stopColor: color,
								stopOpacity: 0
							})]
						}, dataKey)), series.map(({ dataKey, color }) => /* @__PURE__ */ jsx("filter", {
							id: `${uid}-glow-${dataKey}`,
							x: "-20%",
							y: "-20%",
							width: "140%",
							height: "140%",
							children: /* @__PURE__ */ jsx("feDropShadow", {
								dx: "0",
								dy: "0",
								stdDeviation: "2.5",
								floodColor: color,
								floodOpacity: .7
							})
						}, dataKey))] }),
						/* @__PURE__ */ jsx(XAxis, {
							dataKey: "t",
							type: "number",
							domain: xDomain,
							allowDataOverflow: true,
							hide: true
						}),
						/* @__PURE__ */ jsx(YAxis, {
							hide: true,
							tickCount: 3,
							domain: yDomain
						}),
						series.map(({ dataKey, color }) => /* @__PURE__ */ jsx(Area, {
							type: "monotone",
							dataKey,
							stroke: color,
							strokeWidth: 2,
							fill: `url(#${uid}-fill-${dataKey})`,
							filter: `url(#${uid}-glow-${dataKey})`,
							isAnimationActive: false,
							dot: false,
							activeDot: false,
							connectNulls: false
						}, dataKey))
					]
				})
			})
		})] });
	} };
});
/** A live time series chart drawn with the `--chart-*`, `--border` and `--muted-foreground` tokens. */
function AreaChart({ data, series, live, windowMs, suggestedMax, tickFormatter, height = 180 }) {
	const uid = useId().replaceAll(":", "");
	const container = useRef(null);
	const width = useElementWidth(container);
	const yDomain = useMemo(() => suggestedMax === void 0 ? [0, "auto"] : [0, (dataMax) => Math.max(suggestedMax, dataMax)], [suggestedMax]);
	return /* @__PURE__ */ jsx("div", {
		ref: container,
		className: "relative",
		style: { height },
		children: width > 0 && /* @__PURE__ */ jsx(Suspense, { children: /* @__PURE__ */ jsx(LazyRechartsAreaChart, {
			data,
			series,
			live,
			uid,
			width,
			height,
			windowMs,
			yDomain,
			tickFormatter
		}) })
	});
}
//#endregion
export { Avatar as $, serverFileContentQueryOptions as A, Code$1 as At, useServerStartup as B, NamedIcon as Bt, useSendServerCommand as C, screenImages as Ct, useWriteServerFile as D, ServerContentBlock as Dt, useUpdateServerStartupVariable as E, TitledGreyBox as Et, serverStartupQueryOptions as F, ProgressBar as Ft, EditLinkAction as G, Tooltip as H, useServerBackups as I, ListRow as It, RowActionsMenu as J, RowActionButton as K, useServerFileContent as L, Card as Lt, serverLogsQueryOptions as M, PageFooter as Mt, serverQueryOptions as N, ChartCard as Nt, invalidateServerData as O, PageContentBlock as Ot, serverResourcesQueryOptions as P, Stat as Pt, ListToolbar as Q, useServerFiles as R, SpinnerOverlay as Rt, useRenameServerFiles as S, ServerError as St, useSetServerDockerImage as T, Portal as Tt, DeleteAction as U, QrCode as V, loadIconNames as Vt, EditAction as W, actionsColumn as X, Table as Y, SecretInput as Z, useExtensionJobProgress as _, PageHeading as _t, definePterodactylExtension as a, EmptyTitle as at, useCreateServerDirectory as b, NotFound as bt, useCurrentServerRequired as c, SubNavigationLayout as ct, useServerPermission as d, ContextDropdownMenu as dt, Empty as et, useServerWebsocketEvent as f, DropdownMenuItem as ft, extensionProgressQueryOptions as g, NewLinkButton as gt, fromNow as h, NewButton as ht, defineConfiguredExtension as i, EmptyMedia as it, serverFilesQueryOptions as j, Badge as jt, serverBackupsQueryOptions as k, ContentBox as kt, useCurrentServerUuid as l, SubNavigation as lt, formatDate as m, InputSpinner as mt, AreaChart as n, EmptyDescription as nt, useCurrentServer as o, Pagination as ot, useSiteSettings as p, DropdownMenuWithItems as pt, RowActions as q, cn as r, EmptyHeader as rt, useCurrentServerPermissions as s, Alert as st, toast$1 as t, EmptyContent as tt, useCurrentUser as u, NavigationLabel as ut, useExtensionTranslation as v, Translate as vt, useSendServerPower as w, CopyOnClick as wt, useDeleteServerFiles as x, ScreenBlock as xt, useCreateServerBackup as y, PaginationFooter as yt, useServerResources as z, Can as zt };

//# sourceMappingURL=sdk-Chrtpiam.js.map