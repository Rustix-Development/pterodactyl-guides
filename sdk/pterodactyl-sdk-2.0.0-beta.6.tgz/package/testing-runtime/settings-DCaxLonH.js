import { n as ButtonWithVariants } from "./Button-BzlrfY24.js";
import { Dt as ServerContentBlock, Lt as Card, Rt as SpinnerOverlay, r as cn, wt as CopyOnClick } from "./sdk-Chrtpiam.js";
import { c as View } from "./theme-Cgy7R6cy.js";
import { l as Label, n as useAppForm, p as TextInput, r as Form } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { n as ip } from "./formatters-BBp7wFVw.js";
import { jsx, jsxs } from "react/jsx-runtime";
//#region ../../resources/scripts/themes/classic/views/server/settings/SettingsPage.tsx
function SettingsPage({ className }) {
	return /* @__PURE__ */ jsx(ServerContentBlock, {
		title: "Settings",
		className,
		children: /* @__PURE__ */ jsxs("div", {
			className: "md:flex",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "w-full md:flex-1 md:mr-10",
				children: [/* @__PURE__ */ jsx(View, {
					name: "server.sftp",
					className: "mb-6 md:mb-10"
				}), /* @__PURE__ */ jsx(View, {
					name: "server.debug",
					className: "mb-6 md:mb-10"
				})]
			}), /* @__PURE__ */ jsxs("div", {
				className: "w-full mt-6 md:flex-1 md:mt-0",
				children: [/* @__PURE__ */ jsx(View, {
					name: "server.rename",
					className: "mb-6 md:mb-10"
				}), /* @__PURE__ */ jsx(View, { name: "server.reinstall" })]
			})]
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/settings/ServerSftp.tsx
function ServerSftp({ model, className }) {
	if (!model.allowed) return null;
	const host = `${ip(model.ip)}:${model.port}`;
	return /* @__PURE__ */ jsxs(Card, {
		title: "SFTP Details",
		className,
		children: [
			/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(Label, { children: "Server Address" }), /* @__PURE__ */ jsx(CopyOnClick, {
				text: `sftp://${host}`,
				children: /* @__PURE__ */ jsx(TextInput, {
					type: "text",
					value: `sftp://${host}`,
					readOnly: true
				})
			})] }),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ jsx(Label, { children: "Username" }), /* @__PURE__ */ jsx(CopyOnClick, {
					text: model.username,
					children: /* @__PURE__ */ jsx(TextInput, {
						type: "text",
						value: model.username,
						readOnly: true
					})
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6 flex items-center",
				children: [/* @__PURE__ */ jsx("div", {
					className: "flex-1",
					children: /* @__PURE__ */ jsx("div", {
						className: "border-l-4 border-accent p-3",
						children: /* @__PURE__ */ jsx("p", {
							className: "text-xs text-foreground",
							children: "Your SFTP password is the same as the password you use to access this panel."
						})
					})
				}), /* @__PURE__ */ jsx("div", {
					className: "ml-4",
					children: /* @__PURE__ */ jsx("a", {
						href: `sftp://${model.username}@${host}`,
						children: /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
							isSecondary: true,
							children: "Launch SFTP"
						})
					})
				})]
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/settings/ServerDebug.tsx
function ServerDebug({ model, className }) {
	return /* @__PURE__ */ jsxs(Card, {
		title: "Debug Information",
		className,
		children: [/* @__PURE__ */ jsxs("div", {
			className: "flex items-center justify-between text-sm",
			children: [/* @__PURE__ */ jsx("p", { children: "Node" }), /* @__PURE__ */ jsx("code", {
				className: "font-mono bg-muted rounded-sm py-1 px-2",
				children: model.node
			})]
		}), /* @__PURE__ */ jsx(CopyOnClick, {
			text: model.uuid,
			children: /* @__PURE__ */ jsxs("div", {
				className: "flex items-center justify-between mt-2 text-sm",
				children: [/* @__PURE__ */ jsx("p", { children: "Server ID" }), /* @__PURE__ */ jsx("code", {
					className: "font-mono bg-muted rounded-sm py-1 px-2",
					children: model.uuid
				})]
			})
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/settings/ServerRename.tsx
function ServerRename({ model, className }) {
	const form = useAppForm({
		defaultValues: { ...model.values },
		onSubmit: ({ value }) => model.save(value)
	});
	if (!model.allowed) return null;
	return /* @__PURE__ */ jsx("div", {
		className,
		children: /* @__PURE__ */ jsxs(Card, {
			title: "Change Server Details",
			className: "relative",
			children: [/* @__PURE__ */ jsx(form.Subscribe, {
				selector: (state) => state.isSubmitting,
				children: (submitting) => /* @__PURE__ */ jsx(SpinnerOverlay, { visible: submitting })
			}), /* @__PURE__ */ jsxs(Form, {
				form,
				className: "mb-0",
				children: [
					/* @__PURE__ */ jsx(form.AppField, {
						name: "name",
						validators: { onChange: ({ value }) => model.validateName(value) },
						children: (field) => /* @__PURE__ */ jsx(field.TextField, {
							id: "name",
							label: "Server Name",
							type: "text"
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "mt-6",
						children: /* @__PURE__ */ jsx(form.AppField, {
							name: "description",
							children: (field) => /* @__PURE__ */ jsx(field.TextAreaField, {
								label: "Server Description",
								rows: 3
							})
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "mt-6 text-right",
						children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, { children: "Save" }) })
					})
				]
			})]
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/server/settings/ServerReinstall.tsx
function ServerReinstall({ model, className }) {
	if (!model.allowed) return null;
	return /* @__PURE__ */ jsxs(Card, {
		title: "Reinstall Server",
		className: cn("relative", className),
		children: [
			/* @__PURE__ */ jsxs("p", {
				className: "text-sm",
				children: ["Reinstalling your server will stop it, and then re-run the installation script that initially set it up.\xA0", /* @__PURE__ */ jsx("strong", {
					className: "font-medium",
					children: "Some files may be deleted or modified during this process, please back up your data before continuing."
				})]
			}),
			model.unavailable && /* @__PURE__ */ jsx("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: model.unavailable
			}),
			/* @__PURE__ */ jsx(Dialog.ConfirmTrigger, {
				title: "Confirm server reinstallation",
				confirm: "Yes, reinstall server",
				onConfirmed: async (_event, close) => {
					if (await model.reinstall()) close();
				},
				trigger: ({ onClick }) => /* @__PURE__ */ jsx("div", {
					className: "mt-6 text-right",
					children: /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
						isSecondary: true,
						disabled: model.unavailable !== null,
						onClick,
						children: "Reinstall Server"
					})
				}),
				children: "Your server will be stopped and some files may be deleted or modified during this process, are you sure you wish to continue?"
			})
		]
	});
}
//#endregion
export { ServerDebug, ServerReinstall, ServerRename, ServerSftp, SettingsPage };

//# sourceMappingURL=settings-DCaxLonH.js.map