import { d as isString } from "./client.gen-Ci-zROOW.js";
import "./notifications-Ebj0Q0Io.js";
import { t as routeParamStrings } from "./params-HmQaEn9f.js";
import "./useNavigationBlocker-Cl3Kp0j8.js";
import { useCallback, useSyncExternalStore } from "react";
import { Link, useLocation, useNavigate, useParams, useSearch } from "@tanstack/react-router";
import { jsx } from "react/jsx-runtime";
//#region ../../resources/scripts/extensions/formTypes.ts
var EXTENSION_FORM_NAMES = Object.freeze([
	"admin.user",
	"admin.server",
	"admin.node",
	"admin.egg",
	"admin.location",
	"admin.mount",
	"admin.database_host"
]);
//#endregion
//#region ../../resources/scripts/extensions/registry.ts
/** Every anchor a core <Slot/> renders; registering an unknown name fails at load time. */
var SLOT_NAMES = [
	"nav.items.before",
	"nav.items.after",
	"auth.login.before",
	"auth.login.after",
	"auth.login.form.after",
	"auth.checkpoint.before",
	"auth.checkpoint.after",
	"auth.password.before",
	"auth.password.after",
	"auth.passwordReset.before",
	"auth.passwordReset.after",
	"dashboard.before",
	"dashboard.after",
	"dashboard.serverRow.before",
	"dashboard.serverRow.after",
	"dashboard.serverRow.name.after",
	"dashboard.serverRow.metrics.after",
	"account.navigation.before",
	"account.navigation.after",
	"account.overview.before",
	"account.overview.after",
	"account.api.before",
	"account.api.after",
	"account.ssh.before",
	"account.ssh.after",
	"account.activity.before",
	"account.activity.after",
	"server.navigation.before",
	"server.navigation.after",
	"server.console.before",
	"server.console.power.before",
	"server.console.power.after",
	"server.console.after",
	"server.files.before",
	"server.files.after",
	"server.files.toolbar",
	"server.files.rowActions",
	"server.files.selectionActions",
	"server.files.editor.before",
	"server.files.editor.after",
	"server.databases.before",
	"server.databases.after",
	"server.schedules.before",
	"server.schedules.after",
	"server.schedules.detail.before",
	"server.schedules.detail.after",
	"server.users.before",
	"server.users.after",
	"server.users.create.before",
	"server.users.create.after",
	"server.users.permissions.before",
	"server.backups.before",
	"server.backups.after",
	"server.network.before",
	"server.network.after",
	"server.startup.before",
	"server.startup.after",
	"server.startup.form",
	"server.settings.before",
	"server.settings.after",
	"server.activity.before",
	"server.activity.after",
	"panel.navigation.before",
	"panel.navigation.after",
	"panel.overview.before",
	"panel.overview.after",
	"panel.users.before",
	"panel.users.after",
	"panel.users.create.before",
	"panel.users.create.after",
	"panel.users.detail.before",
	"panel.users.detail.after",
	"panel.locations.before",
	"panel.locations.after",
	"panel.locations.detail.before",
	"panel.locations.detail.after",
	"panel.nodes.before",
	"panel.nodes.after",
	"panel.nodes.create.before",
	"panel.nodes.create.after",
	"panel.nodes.detail.before",
	"panel.nodes.detail.after",
	"panel.nodes.detail.actions",
	"panel.nodes.detail.about.before",
	"panel.nodes.detail.about.after",
	"panel.nodes.detail.settings.before",
	"panel.nodes.detail.settings.after",
	"panel.nodes.detail.configuration.before",
	"panel.nodes.detail.configuration.after",
	"panel.nodes.detail.allocations.before",
	"panel.nodes.detail.allocations.after",
	"panel.nodes.detail.tags.before",
	"panel.nodes.detail.tags.after",
	"panel.nodes.detail.servers.before",
	"panel.nodes.detail.servers.after",
	"panel.servers.before",
	"panel.servers.after",
	"panel.servers.create.before",
	"panel.servers.create.after",
	"panel.servers.detail.before",
	"panel.servers.detail.after",
	"panel.servers.detail.actions",
	"panel.servers.detail.about.before",
	"panel.servers.detail.about.after",
	"panel.servers.detail.details.before",
	"panel.servers.detail.details.after",
	"panel.servers.detail.build.before",
	"panel.servers.detail.build.after",
	"panel.servers.detail.startup.before",
	"panel.servers.detail.startup.after",
	"panel.servers.detail.databases.before",
	"panel.servers.detail.databases.after",
	"panel.servers.detail.mounts.before",
	"panel.servers.detail.mounts.after",
	"panel.servers.detail.manage.before",
	"panel.servers.detail.manage.after",
	"panel.servers.detail.delete.before",
	"panel.servers.detail.delete.after",
	"panel.databaseHosts.before",
	"panel.databaseHosts.after",
	"panel.databaseHosts.create.before",
	"panel.databaseHosts.create.after",
	"panel.databaseHosts.detail.before",
	"panel.databaseHosts.detail.after",
	"panel.mounts.before",
	"panel.mounts.after",
	"panel.mounts.create.before",
	"panel.mounts.create.after",
	"panel.mounts.detail.before",
	"panel.mounts.detail.after",
	"panel.eggs.before",
	"panel.eggs.after",
	"panel.eggs.create.before",
	"panel.eggs.create.after",
	"panel.eggs.detail.before",
	"panel.eggs.detail.after",
	"panel.eggs.detail.actions",
	"panel.users.detail.actions",
	"panel.users.detail.form",
	"panel.eggs.detail.configuration.before",
	"panel.eggs.detail.configuration.after",
	"panel.eggs.detail.tags.before",
	"panel.eggs.detail.tags.after",
	"panel.eggs.detail.variables.before",
	"panel.eggs.detail.variables.after",
	"panel.eggs.detail.script.before",
	"panel.eggs.detail.script.after",
	"panel.tags.before",
	"panel.tags.after",
	"panel.activity.before",
	"panel.activity.after",
	"panel.settings.before",
	"panel.settings.after",
	"panel.extensions.before",
	"panel.extensions.after",
	"panel.themes.before",
	"panel.themes.after",
	"panel.apiKeys.before",
	"panel.apiKeys.after"
];
/** The panel path each area and resource mounts its extension screens under. */
var SCREEN_ROOTS = {
	account: "/account",
	server: "/server/$id",
	admin: "/panel",
	"admin.node": "/panel/nodes/$id",
	"admin.server": "/panel/servers/$id",
	"admin.egg": "/panel/eggs/$eggId",
	"admin.user": "/panel/users/$id"
};
var slots = /* @__PURE__ */ new Map();
Object.freeze([]);
Object.freeze([]);
var emptySlots = Object.freeze([]);
var screens = [];
var ExtensionImportError = class extends Error {};
var screenImplementations = /* @__PURE__ */ new Map();
var emptyConfig = Object.freeze({});
/** Committed view overrides, keyed by extension id and view name. */
var viewOverrides = /* @__PURE__ */ new Map();
var loadStates = /* @__PURE__ */ new Map();
/** Failures of mounted extension code, by extension and then by context, the latest last. */
var mountErrors = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var entries;
var nextSlotRegistrationId = 1;
/** Every change notifies every listener; each getter returns the same value until its own data changes. */
function subscribeExtensionRegistry(listener) {
	listeners.add(listener);
	return () => {
		listeners.delete(listener);
	};
}
function useExtensionRegistry(read) {
	return useSyncExternalStore(subscribeExtensionRegistry, read);
}
/** The latest failure of mounted code overrides the load state. */
function runtimeState(id) {
	const latest = [...mountErrors.get(id) ?? []].at(-1);
	return latest ? Object.freeze({
		id,
		status: "failed",
		error: `${latest[0]}: ${latest[1]}`
	}) : loadStates.get(id);
}
function publish() {
	const ids = new Set([...loadStates.keys(), ...mountErrors.keys()]);
	Object.freeze([...ids].flatMap((id) => runtimeState(id) ?? []));
	for (const listener of listeners) listener();
}
function getExtensionLoadState(id) {
	return loadStates.get(id);
}
/** Undefined until the screen's bundle has loaded. */
function getScreenOptions(extensionId, screenId) {
	return screenImplementations.get(`${extensionId}:${screenId}`)?.options;
}
function getExtensionConfig(extensionId) {
	return entries?.find((entry) => entry.id === extensionId)?.config ?? emptyConfig;
}
/** Extensions that declare an override of the view, in load order. */
function getViewOwners(name) {
	return (entries ?? []).filter((entry) => entry.views?.includes(name)).map((entry) => entry.id);
}
function getViewOverride(extensionId, name) {
	return viewOverrides.get(`${extensionId}:${name}`);
}
/** Records a failure, unless the same one is already recorded for the context; returns its message. */
function recordError(extensionId, context, cause) {
	const message = cause instanceof Error ? cause.message : String(cause);
	const errors = mountErrors.get(extensionId) ?? /* @__PURE__ */ new Map();
	if (errors.get(context) === message) return;
	console.error(`[extensions] "${extensionId}" failed in ${context}:`, cause);
	errors.delete(context);
	errors.set(context, message);
	mountErrors.set(extensionId, errors);
	return message;
}
/** Every failure of mounted code still recorded, oldest first for each extension. */
function getExtensionErrors() {
	return [...mountErrors].flatMap(([extensionId, errors]) => [...errors].map(([context, message]) => ({
		extensionId,
		context,
		message
	})));
}
/** Repeat reports of the same failure in a context are ignored. */
function reportExtensionError(extensionId, context, cause) {
	if (recordError(extensionId, context, cause) !== void 0) publish();
}
function resolveScreenPath(path, params = {}) {
	return path.replaceAll(/\$([a-zA-Z][a-zA-Z0-9_]*)/g, (_match, name) => {
		const value = params[name];
		if (!value) throw new Error(`Missing navigation parameter "${name}".`);
		return encodeURIComponent(value);
	});
}
function matchesValues(matcher, values) {
	const present = new Set(values.map((value) => value.toLowerCase()));
	const has = (value) => present.has(value.toLowerCase());
	return (matcher.all ?? []).every(has) && (!matcher.any || matcher.any.some(has));
}
/** A rule never matches without a server to test. */
function matchesScreenCondition(when, server) {
	const results = [];
	if (when?.eggFeatures) results.push(matchesValues(when.eggFeatures, server?.attributes.egg_features ?? []));
	if (when?.eggTags) results.push(matchesValues(when.eggTags, server?.attributes.egg_tags ?? []));
	return when?.match === "any" ? results.some(Boolean) : results.every(Boolean);
}
function getSlotComponents(name) {
	return slots.get(name) ?? emptySlots;
}
/** Mounts components in slots without an extension batch, as the SDK's `renderView` does; returns their removal. */
function mountSlotComponents(extensionId, components) {
	const added = [];
	for (const [name, component] of Object.entries(components)) {
		const slot = SLOT_NAMES.find((candidate) => candidate === name);
		if (!slot) throw new Error(`Unknown slot "${name}"`);
		if (component) added.push(Object.freeze({
			id: nextSlotRegistrationId++,
			extensionId,
			name: slot,
			component
		}));
	}
	for (const registration of added) slots.set(registration.name, Object.freeze([...getSlotComponents(registration.name), registration]));
	publish();
	return () => {
		for (const registration of added) slots.set(registration.name, Object.freeze(getSlotComponents(registration.name).filter((existing) => existing !== registration)));
		publish();
	};
}
function findExtensionScreen(extensionId, id) {
	return screens.find((screen) => screen.extensionId === extensionId && screen.id === id);
}
function clearExtensionError(extensionId, context) {
	const errors = mountErrors.get(extensionId);
	if (!errors?.delete(context)) return;
	if (!errors.size) mountErrors.delete(extensionId);
	publish();
}
//#endregion
//#region ../../resources/scripts/router/redirect.ts
var redirectOrigin = "http://redirect.invalid";
var parseRedirectSearch = (search) => {
	const redirect = isString(search.redirect) ? search.redirect.trim() : "";
	if (!redirect.startsWith("/")) return {};
	let url;
	try {
		url = new URL(redirect, redirectOrigin);
	} catch {
		return {};
	}
	if (url.origin !== redirectOrigin || url.pathname === "/auth" || url.pathname.startsWith("/auth/")) return {};
	const path = `${url.pathname}${url.search}${url.hash}`;
	return path === "/" ? {} : { redirect: path };
};
//#endregion
//#region ../../resources/scripts/sdk/navigation.tsx
function resolvePanelDestination(destination) {
	let path;
	if ("to" in destination) path = destination.to;
	else {
		const screen = findExtensionScreen(destination.extension, destination.screen);
		if (!screen) throw new Error(`Unknown extension screen "${destination.extension}:${destination.screen}".`);
		path = `${SCREEN_ROOTS[screen.parent ?? screen.area]}/${screen.path}`;
	}
	return {
		pathname: resolveScreenPath(path, destination.params),
		search: destination.search,
		hash: destination.hash,
		replace: destination.replace
	};
}
function usePanelNavigate() {
	const navigate = useNavigate();
	return useCallback((destination) => {
		const { pathname, ...options } = resolvePanelDestination(destination);
		return navigate({
			to: pathname,
			...options,
			search: options.search
		});
	}, [navigate]);
}
/**
* The current path, params and search. A view rendered from fixtures, as in tests, sits
* outside any route and sees empty params and search.
*/
function usePanelLocation() {
	const { pathname } = useLocation();
	const params = useParams({
		strict: false,
		shouldThrow: false
	}) ?? {};
	const search = useSearch({
		strict: false,
		shouldThrow: false
	}) ?? {};
	return {
		pathname,
		params: routeParamStrings(params),
		search
	};
}
function PanelLink({ destination, exact = false, includeSearch = false, ...props }) {
	const { pathname, ...options } = resolvePanelDestination(destination);
	return /* @__PURE__ */ jsx(Link, {
		to: pathname,
		...options,
		search: options.search,
		activeOptions: {
			exact,
			includeSearch
		},
		...props
	});
}
function useOpenLoginCheckpoint() {
	const navigate = useNavigate();
	const { redirect } = parseRedirectSearch(useSearch({ strict: false }));
	return useCallback((confirmationToken) => navigate({
		to: "/auth/login/checkpoint",
		search: { redirect },
		replace: true,
		state: { token: confirmationToken }
	}), [navigate, redirect]);
}
//#endregion
export { useExtensionRegistry as C, subscribeExtensionRegistry as S, getViewOverride as _, usePanelNavigate as a, mountSlotComponents as b, SCREEN_ROOTS as c, findExtensionScreen as d, getExtensionConfig as f, getSlotComponents as g, getScreenOptions as h, usePanelLocation as i, SLOT_NAMES as l, getExtensionLoadState as m, resolvePanelDestination as n, parseRedirectSearch as o, getExtensionErrors as p, useOpenLoginCheckpoint as r, ExtensionImportError as s, PanelLink as t, clearExtensionError as u, getViewOwners as v, EXTENSION_FORM_NAMES as w, reportExtensionError as x, matchesScreenCondition as y };

//# sourceMappingURL=navigation-9aP-0Hbq.js.map