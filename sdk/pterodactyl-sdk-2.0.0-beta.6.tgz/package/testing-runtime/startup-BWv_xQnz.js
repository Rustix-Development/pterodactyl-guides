import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { i as useCurrentServer } from "./queries-D_-2KdyF.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { a as useUpdateStartupVariable, i as useSetSelectedDockerImage, n as useDockerImagePending, r as useServerStartup } from "./queries-BuegeFTA.js";
import { t as createTestServer } from "./fixtures-sueNo-ZT.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { useMemo } from "react";
//#region ../../resources/scripts/views/server/startup.ts
var booleanRules = new Set([
	"boolean",
	"in:0,1",
	"in:1,0",
	"in:true,false",
	"in:false,true"
]);
function variableControl(rules) {
	const parsed = rules.split("|");
	if (parsed.some((rule) => booleanRules.has(rule))) return parsed.includes("string") ? {
		kind: "switch",
		on: "true",
		off: "false"
	} : {
		kind: "switch",
		on: "1",
		off: "0"
	};
	const options = parsed.find((rule) => rule.startsWith("in:"))?.split(",") ?? [];
	return options.length ? {
		kind: "select",
		options: options.map((option) => option.replace("in:", ""))
	} : { kind: "text" };
}
var startupVariable = ({ attributes }) => ({
	key: attributes.env_variable,
	name: attributes.name,
	description: attributes.description,
	value: attributes.server_value ?? attributes.default_value,
	defaultValue: attributes.default_value,
	editable: attributes.is_editable,
	control: variableControl(attributes.rules)
});
function useStartup() {
	const server = useCurrentServer();
	const uuid = server?.attributes.uuid ?? "";
	return {
		server,
		uuid,
		query: useServerStartup(uuid)
	};
}
/** The image the server runs, the egg's images, and switching between them. */
function useDockerImage() {
	const { server, uuid, query } = useStartup();
	const { mutateAsync } = useSetSelectedDockerImage(uuid);
	const [allowed] = usePermissions(["startup.docker-image"]);
	const pending = useDockerImagePending(uuid);
	const image = server?.attributes.docker_image ?? "";
	const offered = query.data?.meta?.docker_images;
	return useMemo(() => {
		const images = Object.entries(offered ?? {}).map(([label, value]) => ({
			label,
			value
		}));
		return {
			image,
			images,
			custom: query.data !== void 0 && !images.some(({ value }) => value.toLowerCase() === image.toLowerCase()),
			allowed,
			pending,
			select: async (selected) => {
				await mutateAsync({
					path: { server_uuid: uuid },
					body: { docker_image: selected }
				});
			}
		};
	}, [
		image,
		offered,
		query.data,
		allowed,
		pending,
		mutateAsync,
		uuid
	]);
}
function useStartupPageModel() {
	const { server, query } = useStartup();
	const docker = useDockerImage();
	const { data, refetch } = query;
	const slot = useMemo(() => data && server ? {
		server,
		configuration: data,
		isPending: docker.pending,
		canChangeDockerImage: docker.allowed && !docker.custom,
		setDockerImage: async (image) => {
			if (!docker.allowed || docker.custom || !docker.images.some(({ value }) => value === image)) throw new Error("This Docker image cannot be selected for the current server.");
			await docker.select(image);
		},
		refresh: async () => {
			const result = await refetch();
			if (result.error) throw result.error;
		}
	} : null, [
		server,
		data,
		refetch,
		docker
	]);
	return {
		...pageStatus(query),
		slot
	};
}
function useStartupCommandModel() {
	const command = useStartup().query.data?.meta?.startup_command ?? null;
	return useMemo(() => ({ command }), [command]);
}
function useStartupVariablesModel() {
	const { uuid, query } = useStartup();
	const [canEdit] = usePermissions(["startup.update"]);
	const { mutateAsync } = useUpdateStartupVariable(uuid);
	const listed = query.data?.data;
	return useMemo(() => ({
		variables: (listed ?? []).map(startupVariable),
		canEdit,
		update: async (key, value) => {
			await mutateAsync({
				path: { server_uuid: uuid },
				body: {
					key,
					value
				}
			});
		}
	}), [
		listed,
		canEdit,
		mutateAsync,
		uuid
	]);
}
var resolved = async () => {};
var images = [{
	label: "Java 21",
	value: "ghcr.io/pterodactyl/yolks:java_21"
}, {
	label: "Java 17",
	value: "ghcr.io/pterodactyl/yolks:java_17"
}];
var image = (options = {}) => ({
	image: images[0].value,
	images,
	custom: false,
	allowed: true,
	pending: false,
	select: resolved,
	...options
});
var variable = (options) => ({
	description: "",
	value: "",
	defaultValue: "",
	editable: true,
	control: { kind: "text" },
	...options
});
var variables = [
	variable({
		key: "SERVER_JARFILE",
		name: "Server Jar File",
		description: "The name of the server jarfile to run the server with.",
		value: "server.jar",
		defaultValue: "server.jar"
	}),
	variable({
		key: "MINECRAFT_VERSION",
		name: "Minecraft Version",
		description: "The version of Minecraft to download.",
		value: "latest",
		defaultValue: "latest",
		control: {
			kind: "select",
			options: [
				"latest",
				"snapshot",
				"1.21.4"
			]
		}
	}),
	variable({
		key: "AUTO_UPDATE",
		name: "Auto Update",
		description: "Update the server on every start.",
		value: "1",
		defaultValue: "0",
		control: {
			kind: "switch",
			on: "1",
			off: "0"
		}
	}),
	variable({
		key: "BUILD_NUMBER",
		name: "Build Number",
		description: "Set by the administrator.",
		value: "412",
		defaultValue: "latest",
		editable: false
	})
];
var configuration = {
	object: "list",
	data: [],
	meta: {
		startup_command: "java -Xms128M -Xmx2048M -jar server.jar nogui",
		raw_startup_command: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui",
		docker_images: Object.fromEntries(images.map(({ label, value }) => [label, value]))
	}
};
implementViews({
	"page.server.startup": {
		use: useStartupPageModel,
		fixtures: {
			default: () => ({
				...pageStatusFixtures.default(),
				slot: {
					server: createTestServer(),
					configuration,
					isPending: false,
					canChangeDockerImage: true,
					setDockerImage: resolved,
					refresh: resolved
				}
			}),
			loading: () => ({
				...pageStatusFixtures.loading(),
				slot: null
			}),
			error: () => ({
				...pageStatusFixtures.error(),
				slot: null
			})
		}
	},
	"server.startup.command": {
		use: useStartupCommandModel,
		fixtures: { default: () => ({ command: "java -Xms128M -Xmx2048M -jar server.jar nogui" }) }
	},
	"server.startup.image": {
		use: useDockerImage,
		fixtures: {
			selectable: () => image(),
			single: () => image({ images: images.slice(0, 1) }),
			custom: () => image({
				image: "ghcr.io/example/custom:latest",
				custom: true
			}),
			pending: () => image({ pending: true })
		}
	},
	"server.startup.variables": {
		use: useStartupVariablesModel,
		fixtures: {
			variables: () => ({
				variables,
				canEdit: true,
				update: resolved
			}),
			readOnly: () => ({
				variables,
				canEdit: false,
				update: resolved
			}),
			empty: () => ({
				variables: [],
				canEdit: true,
				update: resolved
			})
		}
	}
});
//#endregion

//# sourceMappingURL=startup-BWv_xQnz.js.map