import { p as Icon } from "./Button-BzlrfY24.js";
import { H as Tooltip, at as EmptyTitle, et as Empty, it as EmptyMedia, mt as InputSpinner, nt as EmptyDescription, r as cn, rt as EmptyHeader, st as Alert } from "./sdk-Chrtpiam.js";
import { t as PanelLink } from "./navigation-9aP-0Hbq.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { n as TextField } from "./fields-DSobJx3_.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Search as Search$1, SearchX } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/layout/Search.tsx
var resultClass = [
	"flex items-center bg-muted p-4 rounded-sm border-l-4 border-border no-underline transition-[background-color,border-color,color] duration-150",
	"hover:shadow-sm hover:border-accent",
	"not-last-of-type:mb-2"
].join(" ");
function Results({ model }) {
	if (model.error) return /* @__PURE__ */ jsx("div", {
		className: "mt-4",
		children: /* @__PURE__ */ jsx(Alert, {
			type: "danger",
			children: model.error
		})
	});
	if (model.searched && model.results.length === 0) return /* @__PURE__ */ jsx(Empty, {
		size: "compact",
		className: "mt-6",
		children: /* @__PURE__ */ jsxs(EmptyHeader, { children: [
			/* @__PURE__ */ jsx(EmptyMedia, {
				variant: "icon",
				children: /* @__PURE__ */ jsx(SearchX, {})
			}),
			/* @__PURE__ */ jsx(EmptyTitle, { children: "No servers found" }),
			/* @__PURE__ */ jsx(EmptyDescription, { children: "No servers match your search. Try a different name or address." })
		] })
	});
	return model.results.length > 0 ? /* @__PURE__ */ jsx("div", {
		className: "mt-6",
		children: model.results.map((result) => /* @__PURE__ */ jsxs(PanelLink, {
			destination: result.destination,
			className: resultClass,
			onClick: model.close,
			children: [/* @__PURE__ */ jsxs("div", {
				className: "flex-1 mr-4",
				children: [/* @__PURE__ */ jsx("p", {
					className: "text-sm",
					children: result.name
				}), /* @__PURE__ */ jsx("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: result.addresses.map((address) => /* @__PURE__ */ jsx("span", { children: address }, address))
				})]
			}), /* @__PURE__ */ jsx("div", {
				className: "flex-none text-right",
				children: /* @__PURE__ */ jsx("span", {
					className: "text-xs py-1 px-2 bg-accent text-accent-foreground rounded-sm",
					children: result.node
				})
			})]
		}, result.uuid))
	}) : null;
}
function Search({ model, className }) {
	return /* @__PURE__ */ jsxs(Fragment, { children: [model.open && /* @__PURE__ */ jsxs(Dialog, {
		title: "Search servers",
		open: true,
		onClose: model.close,
		children: [/* @__PURE__ */ jsx("form", {
			noValidate: true,
			onSubmit: (event) => event.preventDefault(),
			children: /* @__PURE__ */ jsx(InputSpinner, {
				visible: model.loading,
				children: /* @__PURE__ */ jsx(TextField, {
					field: model.field,
					label: "Search term",
					description: "Enter a server name, uuid, or allocation to begin searching.",
					autoFocus: true
				})
			})
		}), /* @__PURE__ */ jsx(Results, { model })]
	}), /* @__PURE__ */ jsx(Tooltip, {
		placement: "bottom",
		content: "Search",
		children: /* @__PURE__ */ jsx("button", {
			type: "button",
			"aria-label": "Search",
			"aria-keyshortcuts": model.shortcut.aria,
			className: cn("navigation-link", className),
			onClick: model.show,
			children: /* @__PURE__ */ jsx(Icon, { icon: Search$1 })
		})
	})] });
}
//#endregion
export { Search as default };

//# sourceMappingURL=Search-DUT5_8F8.js.map