import { o as httpErrorToHuman, t as client, u as isObject } from "./client.gen-Ci-zROOW.js";
import { createElement, use, useSyncExternalStore } from "react";
import { queryOptions } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/views/lazy.ts
/** Load state per importer, so every view exported by one chunk is ready once any of them is. */
var modules = /* @__PURE__ */ new WeakMap();
/**
* Marks a load done on its promise the way React's `use` reads it. A component that suspended on the load
* passes it to `use` on every render after, which returns at once once it has loaded. A failed load is
* dropped and imported again, so its failure is not recorded.
*/
function settledLoad(promise) {
	const settled = promise;
	promise.then(() => {
		settled.status = "fulfilled";
		settled.value = void 0;
	}, () => {});
	return promise;
}
function loadModule(importer) {
	let state = modules.get(importer);
	if (!state) {
		const created = { ready: settledLoad(importer().then((module) => {
			created.module = module;
		}, (cause) => {
			modules.delete(importer);
			throw cause;
		})) };
		state = created;
		modules.set(importer, created);
	}
	return state;
}
function isLazyView(component) {
	return "loaded" in component && "preload" in component;
}
function isPendingLazyView(component) {
	return isLazyView(component) && component.loaded === false;
}
function lazyView(importer, exportName = "default") {
	const loaded = () => modules.get(importer)?.module;
	function LazyView(props) {
		const state = loadModule(importer);
		use(state.ready);
		return createElement(Reflect.get(state.module ?? {}, exportName), props);
	}
	return Object.defineProperties(LazyView, {
		preload: { value: () => loadModule(importer).ready },
		loaded: { get: () => loaded() !== void 0 }
	});
}
//#endregion
//#region ../../resources/scripts/views/registry.ts
/** The hook of a view its parent places with the parent's model, such as a piece of a card. */
var modelFromInput = ({ model }) => model;
var definitions = /* @__PURE__ */ new Map();
/** Implementations by view name, kept for a definition registered after its module ran. */
var implementations = /* @__PURE__ */ new Map();
var loads = /* @__PURE__ */ new WeakMap();
var layers = /* @__PURE__ */ new Map();
var chains = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var emptyChain = Object.freeze([]);
var sortedDefinitions;
function notify() {
	for (const listener of listeners) listener();
}
function publishDefinitions() {
	sortedDefinitions = void 0;
	notify();
}
function publish() {
	chains.clear();
	publishDefinitions();
}
function subscribeViews(listener) {
	listeners.add(listener);
	return () => {
		listeners.delete(listener);
	};
}
function viewKind(name) {
	if (name.startsWith("layout.")) return "layout";
	return name.startsWith("page.") ? "page" : "block";
}
/** Core definitions replace an earlier one of the same name, so a hot reload re-registers cleanly. */
function defineView(name, options) {
	const definition = Object.freeze({
		...options,
		name,
		kind: viewKind(name)
	});
	definitions.set(name, Object.freeze({
		...definition,
		...implementations.get(name)
	}));
	publishDefinitions();
	return definition;
}
/** Called by the module a view's `load` imports, which implements every view of its area. */
function implementViews(views) {
	for (const [name, implementation] of Object.entries(views)) {
		const erased = implementation;
		const definition = definitions.get(name);
		implementations.set(name, erased);
		if (definition) definitions.set(name, Object.freeze({
			...definition,
			...erased
		}));
	}
	publishDefinitions();
}
async function importImplementation(load) {
	try {
		await load();
	} catch (cause) {
		loads.delete(load);
		throw cause;
	}
}
/**
* The import of the module implementing a view, started the first time one of its views needs it and
* shared by all of them; null when the view was implemented without one.
*/
function loadViewImplementation(name) {
	const definition = definitions.get(name);
	if (!definition?.load) return null;
	const { load } = definition;
	let loading = loads.get(load);
	if (!loading && !definition.use) {
		loading = settledLoad(importImplementation(load));
		loads.set(load, loading);
	}
	return loading ?? null;
}
function getViewDefinition(name) {
	return definitions.get(name);
}
function getViewDefinitions() {
	return sortedDefinitions ??= Object.freeze([...definitions.values()].sort((a, b) => a.name.localeCompare(b.name)));
}
function useViewDefinition(name) {
	return useSyncExternalStore(subscribeViews, () => definitions.get(name));
}
function layerSet(name) {
	let set = layers.get(name);
	if (!set) {
		set = { themes: [] };
		layers.set(name, set);
	}
	return set;
}
/** A function component, or a memo, forwardRef or lazy wrapper of one. */
function isViewComponent(value) {
	return value instanceof Function || isObject(value) && "$$typeof" in value && [
		"react.memo",
		"react.forward_ref",
		"react.lazy"
	].some((type) => Symbol.for(type) === value.$$typeof);
}
function toLayer(id, source, component) {
	return Object.freeze({
		id,
		source,
		component
	});
}
/** Classic is registered once at boot; theme layers stack in chain order, parent first. */
function registerViewLayer(id, source, views) {
	for (const [name, component] of Object.entries(views)) {
		if (!component) continue;
		const set = layerSet(name);
		const layer = toLayer(id, source, component);
		if (source === "classic") set.base = layer;
		else set.themes = [...set.themes.filter((existing) => existing.id !== id), layer];
	}
	publish();
}
/** Drops every theme layer, leaving classic; used when a theme fails to boot. */
function clearThemeLayers() {
	for (const set of layers.values()) set.themes = [];
	publish();
}
/** Classic, then the theme chain; extension overrides come from the view session. */
function getViewChain(name) {
	let chain = chains.get(name);
	if (!chain) {
		const set = layers.get(name);
		chain = set ? Object.freeze([...set.base ? [set.base] : [], ...set.themes]) : emptyChain;
		chains.set(name, chain);
	}
	return chain;
}
function useViewChain(name) {
	return useSyncExternalStore(subscribeViews, () => getViewChain(name));
}
//#endregion
//#region ../../resources/scripts/api/generated/sdk.gen.ts
/**
* List activity
*
* Returns a paginated list of administrative activity. Only events in the "admin" namespace are returned; customer activity against a server or account is excluded.
*/
var adminListActivity = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/admin/activity",
	...options
});
/**
* List activity filter options
*
* Returns the distinct events and users present in the administrative activity log.
*/
var adminListActivityFilterOptions = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/admin/activity/filters",
	...options
});
/**
* Login
*
* Authenticates a browser session. Returns a complete login payload, or a two-factor checkpoint token when the account requires a second factor.
*/
var authLogin = (options) => (options.client ?? client).post({
	responseType: "json",
	url: "/auth/login",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Complete login checkpoint
*
* Completes a two-factor login checkpoint using either a TOTP code or a recovery token.
*/
var authCompleteLoginCheckpoint = (options) => (options.client ?? client).post({
	responseType: "json",
	url: "/auth/login/checkpoint",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Request password reset email
*
* Sends a password reset email when the account exists. The response is intentionally the same when no matching account is found.
*/
var authRequestPasswordResetEmail = (options) => (options.client ?? client).post({
	responseType: "json",
	url: "/auth/password",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Reset password
*
* Resets an account password using a password reset token. The response tells the frontend whether the user must return to the login form.
*/
var authResetPassword = (options) => (options.client ?? client).post({
	responseType: "json",
	url: "/auth/password/reset",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Logout
*
* Destroys the current browser session and regenerates the CSRF token.
*/
var authLogout = (options) => (options?.client ?? client).post({
	security: [{
		in: "cookie",
		name: "pterodactyl_session",
		type: "apiKey"
	}],
	url: "/auth/logout",
	...options
});
/**
* List client servers
*
* Returns a paginated list of servers the authenticated user can access as an owner, subuser, or administrator.
*/
var clientListClientServers = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client",
	...options
});
/**
* List server permissions
*
* Returns the permission keys that can be granted to server subusers, including those registered by enabled extensions under `ext.<extension id>`.
*/
var clientListServerPermissions = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/permissions",
	...options
});
/**
* Get extension job progress
*
* Returns the latest user-scoped progress snapshot, including after reconnect. Expired, disabled, and inaccessible jobs return 404.
*/
var clientGetExtensionJobProgress = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/extension-progress/{extension}/{job}",
	...options
});
/**
* Get account
*
* Returns profile details for the authenticated user.
*/
var clientGetAccount = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account",
	...options
});
/**
* Get two-factor setup
*
* Creates or returns the current two-factor setup payload for the authenticated user.
*/
var clientGetTwoFactorSetup = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/two-factor",
	...options
});
/**
* Enable two-factor authentication
*
* Enables two-factor authentication for the authenticated user and returns one-time recovery tokens.
*/
var clientEnableTwoFactorAuthentication = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/two-factor",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Disable two-factor authentication
*
* Disables two-factor authentication for the authenticated user after verifying their password.
*/
var clientDisableTwoFactorAuthentication = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/two-factor/disable",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Update account email
*
* Updates the authenticated user's email address after verifying their current password.
*/
var clientUpdateAccountEmail = (options) => (options.client ?? client).put({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/email",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Update account password
*
* Updates the authenticated user's password and revokes other active sessions where supported.
*/
var clientUpdateAccountPassword = (options) => (options.client ?? client).put({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/password",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* List account activity
*
* Returns a paginated list of activity log entries for the authenticated user account.
*/
var clientListAccountActivity = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/activity",
	...options
});
/**
* List account activity filter options
*
* Returns the distinct events and users present in the account activity log.
*/
var clientListAccountActivityFilterOptions = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/activity/filters",
	...options
});
/**
* List account API keys
*
* Returns all client API keys owned by the authenticated user.
*/
var clientListAccountApiKeys = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/api-keys",
	...options
});
/**
* Create account API key
*
* Creates a client API key for the authenticated user and returns the secret token once.
*/
var clientCreateAccountApiKey = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/api-keys",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Delete account API key
*
* Deletes one client API key owned by the authenticated user.
*/
var clientDeleteAccountApiKey = (options) => (options.client ?? client).delete({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/api-keys/{identifier}",
	...options
});
/**
* List SSH keys
*
* Returns all SSH public keys configured for the authenticated user.
*/
var clientListSshKeys = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/ssh-keys",
	...options
});
/**
* Create SSH key
*
* Adds an SSH public key to the authenticated user account.
*/
var clientCreateSshKey = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/ssh-keys",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Delete SSH key
*
* Deletes an SSH key from the authenticated user account by fingerprint. Missing keys are treated as already deleted.
*/
var clientDeleteSshKey = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account/ssh-keys/remove",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Get server
*
* Returns details for one server the authenticated user can access.
*/
var clientGetServer = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}",
	...options
});
/**
* Get server resources
*
* Returns the latest cached resource utilization reported by Wings for the server.
*/
var clientGetServerResources = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/resources",
	...options
});
/**
* Get server logs
*
* Returns the most recent console output lines Wings holds for the server, oldest first.
*/
var clientGetServerLogs = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/logs",
	...options
});
/**
* Get server extension job progress
*
* Returns the latest server-scoped snapshot to its creator or users holding the operation permission. Expired, disabled, and inaccessible jobs return 404.
*/
var clientGetServerExtensionJobProgress = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/extension-progress/{extension}/{job}",
	...options
});
/**
* List server activity
*
* Returns a paginated list of activity log entries for the server.
*/
var clientListServerActivity = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/activity",
	...options
});
/**
* List server activity filter options
*
* Returns the distinct events and users present in the server activity log.
*/
var clientListServerActivityFilterOptions = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/activity/filters",
	...options
});
/**
* Send server command
*
* Sends a console command to the running server through Wings.
*/
var clientSendServerCommand = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/command",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Send power action
*
* Sends a power signal to the server through Wings.
*/
var clientSendPowerAction = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/power",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* List server databases
*
* Returns databases attached to a server visible to the authenticated user.
*/
var clientListServerDatabases = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/databases",
	...options
});
/**
* Create server database
*
* Creates a database for a server on an automatically selected database host.
*/
var clientCreateServerDatabase = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/databases",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Rotate server database password
*
* Rotates the password for a database attached to a server and returns the updated database.
*/
var clientRotateServerDatabasePassword = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/databases/{database_id}/rotate-password",
	...options
});
/**
* Delete server database
*
* Deletes a database attached to a server.
*/
var clientDeleteServerDatabase = (options) => (options.client ?? client).delete({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/databases/{database_id}",
	...options
});
/**
* List files
*
* Returns files and folders in a server directory.
*/
var clientListFiles = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/list",
	...options
});
/**
* Get file contents
*
* Returns raw text contents for a server file.
*/
var clientGetFileContents = (options) => (options.client ?? client).get({
	responseType: "text",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/contents",
	...options
});
/**
* Get file download URL
*
* Returns a short-lived signed URL for downloading a server file directly from Wings.
*/
var clientGetFileDownloadUrl = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/download",
	...options
});
/**
* Rename files
*
* Renames one or more files or folders in a server directory.
*/
var clientRenameFiles = (options) => (options.client ?? client).put({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/rename",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Copy file
*
* Creates a copy of a file on the server.
*/
var clientCopyFile = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/copy",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Write file contents
*
* Writes the raw request body to a server file. This endpoint does not expect a JSON wrapper for the file contents.
*/
var clientWriteFileContents = (options) => (options.client ?? client).post({
	bodySerializer: null,
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/write",
	...options,
	headers: {
		"Content-Type": "text/plain",
		...options.headers
	}
});
/**
* Compress files
*
* Creates an archive from one or more files or folders in a server directory.
*/
var clientCompressFiles = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/compress",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Decompress file
*
* Extracts an archive in a server directory.
*/
var clientDecompressFile = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/decompress",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Delete files
*
* Deletes one or more files or folders from a server directory.
*/
var clientDeleteFiles = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/delete",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Create folder
*
* Creates a folder in a server directory.
*/
var clientCreateFolder = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/create-folder",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Change file permissions
*
* Updates POSIX mode bits for one or more files or folders in a server directory.
*/
var clientChangeFilePermissions = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/chmod",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Get file upload URL
*
* Returns a short-lived signed URL for uploading a file directly to Wings.
*/
var clientGetFileUploadUrl = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/upload",
	...options
});
/**
* List server schedules
*
* Returns all schedules configured for the server, including their tasks.
*/
var clientListServerSchedules = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules",
	...options
});
/**
* Create server schedule
*
* Creates a schedule for the server.
*/
var clientCreateServerSchedule = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Delete server schedule
*
* Deletes a schedule and its tasks from the server.
*/
var clientDeleteServerSchedule = (options) => (options.client ?? client).delete({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules/{schedule_id}",
	...options
});
/**
* Get server schedule
*
* Returns one schedule configured for the server, including its tasks.
*/
var clientGetServerSchedule = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules/{schedule_id}",
	...options
});
/**
* Update server schedule
*
* Updates a schedule for the server and recalculates its next run time.
*/
var clientUpdateServerSchedule = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules/{schedule_id}",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Execute server schedule
*
* Queues a schedule to run immediately regardless of its active state.
*/
var clientExecuteServerSchedule = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules/{schedule_id}/execute",
	...options
});
/**
* Create schedule task
*
* Creates a task in a server schedule.
*/
var clientCreateScheduleTask = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules/{schedule_id}/tasks",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Delete schedule task
*
* Deletes a task from a server schedule and compacts subsequent sequence IDs.
*/
var clientDeleteScheduleTask = (options) => (options.client ?? client).delete({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules/{schedule_id}/tasks/{task_id}",
	...options
});
/**
* Update schedule task
*
* Updates a task in a server schedule, including its sequence position.
*/
var clientUpdateScheduleTask = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/schedules/{schedule_id}/tasks/{task_id}",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* List server allocations
*
* Returns all network allocations assigned to the server.
*/
var clientListServerAllocations = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/network/allocations",
	...options
});
/**
* Create server allocation
*
* Assigns an available allocation to the server.
*/
var clientCreateServerAllocation = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/network/allocations",
	...options
});
/**
* Delete server allocation
*
* Removes a non-primary allocation from the server and returns it to the available pool.
*/
var clientDeleteServerAllocation = (options) => (options.client ?? client).delete({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/network/allocations/{allocation_id}",
	...options
});
/**
* Update allocation notes
*
* Updates notes attached to a server allocation.
*/
var clientUpdateAllocationNotes = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/network/allocations/{allocation_id}",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Set primary allocation
*
* Sets the primary network allocation for the server.
*/
var clientSetPrimaryAllocation = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/network/allocations/{allocation_id}/primary",
	...options
});
/**
* List server subusers
*
* Returns subusers assigned to the server.
*/
var clientListServerSubusers = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/users",
	...options
});
/**
* Create server subuser
*
* Assigns an existing or new user as a subuser on the server.
*/
var clientCreateServerSubuser = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/users",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Delete server subuser
*
* Removes a subuser assignment from the server and revokes SFTP access tokens.
*/
var clientDeleteServerSubuser = (options) => (options.client ?? client).delete({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/users/{user}",
	...options
});
/**
* Update server subuser
*
* Updates permissions for a server subuser and revokes their SFTP access tokens.
*/
var clientUpdateServerSubuser = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/users/{user}",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* List server backups
*
* Returns a paginated list of backups for the server.
*/
var clientListServerBackups = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/backups",
	...options
});
/**
* Create server backup
*
* Starts a new backup for the server.
*/
var clientCreateServerBackup = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/backups",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Delete server backup
*
* Deletes a backup record and its stored archive.
*/
var clientDeleteServerBackup = (options) => (options.client ?? client).delete({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/backups/{backup_uuid}",
	...options
});
/**
* Get backup download URL
*
* Returns a signed URL for downloading a server backup.
*/
var clientGetBackupDownloadUrl = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/backups/{backup_uuid}/download",
	...options
});
/**
* Toggle backup lock
*
* Toggles whether a backup is locked against deletion.
*/
var clientToggleBackupLock = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/backups/{backup_uuid}/lock",
	...options
});
/**
* Restore server backup
*
* Restores a backup over the server files.
*/
var clientRestoreServerBackup = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/backups/{backup_uuid}/restore",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Get startup configuration
*
* Returns the rendered startup command, available Docker images, raw startup command, and user-visible variables for the server.
*/
var clientGetStartupConfiguration = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/startup",
	...options
});
/**
* Update startup variable
*
* Updates one editable startup variable for the server and returns the updated rendered startup command.
*/
var clientUpdateStartupVariable = (options) => (options.client ?? client).put({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/startup/variable",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Rename server
*
* Updates the server name and optionally its description.
*/
var clientRenameServer = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/settings/rename",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Reinstall server
*
* Queues a reinstall of the server on Wings.
*/
var clientReinstallServer = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/settings/reinstall",
	...options
});
/**
* Set server Docker image
*
* Updates the server Docker image to one of the images allowed by the server egg.
*/
var clientSetServerDockerImage = (options) => (options.client ?? client).put({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/settings/docker-image",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Get CSRF cookie
*
* Initializes the Laravel Sanctum CSRF cookie required before browser-session authentication requests.
*/
var authGetCsrfCookie = (options) => (options?.client ?? client).get({
	url: "/sanctum/csrf-cookie",
	...options
});
//#endregion
//#region ../../resources/scripts/api/generated/@tanstack/react-query.gen.ts
var createQueryKey = (id, options, infinite, tags) => {
	const params = {
		_id: id,
		baseURL: options?.baseURL || (options?.client ?? client).getConfig().baseURL
	};
	if (infinite) params._infinite = infinite;
	if (tags) params.tags = tags;
	if (options?.body) params.body = options.body;
	if (options?.headers) params.headers = options.headers;
	if (options?.path) params.path = options.path;
	if (options?.query) params.query = options.query;
	return [params];
};
var adminListActivityQueryKey = (options) => createQueryKey("adminListActivity", options);
/**
* List activity
*
* Returns a paginated list of administrative activity. Only events in the "admin" namespace are returned; customer activity against a server or account is excluded.
*/
var adminListActivityOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await adminListActivity({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: adminListActivityQueryKey(options)
});
var adminListActivityFilterOptionsQueryKey = (options) => createQueryKey("adminListActivityFilterOptions", options);
/**
* List activity filter options
*
* Returns the distinct events and users present in the administrative activity log.
*/
var adminListActivityFilterOptionsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await adminListActivityFilterOptions({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: adminListActivityFilterOptionsQueryKey(options)
});
var createMutationKey = (id, options, tags) => {
	const params = {
		_id: id,
		baseURL: options?.baseURL || (options?.client ?? client).getConfig().baseURL
	};
	if (tags) params.tags = tags;
	if (options?.body) params.body = options.body;
	if (options?.headers) params.headers = options.headers;
	if (options?.path) params.path = options.path;
	if (options?.query) params.query = options.query;
	return [params];
};
var authLoginMutationKey = (options) => createMutationKey("authLogin", options);
/**
* Login
*
* Authenticates a browser session. Returns a complete login payload, or a two-factor checkpoint token when the account requires a second factor.
*/
var authLoginMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await authLogin({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: authLoginMutationKey(options)
	};
};
var authCompleteLoginCheckpointMutationKey = (options) => createMutationKey("authCompleteLoginCheckpoint", options);
/**
* Complete login checkpoint
*
* Completes a two-factor login checkpoint using either a TOTP code or a recovery token.
*/
var authCompleteLoginCheckpointMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await authCompleteLoginCheckpoint({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: authCompleteLoginCheckpointMutationKey(options)
	};
};
var authRequestPasswordResetEmailMutationKey = (options) => createMutationKey("authRequestPasswordResetEmail", options);
/**
* Request password reset email
*
* Sends a password reset email when the account exists. The response is intentionally the same when no matching account is found.
*/
var authRequestPasswordResetEmailMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await authRequestPasswordResetEmail({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: authRequestPasswordResetEmailMutationKey(options)
	};
};
var authResetPasswordMutationKey = (options) => createMutationKey("authResetPassword", options);
/**
* Reset password
*
* Resets an account password using a password reset token. The response tells the frontend whether the user must return to the login form.
*/
var authResetPasswordMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await authResetPassword({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: authResetPasswordMutationKey(options)
	};
};
var authLogoutMutationKey = (options) => createMutationKey("authLogout", options);
/**
* Logout
*
* Destroys the current browser session and regenerates the CSRF token.
*/
var authLogoutMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await authLogout({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: authLogoutMutationKey(options)
	};
};
var clientListClientServersQueryKey = (options) => createQueryKey("clientListClientServers", options);
/**
* List client servers
*
* Returns a paginated list of servers the authenticated user can access as an owner, subuser, or administrator.
*/
var clientListClientServersOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListClientServers({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListClientServersQueryKey(options)
});
var clientListServerPermissionsQueryKey = (options) => createQueryKey("clientListServerPermissions", options);
/**
* List server permissions
*
* Returns the permission keys that can be granted to server subusers, including those registered by enabled extensions under `ext.<extension id>`.
*/
var clientListServerPermissionsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerPermissions({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerPermissionsQueryKey(options)
});
var clientGetTwoFactorSetupQueryKey = (options) => createQueryKey("clientGetTwoFactorSetup", options);
/**
* Get two-factor setup
*
* Creates or returns the current two-factor setup payload for the authenticated user.
*/
var clientGetTwoFactorSetupOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetTwoFactorSetup({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetTwoFactorSetupQueryKey(options)
});
var clientEnableTwoFactorAuthenticationMutationKey = (options) => createMutationKey("clientEnableTwoFactorAuthentication", options);
/**
* Enable two-factor authentication
*
* Enables two-factor authentication for the authenticated user and returns one-time recovery tokens.
*/
var clientEnableTwoFactorAuthenticationMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientEnableTwoFactorAuthentication({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientEnableTwoFactorAuthenticationMutationKey(options)
	};
};
var clientDisableTwoFactorAuthenticationMutationKey = (options) => createMutationKey("clientDisableTwoFactorAuthentication", options);
/**
* Disable two-factor authentication
*
* Disables two-factor authentication for the authenticated user after verifying their password.
*/
var clientDisableTwoFactorAuthenticationMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDisableTwoFactorAuthentication({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDisableTwoFactorAuthenticationMutationKey(options)
	};
};
var clientUpdateAccountEmailMutationKey = (options) => createMutationKey("clientUpdateAccountEmail", options);
/**
* Update account email
*
* Updates the authenticated user's email address after verifying their current password.
*/
var clientUpdateAccountEmailMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientUpdateAccountEmail({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientUpdateAccountEmailMutationKey(options)
	};
};
var clientUpdateAccountPasswordMutationKey = (options) => createMutationKey("clientUpdateAccountPassword", options);
/**
* Update account password
*
* Updates the authenticated user's password and revokes other active sessions where supported.
*/
var clientUpdateAccountPasswordMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientUpdateAccountPassword({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientUpdateAccountPasswordMutationKey(options)
	};
};
var clientListAccountActivityQueryKey = (options) => createQueryKey("clientListAccountActivity", options);
/**
* List account activity
*
* Returns a paginated list of activity log entries for the authenticated user account.
*/
var clientListAccountActivityOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListAccountActivity({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListAccountActivityQueryKey(options)
});
var clientListAccountActivityFilterOptionsQueryKey = (options) => createQueryKey("clientListAccountActivityFilterOptions", options);
/**
* List account activity filter options
*
* Returns the distinct events and users present in the account activity log.
*/
var clientListAccountActivityFilterOptionsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListAccountActivityFilterOptions({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListAccountActivityFilterOptionsQueryKey(options)
});
var clientListAccountApiKeysQueryKey = (options) => createQueryKey("clientListAccountApiKeys", options);
/**
* List account API keys
*
* Returns all client API keys owned by the authenticated user.
*/
var clientListAccountApiKeysOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListAccountApiKeys({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListAccountApiKeysQueryKey(options)
});
var clientCreateAccountApiKeyMutationKey = (options) => createMutationKey("clientCreateAccountApiKey", options);
/**
* Create account API key
*
* Creates a client API key for the authenticated user and returns the secret token once.
*/
var clientCreateAccountApiKeyMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateAccountApiKey({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateAccountApiKeyMutationKey(options)
	};
};
var clientDeleteAccountApiKeyMutationKey = (options) => createMutationKey("clientDeleteAccountApiKey", options);
/**
* Delete account API key
*
* Deletes one client API key owned by the authenticated user.
*/
var clientDeleteAccountApiKeyMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteAccountApiKey({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteAccountApiKeyMutationKey(options)
	};
};
var clientListSshKeysQueryKey = (options) => createQueryKey("clientListSshKeys", options);
/**
* List SSH keys
*
* Returns all SSH public keys configured for the authenticated user.
*/
var clientListSshKeysOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListSshKeys({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListSshKeysQueryKey(options)
});
var clientCreateSshKeyMutationKey = (options) => createMutationKey("clientCreateSshKey", options);
/**
* Create SSH key
*
* Adds an SSH public key to the authenticated user account.
*/
var clientCreateSshKeyMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateSshKey({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateSshKeyMutationKey(options)
	};
};
var clientDeleteSshKeyMutationKey = (options) => createMutationKey("clientDeleteSshKey", options);
/**
* Delete SSH key
*
* Deletes an SSH key from the authenticated user account by fingerprint. Missing keys are treated as already deleted.
*/
var clientDeleteSshKeyMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteSshKey({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteSshKeyMutationKey(options)
	};
};
var clientGetServerQueryKey = (options) => createQueryKey("clientGetServer", options);
/**
* Get server
*
* Returns details for one server the authenticated user can access.
*/
var clientGetServerOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetServer({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetServerQueryKey(options)
});
var clientGetServerResourcesQueryKey = (options) => createQueryKey("clientGetServerResources", options);
/**
* Get server resources
*
* Returns the latest cached resource utilization reported by Wings for the server.
*/
var clientGetServerResourcesOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetServerResources({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetServerResourcesQueryKey(options)
});
var clientGetServerLogsQueryKey = (options) => createQueryKey("clientGetServerLogs", options);
/**
* Get server logs
*
* Returns the most recent console output lines Wings holds for the server, oldest first.
*/
var clientGetServerLogsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetServerLogs({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetServerLogsQueryKey(options)
});
var clientListServerActivityQueryKey = (options) => createQueryKey("clientListServerActivity", options);
/**
* List server activity
*
* Returns a paginated list of activity log entries for the server.
*/
var clientListServerActivityOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerActivity({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerActivityQueryKey(options)
});
var clientListServerActivityFilterOptionsQueryKey = (options) => createQueryKey("clientListServerActivityFilterOptions", options);
/**
* List server activity filter options
*
* Returns the distinct events and users present in the server activity log.
*/
var clientListServerActivityFilterOptionsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerActivityFilterOptions({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerActivityFilterOptionsQueryKey(options)
});
var clientSendServerCommandMutationKey = (options) => createMutationKey("clientSendServerCommand", options);
/**
* Send server command
*
* Sends a console command to the running server through Wings.
*/
var clientSendServerCommandMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientSendServerCommand({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientSendServerCommandMutationKey(options)
	};
};
var clientSendPowerActionMutationKey = (options) => createMutationKey("clientSendPowerAction", options);
/**
* Send power action
*
* Sends a power signal to the server through Wings.
*/
var clientSendPowerActionMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientSendPowerAction({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientSendPowerActionMutationKey(options)
	};
};
var clientListServerDatabasesQueryKey = (options) => createQueryKey("clientListServerDatabases", options);
/**
* List server databases
*
* Returns databases attached to a server visible to the authenticated user.
*/
var clientListServerDatabasesOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerDatabases({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerDatabasesQueryKey(options)
});
var clientCreateServerDatabaseMutationKey = (options) => createMutationKey("clientCreateServerDatabase", options);
/**
* Create server database
*
* Creates a database for a server on an automatically selected database host.
*/
var clientCreateServerDatabaseMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateServerDatabase({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateServerDatabaseMutationKey(options)
	};
};
var clientRotateServerDatabasePasswordMutationKey = (options) => createMutationKey("clientRotateServerDatabasePassword", options);
/**
* Rotate server database password
*
* Rotates the password for a database attached to a server and returns the updated database.
*/
var clientRotateServerDatabasePasswordMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientRotateServerDatabasePassword({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientRotateServerDatabasePasswordMutationKey(options)
	};
};
var clientDeleteServerDatabaseMutationKey = (options) => createMutationKey("clientDeleteServerDatabase", options);
/**
* Delete server database
*
* Deletes a database attached to a server.
*/
var clientDeleteServerDatabaseMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteServerDatabase({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteServerDatabaseMutationKey(options)
	};
};
var clientListFilesQueryKey = (options) => createQueryKey("clientListFiles", options);
/**
* List files
*
* Returns files and folders in a server directory.
*/
var clientListFilesOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListFiles({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListFilesQueryKey(options)
});
var clientGetFileContentsQueryKey = (options) => createQueryKey("clientGetFileContents", options);
var clientRenameFilesMutationKey = (options) => createMutationKey("clientRenameFiles", options);
/**
* Rename files
*
* Renames one or more files or folders in a server directory.
*/
var clientRenameFilesMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientRenameFiles({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientRenameFilesMutationKey(options)
	};
};
var clientCopyFileMutationKey = (options) => createMutationKey("clientCopyFile", options);
/**
* Copy file
*
* Creates a copy of a file on the server.
*/
var clientCopyFileMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCopyFile({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCopyFileMutationKey(options)
	};
};
var clientWriteFileContentsMutationKey = (options) => createMutationKey("clientWriteFileContents", options);
/**
* Write file contents
*
* Writes the raw request body to a server file. This endpoint does not expect a JSON wrapper for the file contents.
*/
var clientWriteFileContentsMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientWriteFileContents({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientWriteFileContentsMutationKey(options)
	};
};
var clientCompressFilesMutationKey = (options) => createMutationKey("clientCompressFiles", options);
/**
* Compress files
*
* Creates an archive from one or more files or folders in a server directory.
*/
var clientCompressFilesMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCompressFiles({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCompressFilesMutationKey(options)
	};
};
var clientDecompressFileMutationKey = (options) => createMutationKey("clientDecompressFile", options);
/**
* Decompress file
*
* Extracts an archive in a server directory.
*/
var clientDecompressFileMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDecompressFile({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDecompressFileMutationKey(options)
	};
};
var clientDeleteFilesMutationKey = (options) => createMutationKey("clientDeleteFiles", options);
/**
* Delete files
*
* Deletes one or more files or folders from a server directory.
*/
var clientDeleteFilesMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteFiles({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteFilesMutationKey(options)
	};
};
var clientCreateFolderMutationKey = (options) => createMutationKey("clientCreateFolder", options);
/**
* Create folder
*
* Creates a folder in a server directory.
*/
var clientCreateFolderMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateFolder({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateFolderMutationKey(options)
	};
};
var clientChangeFilePermissionsMutationKey = (options) => createMutationKey("clientChangeFilePermissions", options);
/**
* Change file permissions
*
* Updates POSIX mode bits for one or more files or folders in a server directory.
*/
var clientChangeFilePermissionsMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientChangeFilePermissions({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientChangeFilePermissionsMutationKey(options)
	};
};
var clientListServerSchedulesQueryKey = (options) => createQueryKey("clientListServerSchedules", options);
/**
* List server schedules
*
* Returns all schedules configured for the server, including their tasks.
*/
var clientListServerSchedulesOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerSchedules({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerSchedulesQueryKey(options)
});
var clientCreateServerScheduleMutationKey = (options) => createMutationKey("clientCreateServerSchedule", options);
/**
* Create server schedule
*
* Creates a schedule for the server.
*/
var clientCreateServerScheduleMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateServerSchedule({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateServerScheduleMutationKey(options)
	};
};
var clientDeleteServerScheduleMutationKey = (options) => createMutationKey("clientDeleteServerSchedule", options);
/**
* Delete server schedule
*
* Deletes a schedule and its tasks from the server.
*/
var clientDeleteServerScheduleMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteServerSchedule({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteServerScheduleMutationKey(options)
	};
};
var clientGetServerScheduleQueryKey = (options) => createQueryKey("clientGetServerSchedule", options);
/**
* Get server schedule
*
* Returns one schedule configured for the server, including its tasks.
*/
var clientGetServerScheduleOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetServerSchedule({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetServerScheduleQueryKey(options)
});
var clientUpdateServerScheduleMutationKey = (options) => createMutationKey("clientUpdateServerSchedule", options);
/**
* Update server schedule
*
* Updates a schedule for the server and recalculates its next run time.
*/
var clientUpdateServerScheduleMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientUpdateServerSchedule({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientUpdateServerScheduleMutationKey(options)
	};
};
var clientExecuteServerScheduleMutationKey = (options) => createMutationKey("clientExecuteServerSchedule", options);
/**
* Execute server schedule
*
* Queues a schedule to run immediately regardless of its active state.
*/
var clientExecuteServerScheduleMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientExecuteServerSchedule({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientExecuteServerScheduleMutationKey(options)
	};
};
var clientCreateScheduleTaskMutationKey = (options) => createMutationKey("clientCreateScheduleTask", options);
/**
* Create schedule task
*
* Creates a task in a server schedule.
*/
var clientCreateScheduleTaskMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateScheduleTask({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateScheduleTaskMutationKey(options)
	};
};
var clientDeleteScheduleTaskMutationKey = (options) => createMutationKey("clientDeleteScheduleTask", options);
/**
* Delete schedule task
*
* Deletes a task from a server schedule and compacts subsequent sequence IDs.
*/
var clientDeleteScheduleTaskMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteScheduleTask({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteScheduleTaskMutationKey(options)
	};
};
var clientUpdateScheduleTaskMutationKey = (options) => createMutationKey("clientUpdateScheduleTask", options);
/**
* Update schedule task
*
* Updates a task in a server schedule, including its sequence position.
*/
var clientUpdateScheduleTaskMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientUpdateScheduleTask({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientUpdateScheduleTaskMutationKey(options)
	};
};
var clientListServerAllocationsQueryKey = (options) => createQueryKey("clientListServerAllocations", options);
/**
* List server allocations
*
* Returns all network allocations assigned to the server.
*/
var clientListServerAllocationsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerAllocations({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerAllocationsQueryKey(options)
});
var clientCreateServerAllocationMutationKey = (options) => createMutationKey("clientCreateServerAllocation", options);
/**
* Create server allocation
*
* Assigns an available allocation to the server.
*/
var clientCreateServerAllocationMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateServerAllocation({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateServerAllocationMutationKey(options)
	};
};
var clientDeleteServerAllocationMutationKey = (options) => createMutationKey("clientDeleteServerAllocation", options);
/**
* Delete server allocation
*
* Removes a non-primary allocation from the server and returns it to the available pool.
*/
var clientDeleteServerAllocationMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteServerAllocation({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteServerAllocationMutationKey(options)
	};
};
var clientUpdateAllocationNotesMutationKey = (options) => createMutationKey("clientUpdateAllocationNotes", options);
/**
* Update allocation notes
*
* Updates notes attached to a server allocation.
*/
var clientUpdateAllocationNotesMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientUpdateAllocationNotes({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientUpdateAllocationNotesMutationKey(options)
	};
};
var clientSetPrimaryAllocationMutationKey = (options) => createMutationKey("clientSetPrimaryAllocation", options);
/**
* Set primary allocation
*
* Sets the primary network allocation for the server.
*/
var clientSetPrimaryAllocationMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientSetPrimaryAllocation({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientSetPrimaryAllocationMutationKey(options)
	};
};
var clientListServerSubusersQueryKey = (options) => createQueryKey("clientListServerSubusers", options);
/**
* List server subusers
*
* Returns subusers assigned to the server.
*/
var clientListServerSubusersOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerSubusers({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerSubusersQueryKey(options)
});
var clientCreateServerSubuserMutationKey = (options) => createMutationKey("clientCreateServerSubuser", options);
/**
* Create server subuser
*
* Assigns an existing or new user as a subuser on the server.
*/
var clientCreateServerSubuserMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateServerSubuser({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateServerSubuserMutationKey(options)
	};
};
var clientDeleteServerSubuserMutationKey = (options) => createMutationKey("clientDeleteServerSubuser", options);
/**
* Delete server subuser
*
* Removes a subuser assignment from the server and revokes SFTP access tokens.
*/
var clientDeleteServerSubuserMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteServerSubuser({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteServerSubuserMutationKey(options)
	};
};
var clientUpdateServerSubuserMutationKey = (options) => createMutationKey("clientUpdateServerSubuser", options);
/**
* Update server subuser
*
* Updates permissions for a server subuser and revokes their SFTP access tokens.
*/
var clientUpdateServerSubuserMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientUpdateServerSubuser({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientUpdateServerSubuserMutationKey(options)
	};
};
var clientListServerBackupsQueryKey = (options) => createQueryKey("clientListServerBackups", options);
/**
* List server backups
*
* Returns a paginated list of backups for the server.
*/
var clientListServerBackupsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerBackups({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerBackupsQueryKey(options)
});
var clientCreateServerBackupMutationKey = (options) => createMutationKey("clientCreateServerBackup", options);
/**
* Create server backup
*
* Starts a new backup for the server.
*/
var clientCreateServerBackupMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateServerBackup({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateServerBackupMutationKey(options)
	};
};
var clientDeleteServerBackupMutationKey = (options) => createMutationKey("clientDeleteServerBackup", options);
/**
* Delete server backup
*
* Deletes a backup record and its stored archive.
*/
var clientDeleteServerBackupMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteServerBackup({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteServerBackupMutationKey(options)
	};
};
var clientToggleBackupLockMutationKey = (options) => createMutationKey("clientToggleBackupLock", options);
/**
* Toggle backup lock
*
* Toggles whether a backup is locked against deletion.
*/
var clientToggleBackupLockMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientToggleBackupLock({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientToggleBackupLockMutationKey(options)
	};
};
var clientRestoreServerBackupMutationKey = (options) => createMutationKey("clientRestoreServerBackup", options);
/**
* Restore server backup
*
* Restores a backup over the server files.
*/
var clientRestoreServerBackupMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientRestoreServerBackup({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientRestoreServerBackupMutationKey(options)
	};
};
var clientGetStartupConfigurationQueryKey = (options) => createQueryKey("clientGetStartupConfiguration", options);
/**
* Get startup configuration
*
* Returns the rendered startup command, available Docker images, raw startup command, and user-visible variables for the server.
*/
var clientGetStartupConfigurationOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetStartupConfiguration({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetStartupConfigurationQueryKey(options)
});
var clientUpdateStartupVariableMutationKey = (options) => createMutationKey("clientUpdateStartupVariable", options);
/**
* Update startup variable
*
* Updates one editable startup variable for the server and returns the updated rendered startup command.
*/
var clientUpdateStartupVariableMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientUpdateStartupVariable({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientUpdateStartupVariableMutationKey(options)
	};
};
var clientRenameServerMutationKey = (options) => createMutationKey("clientRenameServer", options);
/**
* Rename server
*
* Updates the server name and optionally its description.
*/
var clientRenameServerMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientRenameServer({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientRenameServerMutationKey(options)
	};
};
var clientReinstallServerMutationKey = (options) => createMutationKey("clientReinstallServer", options);
/**
* Reinstall server
*
* Queues a reinstall of the server on Wings.
*/
var clientReinstallServerMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientReinstallServer({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientReinstallServerMutationKey(options)
	};
};
var clientSetServerDockerImageMutationKey = (options) => createMutationKey("clientSetServerDockerImage", options);
/**
* Set server Docker image
*
* Updates the server Docker image to one of the images allowed by the server egg.
*/
var clientSetServerDockerImageMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientSetServerDockerImage({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientSetServerDockerImageMutationKey(options)
	};
};
//#endregion
//#region ../../resources/scripts/plugins/notifications.ts
var DEFAULT_DURATION = 8e3;
var notifyServerError = (title, options = {}) => toast.error(title, {
	duration: DEFAULT_DURATION,
	...options
});
var notifyHttpError = (cause, title, options = {}) => {
	console.error(cause);
	return notifyServerError(title, {
		description: httpErrorToHuman(cause),
		...options
	});
};
//#endregion
export { clientListServerActivityOptions as $, lazyView as $t, clientDeleteSshKeyMutation as A, clientUpdateStartupVariableMutation as At, clientGetServerScheduleOptions as B, clearThemeLayers as Bt, clientDeleteFilesMutation as C, clientToggleBackupLockMutation as Ct, clientDeleteServerDatabaseMutation as D, clientUpdateScheduleTaskMutation as Dt, clientDeleteServerBackupMutation as E, clientUpdateAllocationNotesMutation as Et, clientGetServerLogsOptions as F, clientGetExtensionJobProgress as Ft, clientListAccountActivityFilterOptionsOptions as G, implementViews as Gt, clientGetStartupConfigurationOptions as H, getViewChain as Ht, clientGetServerOptions as I, clientGetFileContents as It, clientListAccountApiKeysQueryKey as J, modelFromInput as Jt, clientListAccountActivityOptions as K, isViewComponent as Kt, clientGetServerQueryKey as L, clientGetFileDownloadUrl as Lt, clientEnableTwoFactorAuthenticationMutation as M, authGetCsrfCookie as Mt, clientExecuteServerScheduleMutation as N, clientGetAccount as Nt, clientDeleteServerScheduleMutation as O, clientUpdateServerScheduleMutation as Ot, clientGetFileContentsQueryKey as P, clientGetBackupDownloadUrl as Pt, clientListServerActivityFilterOptionsOptions as Q, isPendingLazyView as Qt, clientGetServerResourcesOptions as R, clientGetFileUploadUrl as Rt, clientDeleteAccountApiKeyMutation as S, clientSetServerDockerImageMutationKey as St, clientDeleteServerAllocationMutation as T, clientUpdateAccountPasswordMutation as Tt, clientGetStartupConfigurationQueryKey as U, getViewDefinition as Ut, clientGetServerScheduleQueryKey as V, defineView as Vt, clientGetTwoFactorSetupOptions as W, getViewDefinitions as Wt, clientListFilesOptions as X, useViewChain as Xt, clientListClientServersOptions as Y, registerViewLayer as Yt, clientListFilesQueryKey as Z, useViewDefinition as Zt, clientCreateServerDatabaseMutation as _, clientRotateServerDatabasePasswordMutation as _t, authLoginMutation as a, clientListServerDatabasesQueryKey as at, clientCreateSshKeyMutation as b, clientSetPrimaryAllocationMutation as bt, authResetPasswordMutation as c, clientListServerSchedulesQueryKey as ct, clientCopyFileMutation as d, clientListSshKeysOptions as dt, clientListServerAllocationsOptions as et, clientCreateAccountApiKeyMutation as f, clientListSshKeysQueryKey as ft, clientCreateServerBackupMutation as g, clientRestoreServerBackupMutation as gt, clientCreateServerAllocationMutation as h, clientRenameServerMutation as ht, authCompleteLoginCheckpointMutation as i, clientListServerDatabasesOptions as it, clientDisableTwoFactorAuthenticationMutation as j, clientWriteFileContentsMutation as jt, clientDeleteServerSubuserMutation as k, clientUpdateServerSubuserMutation as kt, clientChangeFilePermissionsMutation as l, clientListServerSubusersOptions as lt, clientCreateScheduleTaskMutation as m, clientRenameFilesMutation as mt, adminListActivityFilterOptionsOptions as n, clientListServerBackupsOptions as nt, authLogoutMutation as o, clientListServerPermissionsOptions as ot, clientCreateFolderMutation as p, clientReinstallServerMutation as pt, clientListAccountApiKeysOptions as q, loadViewImplementation as qt, adminListActivityOptions as r, clientListServerBackupsQueryKey as rt, authRequestPasswordResetEmailMutation as s, clientListServerSchedulesOptions as st, notifyHttpError as t, clientListServerAllocationsQueryKey as tt, clientCompressFilesMutation as u, clientListServerSubusersQueryKey as ut, clientCreateServerScheduleMutation as v, clientSendPowerActionMutation as vt, clientDeleteScheduleTaskMutation as w, clientUpdateAccountEmailMutation as wt, clientDecompressFileMutation as x, clientSetServerDockerImageMutation as xt, clientCreateServerSubuserMutation as y, clientSendServerCommandMutation as yt, clientGetServerResourcesQueryKey as z, clientGetServerExtensionJobProgress as zt };

//# sourceMappingURL=notifications-Ebj0Q0Io.js.map