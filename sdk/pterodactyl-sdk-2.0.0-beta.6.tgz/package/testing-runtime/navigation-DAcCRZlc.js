import { n as ButtonWithVariants } from "./Button-BzlrfY24.js";
import { n as getBootstrapTheme } from "./bootstrap-XdDfwDao.js";
import { Kt as isViewComponent } from "./notifications-Ebj0Q0Io.js";
import { n as useServerRouteId } from "./params-HmQaEn9f.js";
import { d as useServerQuery, t as selectServerPermissions } from "./queries-D_-2KdyF.js";
import { t as hasPermission } from "./usePermissions-pEpnhvzH.js";
import { C as useExtensionRegistry, c as SCREEN_ROOTS, d as findExtensionScreen, f as getExtensionConfig, h as getScreenOptions, m as getExtensionLoadState, n as resolvePanelDestination, s as ExtensionImportError, t as PanelLink, u as clearExtensionError, x as reportExtensionError, y as matchesScreenCondition } from "./navigation-9aP-0Hbq.js";
import { r as useCurrentUser } from "./queries-BF8_5ZD3.js";
import { Component, Suspense, createContext, useCallback, useContext, useEffect, useMemo, useSyncExternalStore } from "react";
import { useLocation, useMatchRoute } from "@tanstack/react-router";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { QueryErrorResetBoundary } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/views/theme.ts
/** Identity helper typing a theme entry: `export default defineTheme({ ui, views, icons, setup })`. */
function defineTheme(definition) {
	return definition;
}
var icons = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var fallback = false;
var scheme;
var preference;
var followingDevice = false;
/** Adds a theme's icons; an entry that is not a component is skipped, as no view boundary would catch it. */
function registerThemeIcons(map) {
	for (const [name, icon] of Object.entries(map)) if (isViewComponent(icon)) icons.set(name, icon);
}
function getThemeIcon(name) {
	return icons.get(name);
}
function currentScheme() {
	return scheme ??= getBootstrapTheme().scheme;
}
/** The stored preference; a scheme the theme does not offer was replaced by its default when the page loaded. */
function currentPreference() {
	if (preference === void 0) {
		const stored = /(?:^|;\s*)pterodactyl_scheme=(\w+)/.exec(document.cookie)?.[1];
		const offered = getBootstrapTheme().schemes.find((candidate) => candidate === stored);
		preference = stored === "system" ? "system" : offered ?? currentScheme();
	}
	return preference;
}
var prefersLight = () => matchMedia("(prefers-color-scheme: light)");
var deviceScheme = () => prefersLight().matches ? "light" : "dark";
function applyScheme(chosen) {
	const { schemes } = getBootstrapTheme();
	const resolved = chosen === "system" ? deviceScheme() : chosen;
	const next = schemes.includes(resolved) ? resolved : schemes[0] ?? "dark";
	document.documentElement.classList.remove("dark", "light");
	document.documentElement.classList.add(next);
	scheme = next;
	for (const listener of listeners) listener();
}
function setThemeScheme(chosen) {
	document.cookie = `pterodactyl_scheme=${chosen}; path=/; max-age=31536000; samesite=lax`;
	preference = chosen;
	applyScheme(chosen);
}
function subscribeScheme(listener) {
	listeners.add(listener);
	if (!followingDevice) {
		followingDevice = true;
		prefersLight().addEventListener("change", () => {
			if (currentPreference() === "system") applyScheme("system");
		});
	}
	return () => {
		listeners.delete(listener);
	};
}
function useTheme() {
	const current = useSyncExternalStore(subscribeScheme, currentScheme);
	const chosen = useSyncExternalStore(subscribeScheme, currentPreference);
	const theme = getBootstrapTheme();
	return {
		id: fallback ? "classic" : theme.id,
		chain: fallback ? [] : theme.chain,
		scheme: current,
		preference: chosen,
		schemes: theme.schemes,
		setScheme: setThemeScheme
	};
}
function useThemeSettings() {
	return getBootstrapTheme().settings;
}
//#endregion
//#region ../../resources/scripts/extensions/context.ts
var ExtensionContext = createContext(null);
function useExtensionCallback(event, callback) {
	const mount = useContext(ExtensionContext);
	if (!mount) throw new Error("Extension callbacks require an extension mount.");
	const context = `${mount.context}, event "${event}"`;
	return (...args) => {
		try {
			const result = callback(...args);
			if (result) result.then(() => clearExtensionError(mount.extensionId, context), (error) => reportExtensionError(mount.extensionId, context, error));
			else clearExtensionError(mount.extensionId, context);
		} catch (error) {
			reportExtensionError(mount.extensionId, context, error);
		}
	};
}
//#endregion
//#region ../../resources/scripts/extensions/ExtensionMount.tsx
var ExtensionBoundary = class extends Component {
	state = { error: null };
	static getDerivedStateFromError(cause) {
		return { error: cause instanceof Error ? cause : new Error(String(cause)) };
	}
	componentDidCatch(error) {
		reportExtensionError(this.props.extensionId, this.props.context, error);
	}
	componentDidUpdate(previous) {
		if (previous.resetKey !== this.props.resetKey && this.state.error) this.retry();
	}
	retry = () => {
		this.props.onReset();
		clearExtensionError(this.props.extensionId, this.props.context);
		this.setState({ error: null });
	};
	render() {
		return this.state.error ? this.props.fallback(this.state.error, this.retry) : this.props.children;
	}
};
var failedMountsByNotification = /* @__PURE__ */ new Map();
var failureNotificationId = (extensionId, context) => `extension-failure:${extensionId}:${context}`;
function showFailureNotice(notificationId, extensionId, mounts) {
	const retryable = [...mounts].some((mount) => mount.retry);
	toast.error(`The "${extensionId}" extension could not display this content.`, {
		id: notificationId,
		duration: Infinity,
		action: retryable ? {
			label: "Retry extension",
			onClick: () => {
				for (const mount of mounts) mount.retry?.();
			}
		} : {
			label: "Reload page",
			onClick: () => window.location.reload()
		},
		description: retryable ? /* @__PURE__ */ jsx(ButtonWithVariants, {
			type: "button",
			onClick: () => window.location.reload(),
			children: "Reload page"
		}) : void 0
	});
}
/** Mounts sharing a `notificationId` share one toast whose retry resets all of them. */
function ExtensionFailure({ extensionId, retry, notificationId }) {
	useEffect(() => {
		if (!notificationId) return;
		const mount = { retry };
		const mounts = failedMountsByNotification.get(notificationId) ?? /* @__PURE__ */ new Set();
		mounts.add(mount);
		failedMountsByNotification.set(notificationId, mounts);
		if (mounts.size === 1) showFailureNotice(notificationId, extensionId, mounts);
		return () => {
			mounts.delete(mount);
			if (mounts.size) return;
			failedMountsByNotification.delete(notificationId);
			toast.dismiss(notificationId);
		};
	}, [
		extensionId,
		notificationId,
		retry
	]);
	if (notificationId) return null;
	return /* @__PURE__ */ jsxs("div", {
		role: "alert",
		children: [
			/* @__PURE__ */ jsxs("p", { children: [
				"The \"",
				extensionId,
				"\" extension could not display this content."
			] }),
			retry && /* @__PURE__ */ jsx(ButtonWithVariants, {
				type: "button",
				onClick: retry,
				children: "Retry extension"
			}),
			/* @__PURE__ */ jsx(ButtonWithVariants, {
				type: "button",
				onClick: () => window.location.reload(),
				children: "Reload page"
			})
		]
	});
}
function ExtensionMount({ extensionId, context, resetKey, loading = null, isSlot = false, failure, children }) {
	const mount = useMemo(() => ({
		extensionId,
		context
	}), [extensionId, context]);
	return /* @__PURE__ */ jsx(ExtensionContext.Provider, {
		value: mount,
		children: /* @__PURE__ */ jsx(QueryErrorResetBoundary, { children: ({ reset }) => /* @__PURE__ */ jsx(ExtensionBoundary, {
			...mount,
			resetKey,
			onReset: reset,
			fallback: (error, retry) => {
				if (failure instanceof Function) return failure(error, retry);
				return failure === void 0 ? /* @__PURE__ */ jsx(ExtensionFailure, {
					extensionId,
					notificationId: isSlot ? failureNotificationId(extensionId, context) : void 0,
					retry: error instanceof ExtensionImportError ? void 0 : retry
				}) : failure;
			},
			children: /* @__PURE__ */ jsx(Suspense, {
				fallback: loading,
				children
			})
		}) })
	});
}
//#endregion
//#region ../../resources/scripts/extensions/resourceContext.ts
var ExtensionResourceProvider = createContext(null);
function useCurrentResource() {
	return useContext(ExtensionResourceProvider);
}
//#endregion
//#region ../../resources/scripts/extensions/screenNavigation.tsx
/** Only server-area screens see the current server. */
function useAreaServer(screen) {
	const id = useServerRouteId();
	return useServerQuery(screen.area === "server" ? id ?? "" : "").data;
}
function useScreenContext(screen) {
	const user = useCurrentUser();
	const server = useAreaServer(screen);
	const resource = useCurrentResource() ?? void 0;
	const config = getExtensionConfig(screen.extensionId);
	return useMemo(() => ({
		user,
		server,
		resource,
		config
	}), [
		user,
		server,
		resource,
		config
	]);
}
function Predicate({ screen, visible, hidden, children }) {
	return visible(useScreenContext(screen)) === true ? children : hidden;
}
function ConditionalScreen({ screen, pending, hidden, children }) {
	const { extensionId, id, when } = screen;
	const server = useAreaServer(screen);
	const pathname = useLocation({ select: (location) => location.pathname });
	const visible = useExtensionRegistry(() => getScreenOptions(extensionId, id)?.visible);
	const failed = useExtensionRegistry(() => getExtensionLoadState(extensionId)?.status === "failed");
	if (!matchesScreenCondition(when, server)) return hidden;
	if (!when?.runtime) return children;
	if (!visible) return failed ? hidden : pending;
	return /* @__PURE__ */ jsx(ExtensionMount, {
		extensionId,
		context: `screen "${id}" visibility`,
		resetKey: pathname,
		loading: pending,
		failure: hidden,
		children: /* @__PURE__ */ jsx(Predicate, {
			screen,
			visible,
			hidden,
			children
		})
	});
}
/** Renders `children` while the screen's conditions hold, `pending` while its predicate can't answer yet. */
function ScreenGate({ screen, pending = null, hidden = null, children }) {
	return screen?.when ? /* @__PURE__ */ jsx(ConditionalScreen, {
		screen,
		pending,
		hidden,
		children
	}) : children;
}
var BADGE_MAX_LENGTH = 32;
function Badge({ children }) {
	return /* @__PURE__ */ jsx("span", {
		className: "rounded bg-muted px-1 text-xs text-muted-foreground",
		children
	});
}
function LiveBadge({ screen, badge, fallback }) {
	const value = badge(useScreenContext(screen));
	if (value === void 0) return fallback;
	const text = value === null ? "" : String(value).slice(0, BADGE_MAX_LENGTH);
	return text ? /* @__PURE__ */ jsx(Badge, { children: text }) : null;
}
function RegisteredBadge({ screen, fallback }) {
	const { extensionId, id } = screen;
	const pathname = useLocation({ select: (location) => location.pathname });
	const badge = useExtensionRegistry(() => getScreenOptions(extensionId, id)?.badge);
	if (!badge) return fallback;
	return /* @__PURE__ */ jsx(ExtensionMount, {
		extensionId,
		context: `screen "${id}" badge`,
		resetKey: pathname,
		loading: fallback,
		failure: fallback,
		children: /* @__PURE__ */ jsx(LiveBadge, {
			screen,
			badge,
			fallback
		})
	});
}
/** The extension's live badge once it answers, else the manifest's. */
function ScreenBadge({ screen, badge }) {
	const fallback = badge ? /* @__PURE__ */ jsx(Badge, { children: badge }) : null;
	return screen ? /* @__PURE__ */ jsx(RegisteredBadge, {
		screen,
		fallback
	}) : fallback;
}
//#endregion
//#region ../../resources/scripts/router/nav.ts
var areas = {
	account: [],
	server: [],
	admin: []
};
function getAreaNav(area) {
	return areas[area];
}
//#endregion
//#region ../../resources/scripts/views/navigation.tsx
/** A key that is unique within one navigation. */
var navItemKey = (item) => `${item.extensionId ?? ""}:${item.id}`;
/** A route path, such as `/server/$id/files`, with its params as a destination; extension screens' paths resolve the same way. */
var navItemDestination = (to, params, hash) => ({
	to,
	params,
	hash
});
var toNavItem = (area, entry, order, params) => ({
	id: entry.screen?.id ?? (entry.segment || "index"),
	label: entry.label,
	destination: navItemDestination(entry.segment ? `${SCREEN_ROOTS[area]}/${entry.segment}` : SCREEN_ROOTS[area], params, entry.hash),
	icon: entry.icon ?? null,
	group: entry.group ?? null,
	order,
	exact: entry.exact ?? false,
	extensionId: entry.screen?.extensionId
});
/** Server items need one of their subuser permissions and, for extension screens, a matching egg. */
function isListed(entry, server) {
	const permissions = server ? selectServerPermissions(server) : [];
	const required = entry.permission === void 0 ? [] : [entry.permission].flat();
	return (!required.length || required.some((permission) => hasPermission(permissions, permission))) && matchesScreenCondition(entry.screen?.when, server);
}
/**
* The navigation of an area, filtered by subuser permissions and egg rules. Screens with a runtime
* predicate stay listed; `<Navigation>` renders them once the predicate allows it.
*/
function useNavigation(area) {
	const id = useServerRouteId();
	const serverId = area === "server" ? id ?? "" : "";
	const server = useServerQuery(serverId).data;
	return useMemo(() => {
		const params = serverId ? { id: serverId } : {};
		return { items: getAreaNav(area).map((entry, order) => ({
			entry,
			item: toNavItem(area, entry, order, params)
		})).filter(({ entry }) => area !== "server" || isListed(entry, server)).map(({ item }) => item) };
	}, [
		area,
		serverId,
		server
	]);
}
var itemScreen = (item) => item.extensionId === void 0 ? void 0 : findExtensionScreen(item.extensionId, item.id);
function navItemBadge(item) {
	const screen = itemScreen(item);
	return screen ? /* @__PURE__ */ jsx(ScreenBadge, {
		screen,
		badge: screen.nav?.badge
	}) : null;
}
/** Whether an item is active: on its path, or below it unless it is exact. */
function useNavItemActive() {
	const matchRoute = useMatchRoute();
	return useCallback((item) => matchRoute({
		to: resolvePanelDestination(item.destination).pathname,
		fuzzy: !item.exact,
		includeSearch: false
	}) !== false, [matchRoute]);
}
var pathLength = (item) => resolvePanelDestination(item.destination).pathname.length;
/** The most specific active item, e.g. to title a collapsed navigation. */
function useActiveNavItem(items) {
	const isActive = useNavItemActive();
	return items.filter(isActive).sort((a, b) => pathLength(b) - pathLength(a))[0];
}
/**
* Renders each item through `children`, inside the runtime gate of its extension screen, so a
* screen hidden by its predicate renders nothing.
*/
function Navigation({ items, children }) {
	const isActive = useNavItemActive();
	return /* @__PURE__ */ jsx(Fragment$1, { children: items.map((item) => /* @__PURE__ */ jsx(ScreenGate, {
		screen: itemScreen(item),
		children: children(item, {
			active: isActive(item),
			badge: navItemBadge(item)
		})
	}, navItemKey(item))) });
}
/** A link to an item; it carries `data-status="active"` while the item is active. */
function NavigationLink({ item, ...props }) {
	return /* @__PURE__ */ jsx(PanelLink, {
		destination: item.destination,
		exact: item.exact,
		...props
	});
}
//#endregion
export { useTheme as _, navItemKey as a, useNavigation as c, ExtensionMount as d, ExtensionContext as f, registerThemeIcons as g, getThemeIcon as h, navItemDestination as i, ExtensionResourceProvider as l, defineTheme as m, NavigationLink as n, useActiveNavItem as o, useExtensionCallback as p, navItemBadge as r, useNavItemActive as s, Navigation as t, useCurrentResource as u, useThemeSettings as v };

//# sourceMappingURL=navigation-DAcCRZlc.js.map