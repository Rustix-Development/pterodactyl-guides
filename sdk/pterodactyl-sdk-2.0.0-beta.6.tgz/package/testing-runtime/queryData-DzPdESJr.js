//#region ../../resources/scripts/api/queryData.ts
var upsertListItem = (current, item, matches, create) => {
	if (!current) return create?.(item);
	const data = current.data.some((currentItem) => matches(currentItem, item)) ? current.data.map((currentItem) => matches(currentItem, item) ? item : currentItem) : [...current.data, item];
	return {
		...current,
		data
	};
};
var removeListItems = (current, matches) => current ? {
	...current,
	data: current.data.filter((item) => !matches(item))
} : current;
var updateListItems = (current, matches, updater) => current ? {
	...current,
	data: current.data.map((item) => matches(item) ? updater(item) : item)
} : current;
var mapListItems = (current, mapper) => current ? {
	...current,
	data: current.data.map(mapper)
} : current;
//#endregion
export { upsertListItem as i, removeListItems as n, updateListItems as r, mapListItems as t };

//# sourceMappingURL=queryData-DzPdESJr.js.map