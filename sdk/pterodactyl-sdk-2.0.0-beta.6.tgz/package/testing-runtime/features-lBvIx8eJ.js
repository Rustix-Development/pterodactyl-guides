import { n as featureViews, t as SERVER_FEATURES } from "./features-Dlz0IKyT.js";
export { SERVER_FEATURES, featureViews };
