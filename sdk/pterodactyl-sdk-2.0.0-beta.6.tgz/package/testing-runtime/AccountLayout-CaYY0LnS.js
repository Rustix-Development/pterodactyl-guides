import { ct as SubNavigationLayout, lt as SubNavigation } from "./sdk-Chrtpiam.js";
import { a as Slot, o as Main } from "./theme-Cgy7R6cy.js";
import { t as tabLabel } from "./tabLabel-DAPdSje5.js";
import { jsx } from "react/jsx-runtime";
//#region ../../resources/scripts/themes/classic/views/layout/AccountLayout.tsx
function AccountLayout({ model, className, children }) {
	return /* @__PURE__ */ jsx(SubNavigationLayout, {
		className,
		navigation: /* @__PURE__ */ jsx(SubNavigation, {
			items: model.nav.items,
			renderItem: tabLabel,
			before: /* @__PURE__ */ jsx(Slot, { name: "account.navigation.before" }),
			after: /* @__PURE__ */ jsx(Slot, { name: "account.navigation.after" })
		}),
		children: /* @__PURE__ */ jsx(Main, { children })
	});
}
//#endregion
export { AccountLayout as default };

//# sourceMappingURL=AccountLayout-CaYY0LnS.js.map