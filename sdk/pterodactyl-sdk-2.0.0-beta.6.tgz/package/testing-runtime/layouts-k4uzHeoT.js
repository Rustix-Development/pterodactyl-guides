import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { _ as useTheme, c as useNavigation, i as navItemDestination } from "./navigation-DAcCRZlc.js";
import { i as useCurrentServer } from "./queries-D_-2KdyF.js";
import { c as SCREEN_ROOTS } from "./navigation-9aP-0Hbq.js";
import { r as useCurrentUser } from "./queries-BF8_5ZD3.js";
import { t as serverResourceUsageQueryOptions } from "./queries-ubEuC6zs.js";
import { n as onThemeChange, r as readThemeToken } from "./theme-BChAVzYS.js";
import { n as useSiteSettings } from "./queries-DXZ7OlB6.js";
import { n as serverConflict, t as runState } from "./state-CUrz93jS.js";
import { t as createTestServer } from "./fixtures-sueNo-ZT.js";
import { r as useLogout } from "./queries-DA42aKcL.js";
import { useMemo, useSyncExternalStore } from "react";
import { useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
//#region ../../resources/scripts/views/brand.ts
var URL_TOKEN = /^url\(\s*(?:"((?:[^"\\]|\\.)*)"|'((?:[^'\\]|\\.)*)'|([^\s"'()\\]*))\s*\)$/s;
var ESCAPE = /\\(?:([0-9a-fA-F]{1,6})\s?|(.))/gs;
var codePoint = (hex) => {
	const value = Number.parseInt(hex, 16);
	return String.fromCodePoint(value > 0 && value <= 1114111 ? value : 65533);
};
/** The address in a `url(…)` token value, with CSS escapes undone; null for any other value. */
function cssUrl(value) {
	const match = URL_TOKEN.exec(value.trim());
	const raw = match?.[1] ?? match?.[2] ?? match?.[3];
	return raw ? raw.replaceAll(ESCAPE, (_, hex, char) => hex ? codePoint(hex) : char ?? "") : null;
}
var logo$1;
var readLogo = () => cssUrl(readThemeToken("--brand-logo"));
function subscribeLogo(listener) {
	return onThemeChange(() => {
		logo$1 = readLogo();
		listener();
	});
}
function currentLogo() {
	if (logo$1 === void 0) logo$1 = readLogo();
	return logo$1;
}
/**
* The logo of the active theme: the `--brand-logo` token its image setting writes. It follows the
* admin's live preview of the theme settings.
*/
function useBrandLogo() {
	return useSyncExternalStore(subscribeLogo, currentLogo, () => null);
}
//#endregion
//#region ../../resources/scripts/views/layouts.ts
function useBrand() {
	const { name } = useSiteSettings();
	const logoUrl = useBrandLogo();
	return useMemo(() => ({
		name,
		logoUrl
	}), [name, logoUrl]);
}
function useAuthLayoutModel() {
	const brand = useBrand();
	return useMemo(() => ({ brand }), [brand]);
}
function useAccountLayoutModel() {
	const nav = useNavigation("account");
	return useMemo(() => ({ nav }), [nav]);
}
var adminLink = (internalId, order) => ({
	id: "admin",
	label: "Open Admin Area",
	destination: {
		to: "/panel/servers/$id",
		params: { id: String(internalId) }
	},
	icon: "external-link",
	group: null,
	order,
	exact: false
});
/** What Wings last reported: the resources query, fetched once and kept current by the server's websocket. */
function useServerRunState(uuid) {
	const { data } = useQuery({
		...serverResourceUsageQueryOptions(uuid),
		enabled: uuid !== "",
		staleTime: Infinity,
		select: (resources) => runState(resources.attributes.current_state)
	});
	return data ?? null;
}
/** The model of `layout.server` for the server of the route; null outside a server and while it loads. */
function useServerFrame() {
	const server = useCurrentServer();
	const { rootAdmin } = useCurrentUser();
	const nav = useNavigation("server");
	const state = useServerRunState(server?.attributes.uuid ?? "");
	return useMemo(() => {
		if (!server) return null;
		const { name, identifier, uuid, internal_id: internalId } = server.attributes;
		return {
			name,
			identifier,
			uuid,
			internalId,
			state,
			conflict: serverConflict(server),
			adminLink: rootAdmin ? adminLink(internalId, nav.items.length) : null,
			nav,
			server
		};
	}, [
		server,
		rootAdmin,
		nav,
		state
	]);
}
function useServerLayoutModel() {
	const model = useServerFrame();
	if (!model) throw new Error("layout.server renders once its server has loaded.");
	return model;
}
function useAdminLayoutModel() {
	const nav = useNavigation("admin");
	const { uuid, username, email } = useCurrentUser();
	return useMemo(() => ({
		nav,
		user: {
			uuid,
			username,
			email
		}
	}), [
		nav,
		uuid,
		username,
		email
	]);
}
var appLinks = (rootAdmin) => [
	{
		id: "dashboard",
		label: "Dashboard",
		destination: { to: "/" },
		exact: true,
		icon: "layers"
	},
	...rootAdmin ? [{
		id: "admin",
		label: "Admin",
		destination: { to: "/panel" },
		exact: false,
		icon: "user-cog"
	}] : [],
	{
		id: "account",
		label: "Account Settings",
		destination: { to: "/account" },
		exact: false,
		icon: "user-round"
	}
];
var DASHBOARD = Object.freeze({ kind: "dashboard" });
/** The routes that open an area, by id. */
var AREA_ROUTES = [
	["/authenticated/account", "account"],
	["/authenticated/server/$id", "server"],
	["/authenticated/panel", "admin"]
];
function useAppArea() {
	const kind = useRouterState({ select: ({ matches }) => AREA_ROUTES.find(([id]) => matches.some((match) => match.routeId === id))?.[1] ?? "dashboard" });
	const account = useAccountLayoutModel();
	const server = useServerFrame();
	const admin = useAdminLayoutModel();
	return useMemo(() => {
		if (kind === "account") return {
			kind,
			...account
		};
		if (kind === "admin") return {
			kind,
			...admin
		};
		return kind === "server" && server ? {
			kind,
			...server
		} : DASHBOARD;
	}, [
		kind,
		account,
		server,
		admin
	]);
}
function useAppLayoutModel() {
	const brand = useBrand();
	const { uuid, username, email, rootAdmin } = useCurrentUser();
	const { scheme, preference, schemes, setScheme } = useTheme();
	const { mutate, isPending } = useLogout();
	const area = useAppArea();
	return useMemo(() => ({
		brand,
		links: appLinks(rootAdmin),
		area,
		user: {
			uuid,
			username,
			email,
			rootAdmin
		},
		scheme,
		preference,
		schemes,
		setScheme: schemes.length > 1 ? setScheme : null,
		signOut: () => mutate({}),
		signingOut: isPending
	}), [
		brand,
		area,
		uuid,
		username,
		email,
		rootAdmin,
		scheme,
		preference,
		schemes,
		setScheme,
		mutate,
		isPending
	]);
}
var noop = () => {};
var brand = {
	name: "Pterodactyl",
	logoUrl: null
};
var logo = {
	...brand,
	logoUrl: "/favicons/android-chrome-192x192.png"
};
var appLayoutFixture = (rootAdmin, schemes = ["dark"], area = DASHBOARD) => ({
	brand,
	links: appLinks(rootAdmin),
	area,
	user: {
		uuid: "11111111-1111-4111-8111-111111111111",
		username: "alex",
		email: "alex@example.test",
		rootAdmin
	},
	scheme: schemes[0] ?? "dark",
	preference: schemes[0] ?? "dark",
	schemes,
	setScheme: schemes.length > 1 ? noop : null,
	signOut: noop,
	signingOut: false
});
var SERVER_ID = "a1b2c3d4";
/** Core items of an area as `useNavigation` lists them, from `[path, label, icon, options]`. */
function navFixture(area, entries) {
	return { items: entries.map(([path, label, icon, { hash, ...options } = {}], order) => ({
		id: path || "index",
		label,
		destination: navItemDestination(path ? `${SCREEN_ROOTS[area]}/${path}` : SCREEN_ROOTS[area], area === "server" ? { id: SERVER_ID } : {}, hash),
		icon,
		group: null,
		order,
		exact: path === "",
		...options
	})) };
}
var extensionItem = (area, order) => ({
	id: "tickets",
	extensionId: "support",
	icon: "life-buoy",
	group: "Support",
	order,
	destination: navItemDestination(`${SCREEN_ROOTS[area]}/tickets`, area === "server" ? { id: SERVER_ID } : {})
});
var accountNav = (extension = false) => navFixture("account", [
	[
		"",
		"Account",
		"user-round"
	],
	[
		"api",
		"API Credentials",
		"key-round"
	],
	[
		"ssh",
		"SSH Keys",
		"terminal"
	],
	[
		"activity",
		"Activity",
		"history"
	],
	...extension ? [[
		"tickets",
		"Tickets",
		"life-buoy",
		extensionItem("account", 4)
	]] : []
]);
var serverPaths = [
	[
		"",
		"Console",
		"square-terminal"
	],
	[
		"files",
		"Files",
		"folder",
		{ hash: "/" }
	],
	[
		"databases",
		"Databases",
		"database"
	],
	[
		"schedules",
		"Schedules",
		"calendar-clock"
	],
	[
		"users",
		"Users",
		"users"
	],
	[
		"backups",
		"Backups",
		"archive"
	],
	[
		"network",
		"Network",
		"network"
	],
	[
		"startup",
		"Startup",
		"rocket"
	],
	[
		"settings",
		"Settings",
		"settings"
	],
	[
		"activity",
		"Activity",
		"history"
	]
];
function serverLayoutFixture(options = {}) {
	const server = createTestServer({
		identifier: SERVER_ID,
		name: "Survival",
		status: options.status ?? null
	});
	const { items } = navFixture("server", serverPaths);
	const nav = { items: items.filter((item) => !options.allowed || options.allowed.includes(item.id)) };
	return {
		name: server.attributes.name,
		identifier: SERVER_ID,
		uuid: server.attributes.uuid,
		internalId: server.attributes.internal_id,
		state: options.state === void 0 ? "running" : options.state,
		conflict: serverConflict(server),
		adminLink: options.rootAdmin ? adminLink(server.attributes.internal_id, nav.items.length) : null,
		nav,
		server
	};
}
var adminNav = (extension = false) => navFixture("admin", [
	[
		"",
		"Overview",
		"layout-dashboard"
	],
	[
		"activity",
		"Activity",
		"history"
	],
	[
		"settings",
		"Settings",
		"settings"
	],
	[
		"users",
		"Users",
		"users"
	],
	[
		"locations",
		"Locations",
		"map-pin"
	],
	[
		"nodes",
		"Nodes",
		"network"
	],
	[
		"servers",
		"Servers",
		"server"
	],
	[
		"databases",
		"Database Hosts",
		"database"
	],
	[
		"mounts",
		"Mounts",
		"folder-tree"
	],
	[
		"eggs",
		"Eggs",
		"egg"
	],
	[
		"tags",
		"Tags",
		"tag"
	],
	[
		"extensions",
		"Extensions",
		"blocks"
	],
	[
		"themes",
		"Themes",
		"palette"
	],
	[
		"api",
		"API Keys",
		"key-round"
	],
	...extension ? [[
		"tickets",
		"Tickets",
		"life-buoy",
		extensionItem("admin", 14)
	]] : []
]);
var adminUser = {
	uuid: "11111111-1111-4111-8111-111111111111",
	username: "alex",
	email: "alex@example.test"
};
implementViews({
	"layout.auth": {
		use: useAuthLayoutModel,
		fixtures: {
			default: () => ({ brand }),
			logo: () => ({ brand: logo })
		}
	},
	"layout.app": {
		use: useAppLayoutModel,
		fixtures: {
			user: () => appLayoutFixture(false),
			admin: () => appLayoutFixture(true),
			schemes: () => appLayoutFixture(false, ["dark", "light"]),
			logo: () => ({
				...appLayoutFixture(false),
				brand: logo
			}),
			accountArea: () => appLayoutFixture(false, ["dark"], {
				kind: "account",
				nav: accountNav()
			}),
			serverArea: () => appLayoutFixture(false, ["dark"], {
				kind: "server",
				...serverLayoutFixture()
			}),
			adminArea: () => appLayoutFixture(true, ["dark"], {
				kind: "admin",
				nav: adminNav(),
				user: adminUser
			})
		}
	},
	"layout.account": {
		use: useAccountLayoutModel,
		fixtures: {
			default: () => ({ nav: accountNav() }),
			extension: () => ({ nav: accountNav(true) })
		}
	},
	"layout.server": {
		use: useServerLayoutModel,
		fixtures: {
			owner: () => serverLayoutFixture(),
			subuser: () => serverLayoutFixture({ allowed: [
				"index",
				"files",
				"backups"
			] }),
			admin: () => serverLayoutFixture({ rootAdmin: true }),
			offline: () => serverLayoutFixture({ state: "offline" }),
			installing: () => serverLayoutFixture({
				status: "installing",
				state: "offline"
			}),
			suspended: () => serverLayoutFixture({
				status: "suspended",
				state: "offline"
			})
		}
	},
	"layout.admin": {
		use: useAdminLayoutModel,
		fixtures: {
			default: () => ({
				nav: adminNav(),
				user: adminUser
			}),
			extension: () => ({
				nav: adminNav(true),
				user: adminUser
			})
		}
	}
});
//#endregion

//# sourceMappingURL=layouts-k4uzHeoT.js.map