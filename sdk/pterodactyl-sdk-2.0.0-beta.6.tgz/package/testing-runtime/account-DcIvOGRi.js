import { a as Spinner, n as ButtonWithVariants } from "./Button-BzlrfY24.js";
import { At as Code$1, H as Tooltip, Ot as PageContentBlock, Rt as SpinnerOverlay, U as DeleteAction, V as QrCode, Y as Table, _t as PageHeading, at as EmptyTitle, et as Empty, it as EmptyMedia, kt as ContentBox, m as formatDate, nt as EmptyDescription, q as RowActions, r as cn, rt as EmptyHeader, st as Alert, wt as CopyOnClick } from "./sdk-Chrtpiam.js";
import { a as Slot, c as View } from "./theme-Cgy7R6cy.js";
import { p as TextInput, r as Form } from "./useDebouncedCallback-B4Ebjqc5.js";
import { T as Dialog } from "./queries-DIMnAeHP.js";
import { n as TextField, t as TextAreaField } from "./fields-DSobJx3_.js";
import { t as PageStatus } from "./PageStatus-BQN7WjmQ.js";
import { useMemo, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { KeyRound, KeySquare } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/account/AccountOverview.tsx
var CARD_WIDTH = "w-full sm:w-[calc(50%_-_1rem)] md:w-auto md:flex-1";
function AccountOverview({ model, className }) {
	return /* @__PURE__ */ jsxs(PageContentBlock, {
		title: "Account Overview",
		className,
		children: [
			/* @__PURE__ */ jsx(PageHeading, {
				title: "Account",
				description: "Manage your profile, credentials, and account security."
			}),
			model.twoFactorRequired && /* @__PURE__ */ jsx(Alert, {
				title: "2-Factor Required",
				type: "danger",
				children: "Your account must have two-factor authentication enabled in order to continue."
			}),
			/* @__PURE__ */ jsx(Slot, { name: "account.overview.before" }),
			/* @__PURE__ */ jsxs("div", {
				className: cn("flex flex-wrap lg:grid lg:grid-cols-3 mb-10", model.twoFactorRequired && "mt-4"),
				children: [
					/* @__PURE__ */ jsx(View, {
						name: "account.password",
						className: CARD_WIDTH
					}),
					/* @__PURE__ */ jsx(View, {
						name: "account.email",
						className: cn(CARD_WIDTH, "mt-8 sm:mt-0 sm:ml-8")
					}),
					/* @__PURE__ */ jsx(View, {
						name: "account.twoFactor",
						className: cn(CARD_WIDTH, "md:ml-8 mt-8 md:mt-0")
					})
				]
			}),
			/* @__PURE__ */ jsx(Slot, { name: "account.overview.after" })
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/PasswordCard.tsx
function PasswordCard({ model, className }) {
	const { fields } = model;
	return /* @__PURE__ */ jsxs(ContentBox, {
		className,
		title: "Update Password",
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, {
			size: "large",
			visible: model.submitting
		}), /* @__PURE__ */ jsxs(Form, {
			form: { handleSubmit: model.submit },
			className: "m-0",
			children: [
				/* @__PURE__ */ jsx(TextField, {
					field: fields.current,
					id: "current_password",
					label: "Current Password"
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-6",
					children: /* @__PURE__ */ jsx(TextField, {
						field: fields.password,
						id: "new_password",
						label: "New Password",
						description: "Your new password should be at least 8 characters in length and unique to this website."
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-6",
					children: /* @__PURE__ */ jsx(TextField, {
						field: fields.confirmPassword,
						id: "confirm_new_password",
						label: "Confirm New Password"
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-6",
					children: /* @__PURE__ */ jsx(ButtonWithVariants, {
						type: "submit",
						disabled: !model.canSubmit,
						isLoading: model.submitting,
						children: "Update Password"
					})
				})
			]
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/EmailCard.tsx
function EmailCard({ model, className }) {
	return /* @__PURE__ */ jsxs(ContentBox, {
		className,
		title: "Update Email Address",
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, {
			size: "large",
			visible: model.submitting
		}), /* @__PURE__ */ jsxs(Form, {
			form: { handleSubmit: model.submit },
			className: "m-0",
			children: [
				/* @__PURE__ */ jsx(TextField, {
					field: model.fields.email,
					id: "current_email",
					label: "Email"
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-6",
					children: /* @__PURE__ */ jsx(TextField, {
						field: model.fields.password,
						id: "confirm_password",
						label: "Confirm Password"
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-6",
					children: /* @__PURE__ */ jsx(ButtonWithVariants, {
						type: "submit",
						disabled: !model.canSubmit,
						isLoading: model.submitting,
						children: "Update Email"
					})
				})
			]
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/DisableTwoFactorDialog.tsx
function DisableTwoFactorDialog({ model }) {
	const { disable } = model;
	const { password } = disable.fields;
	return /* @__PURE__ */ jsx(Dialog, {
		open: model.dialog === "disable",
		onClose: model.closeDialog,
		preventExternalClose: disable.submitting,
		hideCloseIcon: disable.submitting,
		title: "Disable Two-Step Verification",
		description: "Disabling two-step verification will make your account less secure.",
		children: /* @__PURE__ */ jsxs("form", {
			id: "disable-totp-form",
			className: "mt-6",
			onSubmit: (event) => {
				event.preventDefault();
				event.stopPropagation();
				disable.submit();
			},
			children: [
				/* @__PURE__ */ jsx("label", {
					className: "block pb-1",
					htmlFor: "totp-password",
					children: "Password"
				}),
				/* @__PURE__ */ jsx(TextInput, {
					...password.fieldProps,
					id: "totp-password"
				}),
				/* @__PURE__ */ jsxs(Dialog.Footer, { children: [/* @__PURE__ */ jsx(ButtonWithVariants.Text, {
					onClick: model.closeDialog,
					children: "Cancel"
				}), /* @__PURE__ */ jsx(Tooltip, {
					delay: 100,
					disabled: password.fieldProps.value.length > 0,
					content: "You must enter your account password to continue.",
					children: /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
						type: "submit",
						form: "disable-totp-form",
						disabled: !disable.canSubmit,
						isLoading: disable.submitting,
						children: "Disable"
					})
				})] })
			]
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/RecoveryTokensDialog.tsx
function RecoveryTokensDialog({ tokens, onClose }) {
	const grouped = [];
	for (const [index, token] of tokens.entries()) if (index % 2 === 0) grouped.push([token, tokens[index + 1] || ""]);
	return /* @__PURE__ */ jsxs(Dialog, {
		open: tokens.length > 0,
		onClose,
		title: "Two-Step Authentication Enabled",
		description: "Store the codes below somewhere safe. If you lose access to your phone you can use these backup codes to sign in.",
		hideCloseIcon: true,
		preventExternalClose: true,
		children: [
			/* @__PURE__ */ jsx(Dialog.Icon, {
				position: "container",
				type: "success"
			}),
			/* @__PURE__ */ jsx(CopyOnClick, {
				text: tokens.join("\n"),
				showInNotification: false,
				children: /* @__PURE__ */ jsx("pre", {
					className: "bg-background rounded-sm p-2 mt-6",
					children: grouped.map((value) => /* @__PURE__ */ jsxs("span", {
						className: "block",
						children: [
							value[0],
							/* @__PURE__ */ jsx("span", {
								className: "mx-2 selection:bg-background",
								children: "\xA0"
							}),
							value[1],
							/* @__PURE__ */ jsx("span", {
								className: "selection:bg-background",
								children: "\xA0"
							})
						]
					}, value.join("_")))
				})
			}),
			/* @__PURE__ */ jsx(Alert, {
				type: "danger",
				className: "mt-3",
				children: "These codes will not be shown again."
			}),
			/* @__PURE__ */ jsx(Dialog.Footer, { children: /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
				onClick: onClose,
				children: "Done"
			}) })
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/SetupTwoFactorDialog.tsx
function SecretQrCode({ setup }) {
	if (setup.error) return /* @__PURE__ */ jsx("span", {
		className: "text-sm text-muted-foreground text-center",
		children: "Unable to load QR code."
	});
	return setup.qrCode === null ? /* @__PURE__ */ jsx(Spinner, {}) : /* @__PURE__ */ jsx(QrCode, {
		value: setup.qrCode,
		className: "w-full h-full shadow-none"
	});
}
function SetupForm({ setup, onClose }) {
	const { code, password } = setup.fields;
	const complete = password.fieldProps.value.length > 0 && code.fieldProps.value.length === 6;
	return /* @__PURE__ */ jsxs("form", {
		id: "enable-totp-form",
		onSubmit: (event) => {
			event.preventDefault();
			event.stopPropagation();
			setup.submit();
		},
		children: [
			/* @__PURE__ */ jsx("div", {
				className: "flex items-center justify-center w-56 h-56 p-2 bg-card shadow-sm mx-auto mt-6",
				children: /* @__PURE__ */ jsx(SecretQrCode, { setup })
			}),
			/* @__PURE__ */ jsx(CopyOnClick, {
				text: setup.secret ?? void 0,
				children: /* @__PURE__ */ jsx("p", {
					className: "font-mono text-sm text-foreground text-center mt-2",
					children: setup.secret?.match(/.{1,4}/g)?.join(" ") || "Loading..."
				})
			}),
			setup.error && /* @__PURE__ */ jsxs("div", {
				className: "mt-4 space-y-3",
				children: [/* @__PURE__ */ jsx(Alert, {
					type: "danger",
					children: setup.error
				}), /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
					type: "button",
					onClick: setup.retry,
					children: "Retry"
				})]
			}),
			/* @__PURE__ */ jsx("p", {
				id: "totp-code-description",
				className: "mt-6",
				children: "Scan the QR code above using the two-step authentication app of your choice. Then, enter the 6-digit code generated into the field below."
			}),
			/* @__PURE__ */ jsx(TextInput, {
				...code.fieldProps,
				"aria-labelledby": "totp-code-description",
				className: "mt-3",
				placeholder: "000000"
			}),
			/* @__PURE__ */ jsx("label", {
				htmlFor: "totp-password",
				className: "block mt-3",
				children: "Account Password"
			}),
			/* @__PURE__ */ jsx(TextInput, {
				...password.fieldProps,
				id: "totp-password",
				className: "mt-1"
			}),
			/* @__PURE__ */ jsxs(Dialog.Footer, { children: [/* @__PURE__ */ jsx(ButtonWithVariants.Text, {
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ jsx(Tooltip, {
				disabled: complete,
				content: setup.secret ? "You must enter the 6-digit code and your password to continue." : "Waiting for QR code to load...",
				delay: 100,
				children: /* @__PURE__ */ jsx(ButtonWithVariants, {
					disabled: !setup.canSubmit,
					isLoading: setup.submitting,
					type: "submit",
					form: "enable-totp-form",
					children: "Enable"
				})
			})] })
		]
	});
}
function SetupTwoFactorDialog({ model }) {
	return /* @__PURE__ */ jsx(Dialog, {
		open: model.dialog === "enable",
		onClose: model.closeDialog,
		preventExternalClose: model.setup.submitting,
		hideCloseIcon: model.setup.submitting,
		title: "Enable Two-Step Verification",
		description: "Help protect your account from unauthorized access. You'll be prompted for a verification code each time you sign in.",
		children: /* @__PURE__ */ jsx(SetupForm, {
			setup: model.setup,
			onClose: model.closeDialog
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/TwoFactorCard.tsx
function TwoFactorCard({ model, className }) {
	return /* @__PURE__ */ jsx(ContentBox, {
		className,
		title: "Two-Step Verification",
		children: /* @__PURE__ */ jsxs("div", { children: [
			/* @__PURE__ */ jsx(SetupTwoFactorDialog, { model }),
			/* @__PURE__ */ jsx(RecoveryTokensDialog, {
				tokens: model.recoveryTokens,
				onClose: model.dismissRecoveryTokens
			}),
			/* @__PURE__ */ jsx(DisableTwoFactorDialog, { model }),
			/* @__PURE__ */ jsx("p", {
				className: "text-sm",
				children: model.enabled ? "Two-step verification is currently enabled on your account." : "You do not currently have two-step verification enabled on your account. Click the button below to begin configuring it."
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6",
				children: model.enabled ? /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
					onClick: () => model.openDialog("disable"),
					children: "Disable Two-Step"
				}) : /* @__PURE__ */ jsx(ButtonWithVariants, {
					onClick: () => model.openDialog("enable"),
					children: "Enable Two-Step"
				})
			})
		] })
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/ApiKeysPage.tsx
function ApiKeysPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(PageContentBlock, {
			title: "Account API",
			className,
			children: /* @__PURE__ */ jsxs("div", {
				className: "md:flex flex-nowrap my-10",
				children: [/* @__PURE__ */ jsx(View, {
					name: "account.apiKeys.create",
					className: "flex-none w-full md:w-1/2"
				}), /* @__PURE__ */ jsx(View, {
					name: "account.apiKeys.list",
					className: "flex-1 overflow-hidden mt-8 md:mt-0 md:ml-8"
				})]
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/ApiKeyList.tsx
var apiKeyColumns = (onDelete) => [
	{
		id: "description",
		label: "Description",
		sortValue: (key) => key.description,
		cell: (key) => /* @__PURE__ */ jsxs("div", {
			className: "min-w-40",
			children: [/* @__PURE__ */ jsx("p", {
				className: "truncate font-medium",
				children: key.description
			}), /* @__PURE__ */ jsx("p", {
				className: "mt-0.5 truncate font-mono text-xs text-muted-foreground md:hidden",
				children: key.identifier
			})]
		})
	},
	{
		id: "identifier",
		label: "Identifier",
		sortValue: (key) => key.identifier,
		cell: (key) => /* @__PURE__ */ jsx("code", {
			className: "font-mono text-xs text-muted-foreground",
			children: key.identifier
		}),
		headerClassName: "hidden md:table-cell",
		cellClassName: "hidden md:table-cell"
	},
	{
		id: "last_used_at",
		label: "Last used",
		sortValue: (key) => key.lastUsedAt,
		cell: (key) => /* @__PURE__ */ jsx("span", {
			className: "whitespace-nowrap text-xs text-muted-foreground",
			children: key.lastUsedAt ? formatDate(key.lastUsedAt, "MMM D, YYYY HH:mm") : "Never"
		}),
		headerClassName: "hidden lg:table-cell w-40",
		cellClassName: "hidden lg:table-cell w-40"
	},
	{
		id: "actions",
		label: /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "Actions"
		}),
		cell: (key) => /* @__PURE__ */ jsx(RowActions, { children: /* @__PURE__ */ jsx(DeleteAction, {
			"aria-label": `Delete ${key.description} API key`,
			onClick: () => onDelete(key.identifier)
		}) }),
		headerClassName: "w-14 text-right",
		cellClassName: "w-14 text-right"
	}
];
function ApiKeyList({ model, className }) {
	const [deleteIdentifier, setDeleteIdentifier] = useState("");
	const columns = useMemo(() => apiKeyColumns(setDeleteIdentifier), []);
	return /* @__PURE__ */ jsxs(ContentBox, {
		title: "API Keys",
		className,
		children: [
			/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.deleting }),
			/* @__PURE__ */ jsxs(Dialog.Confirm, {
				title: "Delete API Key",
				confirm: "Delete Key",
				open: !!deleteIdentifier,
				pending: model.deleting,
				onClose: () => setDeleteIdentifier(""),
				onConfirmed: () => void model.remove(deleteIdentifier).then(() => setDeleteIdentifier("")),
				children: [
					"All requests using the ",
					/* @__PURE__ */ jsx(Code$1, { children: deleteIdentifier }),
					" key will be invalidated."
				]
			}),
			model.loading ? /* @__PURE__ */ jsx(Spinner, {
				size: "large",
				centered: true
			}) : /* @__PURE__ */ jsx(Table, {
				rows: model.keys,
				columns,
				keyOf: (key) => key.identifier,
				emptyState: /* @__PURE__ */ jsx(Empty, {
					size: "compact",
					children: /* @__PURE__ */ jsxs(EmptyHeader, { children: [
						/* @__PURE__ */ jsx(EmptyMedia, {
							variant: "icon",
							children: /* @__PURE__ */ jsx(KeyRound, {})
						}),
						/* @__PURE__ */ jsx(EmptyTitle, { children: "No API keys" }),
						/* @__PURE__ */ jsx(EmptyDescription, { children: "Create a key to use the client API from your own scripts and tools." })
					] })
				})
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/ApiKeyCreate.tsx
function CreatedKeyDialog({ apiKey, onClose }) {
	return /* @__PURE__ */ jsxs(Dialog, {
		open: apiKey !== null,
		onClose,
		preventExternalClose: true,
		title: "Your API key",
		children: [
			/* @__PURE__ */ jsx("p", {
				className: "text-sm mb-6",
				children: "The API key you have requested is shown below. Please store this in a safe location, it will not be shown again."
			}),
			/* @__PURE__ */ jsx("pre", {
				className: "overflow-x-scroll text-sm bg-muted rounded-sm py-2 px-4 font-mono",
				children: /* @__PURE__ */ jsx(CopyOnClick, {
					text: apiKey ?? "",
					children: /* @__PURE__ */ jsx("code", {
						className: "font-mono",
						children: apiKey
					})
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "flex justify-end mt-6",
				children: /* @__PURE__ */ jsx(ButtonWithVariants, {
					type: "button",
					onClick: onClose,
					children: "Close"
				})
			})
		]
	});
}
function ApiKeyCreate({ model, className }) {
	return /* @__PURE__ */ jsxs(ContentBox, {
		title: "Create API Key",
		className,
		children: [/* @__PURE__ */ jsx(CreatedKeyDialog, {
			apiKey: model.createdKey,
			onClose: model.dismissCreatedKey
		}), /* @__PURE__ */ jsxs(Form, {
			form: { handleSubmit: model.submit },
			children: [
				/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.submitting }),
				/* @__PURE__ */ jsx("div", {
					className: "mb-6",
					children: /* @__PURE__ */ jsx(TextField, {
						field: model.fields.description,
						label: "Description",
						description: "A description of this API key."
					})
				}),
				/* @__PURE__ */ jsx(TextAreaField, {
					field: model.fields.allowedIps,
					label: "Allowed IPs",
					rows: 6,
					description: "Leave blank to allow any IP address to use this API key, otherwise provide each IP address on a new line."
				}),
				/* @__PURE__ */ jsx("div", {
					className: "flex justify-end mt-6",
					children: /* @__PURE__ */ jsx(ButtonWithVariants, {
						type: "submit",
						disabled: !model.canSubmit,
						isLoading: model.submitting,
						children: "Create"
					})
				})
			]
		})]
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/SshKeysPage.tsx
function SshKeysPage({ model, className }) {
	return /* @__PURE__ */ jsx(PageStatus, {
		model,
		className,
		children: /* @__PURE__ */ jsx(PageContentBlock, {
			title: "SSH Keys",
			className,
			children: /* @__PURE__ */ jsxs("div", {
				className: "md:flex flex-nowrap my-10",
				children: [/* @__PURE__ */ jsx(View, {
					name: "account.sshKeys.create",
					className: "flex-none w-full md:w-1/2"
				}), /* @__PURE__ */ jsx(View, {
					name: "account.sshKeys.list",
					className: "flex-1 overflow-hidden mt-8 md:mt-0 md:ml-8"
				})]
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/SshKeyList.tsx
function DeleteKeyButton({ item, remove }) {
	return /* @__PURE__ */ jsxs(Dialog.ConfirmTrigger, {
		title: "Delete SSH Key",
		confirm: "Delete Key",
		onConfirmed: (_event, close) => remove(item.fingerprint).then(close),
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(DeleteAction, {
			"aria-label": `Delete ${item.name}`,
			onClick
		}),
		children: [
			"Removing the ",
			/* @__PURE__ */ jsx(Code$1, { children: item.name }),
			" SSH key will invalidate its usage across the Panel."
		]
	});
}
var sshKeyColumns = (remove) => [
	{
		id: "name",
		label: "Name",
		sortValue: (key) => key.name,
		cell: (key) => /* @__PURE__ */ jsxs("div", {
			className: "min-w-40",
			children: [/* @__PURE__ */ jsx("p", {
				className: "truncate font-medium",
				children: key.name
			}), /* @__PURE__ */ jsxs("p", {
				className: "mt-0.5 truncate font-mono text-xs text-muted-foreground md:hidden",
				children: ["SHA256:", key.fingerprint]
			})]
		})
	},
	{
		id: "fingerprint",
		label: "Fingerprint",
		sortValue: (key) => key.fingerprint,
		cell: (key) => /* @__PURE__ */ jsxs("code", {
			className: "font-mono text-xs text-muted-foreground",
			children: ["SHA256:", key.fingerprint]
		}),
		headerClassName: "hidden md:table-cell",
		cellClassName: "hidden md:table-cell"
	},
	{
		id: "created_at",
		label: "Added",
		sortValue: (key) => key.createdAt,
		cell: (key) => /* @__PURE__ */ jsx("time", {
			dateTime: key.createdAt,
			className: "whitespace-nowrap text-xs text-muted-foreground",
			children: formatDate(key.createdAt, "MMM D, YYYY HH:mm")
		}),
		headerClassName: "hidden lg:table-cell w-40",
		cellClassName: "hidden lg:table-cell w-40"
	},
	{
		id: "actions",
		label: /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "Actions"
		}),
		cell: (key) => /* @__PURE__ */ jsx(RowActions, { children: /* @__PURE__ */ jsx(DeleteKeyButton, {
			item: key,
			remove
		}) }),
		headerClassName: "w-14 text-right",
		cellClassName: "w-14 text-right"
	}
];
function SshKeyList({ model, className }) {
	const { remove } = model;
	const columns = useMemo(() => sshKeyColumns(remove), [remove]);
	return /* @__PURE__ */ jsx(ContentBox, {
		title: "SSH Keys",
		className,
		children: model.loading ? /* @__PURE__ */ jsx(Spinner, {
			size: "large",
			centered: true
		}) : /* @__PURE__ */ jsx(Table, {
			rows: model.keys,
			columns,
			keyOf: (key) => key.fingerprint,
			emptyState: /* @__PURE__ */ jsx(Empty, {
				size: "compact",
				children: /* @__PURE__ */ jsxs(EmptyHeader, { children: [
					/* @__PURE__ */ jsx(EmptyMedia, {
						variant: "icon",
						children: /* @__PURE__ */ jsx(KeySquare, {})
					}),
					/* @__PURE__ */ jsx(EmptyTitle, { children: "No SSH keys" }),
					/* @__PURE__ */ jsx(EmptyDescription, { children: "Add a public key to sign in to SFTP without a password." })
				] })
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/themes/classic/views/account/SshKeyCreate.tsx
function SshKeyCreate({ model, className }) {
	return /* @__PURE__ */ jsx(ContentBox, {
		title: "Add SSH Key",
		className,
		children: /* @__PURE__ */ jsxs(Form, {
			form: { handleSubmit: model.submit },
			children: [
				/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.submitting }),
				/* @__PURE__ */ jsx("div", {
					className: "mb-6",
					children: /* @__PURE__ */ jsx(TextField, {
						field: model.fields.name,
						label: "SSH Key Name"
					})
				}),
				/* @__PURE__ */ jsx(TextAreaField, {
					field: model.fields.publicKey,
					label: "Public Key",
					rows: 6,
					description: "Enter your public SSH key."
				}),
				/* @__PURE__ */ jsx("div", {
					className: "flex justify-end mt-6",
					children: /* @__PURE__ */ jsx(ButtonWithVariants, {
						type: "submit",
						disabled: !model.canSubmit,
						isLoading: model.submitting,
						children: "Save"
					})
				})
			]
		})
	});
}
//#endregion
export { AccountOverview, ApiKeyCreate, ApiKeyList, ApiKeysPage, EmailCard, PasswordCard, SshKeyCreate, SshKeyList, SshKeysPage, TwoFactorCard };

//# sourceMappingURL=account-DcIvOGRi.js.map