import { A as clientDeleteSshKeyMutation, Gt as implementViews, J as clientListAccountApiKeysQueryKey, S as clientDeleteAccountApiKeyMutation, b as clientCreateSshKeyMutation, dt as clientListSshKeysOptions, f as clientCreateAccountApiKeyMutation, ft as clientListSshKeysQueryKey, q as clientListAccountApiKeysOptions, t as notifyHttpError } from "./notifications-Ebj0Q0Io.js";
import { i as upsertListItem, n as removeListItems } from "./queryData-DzPdESJr.js";
import { n as fixtureField, t as boundField } from "./forms-DcsxfoFI.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useField, useForm, useStore } from "@tanstack/react-form";
//#region ../../resources/scripts/api/account/api-keys/queries.ts
var accountApiKeysQueryOptions = () => clientListAccountApiKeysOptions();
var useAccountApiKeys = () => useQuery(accountApiKeysQueryOptions());
var useCreateAccountApiKey = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateAccountApiKeyMutation(),
		onSuccess: async (created) => {
			await queryClient.cancelQueries({ queryKey: clientListAccountApiKeysQueryKey() });
			queryClient.setQueryData(clientListAccountApiKeysQueryKey(), (current) => upsertListItem(current, created, (key) => key.attributes.identifier === created.attributes.identifier));
			toast.success("API key created");
		},
		onError: (error) => notifyHttpError(error, "Unable to create API key")
	});
};
var useDeleteAccountApiKey = () => {
	const queryClient = useQueryClient();
	const queryKey = clientListAccountApiKeysQueryKey();
	return useMutation({
		...clientDeleteAccountApiKeyMutation(),
		onMutate: async (variables) => {
			await queryClient.cancelQueries({ queryKey });
			const previous = queryClient.getQueryData(queryKey);
			queryClient.setQueryData(queryKey, (current) => removeListItems(current, (key) => key.attributes.identifier === variables.path.identifier));
			return { removed: previous?.data.find((item) => item.attributes.identifier === variables.path.identifier) };
		},
		onSuccess: () => {
			toast.success("API key deleted");
		},
		onSettled: () => {
			if (queryClient.isMutating({ mutationKey: clientDeleteAccountApiKeyMutation().mutationKey }) === 1) return queryClient.invalidateQueries({ queryKey });
			return Promise.resolve();
		},
		onError: (error, _variables, context) => {
			if (context?.removed) {
				const removed = context.removed;
				queryClient.setQueryData(queryKey, (current) => upsertListItem(current, removed, (item) => item.attributes.identifier === removed.attributes.identifier));
			}
			notifyHttpError(error, "Unable to delete API key");
		}
	});
};
//#endregion
//#region ../../resources/scripts/api/account/ssh-keys/queries.ts
var accountSshKeysQueryOptions = () => clientListSshKeysOptions();
var useSSHKeys = () => useQuery(accountSshKeysQueryOptions());
var useCreateSSHKey = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateSshKeyMutation(),
		onSuccess: async (key) => {
			await queryClient.cancelQueries({ queryKey: clientListSshKeysQueryKey() });
			queryClient.setQueryData(clientListSshKeysQueryKey(), (current) => upsertListItem(current, key, (item) => item.attributes.fingerprint === key.attributes.fingerprint));
			toast.success("SSH key created");
		},
		onError: (error) => notifyHttpError(error, "Unable to create SSH key")
	});
};
var useDeleteSSHKey = () => {
	const queryClient = useQueryClient();
	const queryKey = clientListSshKeysQueryKey();
	return useMutation({
		...clientDeleteSshKeyMutation(),
		onMutate: async (variables) => {
			await queryClient.cancelQueries({ queryKey });
			const previous = queryClient.getQueryData(queryKey);
			queryClient.setQueryData(queryKey, (current) => removeListItems(current, (key) => key.attributes.fingerprint === variables.body.fingerprint));
			return { removed: previous?.data.find((item) => item.attributes.fingerprint === variables.body.fingerprint) };
		},
		onSuccess: () => {
			toast.success("SSH key deleted");
		},
		onSettled: () => {
			if (queryClient.isMutating({ mutationKey: clientDeleteSshKeyMutation().mutationKey }) === 1) return queryClient.invalidateQueries({ queryKey });
			return Promise.resolve();
		},
		onError: (error, _variables, context) => {
			if (context?.removed) {
				const removed = context.removed;
				queryClient.setQueryData(queryKey, (current) => upsertListItem(current, removed, (item) => item.attributes.fingerprint === removed.attributes.fingerprint));
			}
			notifyHttpError(error, "Unable to delete SSH key");
		}
	});
};
//#endregion
//#region ../../resources/scripts/views/account/keys.ts
var noop = () => {};
var useApiKeysPageModel = () => pageStatus(useAccountApiKeys());
var useSshKeysPageModel = () => pageStatus(useSSHKeys());
var toApiKeyItem = ({ attributes }) => ({
	identifier: attributes.identifier,
	description: attributes.description,
	allowedIps: attributes.allowed_ips ?? [],
	lastUsedAt: attributes.last_used_at,
	createdAt: attributes.created_at
});
var toSshKeyItem = ({ attributes }) => ({
	name: attributes.name,
	fingerprint: attributes.fingerprint,
	createdAt: attributes.created_at
});
function useApiKeyListModel() {
	const { data } = useAccountApiKeys();
	const { mutateAsync, isPending } = useDeleteAccountApiKey();
	return useMemo(() => ({
		keys: (data?.data ?? []).map(toApiKeyItem),
		loading: !data,
		deleting: isPending,
		remove: (identifier) => mutateAsync({ path: { identifier } }).then(noop, noop)
	}), [
		data,
		isPending,
		mutateAsync
	]);
}
function useApiKeyCreateModel() {
	const [createdKey, setCreatedKey] = useState(null);
	const createApiKey = useCreateAccountApiKey();
	const form = useForm({
		defaultValues: {
			description: "",
			allowedIps: ""
		},
		onSubmit: async ({ value, formApi }) => {
			try {
				const created = await createApiKey.mutateAsync({ body: {
					description: value.description,
					allowed_ips: value.allowedIps.length > 0 ? value.allowedIps.split("\n") : []
				} });
				formApi.reset();
				setCreatedKey(`${created.attributes.identifier}${created.meta?.secret_token ?? ""}`);
			} catch {}
		}
	});
	const description = useField({
		form,
		name: "description",
		validators: { onChange: ({ value }) => value.length >= 4 ? void 0 : "A description of at least 4 characters must be provided." }
	});
	const allowedIps = useField({
		form,
		name: "allowedIps"
	});
	const canSubmit = useStore(form.store, (state) => state.canSubmit);
	const submitting = useStore(form.store, (state) => state.isSubmitting);
	return {
		fields: {
			description: boundField(description, { type: "text" }),
			allowedIps: boundField(allowedIps)
		},
		submit: () => void form.handleSubmit(),
		canSubmit,
		submitting,
		createdKey,
		dismissCreatedKey: () => setCreatedKey(null)
	};
}
function useSshKeyListModel() {
	const { data } = useSSHKeys();
	const { mutateAsync } = useDeleteSSHKey();
	return useMemo(() => ({
		keys: (data?.data ?? []).map(toSshKeyItem),
		loading: !data,
		remove: (fingerprint) => mutateAsync({ body: { fingerprint } }).then(noop, noop)
	}), [data, mutateAsync]);
}
function useSshKeyCreateModel() {
	const createSshKey = useCreateSSHKey();
	const form = useForm({
		defaultValues: {
			name: "",
			publicKey: ""
		},
		onSubmit: async ({ value, formApi }) => {
			try {
				await createSshKey.mutateAsync({ body: {
					name: value.name,
					public_key: value.publicKey
				} });
				formApi.reset();
			} catch {}
		}
	});
	const name = useField({
		form,
		name: "name",
		validators: { onChange: ({ value }) => value.length >= 1 ? void 0 : "A key name must be provided." }
	});
	const publicKey = useField({
		form,
		name: "publicKey",
		validators: { onChange: ({ value }) => value.length >= 1 ? void 0 : "A public key must be provided." }
	});
	const canSubmit = useStore(form.store, (state) => state.canSubmit);
	const submitting = useStore(form.store, (state) => state.isSubmitting);
	return {
		fields: {
			name: boundField(name, { type: "text" }),
			publicKey: boundField(publicKey)
		},
		submit: () => void form.handleSubmit(),
		canSubmit,
		submitting
	};
}
var apiKeys = [{
	identifier: "ptlc_7hX2kQ9vLm",
	description: "Deploy script",
	allowedIps: ["203.0.113.10"],
	lastUsedAt: "2026-10-11T18:24:00Z",
	createdAt: "2026-03-02T09:15:00Z"
}, {
	identifier: "ptlc_c4Rt8bZ1Yw",
	description: "Home Assistant",
	allowedIps: [],
	lastUsedAt: null,
	createdAt: "2026-08-19T21:40:00Z"
}];
var sshKeys = [{
	name: "Laptop",
	fingerprint: "W1kFq9n8Zt2c6Vb0RkM5yXo3sLe7uPj4hAdGiQ",
	createdAt: "2026-02-14T10:05:00Z"
}, {
	name: "Build server",
	fingerprint: "k3Nf8Qz2Lx7Wc1Vy5Rb9Tm4Hs6Ju0Pe2Ga8DiO",
	createdAt: "2026-09-30T16:42:00Z"
}];
var apiKeyListFixture = (overrides = {}) => ({
	keys: apiKeys,
	loading: false,
	deleting: false,
	remove: async () => {},
	...overrides
});
var sshKeyListFixture = (overrides = {}) => ({
	keys: sshKeys,
	loading: false,
	remove: async () => {},
	...overrides
});
var apiKeyCreateFixture = (createdKey = null) => ({
	fields: {
		description: fixtureField("description", { type: "text" }),
		allowedIps: fixtureField("allowedIps")
	},
	submit: noop,
	canSubmit: true,
	submitting: false,
	createdKey,
	dismissCreatedKey: noop
});
implementViews({
	"page.account.api": {
		use: useApiKeysPageModel,
		fixtures: pageStatusFixtures
	},
	"page.account.ssh": {
		use: useSshKeysPageModel,
		fixtures: pageStatusFixtures
	},
	"account.apiKeys.list": {
		use: useApiKeyListModel,
		fixtures: {
			keys: () => apiKeyListFixture(),
			empty: () => apiKeyListFixture({ keys: [] }),
			loading: () => apiKeyListFixture({
				keys: [],
				loading: true
			}),
			deleting: () => apiKeyListFixture({ deleting: true })
		}
	},
	"account.apiKeys.create": {
		use: useApiKeyCreateModel,
		fixtures: {
			default: () => apiKeyCreateFixture(),
			invalid: () => {
				const model = apiKeyCreateFixture();
				return {
					...model,
					fields: {
						...model.fields,
						description: fixtureField("description", { type: "text" }, "ci", "A description of at least 4 characters must be provided.")
					},
					canSubmit: false
				};
			},
			created: () => apiKeyCreateFixture("ptlc_9mQ4rT2xVbN8kLw3Zp7Hy1Jc6Fs0Dg5Ae")
		}
	},
	"account.sshKeys.list": {
		use: useSshKeyListModel,
		fixtures: {
			keys: () => sshKeyListFixture(),
			empty: () => sshKeyListFixture({ keys: [] }),
			loading: () => sshKeyListFixture({
				keys: [],
				loading: true
			})
		}
	},
	"account.sshKeys.create": {
		use: useSshKeyCreateModel,
		fixtures: {
			default: () => ({
				fields: {
					name: fixtureField("name", { type: "text" }),
					publicKey: fixtureField("publicKey")
				},
				submit: noop,
				canSubmit: true,
				submitting: false
			}),
			submitting: () => ({
				fields: {
					name: fixtureField("name", { type: "text" }, "Laptop"),
					publicKey: fixtureField("publicKey", {}, "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMq alex@laptop")
				},
				submit: noop,
				canSubmit: false,
				submitting: true
			})
		}
	}
});
//#endregion

//# sourceMappingURL=keys-Dll_-Z4N.js.map