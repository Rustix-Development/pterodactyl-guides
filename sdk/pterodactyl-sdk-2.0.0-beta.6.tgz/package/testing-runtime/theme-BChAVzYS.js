//#region ../../resources/scripts/lib/theme.ts
var THEME_CHANGE_EVENT = "pterodactyl:theme-change";
var listeners = /* @__PURE__ */ new Set();
var stopWatching;
var frame;
var isStylesheetNode = (node) => node instanceof HTMLStyleElement || node instanceof HTMLLinkElement && node.relList.contains("stylesheet");
var affectsTheme = (mutation) => {
	if (mutation.target === document.documentElement) return mutation.type === "attributes";
	if (mutation.type === "childList") return isStylesheetNode(mutation.target) || [...mutation.addedNodes, ...mutation.removedNodes].some((node) => isStylesheetNode(node));
	return isStylesheetNode(mutation.type === "characterData" ? mutation.target.parentNode : mutation.target);
};
var flush = () => {
	frame = void 0;
	for (const listener of listeners) listener();
};
var schedule = () => {
	frame ??= requestAnimationFrame(flush);
};
var watch = () => {
	const observer = new MutationObserver((mutations) => {
		if (mutations.some(affectsTheme)) schedule();
	});
	observer.observe(document.documentElement, { attributes: true });
	observer.observe(document.head, {
		attributes: true,
		characterData: true,
		childList: true,
		subtree: true
	});
	const onLoad = (event) => {
		if (event.target instanceof Node && isStylesheetNode(event.target)) schedule();
	};
	document.head.addEventListener("load", onLoad, true);
	window.addEventListener(THEME_CHANGE_EVENT, schedule);
	const scheme = window.matchMedia?.("(prefers-color-scheme: dark)");
	scheme?.addEventListener("change", schedule);
	return () => {
		observer.disconnect();
		document.head.removeEventListener("load", onLoad, true);
		window.removeEventListener(THEME_CHANGE_EVENT, schedule);
		scheme?.removeEventListener("change", schedule);
		if (frame !== void 0) {
			cancelAnimationFrame(frame);
			frame = void 0;
		}
	};
};
/** Calls `listener` at most once a frame; a hint, not a diff. */
var onThemeChange = (listener) => {
	listeners.add(listener);
	stopWatching ??= watch();
	return () => {
		listeners.delete(listener);
		if (listeners.size === 0) {
			stopWatching?.();
			stopWatching = void 0;
		}
	};
};
var notifyThemeChange = () => {
	window.dispatchEvent(new Event(THEME_CHANGE_EVENT));
};
var readThemeToken = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
//#endregion
export { onThemeChange as n, readThemeToken as r, notifyThemeChange as t };

//# sourceMappingURL=theme-BChAVzYS.js.map