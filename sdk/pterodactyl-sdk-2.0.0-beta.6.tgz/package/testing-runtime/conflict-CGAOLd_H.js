import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { n as serverConflict } from "./state-CUrz93jS.js";
import { t as useLoadedServer } from "./loadedServer-Bw7lSBA6.js";
import { useMemo } from "react";
//#region ../../resources/scripts/views/server/conflict.ts
function useConflictModel() {
	const kind = serverConflict(useLoadedServer());
	return useMemo(() => ({ kind }), [kind]);
}
implementViews({ "server.conflict": {
	use: useConflictModel,
	fixtures: {
		installing: () => ({ kind: "installing" }),
		suspended: () => ({ kind: "suspended" }),
		maintenance: () => ({ kind: "maintenance" }),
		transferring: () => ({ kind: "transferring" }),
		restoring: () => ({ kind: "restoring-backup" })
	}
} });
//#endregion

//# sourceMappingURL=conflict-CGAOLd_H.js.map