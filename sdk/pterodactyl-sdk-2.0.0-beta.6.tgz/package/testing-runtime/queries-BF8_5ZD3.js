import { r as getBootstrapUser } from "./bootstrap-XdDfwDao.js";
import { Nt as clientGetAccount, Tt as clientUpdateAccountPasswordMutation, t as notifyHttpError, wt as clientUpdateAccountEmailMutation } from "./notifications-Ebj0Q0Io.js";
import "./generated-curw-uY5.js";
import { queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/account/queries.ts
var currentUserQueryKey = ["account", "current-user"];
var getBootstrapCurrentUser = () => {
	const user = getBootstrapUser();
	if (!user) throw new Error("Current user has not been hydrated.");
	return user;
};
/** Keeps the fields the account endpoint does not return. */
var withAccount = (user, { attributes }) => ({
	...user,
	username: attributes.username,
	email: attributes.email,
	language: attributes.language,
	rootAdmin: attributes.admin
});
var currentUserQueryOptions = () => queryOptions({
	queryKey: currentUserQueryKey,
	queryFn: async ({ client, signal }) => {
		const { data } = await clientGetAccount({ signal });
		return withAccount(client.getQueryData(currentUserQueryKey) ?? getBootstrapCurrentUser(), data);
	},
	initialData: getBootstrapCurrentUser,
	staleTime: Infinity
});
var useCurrentUser = () => useQuery(currentUserQueryOptions()).data;
var setCurrentUserQueryData = (queryClient, updater) => {
	queryClient.setQueryData(currentUserQueryKey, (user) => {
		return {
			...user ?? getBootstrapCurrentUser(),
			...updater
		};
	});
};
var useUpdateAccountEmail = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientUpdateAccountEmailMutation(),
		onSuccess: (_data, variables) => {
			setCurrentUserQueryData(queryClient, { email: variables.body.email });
			toast.success("Email address updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update email address")
	});
};
var useUpdateAccountPassword = () => useMutation({
	...clientUpdateAccountPasswordMutation(),
	onSuccess: () => window.location.assign("/auth/login"),
	onError: (error) => notifyHttpError(error, "Unable to update password")
});
//#endregion
export { useUpdateAccountPassword as a, useUpdateAccountEmail as i, setCurrentUserQueryData as n, useCurrentUser as r, currentUserQueryKey as t };

//# sourceMappingURL=queries-BF8_5ZD3.js.map