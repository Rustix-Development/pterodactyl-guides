import { n as useSiteSettings } from "./queries-DXZ7OlB6.js";
import { createContext, createElement, useCallback, useContext, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { toast } from "sonner";
//#region ../../node_modules/@google-recaptcha/react/dist/esm/context/GoogleReCaptchaContext.mjs
var t = "GoogleReCaptcha Context has not yet been implemented, if you are using useGoogleReCaptcha hook, make sure the hook is called inside component wrapped by GoogleRecaptchaProvider", n$2 = createContext({
	instance: void 0,
	siteKey: "",
	language: "",
	isLoading: !0,
	executeV3: () => {
		throw Error(t);
	},
	executeV2Invisible: () => {
		throw Error(t);
	},
	reset: () => {
		throw Error(t);
	},
	getResponse: () => {
		throw Error(t);
	},
	render: () => {
		throw Error(t);
	}
});
//#endregion
//#region ../../node_modules/@google-recaptcha/react/dist/esm/context/useGoogleReCaptcha.mjs
var n$1 = () => useContext(n$2);
//#endregion
//#region ../../node_modules/@google-recaptcha/core/dist/esm/helpers/checkGoogleReCaptchaInjected.mjs
var c = () => !!document.querySelector("script[src*=\"/recaptcha/\"]:not([src*=\"gstatic\"])");
//#endregion
//#region ../../node_modules/@google-recaptcha/core/dist/esm/helpers/generateGoogleReCaptchaHiddenBadgeStyles.mjs
var e$1 = () => ".grecaptcha-badge{display: none !important;}";
//#endregion
//#region ../../node_modules/@google-recaptcha/core/dist/esm/helpers/generateGoogleReCaptchaScriptSrc.mjs
var n = ({ host: t = "google.com", isEnterprise: c = !1, render: s, hl: e, badge: r }) => {
	const a = new URLSearchParams({
		...e && { hl: e },
		...r && { badge: r },
		render: s
	});
	return `https://www.${t}/recaptcha/${c ? "enterprise.js" : "api.js"}?${a}`;
};
//#endregion
//#region ../../node_modules/@google-recaptcha/core/dist/esm/helpers/hideGoogleReCaptchaBadge.mjs
var d$1 = () => {
	const e = document.createElement("style");
	e.innerHTML = e$1(), document.body.appendChild(e);
};
//#endregion
//#region ../../node_modules/@google-recaptcha/core/dist/esm/helpers/injectGoogleReCaptchaScript.mjs
var m = ({ onload: e, appendTo: c = "head", isEnterprise: o = !1, host: r, render: a, badge: n$3, hl: p, ...i }) => {
	const s = n({
		host: r,
		isEnterprise: o,
		render: a,
		hl: p,
		badge: n$3
	}), t = document.createElement("script");
	Object.entries(i).forEach(([l, d]) => {
		t.setAttribute(l, d?.toString() ?? "");
	}), t.src = s, t.onload = e, document[c].appendChild(t);
};
//#endregion
//#region ../../node_modules/@google-recaptcha/core/dist/esm/helpers/removeGoogleReCaptchaBadge.mjs
var o$3 = () => {
	const e = document.querySelector(".grecaptcha-badge");
	e && e.parentNode && document.body.removeChild(e.parentNode);
};
//#endregion
//#region ../../node_modules/@google-recaptcha/core/dist/esm/helpers/removeGoogleReCaptchaContainer.mjs
var o$2 = (t) => {
	const e = document.getElementById(t);
	if (e) for (; e.lastChild;) e.lastChild.remove();
};
//#endregion
//#region ../../node_modules/@google-recaptcha/core/dist/esm/helpers/removeGoogleReCaptchaScript.mjs
var e = "https://www.gstatic.com/recaptcha/releases", o$1 = () => {
	window.___grecaptcha_cfg = void 0;
	const c = document.querySelector("script[src*=\"/recaptcha/\"]:not([src*=\"gstatic\"])");
	c && c.remove();
	const t = document.querySelector(`script[src^="${e}"]`);
	t && t.remove();
};
//#endregion
//#region ../../node_modules/@google-recaptcha/react/dist/esm/components/GoogleReCaptchaBadge.mjs
var a = "google-recaptcha-badge-container", o = ({ id: o = a, theme: s, language: c, badge: l = "bottomright", onChange: u, onError: d, onExpired: f }) => {
	let p = useRef(null), m = n$1(), h = s ?? m.theme, g = c ?? m.language;
	return useEffect(() => {
		if (!m.render) return;
		let e = document.createElement("div"), n = {
			sitekey: m.siteKey,
			badge: l,
			size: "invisible",
			callback: u,
			"expired-callback": f,
			"error-callback": d,
			theme: h,
			...g && { hl: g }
		};
		return m.render(e, n), p.current && p.current.appendChild(e), () => {
			o$2(o);
		};
	}, [
		m.render,
		m.siteKey,
		l,
		u,
		d,
		f,
		h,
		g
	]), !m.render || !m.siteKey ? null : /* @__PURE__ */ jsx("div", {
		ref: p,
		id: o
	});
};
//#endregion
//#region ../../node_modules/@google-recaptcha/react/dist/esm/context/GoogleReCaptchaProvider.mjs
var d = "onGoogleReCaptchaLoad", f = "google-recaptcha-container", p = ({ type: p, siteKey: m$1, language: h, scriptProps: g, isEnterprise: _ = !1, host: v, theme: y = "light", children: b, explicit: x, onLoad: S, onError: C }) => {
	let [w, T] = useState(!0), [E, D] = useState();
	useEffect(() => {
		let e = g?.id ?? `google-recaptcha-${p}-script`, s = c();
		try {
			let c$1 = () => {
				T(!0);
				let e = _ ? window.grecaptcha?.enterprise : window.grecaptcha;
				if (!e) {
					C?.(), T(!1);
					return;
				}
				if (x || e.ready(async () => {
					D(e), await S?.(e), T(!1);
				}), x) {
					let t = {
						size: p === "v3" || p === "v2-invisible" ? "invisible" : "normal",
						...(p === "v3" || p === "v2-invisible") && { badge: "bottomright" },
						sitekey: m$1,
						theme: y,
						...typeof x == "object" && {
							...x,
							"expired-callback": x.expiredCallback,
							"error-callback": x.errorCallback
						}
					};
					s || typeof x == "object" && (p === "v3" || p === "v2-invisible") && x?.badge === "hidden" && d$1(), e.ready(async () => {
						typeof x == "object" && x.container && e.render(x.container, t, !!x.inherit), D(e), S && await S(e), T(!1);
					});
				}
			};
			return window[d] = c$1, s ? c$1() : m({
				isEnterprise: _,
				host: v,
				...(p === "v3" || p === "v2-invisible") && typeof x == "object" && x?.badge && { badge: x?.badge === "hidden" ? "bottomright" : x?.badge },
				...h && { hl: h },
				render: x || p === "v2-checkbox" ? "explicit" : m$1,
				...g,
				onload: c$1,
				id: e
			}), () => {
				c() && o$1(), typeof x == "object" && (p === "v3" || p === "v2-invisible") && !x?.container && x?.badge ? o$2(f) : o$3();
			};
		} catch {
			T(!1);
		}
	}, [
		_,
		h,
		v,
		m$1,
		p
	]);
	let O = (e) => {
		if (!E?.execute) throw Error("Google ReCaptcha has not been loaded");
		return E.execute(m$1, { action: e });
	}, k = (e) => {
		if (!E?.execute) throw Error("Google ReCaptcha has not been loaded");
		return E.execute(e);
	}, A = useMemo(() => ({
		instance: E,
		siteKey: m$1,
		isLoading: w,
		theme: y,
		executeV2Invisible: k,
		executeV3: O,
		reset: E?.reset,
		getResponse: E?.getResponse,
		render: E?.render,
		...h && { language: h }
	}), [
		E,
		m$1,
		w,
		h
	]);
	return /* @__PURE__ */ jsx(n$2.Provider, {
		value: A,
		children: b
	});
};
//#endregion
//#region ../../resources/scripts/components/elements/InvisibleRecaptcha.tsx
var EXECUTE_TIMEOUT_MS = 12e4;
var DISMISS_GRACE_MS = 1e3;
var CHALLENGE_FRAME_SELECTOR = "iframe[src*=\"/recaptcha/api2/bframe\"], iframe[src*=\"/recaptcha/enterprise/bframe\"]";
var readResponse = (instance) => {
	try {
		return instance.getResponse() || null;
	} catch {
		return null;
	}
};
var resetWidget = (instance) => {
	try {
		instance.reset();
	} catch {}
};
/** Calls `onDismiss` once the reCAPTCHA challenge popup hides after being shown. */
function watchChallengeDismissal(onDismiss) {
	let shown = false;
	let graceTimeout;
	const check = () => {
		const popup = document.querySelector(CHALLENGE_FRAME_SELECTOR)?.parentElement?.parentElement;
		if (!popup) return;
		if (popup.style.visibility === "visible") {
			shown = true;
			window.clearTimeout(graceTimeout);
			graceTimeout = void 0;
		} else if (shown && graceTimeout === void 0) graceTimeout = window.setTimeout(onDismiss, DISMISS_GRACE_MS);
	};
	const observer = new MutationObserver(check);
	observer.observe(document.body, {
		subtree: true,
		childList: true,
		attributes: true,
		attributeFilter: ["style"]
	});
	return () => {
		observer.disconnect();
		window.clearTimeout(graceTimeout);
	};
}
var RecaptchaBridge = ({ ref }) => {
	const { instance, isLoading } = n$1();
	const pendingRef = useRef(null);
	const settle = useCallback((token) => {
		const pending = pendingRef.current;
		pendingRef.current = null;
		pending?.finish();
		pending?.resolve(token);
	}, []);
	const onChange = useCallback((token) => settle(token || null), [settle]);
	const onExpired = useCallback(() => settle(null), [settle]);
	const onError = useCallback(() => settle(null), [settle]);
	useEffect(() => () => settle(null), [settle]);
	useImperativeHandle(ref, () => ({ execute: () => new Promise((resolve) => {
		settle(null);
		if (isLoading || !instance) {
			resolve(null);
			return;
		}
		const timeout = window.setTimeout(() => settle(null), EXECUTE_TIMEOUT_MS);
		const stopWatching = watchChallengeDismissal(() => settle(readResponse(instance)));
		pendingRef.current = {
			resolve,
			finish: () => {
				window.clearTimeout(timeout);
				stopWatching();
				resetWidget(instance);
			}
		};
		try {
			Promise.resolve(instance.execute()).catch(() => settle(null));
		} catch {
			settle(null);
		}
	}) }), [
		instance,
		isLoading,
		settle
	]);
	return /* @__PURE__ */ jsx(o, {
		onChange,
		onError,
		onExpired
	});
};
RecaptchaBridge.displayName = "RecaptchaBridge";
/** Invisible reCAPTCHA v2; call `ref.execute()` to obtain a token. */
var InvisibleRecaptcha = ({ siteKey, ref }) => /* @__PURE__ */ jsx(p, {
	type: "v2-invisible",
	siteKey: siteKey || "_invalid_key",
	children: /* @__PURE__ */ jsx(RecaptchaBridge, { ref })
});
InvisibleRecaptcha.displayName = "InvisibleRecaptcha";
//#endregion
//#region ../../resources/scripts/views/auth/captcha.ts
function captchaLeaf(ref, siteKey) {
	return function Captcha() {
		return createElement(InvisibleRecaptcha, {
			ref,
			siteKey
		});
	};
}
function useCaptcha() {
	const ref = useRef(null);
	const { enabled, siteKey } = useSiteSettings().recaptcha;
	return {
		Captcha: useMemo(() => enabled ? captchaLeaf(ref, siteKey || "") : null, [enabled, siteKey]),
		token: useCallback(async () => {
			if (!enabled) return "";
			const value = await ref.current?.execute() ?? "";
			if (!value) {
				toast.error("Captcha verification failed, please try again.");
				return null;
			}
			return value;
		}, [enabled])
	};
}
//#endregion
export { useCaptcha as t };

//# sourceMappingURL=captcha-BRyXUbvn.js.map