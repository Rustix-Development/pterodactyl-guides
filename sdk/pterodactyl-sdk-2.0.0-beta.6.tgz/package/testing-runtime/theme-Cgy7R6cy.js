import { t as cn$1 } from "./cn-f7uEsK4g.js";
import { f as ErrorBoundary } from "./Button-BzlrfY24.js";
import { Ht as getViewChain, Kt as isViewComponent, Xt as useViewChain, Zt as useViewDefinition, qt as loadViewImplementation } from "./notifications-Ebj0Q0Io.js";
import { d as ExtensionMount } from "./navigation-DAcCRZlc.js";
import { C as useExtensionRegistry, S as subscribeExtensionRegistry, _ as getViewOverride, g as getSlotComponents, m as getExtensionLoadState, v as getViewOwners, x as reportExtensionError } from "./navigation-9aP-0Hbq.js";
import { n as onThemeChange$1, r as readThemeToken$1, t as notifyThemeChange$1 } from "./theme-BChAVzYS.js";
import { createContext, createElement, use, useCallback, useContext, useEffect, useMemo, useState, useSyncExternalStore } from "react";
import "@tanstack/react-router";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
//#region ../../resources/scripts/views/pageTitle.ts
var listeners = /* @__PURE__ */ new Set();
var current;
var read = () => current ?? document.title;
/** Titles the document; `PageContentBlock` and `ServerContentBlock` call it with their `title`. */
function setPageTitle(title) {
	current = title;
	document.title = title;
	for (const listener of listeners) listener();
}
function subscribe(listener) {
	listeners.add(listener);
	return () => {
		listeners.delete(listener);
	};
}
/** The document title the page on show set, such as "Survival | Console", for a shell to show in its own bar. */
function usePageTitle() {
	return useSyncExternalStore(subscribe, read, read);
}
//#endregion
//#region ../../resources/scripts/extensions/slotWatch.ts
/** How many `<Slot>`s and views of each name are mounted. */
var mounted = /* @__PURE__ */ new Map();
var mountedViewNames = /* @__PURE__ */ new Map();
var watched = /* @__PURE__ */ new Set();
var warned = /* @__PURE__ */ new Set();
var timer;
var unsubscribe;
/** Lazy layers and extension bundles mount after the first render, so the check waits for them. */
var SLOT_CHECK_DELAY_MS = 3e3;
var quoted = (names) => names.map((name) => `"${name}"`).join(" and ");
function check() {
	timer = void 0;
	for (const { view, layers, slots } of watched) for (const slot of slots) {
		const owners = [...new Set(getSlotComponents(slot).map(({ extensionId }) => extensionId))];
		const key = `${layers.join()}|${view}|${slot}`;
		if (!owners.length || (mounted.get(slot) ?? 0) > 0 || warned.has(key)) continue;
		warned.add(key);
		const subject = layers.length > 1 ? `${quoted(layers)} layers` : `${quoted(layers)} layer`;
		const verb = layers.length > 1 ? "do" : "does";
		console.warn(`[views] The ${subject} of "${view}" ${verb} not render the "${slot}" slot, so ${quoted(owners)} does not show there.`);
	}
}
function schedule() {
	if (watched.size) {
		clearTimeout(timer);
		timer = setTimeout(check, SLOT_CHECK_DELAY_MS);
	}
}
function count(counts, name) {
	counts.set(name, (counts.get(name) ?? 0) + 1);
	schedule();
	return () => {
		counts.set(name, (counts.get(name) ?? 1) - 1);
		schedule();
	};
}
var positive = (counts) => new Set([...counts].filter(([, total]) => total > 0).map(([name]) => name));
/** Counts a mounted `<Slot>`; returns its removal. */
var slotMounted = (name) => count(mounted, name);
/** Counts a mounted view; returns its removal. */
var viewMounted = (name) => count(mountedViewNames, name);
/** The names of the slots mounted right now. */
var mountedSlots = () => positive(mounted);
/** The names of the views mounted right now. */
var mountedViews = () => positive(mountedViewNames);
/**
* Warns, once per slot, when a view whose layers above classic leave out one of its slots has components
* registered there, which would otherwise look like the extension failed. Returns its removal.
*/
function watchViewSlots(view, layers, slots) {
	const entry = {
		view,
		layers,
		slots
	};
	watched.add(entry);
	unsubscribe ??= subscribeExtensionRegistry(schedule);
	schedule();
	return () => {
		watched.delete(entry);
		if (!watched.size) {
			unsubscribe?.();
			unsubscribe = void 0;
			clearTimeout(timer);
			timer = void 0;
		}
	};
}
//#endregion
//#region ../../resources/scripts/views/session.tsx
var VIEW_LOAD_TIMEOUT_MS = 5e3;
var loading = Object.freeze({ status: "loading" });
var noLayers = Object.freeze({
	status: "ready",
	layers: Object.freeze([])
});
/** Settles once per view name which extension layers it shows; a late bundle cannot replace a committed view. */
function createViewSession() {
	const decisions = /* @__PURE__ */ new Map();
	const listeners = /* @__PURE__ */ new Map();
	const pending = /* @__PURE__ */ new Map();
	const imports = /* @__PURE__ */ new Map();
	const snapshot = (name) => {
		let decision = decisions.get(name);
		if (!decision) {
			decision = getViewOwners(name).length ? loading : noLayers;
			decisions.set(name, decision);
		}
		return decision;
	};
	const importLayer = (extensionId, name) => {
		const override = getViewOverride(extensionId, name);
		if (!override) return null;
		const key = `${extensionId}:${name}`;
		let imported = imports.get(key);
		if (!imported) {
			imported = Promise.resolve().then(async () => {
				const component = "load" in override ? (await override.load()).default : override;
				if (!isViewComponent(component)) throw new Error("The view importer must return a default React component.");
				return {
					id: extensionId,
					source: "extension",
					component
				};
			});
			imports.set(key, imported);
		}
		return imported;
	};
	const start = (name) => {
		if (snapshot(name).status !== "loading" || pending.has(name)) return;
		const owners = getViewOwners(name);
		const settled = /* @__PURE__ */ new Map();
		const started = /* @__PURE__ */ new Set();
		let active = true;
		let unsubscribe = () => {};
		let timer;
		const stop = () => {
			active = false;
			clearTimeout(timer);
			unsubscribe();
			pending.delete(name);
		};
		const settle = () => {
			stop();
			decisions.set(name, {
				status: "ready",
				layers: Object.freeze(owners.flatMap((owner) => settled.get(owner) ?? []))
			});
			for (const listener of listeners.get(name) ?? []) listener();
		};
		const resolve = (owner, layer) => {
			if (!active) return;
			settled.set(owner, layer);
			if (settled.size === owners.length) settle();
		};
		timer = setTimeout(() => {
			for (const owner of owners.filter((candidate) => !settled.has(candidate))) reportExtensionError(owner, `view "${name}"`, /* @__PURE__ */ new Error(`View loading exceeded ${VIEW_LOAD_TIMEOUT_MS}ms; the layer below is kept until this page is reopened.`));
			settle();
		}, VIEW_LOAD_TIMEOUT_MS);
		const check = () => {
			for (const owner of owners.filter((candidate) => !started.has(candidate))) {
				const status = getExtensionLoadState(owner)?.status;
				if (status === "failed") {
					started.add(owner);
					resolve(owner, null);
				} else if (status === "loaded") {
					started.add(owner);
					const imported = importLayer(owner, name);
					if (!imported) {
						resolve(owner, null);
						continue;
					}
					imported.then((layer) => resolve(owner, layer), (error) => {
						if (active) reportExtensionError(owner, `view "${name}"`, error);
						resolve(owner, null);
					});
				}
			}
		};
		pending.set(name, stop);
		unsubscribe = subscribeExtensionRegistry(check);
		check();
	};
	return {
		snapshot,
		subscribe(name, listener) {
			const subscribers = listeners.get(name) ?? /* @__PURE__ */ new Set();
			subscribers.add(listener);
			listeners.set(name, subscribers);
			start(name);
			return () => {
				subscribers.delete(listener);
				if (subscribers.size === 0) {
					listeners.delete(name);
					pending.get(name)?.();
				}
			};
		}
	};
}
var ViewSessionContext = createContext(null);
function useViewDecision(name) {
	const shared = useContext(ViewSessionContext);
	const [local] = useState(createViewSession);
	const session = shared ?? local;
	return useSyncExternalStore(useCallback((listener) => session.subscribe(name, listener), [session, name]), useCallback(() => session.snapshot(name), [session, name]));
}
//#endregion
//#region ../../resources/scripts/views/View.tsx
var noop = () => {};
var FixtureContext = createContext(null);
/** Views below read their model from fixtures instead of running their hook, so they render without a backend. */
function ViewFixtureProvider({ fixtures, models, children }) {
	const value = useMemo(() => ({
		fixtures,
		models
	}), [fixtures, models]);
	return /* @__PURE__ */ jsx(FixtureContext.Provider, {
		value,
		children
	});
}
/**
* A view's model from fixtures: an explicit model, the chosen fixture, the model its inputs give (a card
* placed for each server of a list), or its first fixture.
*/
function fixtureModel(definition, selection, inputs) {
	const models = new Map(Object.entries(selection.models ?? {}));
	if (models.has(definition.name)) return { model: models.get(definition.name) };
	const fixtures = new Map(Object.entries(definition.fixtures ?? {}));
	const chosen = new Map(Object.entries(selection.fixtures ?? {})).get(definition.name);
	if (chosen === void 0 && definition.fixtureFromInput && Object.keys(inputs).length) return { model: definition.fixtureFromInput(inputs) };
	const factory = chosen === void 0 ? [...fixtures.values()][0] : fixtures.get(chosen);
	if (chosen !== void 0 && !factory) throw new Error(`View "${definition.name}" has no fixture "${chosen}".`);
	return factory ? { model: factory() } : void 0;
}
/**
* Each level owns a context, so its `Default` keeps one identity across renders and finds this level
* even when rendered inside another view.
*/
function createLevel() {
	const Context = createContext(null);
	function Default({ model, className, children }) {
		const level = useContext(Context);
		if (!level) throw new Error("Render Default inside the view layer that received it.");
		const { frame } = level;
		return /* @__PURE__ */ jsx(ViewChain, {
			name: level.name,
			layers: level.below,
			placeholder: level.placeholder,
			frame: {
				model: model ?? frame.model,
				inputs: frame.inputs,
				className: cn$1(frame.className, className) || void 0,
				children: children ?? frame.children
			}
		});
	}
	return {
		Context,
		Default
	};
}
/** A failing layer is reported against its package and replaced by the layer below. */
function LayerBoundary({ name, layer, placeholder, below, children }) {
	return /* @__PURE__ */ jsx(ExtensionMount, {
		extensionId: layer.id,
		context: `view "${name}"`,
		resetKey: name,
		loading: placeholder,
		failure: (_error, retry) => /* @__PURE__ */ jsx(ErrorBoundary, {
			onReset: retry,
			children: below
		}),
		children
	});
}
/**
* Watches the slots of a view whose top layer is a theme's or an extension's. It renders beside that
* layer, so its effect runs once the layer has rendered, never while the view shows its placeholder.
*/
function SlotWatcher({ view, owners, slots }) {
	useEffect(() => watchViewSlots(view, owners.split(","), slots), [
		view,
		owners,
		slots
	]);
	return null;
}
function ViewChain({ name, layers, frame, placeholder, watcher }) {
	const [level] = useState(createLevel);
	const below = useMemo(() => layers.slice(0, -1), [layers]);
	const value = useMemo(() => ({
		name,
		below,
		frame,
		placeholder
	}), [
		name,
		below,
		frame,
		placeholder
	]);
	const top = layers.at(-1);
	if (!top) return null;
	const props = {
		...frame.inputs,
		model: frame.model,
		className: frame.className,
		children: frame.children,
		Default: level.Default
	};
	const element = createElement(top.component, props);
	return /* @__PURE__ */ jsx(level.Context.Provider, {
		value,
		children: top.source === "classic" ? element : /* @__PURE__ */ jsxs(LayerBoundary, {
			name,
			layer: top,
			placeholder,
			below: /* @__PURE__ */ jsx(ViewChain, {
				name,
				layers: below,
				frame,
				placeholder
			}),
			children: [element, watcher]
		})
	});
}
function ViewBody({ definition, model, inputs, className, children }) {
	const base = useViewChain(definition.name);
	const decision = useViewDecision(definition.name);
	const layers = useMemo(() => decision.status === "ready" && decision.layers.length ? [...base, ...decision.layers] : base, [base, decision]);
	const placeholder = definition.placeholder ?? null;
	const owners = layers.flatMap(({ id, source }) => source === "classic" ? [] : [id]).join(",");
	useEffect(() => viewMounted(definition.name), [definition.name]);
	if (decision.status === "loading") return placeholder;
	if (!layers.length) throw new Error(`View "${definition.name}" has no implementation.`);
	return /* @__PURE__ */ jsx(ViewChain, {
		name: definition.name,
		layers,
		placeholder,
		frame: {
			model,
			inputs,
			className,
			children
		},
		watcher: owners && definition.slots?.length ? /* @__PURE__ */ jsx(SlotWatcher, {
			view: definition.name,
			owners,
			slots: definition.slots
		}) : void 0
	});
}
function LiveView({ use: useModel, ...props }) {
	return /* @__PURE__ */ jsx(ViewBody, {
		...props,
		model: useModel(props.inputs)
	});
}
/** Loads a view's implementation and the chunks of its lazy layers, so the router waits for them like a route chunk. */
async function preloadView(name) {
	await Promise.all([loadViewImplementation(name), ...getViewChain(name).map(({ source, component }) => {
		if (!("preload" in component) || !(component.preload instanceof Function)) return null;
		const loading = Promise.resolve(component.preload());
		return source === "classic" ? loading : loading.catch(noop);
	})]);
}
function RenderView({ name, className, children, ...inputs }) {
	const definition = useViewDefinition(name);
	const selection = useContext(FixtureContext);
	if (!definition) throw new Error(`View "${name}" is not defined.`);
	const loading = loadViewImplementation(name);
	if (loading) {
		if (!definition.use) preloadView(name).catch(noop);
		use(loading);
	}
	if (!definition.use) throw new Error(`View "${name}" is not implemented by the module its definition loads.`);
	const fixture = selection ? fixtureModel(definition, selection, inputs) : void 0;
	if (!fixture) return /* @__PURE__ */ jsx(LiveView, {
		definition,
		use: definition.use,
		inputs,
		className,
		children
	}, name);
	return /* @__PURE__ */ jsx(ViewBody, {
		definition,
		inputs: {
			...definition.fixtureInput?.(fixture.model),
			...inputs
		},
		className,
		model: fixture.model,
		children
	});
}
/**
* Renders a view: runs its hook once (or reads a fixture), resolves classic, the theme chain and
* extension overrides, and renders the top layer with `{ model, Default, ...inputs, children }`.
*/
var View = RenderView;
//#endregion
//#region ../../resources/scripts/views/a11y.tsx
var InsideMain = createContext(false);
/**
* The routed content of a layout and the target of the skip link. Layouts nest, so only the
* outermost renders the `<main>` element; a nested one with a `className` renders a `<div>` with it.
*/
function Main({ className, children }) {
	if (useContext(InsideMain)) return className ? /* @__PURE__ */ jsx("div", {
		className,
		children
	}) : children;
	return /* @__PURE__ */ jsx(InsideMain.Provider, {
		value: true,
		children: /* @__PURE__ */ jsx("main", {
			id: "main",
			tabIndex: -1,
			className: cn$1("outline-none", className),
			children
		})
	});
}
//#endregion
//#region ../../resources/scripts/extensions/Slot.tsx
function slotResetKey(name, data) {
	if (!data) return name;
	if ("resource" in data) return `${data.kind}:${data.resource.attributes.id}`;
	if ("directory" in data) return `${data.server.attributes.uuid}:${data.directory}`;
	if ("attributes" in data) return data.attributes.uuid;
	if ("pathname" in data) return data.pathname;
	return name;
}
function Slot({ name, data, compact }) {
	const registrations = useExtensionRegistry(() => getSlotComponents(name));
	const resetKey = slotResetKey(name, data);
	useEffect(() => slotMounted(name), [name]);
	return /* @__PURE__ */ jsx(Fragment$1, { children: registrations.map(({ id, extensionId, component: Component }) => /* @__PURE__ */ jsx(ExtensionMount, {
		isSlot: true,
		extensionId,
		context: `slot "${name}"`,
		resetKey,
		children: /* @__PURE__ */ jsx(Component, {
			data,
			compact
		})
	}, id)) });
}
//#endregion
//#region ../../resources/scripts/sdk/theme.ts
/**
* Calls `listener`, at most once a frame, after a stylesheet or an `<html>` attribute changes.
* It is a hint, not a diff: compare the values you read. Returns the unsubscribe function.
*/
function onThemeChange(listener) {
	return onThemeChange$1(listener);
}
/** Report a token change the DOM cannot reveal (CSSOM rule edits, adopted stylesheets). */
function notifyThemeChange() {
	notifyThemeChange$1();
}
/** The current value of a token on `<html>`, e.g. `readThemeToken('--chart-1')`; '' when unset. */
function readThemeToken(name) {
	return readThemeToken$1(name);
}
/** Joins class names; a later Tailwind utility replaces an earlier one of the same kind: `cn('px-3', 'px-4')` is `px-4`. */
function cn(...classes) {
	return cn$1(...classes);
}
//#endregion
export { Slot as a, View as c, mountedSlots as d, mountedViews as f, readThemeToken as i, ViewFixtureProvider as l, usePageTitle as m, notifyThemeChange as n, Main as o, setPageTitle as p, onThemeChange as r, RenderView as s, cn as t, preloadView as u };

//# sourceMappingURL=theme-Cgy7R6cy.js.map