import React, { createContext, use, useEffect, useMemo, useState } from "react";
import { useLocation } from "@tanstack/react-router";
import { jsx } from "react/jsx-runtime";
//#region ../../node_modules/pathe/dist/shared/pathe.M-eThtNZ.mjs
var _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
	if (!input) return input;
	return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
var _UNC_REGEX = /^[/\\]{2}/;
var _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
var _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
var normalize = function(path) {
	if (path.length === 0) return ".";
	path = normalizeWindowsPath(path);
	const isUNCPath = path.match(_UNC_REGEX);
	const isPathAbsolute = isAbsolute(path);
	const trailingSeparator = path[path.length - 1] === "/";
	path = normalizeString(path, !isPathAbsolute);
	if (path.length === 0) {
		if (isPathAbsolute) return "/";
		return trailingSeparator ? "./" : ".";
	}
	if (trailingSeparator) path += "/";
	if (_DRIVE_LETTER_RE.test(path)) path += "/";
	if (isUNCPath) {
		if (!isPathAbsolute) return `//./${path}`;
		return `//${path}`;
	}
	return isPathAbsolute && !isAbsolute(path) ? `/${path}` : path;
};
var join = function(...segments) {
	let path = "";
	for (const seg of segments) {
		if (!seg) continue;
		if (path.length > 0) {
			const pathTrailing = path[path.length - 1] === "/";
			const segLeading = seg[0] === "/";
			if (pathTrailing && segLeading) path += seg.slice(1);
			else path += pathTrailing || segLeading ? seg : `/${seg}`;
		} else path += seg;
	}
	return normalize(path);
};
function normalizeString(path, allowAboveRoot) {
	let res = "";
	let lastSegmentLength = 0;
	let lastSlash = -1;
	let dots = 0;
	let char = null;
	for (let index = 0; index <= path.length; ++index) {
		if (index < path.length) char = path[index];
		else if (char === "/") break;
		else char = "/";
		if (char === "/") {
			if (lastSlash === index - 1 || dots === 1);
			else if (dots === 2) {
				if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
					if (res.length > 2) {
						const lastSlashIndex = res.lastIndexOf("/");
						if (lastSlashIndex === -1) {
							res = "";
							lastSegmentLength = 0;
						} else {
							res = res.slice(0, lastSlashIndex);
							lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
						}
						lastSlash = index;
						dots = 0;
						continue;
					} else if (res.length > 0) {
						res = "";
						lastSegmentLength = 0;
						lastSlash = index;
						dots = 0;
						continue;
					}
				}
				if (allowAboveRoot) {
					res += res.length > 0 ? "/.." : "..";
					lastSegmentLength = 2;
				}
			} else {
				if (res.length > 0) res += `/${path.slice(lastSlash + 1, index)}`;
				else res = path.slice(lastSlash + 1, index);
				lastSegmentLength = index - lastSlash - 1;
			}
			lastSlash = index;
			dots = 0;
		} else if (char === "." && dots !== -1) ++dots;
		else dots = -1;
	}
	return res;
}
var isAbsolute = function(p) {
	return _IS_ABSOLUTE_RE.test(p);
};
//#endregion
//#region ../../resources/scripts/helpers.ts
var cleanDirectoryPath = (path) => path.replaceAll(/(\/(\/*))|(^$)/g, "/");
function fileBitsToString(mode, directory) {
	const m = parseInt(mode, 8);
	let buf = "";
	for (const [i, c] of [..."dalTLDpSugct?"].entries()) if ((m & 1 << 31 - i) !== 0) buf += c;
	if (buf.length === 0) buf = directory ? "d" : "-";
	for (const [i, c] of [..."rwxrwxrwx"].entries()) buf += (m & 1 << 8 - i) === 0 ? "-" : c;
	return buf;
}
function encodePathSegments(path) {
	return path.split("/").map((s) => encodeURIComponent(s)).join("/");
}
function hashToPath(hash) {
	const segments = decodeURIComponent(hash.replace(/^#/, "")).split("/").filter(Boolean);
	return segments.length > 0 ? `/${segments.join("/")}` : "/";
}
/** Strips leading "../" and "/" segments. */
var normalizeServerPath = (path) => normalize(path).replace(/^(\.\.\/|\/)+/, "");
/** The name a newly created directory appears under in its parent's file list. */
var newDirectoryDisplayName = (name) => normalizeServerPath(name).split("/", 1)[0] || name;
//#endregion
//#region ../../node_modules/zustand/esm/vanilla.mjs
var createStoreImpl = (createState) => {
	let state;
	const listeners = /* @__PURE__ */ new Set();
	const setState = (partial, replace) => {
		const nextState = typeof partial === "function" ? partial(state) : partial;
		if (!Object.is(nextState, state)) {
			const previousState = state;
			state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
			listeners.forEach((listener) => listener(state, previousState));
		}
	};
	const getState = () => state;
	const getInitialState = () => initialState;
	const subscribe = (listener) => {
		listeners.add(listener);
		return () => listeners.delete(listener);
	};
	const api = {
		setState,
		getState,
		getInitialState,
		subscribe
	};
	const initialState = state = createState(setState, getState, api);
	return api;
};
var createStore = ((createState) => createState ? createStoreImpl(createState) : createStoreImpl);
//#endregion
//#region ../../node_modules/zustand/esm/react.mjs
var identity = (arg) => arg;
function useStore(api, selector = identity) {
	const slice = React.useSyncExternalStore(api.subscribe, React.useCallback(() => selector(api.getState()), [api, selector]), React.useCallback(() => selector(api.getInitialState()), [api, selector]));
	React.useDebugValue(slice);
	return slice;
}
//#endregion
//#region ../../resources/scripts/state/server/socket.ts
var createSocket = (set) => ({
	instance: null,
	connected: false,
	reconnecting: false,
	setInstance: (payload) => set((state) => ({ socket: {
		...state.socket,
		instance: payload
	} })),
	setConnectionState: (payload) => set((state) => ({ socket: {
		...state.socket,
		connected: payload
	} })),
	setReconnecting: (payload) => set((state) => ({ socket: {
		...state.socket,
		reconnecting: payload
	} }))
});
//#endregion
//#region ../../resources/scripts/state/server/files.ts
var withoutUpload = (uploads, id) => {
	const { [id]: _removed, ...rest } = uploads;
	return rest;
};
var createFiles = (set, get) => ({
	selectedDirectory: null,
	selectedFiles: [],
	uploads: {},
	clearSelectedFiles: () => set((state) => ({ files: {
		...state.files,
		selectedDirectory: null,
		selectedFiles: []
	} })),
	setSelectedFiles: ({ directory, files }) => set((state) => ({ files: {
		...state.files,
		selectedDirectory: directory,
		selectedFiles: files
	} })),
	appendSelectedFile: ({ directory, name }) => set((state) => ({ files: {
		...state.files,
		selectedDirectory: directory,
		selectedFiles: state.files.selectedDirectory === directory ? [...state.files.selectedFiles.filter((file) => file !== name), name] : [name]
	} })),
	removeSelectedFile: ({ directory, name }) => set((state) => ({ files: {
		...state.files,
		selectedDirectory: directory,
		selectedFiles: state.files.selectedDirectory === directory ? state.files.selectedFiles.filter((file) => file !== name) : []
	} })),
	clearFileUploads: () => {
		for (const upload of Object.values(get().files.uploads)) upload.abort.abort();
		set((state) => ({ files: {
			...state.files,
			uploads: {}
		} }));
	},
	pushFileUpload: ({ id, data }) => set((state) => ({ files: {
		...state.files,
		uploads: {
			...state.files.uploads,
			[id]: data
		}
	} })),
	setUploadProgress: ({ id, loaded }) => set((state) => {
		const upload = state.files.uploads[id];
		if (!upload) return state;
		return { files: {
			...state.files,
			uploads: {
				...state.files.uploads,
				[id]: {
					...upload,
					loaded
				}
			}
		} };
	}),
	removeFileUpload: (id) => set((state) => {
		if (!state.files.uploads[id]) return state;
		return { files: {
			...state.files,
			uploads: withoutUpload(state.files.uploads, id)
		} };
	}),
	cancelFileUpload: (id) => {
		const upload = get().files.uploads[id];
		if (upload) {
			upload.abort.abort();
			set((state) => ({ files: {
				...state.files,
				uploads: withoutUpload(state.files.uploads, id)
			} }));
		}
	}
});
//#endregion
//#region ../../resources/scripts/components/server/console/chart.ts
var CHART_WINDOW_MS = 2e4;
var RETAIN_MS = 22e3;
/** A sample value as the graphs plot it. */
var chartValue = (value) => Number(value.toFixed(2));
/** Appends a sample to a rolling buffer, dropping samples older than the chart window keeps. */
function appendChartPoint(points, point) {
	const cutoff = point.t - RETAIN_MS;
	let start = 0;
	while (start < points.length && points[start].t < cutoff) start++;
	return [...points.slice(start), point];
}
/** The element's width in whole pixels; 0 until it has been measured. */
function useElementWidth(ref) {
	const [width, setWidth] = useState(0);
	useEffect(() => {
		const element = ref.current;
		if (!element) return;
		const observer = new ResizeObserver((entries) => {
			const entry = entries.at(-1);
			if (entry) setWidth(Math.floor(entry.contentRect.width));
		});
		observer.observe(element);
		return () => observer.disconnect();
	}, [ref]);
	return width;
}
//#endregion
//#region ../../resources/scripts/state/server/stats.ts
var emptyStatsSample = {
	cpu: 0,
	memory: 0,
	disk: 0,
	rx: 0,
	tx: 0,
	uptime: 0
};
var emptyGraphs = {
	cpu: [],
	memory: [],
	network: []
};
var delta = (total, previous) => previous < 0 ? 0 : Math.max(0, total - previous);
var createStats = (set) => ({
	current: emptyStatsSample,
	graphs: emptyGraphs,
	totals: {
		tx: -1,
		rx: -1
	},
	push: (payload, t) => set(({ stats }) => ({ stats: {
		...stats,
		current: {
			cpu: payload.cpu_absolute,
			memory: payload.memory_bytes,
			disk: payload.disk_bytes,
			rx: payload.network.rx_bytes,
			tx: payload.network.tx_bytes,
			uptime: payload.uptime || 0
		},
		graphs: {
			cpu: appendChartPoint(stats.graphs.cpu, {
				t,
				value: chartValue(payload.cpu_absolute)
			}),
			memory: appendChartPoint(stats.graphs.memory, {
				t,
				value: chartValue(Math.floor(payload.memory_bytes / 1024 / 1024))
			}),
			network: appendChartPoint(stats.graphs.network, {
				t,
				tx: chartValue(delta(payload.network.tx_bytes, stats.totals.tx)),
				rx: chartValue(delta(payload.network.rx_bytes, stats.totals.rx))
			})
		},
		totals: {
			tx: payload.network.tx_bytes,
			rx: payload.network.rx_bytes
		}
	} })),
	clearGraphs: () => set(({ stats }) => ({ stats: {
		...stats,
		graphs: emptyGraphs
	} }))
});
//#endregion
//#region ../../resources/scripts/state/server/index.tsx
var createStatus = (set) => ({
	value: null,
	setServerStatus: (payload) => set((state) => ({ status: {
		...state.status,
		value: payload
	} }))
});
var createServerStore = () => createStore()((set, get) => ({
	socket: createSocket(set),
	status: createStatus(set),
	stats: createStats(set),
	files: createFiles(set, get),
	clearServerState: () => {
		const sock = get().socket.instance;
		if (sock) {
			sock.removeAllListeners();
			sock.close();
		}
		set((state) => ({
			files: {
				...state.files,
				selectedDirectory: null,
				selectedFiles: []
			},
			socket: {
				...state.socket,
				instance: null,
				connected: false,
				reconnecting: false
			},
			status: {
				...state.status,
				value: null
			},
			stats: {
				...state.stats,
				current: emptyStatsSample,
				graphs: emptyGraphs,
				totals: {
					tx: -1,
					rx: -1
				}
			}
		}));
	}
}));
var StoreContext = createContext(null);
var EMPTY_SELECTED_FILES = [];
var Provider = ({ children }) => {
	const [store] = useState(createServerStore);
	return /* @__PURE__ */ jsx(StoreContext.Provider, {
		value: store,
		children
	});
};
var useServerStoreApi = () => {
	const store = use(StoreContext);
	if (!store) throw new Error("ServerContext.Provider is missing from the component tree.");
	return store;
};
function useServerStore(selector) {
	return useStore(useServerStoreApi(), selector);
}
var useServerDirectory = () => {
	return hashToPath(useLocation({ select: (location) => location.hash }));
};
var useSelectedFiles = () => {
	const directory = useServerDirectory();
	return useServerStore((state) => state.files.selectedDirectory === directory ? state.files.selectedFiles : EMPTY_SELECTED_FILES);
};
var useServerStatus = () => useServerStore((state) => state.status.value);
var useServerStats = () => useServerStore((state) => state.stats.current);
var useServerGraphs = () => useServerStore((state) => state.stats.graphs);
var useSocketConnected = () => useServerStore((state) => state.socket.connected);
var useSocketInstance = () => useServerStore((state) => state.socket.instance);
var useFileUploadActions = () => {
	const removeFileUpload = useServerStore((state) => state.files.removeFileUpload);
	const pushFileUpload = useServerStore((state) => state.files.pushFileUpload);
	const setUploadProgress = useServerStore((state) => state.files.setUploadProgress);
	return useMemo(() => ({
		removeFileUpload,
		pushFileUpload,
		setUploadProgress
	}), [
		pushFileUpload,
		removeFileUpload,
		setUploadProgress
	]);
};
//#endregion
export { normalizeServerPath as _, useServerGraphs as a, useServerStore as c, CHART_WINDOW_MS as d, useElementWidth as f, newDirectoryDisplayName as g, fileBitsToString as h, useServerDirectory as i, useSocketConnected as l, encodePathSegments as m, useFileUploadActions as n, useServerStats as o, cleanDirectoryPath as p, useSelectedFiles as r, useServerStatus as s, Provider as t, useSocketInstance as u, join as v, normalize as y };

//# sourceMappingURL=server-U1WA-Nu8.js.map