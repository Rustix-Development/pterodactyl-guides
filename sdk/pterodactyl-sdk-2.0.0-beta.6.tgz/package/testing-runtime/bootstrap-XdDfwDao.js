//#region ../../resources/scripts/bootstrap.ts
var getBootstrapUser = () => {
	const user = window.PterodactylUser;
	return user ? {
		uuid: user.uuid,
		username: user.username,
		email: user.email,
		language: user.language,
		rootAdmin: user.root_admin,
		useTotp: user.use_totp,
		createdAt: new Date(user.created_at),
		updatedAt: new Date(user.updated_at)
	} : void 0;
};
var getBootstrapSiteSettings = () => window.SiteConfiguration;
var classicTheme = {
	id: "classic",
	chain: [],
	settings: {},
	scheme: "dark",
	schemes: ["dark"],
	safeMode: false,
	preview: false
};
var getBootstrapTheme = () => ({
	...classicTheme,
	...window.SiteConfiguration?.theme
});
//#endregion
export { getBootstrapTheme as n, getBootstrapUser as r, getBootstrapSiteSettings as t };

//# sourceMappingURL=bootstrap-XdDfwDao.js.map