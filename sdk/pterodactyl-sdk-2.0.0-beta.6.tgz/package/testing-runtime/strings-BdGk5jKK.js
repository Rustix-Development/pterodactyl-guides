import { d as isString, u as isObject } from "./client.gen-Ci-zROOW.js";
//#region ../../resources/scripts/components/form/errors.ts
function firstError(errors) {
	if (!errors || errors.length === 0) return;
	const error = errors.find((e) => e !== void 0 && e !== null && e !== "");
	if (error === void 0) return;
	if (isString(error)) return error;
	if (isObject(error) && "message" in error) return String(error.message);
	return String(error);
}
//#endregion
//#region ../../resources/scripts/lib/strings.ts
function capitalize(value) {
	return value.charAt(0).toUpperCase() + value.slice(1);
}
//#endregion
export { firstError as n, capitalize as t };

//# sourceMappingURL=strings-BdGk5jKK.js.map