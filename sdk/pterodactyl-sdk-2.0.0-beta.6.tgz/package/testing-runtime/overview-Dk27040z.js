import { o as httpErrorToHuman } from "./client.gen-Ci-zROOW.js";
import { Gt as implementViews, M as clientEnableTwoFactorAuthenticationMutation, W as clientGetTwoFactorSetupOptions, j as clientDisableTwoFactorAuthenticationMutation, t as notifyHttpError } from "./notifications-Ebj0Q0Io.js";
import { a as useUpdateAccountPassword, i as useUpdateAccountEmail, n as setCurrentUserQueryData, r as useCurrentUser } from "./queries-BF8_5ZD3.js";
import { n as fixtureField, r as stateField, t as boundField } from "./forms-DcsxfoFI.js";
import { useState } from "react";
import { useLocation } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useField, useForm, useStore } from "@tanstack/react-form";
//#region ../../resources/scripts/api/account/two-factor/queries.ts
var useAccountTwoFactorToken = (enabled = true) => useQuery({
	...clientGetTwoFactorSetupOptions(),
	enabled
});
var useEnableAccountTwoFactor = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientEnableTwoFactorAuthenticationMutation(),
		onSuccess: () => {
			setCurrentUserQueryData(queryClient, { useTotp: true });
			toast.success("Two-step verification enabled");
		},
		onError: (error) => notifyHttpError(error, "Unable to enable two-step verification")
	});
};
var useDisableAccountTwoFactor = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDisableTwoFactorAuthenticationMutation(),
		onSuccess: () => {
			setCurrentUserQueryData(queryClient, { useTotp: false });
			toast.success("Two-step verification disabled");
		},
		onError: (error) => notifyHttpError(error, "Unable to disable two-step verification")
	});
};
//#endregion
//#region ../../resources/scripts/views/account/overview.ts
var isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
var currentPassword = {
	type: "password",
	autoComplete: "current-password"
};
var newPassword = {
	type: "password",
	autoComplete: "new-password"
};
var totpCode = {
	type: "text",
	inputMode: "numeric",
	autoComplete: "one-time-code",
	pattern: "[0-9]{6}"
};
function useAccountOverviewModel() {
	const state = useLocation().state;
	return { twoFactorRequired: "twoFactorRedirect" in state && state.twoFactorRedirect === true };
}
function useAccountPasswordModel() {
	const updatePassword = useUpdateAccountPassword();
	const form = useForm({
		defaultValues: {
			current: "",
			password: "",
			confirmPassword: ""
		},
		onSubmit: async ({ value }) => {
			try {
				await updatePassword.mutateAsync({ body: {
					current_password: value.current,
					password: value.password,
					password_confirmation: value.confirmPassword
				} });
			} catch {}
		}
	});
	const current = useField({
		form,
		name: "current",
		validators: { onChange: ({ value }) => value.length >= 1 ? void 0 : "You must provide your current password." }
	});
	const password = useField({
		form,
		name: "password",
		validators: { onChange: ({ value }) => value.length >= 8 ? void 0 : "Your new password should be at least 8 characters in length." }
	});
	const confirmPassword = useField({
		form,
		name: "confirmPassword",
		validators: {
			onChangeListenTo: ["password"],
			onChange: ({ value, fieldApi }) => value === fieldApi.form.getFieldValue("password") ? void 0 : "Password confirmation does not match the password you entered."
		}
	});
	const canSubmit = useStore(form.store, (state) => state.canSubmit);
	const submitting = useStore(form.store, (state) => state.isSubmitting);
	return {
		fields: {
			current: boundField(current, currentPassword),
			password: boundField(password, newPassword),
			confirmPassword: boundField(confirmPassword, newPassword)
		},
		submit: () => void form.handleSubmit(),
		canSubmit: canSubmit && !updatePassword.isPending,
		submitting: submitting || updatePassword.isPending
	};
}
function useAccountEmailModel() {
	const user = useCurrentUser();
	const updateEmail = useUpdateAccountEmail();
	const form = useForm({
		defaultValues: {
			email: user.email,
			password: ""
		},
		onSubmit: async ({ value, formApi }) => {
			try {
				await updateEmail.mutateAsync({ body: value });
				formApi.setFieldValue("password", "");
			} catch {} finally {
				formApi.setFieldMeta("password", (meta) => ({
					...meta,
					errors: []
				}));
			}
		}
	});
	const email = useField({
		form,
		name: "email",
		validators: { onChange: ({ value }) => isEmail(value) ? void 0 : "A valid email address must be provided." }
	});
	const password = useField({
		form,
		name: "password",
		validators: { onChange: ({ value }) => value.length >= 1 ? void 0 : "You must provide your current account password." }
	});
	const canSubmit = useStore(form.store, (state) => state.canSubmit);
	const submitting = useStore(form.store, (state) => state.isSubmitting);
	return {
		fields: {
			email: boundField(email, {
				type: "email",
				autoComplete: "email"
			}),
			password: boundField(password, currentPassword)
		},
		submit: () => void form.handleSubmit(),
		canSubmit: canSubmit && !updateEmail.isPending,
		submitting: submitting || updateEmail.isPending
	};
}
function useAccountTwoFactorModel() {
	const enabled = useCurrentUser().useTotp;
	const [dialog, setDialog] = useState(null);
	const [recoveryTokens, setRecoveryTokens] = useState([]);
	const [code, setCode] = useState("");
	const [setupPassword, setSetupPassword] = useState("");
	const [disablePassword, setDisablePassword] = useState("");
	const secret = useAccountTwoFactorToken(dialog === "enable");
	const enable = useEnableAccountTwoFactor();
	const disable = useDisableAccountTwoFactor();
	const token = secret.data?.data;
	const failed = secret.error && !secret.isFetching ? httpErrorToHuman(secret.error) : null;
	const submitSetup = async () => {
		if (enable.isPending) return;
		try {
			setRecoveryTokens((await enable.mutateAsync({ body: {
				code,
				password: setupPassword
			} })).attributes.tokens);
			setDialog(null);
		} catch {}
	};
	const submitDisable = async () => {
		if (disable.isPending) return;
		try {
			await disable.mutateAsync({ body: { password: disablePassword } });
			setDialog(null);
		} catch {}
	};
	return {
		enabled,
		dialog,
		openDialog: (next) => {
			setCode("");
			setSetupPassword("");
			setDisablePassword("");
			setDialog(next);
		},
		closeDialog: () => setDialog(null),
		setup: {
			fields: {
				code: stateField("code", code, setCode, totpCode),
				password: stateField("password", setupPassword, setSetupPassword, currentPassword)
			},
			submit: () => void submitSetup(),
			canSubmit: !!token && code.length === 6 && setupPassword.length > 0 && !enable.isPending,
			submitting: enable.isPending,
			secret: token?.secret ?? null,
			qrCode: token?.image_url_data ?? null,
			error: failed,
			retry: () => void secret.refetch()
		},
		disable: {
			fields: { password: stateField("password", disablePassword, setDisablePassword, currentPassword) },
			submit: () => void submitDisable(),
			canSubmit: disablePassword.length > 0 && !disable.isPending,
			submitting: disable.isPending
		},
		recoveryTokens,
		dismissRecoveryTokens: () => setRecoveryTokens([])
	};
}
var noop = () => {};
var passwordFixture = (error = null) => ({
	fields: {
		current: fixtureField("current", currentPassword),
		password: fixtureField("password", newPassword, error ? "short" : "", error),
		confirmPassword: fixtureField("confirmPassword", newPassword)
	},
	submit: noop,
	canSubmit: error === null,
	submitting: false
});
var emailFixture = (submitting = false) => ({
	fields: {
		email: fixtureField("email", {
			type: "email",
			autoComplete: "email"
		}, "alex@example.test"),
		password: fixtureField("password", currentPassword, submitting ? "correct horse" : "")
	},
	submit: noop,
	canSubmit: !submitting,
	submitting
});
var SECRET = "JBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXP";
function twoFactorFixture(overrides = {}) {
	return {
		enabled: false,
		dialog: null,
		openDialog: noop,
		closeDialog: noop,
		setup: {
			fields: {
				code: fixtureField("code", totpCode),
				password: fixtureField("password", currentPassword)
			},
			submit: noop,
			canSubmit: false,
			submitting: false,
			secret: SECRET,
			qrCode: `otpauth://totp/Pterodactyl:alex%40example.test?secret=${SECRET}&issuer=Pterodactyl`,
			error: null,
			retry: noop
		},
		disable: {
			fields: { password: fixtureField("password", currentPassword) },
			submit: noop,
			canSubmit: false,
			submitting: false
		},
		recoveryTokens: [],
		dismissRecoveryTokens: noop,
		...overrides
	};
}
implementViews({
	"page.account.overview": {
		use: useAccountOverviewModel,
		fixtures: {
			default: () => ({ twoFactorRequired: false }),
			twoFactorRequired: () => ({ twoFactorRequired: true })
		}
	},
	"account.password": {
		use: useAccountPasswordModel,
		fixtures: {
			default: () => passwordFixture(),
			invalid: () => passwordFixture("Your new password should be at least 8 characters in length.")
		}
	},
	"account.email": {
		use: useAccountEmailModel,
		fixtures: {
			default: () => emailFixture(),
			submitting: () => emailFixture(true)
		}
	},
	"account.twoFactor": {
		use: useAccountTwoFactorModel,
		fixtures: {
			disabled: () => twoFactorFixture(),
			enabled: () => twoFactorFixture({ enabled: true }),
			setup: () => twoFactorFixture({ dialog: "enable" }),
			setupLoading: () => {
				const model = twoFactorFixture({ dialog: "enable" });
				return {
					...model,
					setup: {
						...model.setup,
						secret: null,
						qrCode: null
					}
				};
			},
			disabling: () => twoFactorFixture({
				enabled: true,
				dialog: "disable"
			}),
			recoveryTokens: () => twoFactorFixture({
				enabled: true,
				recoveryTokens: [
					"a1b2c3d4e5",
					"f6g7h8i9j0",
					"k1l2m3n4o5",
					"p6q7r8s9t0",
					"u1v2w3x4y5",
					"z6a7b8c9d0"
				]
			})
		}
	}
});
//#endregion

//# sourceMappingURL=overview-Dk27040z.js.map