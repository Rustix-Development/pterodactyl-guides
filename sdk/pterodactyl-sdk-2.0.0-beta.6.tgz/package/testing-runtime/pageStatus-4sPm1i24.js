import { o as httpErrorToHuman } from "./client.gen-Ci-zROOW.js";
//#region ../../resources/scripts/views/pageStatus.ts
/** The status of a page from the queries it loads; a query that fails to refresh keeps its data on show. */
function pageStatus(...queries) {
	const failed = queries.find((query) => query.error && query.data === void 0);
	return {
		loading: !failed && queries.some((query) => query.data === void 0),
		error: failed ? httpErrorToHuman(failed.error) : null,
		retry: () => {
			for (const query of queries) if (query.error) query.refetch();
		}
	};
}
var noop = () => {};
var pageStatusFixtures = {
	default: () => ({
		loading: false,
		error: null,
		retry: noop
	}),
	loading: () => ({
		loading: true,
		error: null,
		retry: noop
	}),
	error: () => ({
		loading: false,
		error: "Request failed with status code 500.",
		retry: noop
	})
};
//#endregion
export { pageStatusFixtures as n, pageStatus as t };

//# sourceMappingURL=pageStatus-4sPm1i24.js.map