import { t as routeParamStrings } from "./params-HmQaEn9f.js";
import { useCallback, useEffect, useRef } from "react";
import { useBlocker } from "@tanstack/react-router";
//#region ../../resources/scripts/plugins/useNavigationBlocker.ts
var UNSAVED_CHANGES_MESSAGE = "You have unsaved changes. Leave this page and discard them?";
/** Asks before leaving while `shouldBlock` holds, including back/forward and tab close. */
function useNavigationBlocker(shouldBlock, options = {}) {
	const latest = useRef({
		shouldBlock,
		options
	});
	useEffect(() => {
		latest.current = {
			shouldBlock,
			options
		};
	});
	const isBlocking = useCallback(() => {
		const { shouldBlock } = latest.current;
		return shouldBlock instanceof Function ? shouldBlock() : shouldBlock;
	}, []);
	useBlocker({
		shouldBlockFn: useCallback(async ({ action, current, next }) => {
			if (!isBlocking()) return false;
			const { confirm, message = UNSAVED_CHANGES_MESSAGE } = latest.current.options;
			if (!confirm) return !window.confirm(message);
			try {
				return !await confirm({
					action,
					current: {
						pathname: current.pathname,
						params: routeParamStrings(current.params),
						search: current.search
					},
					next: {
						pathname: next.pathname,
						params: routeParamStrings(next.params),
						search: next.search
					}
				});
			} catch (error) {
				console.error(error);
				return !window.confirm(message);
			}
		}, [isBlocking]),
		enableBeforeUnload: useCallback(() => latest.current.options.beforeUnload !== false && isBlocking(), [isBlocking])
	});
}
//#endregion
export { useNavigationBlocker as t };

//# sourceMappingURL=useNavigationBlocker-Cl3Kp0j8.js.map