import { p as Icon } from "./Button-BzlrfY24.js";
import { n as NavigationLink, o as useActiveNavItem, t as Navigation } from "./navigation-DAcCRZlc.js";
import { r as cn, ut as NavigationLabel } from "./sdk-Chrtpiam.js";
import { i as usePanelLocation } from "./navigation-9aP-0Hbq.js";
import { a as Slot, o as Main } from "./theme-Cgy7R6cy.js";
import { useEffect, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Blocks, ChevronDown, Database, Egg, FolderTree, History, KeyRound, LayoutDashboard, MapPin, Menu, Network, Palette, Puzzle, Server, Settings, Tag, Users } from "lucide-react";
//#region ../../resources/scripts/themes/classic/views/layout/AdminLayout.tsx
var icons$1 = new Map([
	["layout-dashboard", LayoutDashboard],
	["history", History],
	["settings", Settings],
	["users", Users],
	["map-pin", MapPin],
	["network", Network],
	["server", Server],
	["database", Database],
	["folder-tree", FolderTree],
	["egg", Egg],
	["tag", Tag],
	["blocks", Blocks],
	["palette", Palette],
	["key-round", KeyRound]
]);
var itemClass = [
	"flex items-center gap-3 rounded-md px-3 py-2 text-sm no-underline",
	"text-muted-foreground transition-colors duration-150",
	"hover:bg-card hover:text-foreground active:bg-popover/80",
	"data-[status=active]:bg-popover data-[status=active]:text-foreground"
].join(" ");
var extensionItemsClass = [
	"contents",
	"[&_a]:flex [&_a]:items-center [&_a]:gap-3 [&_a]:rounded-md [&_a]:py-2 [&_a]:pr-3 [&_a]:pl-10 [&_a]:text-sm [&_a]:no-underline",
	"[&_a]:text-muted-foreground [&_a]:transition-colors [&_a]:duration-150",
	"[&_a:hover]:bg-card [&_a:hover]:text-foreground",
	"[&_a[data-status=active]]:bg-popover [&_a[data-status=active]]:text-foreground"
].join(" ");
function ItemLabel({ item, badge }) {
	const glyph = item.extensionId === void 0 && item.icon ? icons$1.get(item.icon) : void 0;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [(glyph !== void 0 || !item.icon) && /* @__PURE__ */ jsx(Icon, {
		icon: glyph ?? Puzzle,
		className: "w-4 h-4 shrink-0"
	}), /* @__PURE__ */ jsx(NavigationLabel, {
		label: item.label,
		group: item.group,
		icon: glyph ? null : item.icon,
		badge
	})] });
}
function AdminSidebar({ nav }) {
	const [open, setOpen] = useState(false);
	const { pathname } = usePanelLocation();
	const current = useActiveNavItem(nav.items);
	useEffect(() => setOpen(false), [pathname]);
	return /* @__PURE__ */ jsxs("div", {
		className: cn("w-full shrink-0 px-4 pt-4", "lg:w-sidebar lg:px-0 lg:pt-0"),
		children: [/* @__PURE__ */ jsxs("button", {
			type: "button",
			onClick: () => setOpen((value) => !value),
			"aria-expanded": open,
			"aria-controls": "admin-sidebar-nav",
			className: cn("flex w-full items-center gap-3 rounded-md bg-card px-3 py-2 text-sm text-foreground shadow-sm", "transition-colors duration-150 hover:bg-popover lg:hidden"),
			children: [
				/* @__PURE__ */ jsx(Icon, {
					icon: Menu,
					className: "w-4 h-4 shrink-0"
				}),
				/* @__PURE__ */ jsx("span", {
					className: "flex-1 min-w-0 truncate text-left",
					children: current?.label ?? "Administration"
				}),
				/* @__PURE__ */ jsx(Icon, {
					icon: ChevronDown,
					className: cn("w-4 h-4 shrink-0 transition-transform", open && "rotate-180")
				})
			]
		}), /* @__PURE__ */ jsxs("nav", {
			id: "admin-sidebar-nav",
			"aria-label": "Administration",
			className: cn("mt-2 flex-col gap-0.5", "lg:sticky lg:top-0 lg:mt-0 lg:flex lg:max-h-dvh lg:overflow-y-auto lg:px-4 lg:py-6", open ? "flex" : "hidden"),
			children: [
				/* @__PURE__ */ jsx("div", {
					className: extensionItemsClass,
					children: /* @__PURE__ */ jsx(Slot, { name: "panel.navigation.before" })
				}),
				/* @__PURE__ */ jsx(Navigation, {
					items: nav.items,
					children: (item, state) => /* @__PURE__ */ jsx(NavigationLink, {
						item,
						className: itemClass,
						children: /* @__PURE__ */ jsx(ItemLabel, {
							item,
							badge: state.badge
						})
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: extensionItemsClass,
					children: /* @__PURE__ */ jsx(Slot, { name: "panel.navigation.after" })
				})
			]
		})]
	});
}
function AdminLayout({ model, className, children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn("mx-auto flex w-full max-w-panel flex-col lg:flex-row", className),
		children: [/* @__PURE__ */ jsx(AdminSidebar, { nav: model.nav }), /* @__PURE__ */ jsx("div", {
			className: "min-w-0 flex-1 xl:pl-4",
			children: /* @__PURE__ */ jsx(Main, { children })
		})]
	});
}
//#endregion
export { AdminLayout as default };

//# sourceMappingURL=AdminLayout-63BBk-ok.js.map