import { B as clientGetServerScheduleOptions, Dt as clientUpdateScheduleTaskMutation, Gt as implementViews, N as clientExecuteServerScheduleMutation, O as clientDeleteServerScheduleMutation, Ot as clientUpdateServerScheduleMutation, V as clientGetServerScheduleQueryKey, ct as clientListServerSchedulesQueryKey, m as clientCreateScheduleTaskMutation, st as clientListServerSchedulesOptions, t as notifyHttpError, v as clientCreateServerScheduleMutation, w as clientDeleteScheduleTaskMutation } from "./notifications-Ebj0Q0Io.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { i as upsertListItem, n as removeListItems } from "./queryData-DzPdESJr.js";
import { n as pageStatusFixtures, t as pageStatus } from "./pageStatus-4sPm1i24.js";
import { n as relationshipData } from "./relationships-CSicEn-V.js";
import { t as attempt } from "./attempt-B1fyfDS4.js";
import { t as useLoadedServer } from "./loadedServer-Bw7lSBA6.js";
import { useCallback, useMemo } from "react";
import { useNavigate, useParams } from "@tanstack/react-router";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
//#region ../../resources/scripts/api/server/schedules/queries.ts
var serverSchedulesInput = (uuid) => ({
	path: { server_uuid: uuid },
	query: { include: "tasks" }
});
var serverScheduleInput = (uuid, scheduleId) => ({
	path: {
		server_uuid: uuid,
		schedule_id: scheduleId
	},
	query: { include: "tasks" }
});
var scheduleBody = (schedule) => ({
	is_active: schedule.isActive,
	only_when_online: schedule.onlyWhenOnline,
	name: schedule.name,
	minute: schedule.cron.minute,
	hour: schedule.cron.hour,
	day_of_month: schedule.cron.dayOfMonth,
	month: schedule.cron.month,
	day_of_week: schedule.cron.dayOfWeek
});
var taskBody = (task) => ({
	action: task.action,
	payload: task.payload,
	continue_on_failure: task.continueOnFailure,
	time_offset: Number(task.timeOffset)
});
var createServerScheduleInput = (uuid, values) => ({
	path: { server_uuid: uuid },
	body: scheduleBody(values)
});
var updateServerScheduleInput = (uuid, scheduleId, values) => ({
	path: {
		server_uuid: uuid,
		schedule_id: scheduleId
	},
	body: scheduleBody(values)
});
var deleteServerScheduleInput = (uuid, scheduleId) => ({ path: {
	server_uuid: uuid,
	schedule_id: scheduleId
} });
var executeServerScheduleInput = (uuid, schedule) => ({ path: {
	server_uuid: uuid,
	schedule_id: schedule.attributes.id
} });
var createScheduleTaskInput = (uuid, schedule, values) => ({
	path: {
		server_uuid: uuid,
		schedule_id: schedule.attributes.id
	},
	body: taskBody(values)
});
var updateScheduleTaskInput = (uuid, schedule, taskId, values) => ({
	path: {
		server_uuid: uuid,
		schedule_id: schedule.attributes.id,
		task_id: taskId
	},
	body: taskBody(values)
});
var deleteScheduleTaskInput = (uuid, schedule, taskId) => ({ path: {
	server_uuid: uuid,
	schedule_id: schedule.attributes.id,
	task_id: taskId
} });
var cacheServerSchedule = async (queryClient, uuid, schedule, updater) => {
	const detailKey = clientGetServerScheduleQueryKey(serverScheduleInput(uuid, schedule.attributes.id));
	const listKey = clientListServerSchedulesQueryKey(serverSchedulesInput(uuid));
	await Promise.all([queryClient.cancelQueries({ queryKey: detailKey }), queryClient.cancelQueries({ queryKey: listKey })]);
	const updated = updater ? updater(queryClient.getQueryData(detailKey) ?? schedule) : schedule;
	queryClient.setQueryData(detailKey, updated);
	queryClient.setQueryData(listKey, (current) => upsertListItem(current, updated, (item) => item.attributes.id === updated.attributes.id));
};
var removeServerSchedule = async (queryClient, uuid, scheduleId) => {
	await queryClient.cancelQueries({ queryKey: clientListServerSchedulesQueryKey(serverSchedulesInput(uuid)) });
	return queryClient.setQueryData(clientListServerSchedulesQueryKey(serverSchedulesInput(uuid)), (current) => removeListItems(current, (schedule) => schedule.attributes.id === scheduleId));
};
var cacheServerScheduleTask = (schedule, task) => {
	const tasksRelationship = schedule.attributes.relationships?.tasks;
	const tasks = tasksRelationship && "data" in tasksRelationship ? tasksRelationship : {
		object: "list",
		data: []
	};
	const data = tasks.data.some((item) => item.attributes.id === task.attributes.id) ? tasks.data.map((item) => item.attributes.id === task.attributes.id ? task : item) : [...tasks.data, task];
	return {
		...schedule,
		attributes: {
			...schedule.attributes,
			relationships: {
				...schedule.attributes.relationships,
				tasks: {
					...tasks,
					data
				}
			}
		}
	};
};
var removeServerScheduleTask = (schedule, taskId) => {
	const tasks = schedule.attributes.relationships?.tasks;
	if (!tasks || !("data" in tasks)) return schedule;
	return {
		...schedule,
		attributes: {
			...schedule.attributes,
			relationships: {
				...schedule.attributes.relationships,
				tasks: {
					...tasks,
					data: tasks.data.filter((task) => task.attributes.id !== taskId)
				}
			}
		}
	};
};
var serverSchedulesQueryOptions = (uuid) => clientListServerSchedulesOptions(serverSchedulesInput(uuid));
var useServerSchedules = (uuid) => useQuery({
	...serverSchedulesQueryOptions(uuid),
	enabled: uuid.length > 0
});
var serverScheduleQueryOptions = (uuid, scheduleId) => clientGetServerScheduleOptions(serverScheduleInput(uuid, scheduleId));
var useServerSchedule = (uuid, scheduleId) => useQuery({
	...serverScheduleQueryOptions(uuid, scheduleId),
	enabled: uuid.length > 0 && Number.isInteger(scheduleId) && scheduleId > 0
});
var useCreateServerSchedule = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateServerScheduleMutation(),
		onSuccess: async (schedule, { path }) => {
			await cacheServerSchedule(queryClient, path.server_uuid, schedule);
			toast.success("Schedule created");
		},
		onError: (error) => notifyHttpError(error, "Unable to save schedule")
	});
};
var useUpdateServerSchedule = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientUpdateServerScheduleMutation(),
		onSuccess: async (schedule, { path }) => {
			await cacheServerSchedule(queryClient, path.server_uuid, schedule);
			toast.success("Schedule saved");
		},
		onError: (error) => notifyHttpError(error, "Unable to save schedule")
	});
};
var useDeleteServerSchedule = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDeleteServerScheduleMutation(),
		onSuccess: async (_data, { path }) => {
			queryClient.removeQueries({ queryKey: clientGetServerScheduleQueryKey(serverScheduleInput(path.server_uuid, path.schedule_id)) });
			await removeServerSchedule(queryClient, path.server_uuid, path.schedule_id);
			toast.success("Schedule deleted");
		},
		onError: (error) => notifyHttpError(error, "Unable to delete schedule")
	});
};
var useTriggerServerScheduleExecution = (schedule) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientExecuteServerScheduleMutation(),
		onSuccess: async (_data, { path }) => {
			await cacheServerSchedule(queryClient, path.server_uuid, {
				...schedule,
				attributes: {
					...schedule.attributes,
					is_processing: true
				}
			});
			toast.success("Schedule queued");
		},
		onError: (error) => notifyHttpError(error, "Unable to run schedule")
	});
};
var useCreateServerScheduleTask = (schedule) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateScheduleTaskMutation(),
		onSuccess: async (task, { path }) => {
			await cacheServerSchedule(queryClient, path.server_uuid, schedule, (current) => cacheServerScheduleTask(current, task));
			toast.success("Task created");
		},
		onError: (error) => notifyHttpError(error, "Unable to save task")
	});
};
var useUpdateServerScheduleTask = (schedule) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientUpdateScheduleTaskMutation(),
		onSuccess: async (task, { path }) => {
			await cacheServerSchedule(queryClient, path.server_uuid, schedule, (current) => cacheServerScheduleTask(current, task));
			toast.success("Task saved");
		},
		onError: (error) => notifyHttpError(error, "Unable to save task")
	});
};
var useDeleteServerScheduleTask = (schedule) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDeleteScheduleTaskMutation(),
		onSuccess: async (_data, { path }) => {
			await cacheServerSchedule(queryClient, path.server_uuid, schedule, (current) => removeServerScheduleTask(current, path.task_id));
			toast.success("Task deleted");
		},
		onError: (error) => notifyHttpError(error, "Unable to delete task")
	});
};
//#endregion
//#region ../../resources/scripts/views/server/schedules.ts
var newSchedule = {
	name: "",
	minute: "*/5",
	hour: "*",
	dayOfMonth: "*",
	month: "*",
	dayOfWeek: "*",
	enabled: true,
	onlyWhenOnline: true
};
var scheduleSummary = ({ attributes }) => ({
	id: attributes.id,
	name: attributes.name,
	cron: {
		minute: attributes.cron.minute,
		hour: attributes.cron.hour,
		dayOfMonth: attributes.cron.day_of_month,
		month: attributes.cron.month,
		dayOfWeek: attributes.cron.day_of_week
	},
	active: attributes.is_active,
	processing: attributes.is_processing,
	onlyWhenOnline: attributes.only_when_online,
	lastRunAt: attributes.last_run_at,
	nextRunAt: attributes.next_run_at
});
var scheduleFormValues = ({ name, cron, active, onlyWhenOnline }) => ({
	name: name || newSchedule.name,
	minute: cron.minute || newSchedule.minute,
	hour: cron.hour || newSchedule.hour,
	dayOfMonth: cron.dayOfMonth || newSchedule.dayOfMonth,
	month: cron.month || newSchedule.month,
	dayOfWeek: cron.dayOfWeek || newSchedule.dayOfWeek,
	enabled: active,
	onlyWhenOnline
});
var scheduleValues = (values) => ({
	name: values.name,
	cron: {
		minute: values.minute,
		hour: values.hour,
		dayOfWeek: values.dayOfWeek,
		month: values.month,
		dayOfMonth: values.dayOfMonth
	},
	onlyWhenOnline: values.onlyWhenOnline,
	isActive: values.enabled
});
var scheduleTask = ({ attributes }) => ({
	id: attributes.id,
	sequence: attributes.sequence_id,
	action: attributes.action,
	payload: attributes.payload,
	timeOffset: attributes.time_offset,
	continueOnFailure: attributes.continue_on_failure
});
var orderedTasks = (schedule) => relationshipData(schedule.attributes.relationships?.tasks).map(scheduleTask).sort((a, b) => a.sequence - b.sequence);
var validateTimeOffset = (value) => {
	if (value === null) return "A time offset must be provided.";
	if (value < 0) return "The time offset must be at least 0 seconds.";
	if (value > 900) return "The time offset must be less than 900 seconds.";
};
/** The task form for a server allowed `backupLimit` backups. */
function scheduleTaskForm(backupLimit) {
	const initialAction = (task) => task?.action || "command";
	return {
		actions: [
			{
				value: "command",
				label: "Send command"
			},
			{
				value: "power",
				label: "Send power action"
			},
			{
				value: "backup",
				label: "Create backup"
			}
		],
		powerSignals: [
			{
				value: "start",
				label: "Start the server"
			},
			{
				value: "restart",
				label: "Restart the server"
			},
			{
				value: "stop",
				label: "Stop the server"
			},
			{
				value: "kill",
				label: "Terminate the server"
			}
		],
		values: (task) => ({
			action: initialAction(task),
			payload: task?.payload || "",
			timeOffset: task?.timeOffset ?? 0,
			continueOnFailure: task?.continueOnFailure || false
		}),
		payloadFor: (action, task) => {
			if (action === initialAction(task)) return task?.payload || "";
			return action === "power" ? "start" : "";
		},
		validateTimeOffset,
		validatePayload: (action, payload) => action !== "command" || payload.length > 0 ? void 0 : "A task payload must be provided.",
		validate: ({ action }) => backupLimit === 0 && action === "backup" ? "A backup task cannot be created when the server's backup limit is set to 0." : null
	};
}
function useScheduleId() {
	const { scheduleId } = useParams({ strict: false });
	return Number(scheduleId);
}
/**
* The route's schedule, which the detail page loads before its blocks render. A deleted schedule's
* blocks keep its last copy while the page navigates away, rather than fetching it again.
*/
function useLoadedSchedule() {
	const { uuid } = useLoadedServer().attributes;
	const { data } = useQuery({
		...serverScheduleQueryOptions(uuid, useScheduleId()),
		enabled: false,
		placeholderData: keepPreviousData
	});
	if (!data) throw new Error("Schedule views render once the detail page has loaded the schedule.");
	return data;
}
function useTaskForm() {
	const backupLimit = useLoadedServer().attributes.feature_limits.backups;
	return useMemo(() => scheduleTaskForm(backupLimit), [backupLimit]);
}
/** Creates a task on the schedule; the time offset must have passed validation. */
function useCreateTask(schedule) {
	const { uuid } = useLoadedServer().attributes;
	const { mutateAsync } = useCreateServerScheduleTask(schedule);
	return useCallback(({ timeOffset, ...values }) => attempt(() => mutateAsync(createScheduleTaskInput(uuid, schedule, {
		...values,
		timeOffset: timeOffset ?? 0
	}))), [
		mutateAsync,
		uuid,
		schedule
	]);
}
var useSchedulesPageModel = () => pageStatus(useServerSchedules(useLoadedServer().attributes.uuid));
function useScheduleListModel() {
	const { uuid, identifier } = useLoadedServer().attributes;
	const { data, isLoading } = useServerSchedules(uuid);
	const [canCreate, canUpdate] = usePermissions(["schedule.create", "schedule.update"]);
	const { mutateAsync } = useCreateServerSchedule();
	const create = useCallback((values) => attempt(() => mutateAsync(createServerScheduleInput(uuid, scheduleValues(values)))), [mutateAsync, uuid]);
	return useMemo(() => ({
		serverId: identifier,
		schedules: (data?.data ?? []).map(scheduleSummary),
		loading: isLoading,
		canCreate,
		canUpdate,
		defaults: newSchedule,
		create
	}), [
		identifier,
		data,
		isLoading,
		canCreate,
		canUpdate,
		create
	]);
}
var useScheduleDetailPageModel = () => pageStatus(useServerSchedule(useLoadedServer().attributes.uuid, useScheduleId()));
function useScheduleModel() {
	const navigate = useNavigate();
	const { uuid, identifier } = useLoadedServer().attributes;
	const schedule = useLoadedSchedule();
	const [canUpdate, canDelete] = usePermissions(["schedule.update", "schedule.delete"]);
	const { mutateAsync: updateSchedule } = useUpdateServerSchedule();
	const { mutateAsync: runSchedule, isPending: running } = useTriggerServerScheduleExecution(schedule);
	const { mutateAsync: deleteSchedule, isPending: deleting } = useDeleteServerSchedule();
	const createTask = useCreateTask(schedule);
	const taskForm = useTaskForm();
	const { id } = schedule.attributes;
	const actions = useMemo(() => ({
		update: (values) => attempt(() => updateSchedule(updateServerScheduleInput(uuid, id, scheduleValues(values)))),
		run: () => attempt(() => runSchedule(executeServerScheduleInput(uuid, schedule))),
		remove: async () => {
			const removed = await attempt(() => deleteSchedule(deleteServerScheduleInput(uuid, id)));
			if (removed) navigate({
				to: "/server/$id/schedules",
				params: { id: identifier }
			});
			return removed;
		},
		createTask
	}), [
		updateSchedule,
		runSchedule,
		deleteSchedule,
		createTask,
		navigate,
		uuid,
		identifier,
		id,
		schedule
	]);
	return useMemo(() => {
		const summary = scheduleSummary(schedule);
		return {
			schedule: summary,
			taskCount: relationshipData(schedule.attributes.relationships?.tasks).length,
			canUpdate,
			canDelete,
			values: scheduleFormValues(summary),
			running,
			deleting,
			taskForm,
			actions
		};
	}, [
		schedule,
		canUpdate,
		canDelete,
		running,
		deleting,
		taskForm,
		actions
	]);
}
function useScheduleTasksModel() {
	const { uuid } = useLoadedServer().attributes;
	const schedule = useLoadedSchedule();
	const [canUpdate] = usePermissions("schedule.update");
	const create = useCreateTask(schedule);
	const { mutateAsync: updateTask } = useUpdateServerScheduleTask(schedule);
	const { mutateAsync: deleteTask, isPending: deleting } = useDeleteServerScheduleTask(schedule);
	const form = useTaskForm();
	const actions = useMemo(() => ({
		create,
		update: (id, { timeOffset, ...values }) => attempt(() => updateTask(updateScheduleTaskInput(uuid, schedule, id, {
			...values,
			timeOffset: timeOffset ?? 0
		}))),
		remove: (id) => attempt(() => deleteTask(deleteScheduleTaskInput(uuid, schedule, id)))
	}), [
		create,
		updateTask,
		deleteTask,
		uuid,
		schedule
	]);
	return useMemo(() => ({
		tasks: orderedTasks(schedule),
		canUpdate,
		deleting,
		form,
		actions
	}), [
		schedule,
		canUpdate,
		deleting,
		form,
		actions
	]);
}
var resolved = async () => true;
var scheduleFixture = (options = {}) => ({
	id: 1,
	name: "Nightly restart",
	cron: {
		minute: "0",
		hour: "4",
		dayOfMonth: "*",
		month: "*",
		dayOfWeek: "*"
	},
	active: true,
	processing: false,
	onlyWhenOnline: true,
	lastRunAt: "2026-10-11T04:00:00Z",
	nextRunAt: "2026-10-12T04:00:00Z",
	...options
});
var scheduleFixtures = [
	scheduleFixture(),
	scheduleFixture({
		id: 2,
		name: "Hourly backup",
		cron: {
			minute: "0",
			hour: "*/1",
			dayOfMonth: "*",
			month: "*",
			dayOfWeek: "*"
		},
		processing: true,
		lastRunAt: "2026-10-12T09:00:00Z",
		nextRunAt: "2026-10-12T10:00:00Z"
	}),
	scheduleFixture({
		id: 3,
		name: "Weekend event",
		cron: {
			minute: "30",
			hour: "18",
			dayOfMonth: "*",
			month: "*",
			dayOfWeek: "SAT,SUN"
		},
		active: false,
		lastRunAt: null,
		nextRunAt: null
	})
];
var listFixture = (options = {}) => ({
	serverId: "a1b2c3d4",
	schedules: scheduleFixtures,
	loading: false,
	canCreate: true,
	canUpdate: true,
	defaults: newSchedule,
	create: resolved,
	...options
});
var taskFixtures = [
	{
		id: 1,
		sequence: 1,
		action: "command",
		payload: "say Restarting in 5 minutes",
		timeOffset: 0,
		continueOnFailure: true
	},
	{
		id: 2,
		sequence: 2,
		action: "backup",
		payload: "",
		timeOffset: 240,
		continueOnFailure: false
	},
	{
		id: 3,
		sequence: 3,
		action: "power",
		payload: "restart",
		timeOffset: 60,
		continueOnFailure: false
	}
];
var scheduleModelFixture = (options = {}) => ({
	schedule: scheduleFixture(),
	taskCount: taskFixtures.length,
	canUpdate: true,
	canDelete: true,
	values: scheduleFormValues(scheduleFixture()),
	running: false,
	deleting: false,
	taskForm: scheduleTaskForm(3),
	actions: {
		update: resolved,
		run: resolved,
		remove: resolved,
		createTask: resolved
	},
	...options
});
var tasksFixture = (options = {}) => ({
	tasks: taskFixtures,
	canUpdate: true,
	deleting: false,
	form: scheduleTaskForm(3),
	actions: {
		create: resolved,
		update: resolved,
		remove: resolved
	},
	...options
});
implementViews({
	"page.server.schedules": {
		use: useSchedulesPageModel,
		fixtures: pageStatusFixtures
	},
	"server.schedules": {
		use: useScheduleListModel,
		fixtures: {
			schedules: () => listFixture(),
			empty: () => listFixture({ schedules: [] }),
			readOnly: () => listFixture({
				canCreate: false,
				canUpdate: false
			}),
			loading: () => listFixture({
				schedules: [],
				loading: true
			})
		}
	},
	"page.server.schedules.detail": {
		use: useScheduleDetailPageModel,
		fixtures: pageStatusFixtures
	},
	"server.schedule": {
		use: useScheduleModel,
		fixtures: {
			active: () => scheduleModelFixture(),
			processing: () => scheduleModelFixture({ schedule: scheduleFixture({ processing: true }) }),
			inactive: () => scheduleModelFixture({
				schedule: scheduleFixture({
					active: false,
					lastRunAt: null,
					nextRunAt: null
				}),
				taskCount: 0
			}),
			readOnly: () => scheduleModelFixture({
				canUpdate: false,
				canDelete: false
			})
		}
	},
	"server.schedule.tasks": {
		use: useScheduleTasksModel,
		fixtures: {
			tasks: () => tasksFixture(),
			empty: () => tasksFixture({ tasks: [] }),
			readOnly: () => tasksFixture({ canUpdate: false }),
			noBackups: () => tasksFixture({ form: scheduleTaskForm(0) })
		}
	}
});
//#endregion
export { scheduleTaskForm };

//# sourceMappingURL=schedules-B_dBY0Ia.js.map