import { t as clsx } from "./clsx-ChvIn16f.js";
import { t as cn } from "./cn-f7uEsK4g.js";
import { d as isString, u as isObject } from "./client.gen-Ci-zROOW.js";
import React, { Suspense, createElement, useSyncExternalStore } from "react";
import { Link, useLocation, useRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { TriangleAlert } from "lucide-react";
//#region ../../resources/scripts/components/elements/Icon.tsx
/** Renders a lucide icon inline at the surrounding text size (1em). */
var Icon = ({ icon: IconComponent, className, size = "1em", ...rest }) => /* @__PURE__ */ jsx(IconComponent, {
	className: cn("inline-block", className),
	size,
	...rest
});
//#endregion
//#region ../../resources/scripts/components/elements/ErrorBoundary.tsx
var retryButtonClass = ["ml-3 shrink-0 rounded-sm border border-border bg-popover px-2 py-1 text-xs uppercase tracking-wide", "text-foreground transition-colors duration-150 hover:bg-secondary"].join(" ");
var keysChanged = (previous = [], next = []) => previous.length !== next.length || previous.some((key, index) => !Object.is(key, next[index]));
var ErrorBoundary = class extends React.Component {
	state = { hasError: false };
	static getDerivedStateFromError() {
		return { hasError: true };
	}
	componentDidCatch(error) {
		console.error(error);
	}
	componentDidUpdate(prevProps, prevState) {
		if (prevState.hasError && this.state.hasError && keysChanged(prevProps.resetKeys, this.props.resetKeys)) this.reset();
	}
	reset = () => {
		this.setState({ hasError: false });
	};
	retry = () => {
		this.props.onReset?.();
		this.reset();
	};
	render() {
		return this.state.hasError ? /* @__PURE__ */ jsx("div", {
			className: "flex items-center justify-center w-full my-4",
			children: /* @__PURE__ */ jsxs("div", {
				role: "alert",
				className: "flex items-center bg-muted rounded-sm p-3 text-destructive",
				children: [
					/* @__PURE__ */ jsx(Icon, {
						icon: TriangleAlert,
						className: "h-4 w-auto mr-2"
					}),
					/* @__PURE__ */ jsx("p", {
						className: "text-sm text-foreground",
						children: "An error was encountered by the application while rendering this view. Try refreshing the page."
					}),
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: retryButtonClass,
						onClick: this.retry,
						children: "Retry"
					})
				]
			})
		}) : this.props.children;
	}
};
//#endregion
//#region ../../node_modules/class-variance-authority/dist/index.mjs
/**
* Copyright 2022 Joe Bell. All rights reserved.
*
* This file is licensed to you under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with the
* License. You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/ var falsyToString = (value) => typeof value === "boolean" ? `${value}` : value === 0 ? "0" : value;
var cx = clsx;
var cva = (base, config) => (props) => {
	var _config_compoundVariants;
	if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
	const { variants, defaultVariants } = config;
	const getVariantClassNames = Object.keys(variants).map((variant) => {
		const variantProp = props === null || props === void 0 ? void 0 : props[variant];
		const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
		if (variantProp === null) return null;
		const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
		return variants[variant][variantKey];
	});
	const propsWithoutUndefined = props && Object.entries(props).reduce((acc, param) => {
		let [key, value] = param;
		if (value === void 0) return acc;
		acc[key] = value;
		return acc;
	}, {});
	return cx(base, getVariantClassNames, config === null || config === void 0 ? void 0 : (_config_compoundVariants = config.compoundVariants) === null || _config_compoundVariants === void 0 ? void 0 : _config_compoundVariants.reduce((acc, param) => {
		let { class: cvClass, className: cvClassName, ...compoundVariantOptions } = param;
		return Object.entries(compoundVariantOptions).every((param) => {
			let [key, value] = param;
			return Array.isArray(value) ? value.includes({
				...defaultVariants,
				...propsWithoutUndefined
			}[key]) : {
				...defaultVariants,
				...propsWithoutUndefined
			}[key] === value;
		}) ? [
			...acc,
			cvClass,
			cvClassName
		] : acc;
	}, []), props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
};
//#endregion
//#region ../../resources/scripts/themes/primitives.ts
/** The parts each UI primitive's skin styles, in the order they render. */
var UI_PRIMITIVE_PARTS = {
	Alert: [
		"root",
		"icon",
		"body",
		"title",
		"content"
	],
	Avatar: ["root"],
	Badge: ["root"],
	Button: [
		"root",
		"spinner",
		"label"
	],
	Card: [
		"root",
		"header",
		"title",
		"icon",
		"actions",
		"body"
	],
	ChartCard: [
		"root",
		"header",
		"title",
		"legend",
		"body"
	],
	Checkbox: ["root", "indicator"],
	Code: ["root"],
	CopyOnClick: [
		"root",
		"status",
		"message",
		"target"
	],
	Dialog: [
		"backdrop",
		"viewport",
		"container",
		"root",
		"body",
		"content",
		"header",
		"heading",
		"title",
		"description",
		"spacer",
		"footer",
		"close",
		"closeButton",
		"closeIcon",
		"icon",
		"iconGlyph"
	],
	DropdownMenu: [
		"trigger",
		"positioner",
		"root"
	],
	DropdownMenuItem: [
		"root",
		"icon",
		"glyph",
		"text",
		"label",
		"description"
	],
	Empty: [
		"root",
		"header",
		"media",
		"title",
		"description",
		"content"
	],
	FileInput: ["root"],
	Input: ["root"],
	Label: ["root"],
	ListRow: [
		"root",
		"icon",
		"title",
		"description",
		"status"
	],
	NewButton: [
		"root",
		"content",
		"icon"
	],
	NumberInput: ["root", "input"],
	PageFooter: [
		"root",
		"text",
		"link"
	],
	PageHeading: [
		"root",
		"text",
		"title",
		"description",
		"actions"
	],
	Pagination: ["root", "page"],
	ProgressBar: ["root", "indicator"],
	Select: [
		"root",
		"input",
		"trigger",
		"positioner",
		"popup",
		"list",
		"item",
		"itemLabel",
		"indicator",
		"empty",
		"group",
		"groupLabel",
		"summary",
		"preview"
	],
	Spinner: ["root", "container"],
	SpinnerOverlay: ["root", "text"],
	Stat: [
		"root",
		"indicator",
		"icon",
		"glyph",
		"body",
		"label",
		"value",
		"limit"
	],
	Switch: [
		"root",
		"control",
		"thumb",
		"text",
		"label",
		"description"
	],
	Table: [
		"root",
		"empty",
		"scroller",
		"table",
		"head",
		"headerRow",
		"headerCell",
		"body",
		"row",
		"cell"
	],
	TextArea: ["root"],
	Tooltip: ["root", "arrow"]
};
/** `data-ui` of a primitive: `DropdownMenuItem` → `dropdown-menu-item`. */
function primitiveAttribute(name) {
	return name.replaceAll(/[A-Z]/g, (letter, index) => `${index ? "-" : ""}${letter.toLowerCase()}`);
}
//#endregion
//#region ../../resources/scripts/themes/skins.ts
/** Types a skin by the parts and state of the primitive `name`. */
function skin(_name, definition) {
	return definition;
}
var layers = [];
var resolutions = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var noClasses = () => "";
function publish() {
	resolutions.clear();
	for (const listener of listeners) listener();
}
function subscribe(listener) {
	listeners.add(listener);
	return () => {
		listeners.delete(listener);
	};
}
var isExoticComponent = (value) => "$$typeof" in value;
/** A layer's entry for a primitive: a skin, or a component (a function, memo, forwardRef or lazy). */
function layerEntry(layer, name) {
	const entry = layer.skins[name];
	if (entry instanceof Function) return {
		kind: "component",
		component: entry
	};
	if (!isObject(entry)) return;
	return isExoticComponent(entry) ? {
		kind: "component",
		component: entry
	} : {
		kind: "skin",
		skin: entry
	};
}
/** A recipe as a resolver; a function recipe reads `below`, the resolver of the layers under it. */
function compile(layer, name, recipe, below) {
	if (isString(recipe)) return () => recipe;
	if (recipe instanceof Function) return (state) => {
		try {
			const classes = recipe(state, (extra) => cn(below(state), extra));
			return isString(classes) ? classes : "";
		} catch (error) {
			console.error(`[skins] The "${layer}" recipe of ${name} failed.`, error);
			return "";
		}
	};
	const { base, variants = {}, ...config } = recipe;
	return cva(base, {
		...config,
		variants
	});
}
/** Folds the layers bottom up: a part's recipe is the topmost one, the component the topmost replacement. */
function resolve(name) {
	const parts = UI_PRIMITIVE_PARTS[name];
	const resolvers = /* @__PURE__ */ new Map();
	let component;
	for (const layer of layers) {
		const entry = layerEntry(layer, name);
		if (entry?.kind === "component") {
			component = entry.component;
			continue;
		}
		for (const [part, recipe] of Object.entries(entry?.skin ?? {})) if (isString(recipe) || recipe instanceof Function || isObject(recipe)) resolvers.set(part, compile(layer.id, name, recipe, resolvers.get(part) ?? noClasses));
	}
	return {
		skin: Object.fromEntries(parts.map((part) => [part, resolvers.get(part) ?? noClasses])),
		component
	};
}
function resolution(name) {
	let resolved = resolutions.get(name);
	if (!resolved) {
		resolved = resolve(name);
		resolutions.set(name, resolved);
	}
	return resolved;
}
/** A primitive's state as the map recipes read. */
var stateMap = (state) => Object.fromEntries(Object.entries(state ?? {}));
/** `data-*` for each set state value: `true` as a present attribute, `false` and `undefined` as none. */
var stateAttributes = (state) => Object.fromEntries(Object.entries(state).flatMap(([key, value]) => value === void 0 || value === false ? [] : [[`data-${key.replaceAll(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`)}`, value === true ? "" : String(value)]]));
function bind(name, { skin: resolved }, state) {
	const ui = primitiveAttribute(name);
	const bound = stateMap(state);
	const classes = (part, className, partState) => cn((resolved[part] ?? noClasses)({
		...bound,
		...stateMap(partState)
	}), className);
	return Object.assign((part, className, partState) => {
		const own = stateMap(partState);
		return {
			className: classes(part, className, partState) || void 0,
			"data-ui": ui,
			"data-part": part,
			...stateAttributes(part === "root" ? {
				...bound,
				...own
			} : own)
		};
	}, { classes });
}
/**
* Adds a skin layer. Classic is registered first, then each theme of the chain parent first; a layer
* registered again keeps classic first and moves to the top otherwise.
*/
function registerSkins(layerId, skins) {
	const layer = {
		id: layerId,
		skins
	};
	const others = layers.filter((existing) => existing.id !== layerId);
	layers = layerId === "classic" ? [layer, ...others] : [...others, layer];
	publish();
}
/** Drops every layer but classic; used when a theme fails to boot. */
function clearThemeSkins() {
	layers = layers.filter((layer) => layer.id === "classic");
	publish();
}
/** Binds a primitive's skin to its state; re-renders when the layers change. */
function useSkin(name, state) {
	return bind(name, useSyncExternalStore(subscribe, () => resolution(name)), state);
}
/** A presentational primitive: the topmost layer's replacement component, given the same props, or `Core`. */
function replaceable(name, Core) {
	function Primitive(props) {
		const { component } = useSyncExternalStore(subscribe, () => resolution(name));
		return createElement(component ?? Core, props);
	}
	Primitive.displayName = name;
	return Primitive;
}
//#endregion
//#region ../../resources/scripts/components/elements/Spinner.tsx
function CoreSpinner({ size = "base", centered = false, isBlue = false }) {
	const ui = useSkin("Spinner", {
		size,
		blue: isBlue,
		centered
	});
	const spinner = /* @__PURE__ */ jsx("span", { ...ui("root") });
	return centered ? /* @__PURE__ */ jsx("div", {
		...ui("container"),
		children: spinner
	}) : spinner;
}
var Spinner = replaceable("Spinner", CoreSpinner);
Spinner.Size = {
	SMALL: "small",
	BASE: "base",
	LARGE: "large"
};
var LocationErrorBoundary = ({ children }) => {
	return /* @__PURE__ */ jsx(ErrorBoundary, {
		resetKeys: [useLocation({ select: (location) => location.href })],
		children
	});
};
var SuspenseErrorBoundary = ({ children }) => useRouter({ warn: false }) ? /* @__PURE__ */ jsx(LocationErrorBoundary, { children }) : /* @__PURE__ */ jsx(ErrorBoundary, { children });
Spinner.Suspense = ({ children, centered = true, size = Spinner.Size.LARGE, ...props }) => /* @__PURE__ */ jsx(Suspense, {
	fallback: /* @__PURE__ */ jsx(Spinner, {
		centered,
		size,
		...props
	}),
	children: /* @__PURE__ */ jsx(SuspenseErrorBoundary, { children })
});
Spinner.Suspense.displayName = "Spinner.Suspense";
//#endregion
//#region ../../resources/scripts/components/elements/Button.tsx
var buttonState = ({ color, size, isSecondary }, loading = false) => ({
	color: color ?? "primary",
	size: size ?? "small",
	secondary: !!isSecondary,
	loading
});
/** Any element, styled as a button. */
var ButtonStyle = ({ as, color, size, isSecondary, className, ref, ...props }) => {
	return /* @__PURE__ */ jsx(as || "button", {
		ref,
		...useSkin("Button", buttonState({
			color,
			size,
			isSecondary
		}))("root", className),
		...props
	});
};
function CoreButton({ children, isLoading, disabled, type = "button", color, size, isSecondary, className, ref, ...props }) {
	const ui = useSkin("Button", buttonState({
		color,
		size,
		isSecondary
	}, !!isLoading));
	return /* @__PURE__ */ jsxs("button", {
		ref,
		...ui("root", className),
		type,
		disabled: disabled || isLoading,
		"aria-busy": isLoading || void 0,
		...props,
		children: [isLoading && /* @__PURE__ */ jsx("span", {
			...ui("spinner"),
			children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
		}), /* @__PURE__ */ jsx("span", {
			...ui("label"),
			children
		})]
	});
}
/** Defaults to `type="button"`; `isLoading` shows a spinner and disables the button. */
var Button = replaceable("Button", CoreButton);
var TextButton = ({ ref, ...props }) => /* @__PURE__ */ jsx(Button, {
	ref,
	color: "grey",
	...props
});
TextButton.displayName = "Button.Text";
var DangerButton = ({ ref, ...props }) => /* @__PURE__ */ jsx(Button, {
	ref,
	color: "red",
	...props
});
DangerButton.displayName = "Button.Danger";
var ButtonWithVariants = Button;
ButtonWithVariants.Text = TextButton;
ButtonWithVariants.Danger = DangerButton;
var LinkButton = (props) => /* @__PURE__ */ jsx(ButtonStyle, {
	as: "a",
	...props
});
var RouterLinkButton = (props) => /* @__PURE__ */ jsx(ButtonStyle, {
	as: Link,
	...props
});
//#endregion
export { Spinner as a, replaceable as c, UI_PRIMITIVE_PARTS as d, ErrorBoundary as f, RouterLinkButton as i, skin as l, ButtonWithVariants as n, clearThemeSkins as o, Icon as p, LinkButton as r, registerSkins as s, ButtonStyle as t, useSkin as u };

//# sourceMappingURL=Button-BzlrfY24.js.map