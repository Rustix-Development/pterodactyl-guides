import { d as isString } from "./client.gen-Ci-zROOW.js";
import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { t as routeParamStrings } from "./params-HmQaEn9f.js";
import { o as parseRedirectSearch, r as useOpenLoginCheckpoint } from "./navigation-9aP-0Hbq.js";
import { n as fixtureField, t as boundField } from "./forms-DcsxfoFI.js";
import { n as useLoginCheckpoint, t as useLogin } from "./queries-DA42aKcL.js";
import { t as useCaptcha } from "./captcha-BRyXUbvn.js";
import { useState } from "react";
import { useLocation, useParams, useSearch } from "@tanstack/react-router";
import { useField, useForm, useStore } from "@tanstack/react-form";
//#region ../../resources/scripts/router/routeSlots.ts
var useRouteSlotData = () => {
	const location = useLocation();
	const params = useParams({ strict: false });
	return {
		pathname: location.pathname,
		search: location.search,
		params: routeParamStrings(params)
	};
};
//#endregion
//#region ../../resources/scripts/views/auth/login.ts
var required = (message) => ({ onChange: ({ value }) => value.length >= 1 ? void 0 : message });
function useLoginFormModel() {
	const { redirect } = parseRedirectSearch(useSearch({ strict: false }));
	const openCheckpoint = useOpenLoginCheckpoint();
	const route = useRouteSlotData();
	const login = useLogin();
	const { Captcha, token } = useCaptcha();
	const form = useForm({
		defaultValues: {
			username: "",
			password: ""
		},
		onSubmit: async ({ value }) => {
			const captcha = await token();
			if (captcha === null) return;
			try {
				const response = await login.mutateAsync({ body: {
					user: value.username,
					password: value.password,
					"g-recaptcha-response": captcha
				} });
				if (response.data.complete) {
					window.location.assign(redirect || response.data.intended || "/");
					return;
				}
				openCheckpoint(response.data.confirmation_token);
			} catch {}
		}
	});
	const username = useField({
		form,
		name: "username",
		validators: required("A username or email must be provided.")
	});
	const password = useField({
		form,
		name: "password",
		validators: required("Please enter your account password.")
	});
	const canSubmit = useStore(form.store, (state) => state.canSubmit);
	const submitting = useStore(form.store, (state) => state.isSubmitting) || login.isPending;
	return {
		fields: {
			username: boundField(username, {
				type: "text",
				autoComplete: "username",
				disabled: submitting
			}),
			password: boundField(password, {
				type: "password",
				autoComplete: "current-password",
				disabled: submitting
			})
		},
		submit: () => void form.handleSubmit(),
		canSubmit,
		submitting,
		Captcha,
		forgotPassword: { to: "/auth/password" },
		route
	};
}
function useCheckpointFormModel() {
	const state = useLocation().state;
	const token = "token" in state && isString(state.token) ? state.token : "";
	const { redirect } = parseRedirectSearch(useSearch({ strict: false }));
	const checkpoint = useLoginCheckpoint();
	const [recovery, setRecovery] = useState(false);
	const form = useForm({
		defaultValues: {
			code: "",
			recoveryCode: ""
		},
		onSubmit: async ({ value }) => {
			try {
				const response = await checkpoint.mutateAsync({ body: {
					confirmation_token: token,
					authentication_code: value.code,
					recovery_token: value.recoveryCode || void 0
				} });
				if (response.data.complete) window.location.assign(redirect || response.data.intended || "/");
			} catch {}
		}
	});
	const code = useField({
		form,
		name: "code"
	});
	const recoveryCode = useField({
		form,
		name: "recoveryCode"
	});
	const canSubmit = useStore(form.store, (state) => state.canSubmit);
	const submitting = useStore(form.store, (state) => state.isSubmitting);
	return {
		fields: { code: boundField(recovery ? recoveryCode : code, {
			type: "text",
			autoComplete: "one-time-code"
		}) },
		submit: () => void form.handleSubmit(),
		canSubmit,
		submitting,
		recovery,
		toggleRecovery: () => {
			form.setFieldValue("code", "");
			form.setFieldValue("recoveryCode", "");
			setRecovery((current) => !current);
		},
		login: {
			to: "/auth/login",
			search: { redirect }
		}
	};
}
var noop = () => {};
var route = {
	pathname: "/auth/login",
	search: {},
	params: {}
};
function loginFixture(values = {
	username: "",
	password: ""
}, overrides = {}) {
	const disabled = overrides.submitting ?? false;
	return {
		fields: {
			username: fixtureField("username", {
				type: "text",
				autoComplete: "username",
				disabled
			}, values.username),
			password: fixtureField("password", {
				type: "password",
				autoComplete: "current-password",
				disabled
			}, values.password)
		},
		submit: noop,
		canSubmit: true,
		submitting: false,
		Captcha: null,
		forgotPassword: { to: "/auth/password" },
		route,
		...overrides
	};
}
var checkpointFixture = (recovery) => ({
	fields: { code: fixtureField(recovery ? "recoveryCode" : "code", {
		type: "text",
		autoComplete: "one-time-code"
	}) },
	submit: noop,
	canSubmit: true,
	submitting: false,
	recovery,
	toggleRecovery: noop,
	login: {
		to: "/auth/login",
		search: {}
	}
});
implementViews({
	"page.auth.login": {
		use: useLoginFormModel,
		fixtures: {
			default: () => loginFixture(),
			invalid: () => {
				const model = loginFixture();
				return {
					...model,
					fields: {
						username: {
							...model.fields.username,
							error: "A username or email must be provided."
						},
						password: {
							...model.fields.password,
							error: "Please enter your account password."
						}
					},
					canSubmit: false
				};
			},
			submitting: () => loginFixture({
				username: "alex",
				password: "correct horse"
			}, { submitting: true })
		}
	},
	"page.auth.checkpoint": {
		use: useCheckpointFormModel,
		fixtures: {
			code: () => checkpointFixture(false),
			recovery: () => checkpointFixture(true)
		}
	}
});
//#endregion

//# sourceMappingURL=login-BiVuGDpr.js.map