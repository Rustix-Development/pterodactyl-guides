import { t as cn } from "./cn-f7uEsK4g.js";
import { s as getObjectKeys } from "./client.gen-Ci-zROOW.js";
import { Gt as implementViews } from "./notifications-Ebj0Q0Io.js";
import { a as useCurrentServerIdentifier } from "./queries-D_-2KdyF.js";
import { n as usePermissions } from "./usePermissions-pEpnhvzH.js";
import { a as useServerGraphs, d as CHART_WINDOW_MS, l as useSocketConnected, o as useServerStats, s as useServerStatus, u as useSocketInstance } from "./server-U1WA-Nu8.js";
import { n as onThemeChange } from "./theme-BChAVzYS.js";
import { n as ip, r as mbToBytes } from "./formatters-BBp7wFVw.js";
import { n as SocketRequest, t as SocketEvent } from "./events-BZtD8HxQ.js";
import { r as statMetric } from "./state-CUrz93jS.js";
import { t as createTestServer } from "./fixtures-sueNo-ZT.js";
import { n as relationshipData } from "./relationships-CSicEn-V.js";
import { t as useLoadedServer } from "./loadedServer-Bw7lSBA6.js";
import { n as featureViews } from "./features-Dlz0IKyT.js";
import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region ../../resources/scripts/plugins/usePersistedState.ts
var readPersistedValue = (key, defaultValue) => {
	try {
		const item = localStorage.getItem(key);
		return item === null ? defaultValue : JSON.parse(item);
	} catch (e) {
		console.warn("Failed to retrieve persisted value from store.", e);
		return defaultValue;
	}
};
function usePersistedState(key, defaultValue) {
	const defaultValueRef = useRef(defaultValue);
	const [persisted, setPersisted] = useState(() => ({
		key,
		value: readPersistedValue(key, defaultValue)
	}));
	useEffect(() => {
		defaultValueRef.current = defaultValue;
	}, [defaultValue]);
	useEffect(() => {
		setPersisted((current) => current.key === key ? current : {
			key,
			value: readPersistedValue(key, defaultValueRef.current)
		});
	}, [key]);
	useEffect(() => {
		if (persisted.key !== key) return;
		const value = JSON.stringify(persisted.value);
		if (value === void 0) localStorage.removeItem(key);
		else localStorage.setItem(key, value);
	}, [key, persisted]);
	const setState = useCallback((next) => {
		setPersisted((current) => {
			const currentValue = current.key === key ? current.value : readPersistedValue(key, defaultValueRef.current);
			return {
				key,
				value: next instanceof Function ? next(currentValue) : next
			};
		});
	}, [key]);
	return [persisted.key === key ? persisted.value : readPersistedValue(key, defaultValueRef.current), setState];
}
//#endregion
//#region ../../resources/scripts/components/server/console/ConsoleScrollbar.tsx
var MIN_THUMB_HEIGHT = "1.25rem";
/**
* Ghostty paints its own scrollbar over the last columns of output, so the console draws this
* one in the gutter FitAddon leaves beside the canvas instead. It is a pointer control only;
* wheel, touch and keyboard scrolling reach the terminal directly.
*/
function ConsoleScrollbar({ scroll, terminal }) {
	const { viewportY, scrollbackLength, rows } = useSyncExternalStore(scroll.subscribe, scroll.getSnapshot);
	const track = useRef(null);
	const thumb = useRef(null);
	const grab = useRef(null);
	if (scrollbackLength === 0) return null;
	const height = `max(${MIN_THUMB_HEIGHT}, var(--thumb-size))`;
	const thumbStyle = {
		"--thumb-size": `${rows / (rows + scrollbackLength) * 100}%`,
		"--thumb-position": 1 - viewportY / scrollbackLength,
		height,
		top: `calc((100% - ${height}) * var(--thumb-position))`
	};
	const moveThumbTo = (clientY) => {
		const term = terminal.current;
		if (!term || !track.current || !thumb.current || grab.current === null) return;
		const { top, height: trackHeight } = track.current.getBoundingClientRect();
		const travel = trackHeight - thumb.current.offsetHeight;
		const target = travel > 0 ? Math.min(1, Math.max(0, (clientY - top - grab.current) / travel)) : 1;
		term.scrollLines(term.getViewportY() - term.getScrollbackLength() * (1 - target));
	};
	const onPointerDown = (event) => {
		if (event.button !== 0 || !thumb.current) return;
		grab.current = event.target === thumb.current ? event.clientY - thumb.current.getBoundingClientRect().top : thumb.current.offsetHeight / 2;
		event.currentTarget.setPointerCapture(event.pointerId);
		event.preventDefault();
		moveThumbTo(event.clientY);
	};
	const release = () => {
		grab.current = null;
	};
	return /* @__PURE__ */ jsx("div", {
		ref: track,
		"aria-hidden": true,
		className: "group absolute inset-y-1 right-0 w-3.5 touch-none",
		onPointerDown,
		onPointerMove: (event) => moveThumbTo(event.clientY),
		onPointerUp: release,
		onPointerCancel: release,
		children: /* @__PURE__ */ jsx("div", {
			ref: thumb,
			className: "absolute inset-x-0.75 rounded-full bg-scrollbar-thumb-fill transition-colors hover:bg-scrollbar-thumb group-active:bg-scrollbar-thumb",
			style: thumbStyle
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/server/transfer.ts
var transferStatuses = new Map([
	["pending", "pending"],
	["processing", "processing"],
	["cancelling", "cancelling"],
	["failure", "failed"],
	["failed", "failed"],
	["cancelled", "failed"],
	["completed", "completed"],
	["success", "success"]
]);
var normalizeTransferStatus = (value) => transferStatuses.get(value.trim().toLowerCase()) ?? null;
//#endregion
//#region ../../resources/scripts/components/server/console/useConsoleSocketLogs.ts
var TERMINAL_PRELUDE = "\x1B[1m\x1B[33mcontainer@pterodactyl~ \x1B[0m";
var THROTTLED_EVENT = "throttled";
var SEND_LOGS_RETRY_MS = 5e3;
var MAX_RETAINED_TRANSFER_LINES = 1e3;
var formatLine = (line, prelude = false) => `${(prelude ? TERMINAL_PRELUDE : "") + line.replace(/(?:\r\n|\r|\n)$/im, "")}\u001b[0m`;
/** Streams the server's socket output into the terminal, requesting log history on each connection. */
var useConsoleSocketLogs = ({ connected, instance, terminal, terminalReady }) => {
	const transferLines = useRef([]);
	useEffect(() => {
		const term = terminal.current;
		if (!terminalReady || !term || !connected || !instance) return;
		const writeTransferLine = (line) => {
			const lines = transferLines.current;
			lines.push(line);
			if (lines.length > MAX_RETAINED_TRANSFER_LINES) lines.splice(0, lines.length - MAX_RETAINED_TRANSFER_LINES);
			term.writeln(line);
		};
		const handleTransferStatus = (status) => {
			if (normalizeTransferStatus(status) === "failed") writeTransferLine(`${TERMINAL_PRELUDE}Transfer has failed.\u001b[0m`);
		};
		const handleDaemonErrorOutput = (line) => term.writeln(`${TERMINAL_PRELUDE}\u001b[1m\u001b[41m${formatLine(line)}`);
		const handlePowerChangeEvent = (state) => term.writeln(`${TERMINAL_PRELUDE}Server marked as ${state}...\u001b[0m`);
		const listeners = [
			[SocketEvent.STATUS, handlePowerChangeEvent],
			[SocketEvent.CONSOLE_OUTPUT, (line) => term.writeln(formatLine(line))],
			[SocketEvent.INSTALL_OUTPUT, (line) => term.writeln(formatLine(line))],
			[SocketEvent.TRANSFER_LOGS, (line) => writeTransferLine(formatLine(line))],
			[SocketEvent.TRANSFER_STATUS, handleTransferStatus],
			[SocketEvent.DAEMON_MESSAGE, (line) => term.writeln(formatLine(line, true))],
			[SocketEvent.DAEMON_ERROR, handleDaemonErrorOutput]
		];
		const requestHistory = () => {
			term.clear();
			for (const line of transferLines.current) term.writeln(line);
			instance.send(SocketRequest.SEND_LOGS);
		};
		let retryTimer;
		const handleThrottled = (request) => {
			if (request !== SocketRequest.SEND_LOGS || retryTimer !== void 0) return;
			retryTimer = setTimeout(() => {
				retryTimer = void 0;
				requestHistory();
			}, SEND_LOGS_RETRY_MS);
		};
		for (const [event, listener] of listeners) instance.addListener(event, listener);
		instance.addListener(THROTTLED_EVENT, handleThrottled);
		requestHistory();
		return () => {
			clearTimeout(retryTimer);
			for (const [event, listener] of listeners) instance.removeListener(event, listener);
			instance.removeListener(THROTTLED_EVENT, handleThrottled);
		};
	}, [
		connected,
		instance,
		terminal,
		terminalReady
	]);
};
//#endregion
//#region ../../resources/scripts/lib/color.ts
var canvas;
var hex = (value) => value.toString(16).padStart(2, "0");
/**
* Any colour the browser understands, such as `oklch()`, `color-mix()` or a name, as `#rrggbb`, or
* `rgba()` when translucent: the forms canvas engines like the terminal's parse. The browser paints
* it on a pixel and reads it back. Without a canvas, the colour is returned as it is.
*/
function toRgbColor(color) {
	canvas ??= document.createElement("canvas").getContext("2d", { willReadFrequently: true });
	if (!canvas) return color;
	canvas.clearRect(0, 0, 1, 1);
	canvas.fillStyle = "transparent";
	canvas.fillStyle = color;
	canvas.fillRect(0, 0, 1, 1);
	const [red, green, blue, alpha] = canvas.getImageData(0, 0, 1, 1).data;
	return alpha === 255 ? `#${hex(red)}${hex(green)}${hex(blue)}` : `rgba(${red}, ${green}, ${blue}, ${Math.round(alpha / 255 * 1e3) / 1e3})`;
}
//#endregion
//#region ../../resources/scripts/components/server/console/TerminalScrollStore.ts
var NO_HISTORY = {
	viewportY: 0,
	scrollbackLength: 0,
	rows: 0
};
var sameScroll = (a, b) => a.viewportY === b.viewportY && a.scrollbackLength === b.scrollbackLength && a.rows === b.rows;
/**
* Publishes a terminal's scroll position for `useSyncExternalStore`, at most once a frame so a
* busy console doesn't re-render on every line. Ghostty reports scrolls and resizes but not the
* history a write adds, so writes are watched as well.
*/
var TerminalScrollStore = class {
	terminal = null;
	snapshot = NO_HISTORY;
	frame = 0;
	listeners = /* @__PURE__ */ new Set();
	subscribe = (listener) => {
		this.listeners.add(listener);
		return () => {
			this.listeners.delete(listener);
		};
	};
	getSnapshot = () => this.snapshot;
	/** Follows `terminal` until `detach()`; call it before the terminal is disposed. */
	attach(terminal) {
		const write = terminal.write.bind(terminal);
		this.terminal = terminal;
		terminal.onScroll(this.schedule);
		terminal.onResize(this.schedule);
		terminal.write = (data, callback) => {
			write(data, callback);
			this.schedule();
		};
		this.schedule();
	}
	detach() {
		cancelAnimationFrame(this.frame);
		this.frame = 0;
		this.terminal = null;
		this.publish(NO_HISTORY);
	}
	schedule = () => {
		if (this.frame === 0) this.frame = requestAnimationFrame(this.sync);
	};
	sync = () => {
		this.frame = 0;
		if (this.terminal) this.publish({
			viewportY: this.terminal.getViewportY(),
			scrollbackLength: this.terminal.getScrollbackLength(),
			rows: this.terminal.rows
		});
	};
	publish(next) {
		if (sameScroll(next, this.snapshot)) return;
		this.snapshot = next;
		for (const listener of this.listeners) listener();
	}
};
//#endregion
//#region ../../resources/scripts/components/server/console/TouchScrollAddon.ts
var FLING_DECELERATION = .998;
var FLING_MIN_VELOCITY = .005;
var FLING_RELEASE_MS = 100;
var VELOCITY_SMOOTHING = .8;
/**
* Ghostty scrolls its history only on wheel events. This scrolls it with a one-finger
* vertical swipe and lets a fast swipe keep going after the finger lifts. At the top or
* bottom of the history the swipe is left alone, so the page scrolls instead.
*/
var TouchScrollAddon = class {
	terminal;
	listeners = new AbortController();
	lastY = 0;
	lastTime = 0;
	velocity = 0;
	frame = 0;
	constructor(terminal) {
		this.terminal = terminal;
	}
	activate() {
		const element = this.terminal.element;
		if (!element) throw new Error("TouchScrollAddon must be loaded after the terminal is opened.");
		const signal = this.listeners.signal;
		element.addEventListener("touchstart", this.onTouchStart, {
			passive: true,
			signal
		});
		element.addEventListener("touchmove", this.onTouchMove, {
			passive: false,
			signal
		});
		element.addEventListener("touchend", this.onTouchEnd, {
			passive: true,
			signal
		});
	}
	dispose() {
		this.listeners.abort();
		cancelAnimationFrame(this.frame);
	}
	onTouchStart = (event) => {
		cancelAnimationFrame(this.frame);
		this.anchor(event);
	};
	onTouchMove = (event) => {
		const touch = event.touches.length === 1 ? event.touches[0] : void 0;
		if (!touch) return;
		const lines = (this.lastY - touch.clientY) / (this.terminal.renderer?.getMetrics().height ?? 20);
		const instant = lines / Math.max(1, event.timeStamp - this.lastTime);
		this.velocity = VELOCITY_SMOOTHING * instant + (1 - VELOCITY_SMOOTHING) * this.velocity;
		this.lastY = touch.clientY;
		this.lastTime = event.timeStamp;
		if (this.scrollBy(lines) && event.cancelable) event.preventDefault();
	};
	onTouchEnd = (event) => {
		if (event.touches.length > 0) this.anchor(event);
		else if (event.timeStamp - this.lastTime < FLING_RELEASE_MS) this.frame = requestAnimationFrame(this.fling(performance.now()));
	};
	anchor(event) {
		this.lastY = event.touches[0]?.clientY ?? 0;
		this.lastTime = event.timeStamp;
		this.velocity = 0;
	}
	fling(previous) {
		return (now) => {
			const elapsed = Math.max(0, now - previous);
			this.velocity *= FLING_DECELERATION ** elapsed;
			if (Math.abs(this.velocity) >= FLING_MIN_VELOCITY && this.scrollBy(this.velocity * elapsed)) this.frame = requestAnimationFrame(this.fling(now));
		};
	}
	/** Scrolls toward newer output for positive `lines`; false once the history can't move that way. */
	scrollBy(lines) {
		const before = this.terminal.getViewportY();
		this.terminal.scrollLines(lines);
		return this.terminal.getViewportY() !== before;
	}
};
//#endregion
//#region ../../resources/scripts/components/server/console/useTerminal.ts
var TERMINAL_COLOR_VARS = {
	background: "--terminal-background",
	foreground: "--terminal-foreground",
	cursor: "--terminal-cursor",
	cursorAccent: "--terminal-cursor",
	selectionBackground: "--terminal-selection",
	selectionForeground: "--terminal-selection-foreground",
	black: "--terminal-ansi-black",
	red: "--terminal-ansi-red",
	green: "--terminal-ansi-green",
	yellow: "--terminal-ansi-yellow",
	blue: "--terminal-ansi-blue",
	magenta: "--terminal-ansi-magenta",
	cyan: "--terminal-ansi-cyan",
	white: "--terminal-ansi-white",
	brightBlack: "--terminal-ansi-bright-black",
	brightRed: "--terminal-ansi-bright-red",
	brightGreen: "--terminal-ansi-bright-green",
	brightYellow: "--terminal-ansi-bright-yellow",
	brightBlue: "--terminal-ansi-bright-blue",
	brightMagenta: "--terminal-ansi-bright-magenta",
	brightCyan: "--terminal-ansi-bright-cyan",
	brightWhite: "--terminal-ansi-bright-white"
};
var buildTerminalStyle = () => {
	const probe = document.createElement("span");
	probe.style.cssText = "position:absolute;visibility:hidden;pointer-events:none";
	probe.style.fontFamily = "var(--font-mono)";
	probe.style.fontSize = "var(--text-xs)";
	document.body.appendChild(probe);
	const theme = {};
	for (const slot of getObjectKeys(TERMINAL_COLOR_VARS)) {
		probe.style.color = `var(${TERMINAL_COLOR_VARS[slot]})`;
		theme[slot] = toRgbColor(getComputedStyle(probe).color);
	}
	const computedStyle = getComputedStyle(probe);
	const fontSize = Number.parseFloat(computedStyle.fontSize);
	const fontFamily = computedStyle.fontFamily;
	probe.remove();
	if (!Number.isFinite(fontSize) || fontFamily.length === 0) throw new Error("Terminal font tokens could not be resolved.");
	return {
		fontFamily,
		fontSize,
		theme
	};
};
var terminalProps = {
	disableStdin: true,
	cursorStyle: "underline",
	cursorBlink: false,
	allowTransparency: true,
	rows: 30,
	smoothScrollDuration: 0
};
var countLineFeeds = (data) => (data instanceof Uint8Array ? data : new TextEncoder().encode(data)).filter((byte) => byte === 10).length;
/** Ghostty jumps to the bottom on every write; keep a reader who scrolled up on the same lines, even as old history is trimmed. */
var preserveScrollPositionOnWrite = (term) => {
	const write = term.write.bind(term);
	term.write = (data, callback) => {
		const viewportY = term.getViewportY();
		if (viewportY === 0) {
			write(data, callback);
			return;
		}
		const scrollbackLength = term.getScrollbackLength();
		write(data, callback);
		const grown = term.getScrollbackLength() - scrollbackLength;
		term.scrollLines(-(viewportY + (grown < 0 ? countLineFeeds(data) : grown)));
	};
};
/**
* Draws the viewport snapped to a whole line, since wheel and touch scrolling leave it between
* lines. Never draws Ghostty's scrollbar: it paints over the last columns of output rather than
* the gutter FitAddon reserves, so ConsoleScrollbar draws one in the gutter instead.
*/
var adjustRendering = (term) => {
	const renderer = term.renderer;
	if (!renderer) return;
	const render = renderer.render.bind(renderer);
	renderer.render = (buffer, forceAll, viewportY = 0, scrollbackProvider) => render(buffer, forceAll, Math.floor(viewportY), scrollbackProvider, 0);
};
var CANVAS_SCROLLBAR_HIT_WIDTH = 12;
/**
* Ghostty still treats a press on the right edge of the canvas as grabbing the scrollbar it no
* longer draws, which would jump the history when someone clicks the end of a line. Registered
* before `open()` so it runs ahead of Ghostty's own listener on the mount.
*/
var ignoreCanvasScrollbarPresses = (mount, signal) => {
	mount.addEventListener("mousedown", (event) => {
		const canvas = event.target;
		if (canvas instanceof HTMLCanvasElement && event.offsetX >= canvas.clientWidth - CANVAS_SCROLLBAR_HIT_WIDTH) event.stopImmediatePropagation();
	}, {
		capture: true,
		signal
	});
};
/** The canvas has no DOM selection, so copy reads the terminal's own selection. */
var copySelectionOnShortcut = (term) => {
	term.attachCustomKeyEventHandler((e) => {
		if (!(e.ctrlKey || e.metaKey) || e.key !== "c") return true;
		const selection = term.getSelection();
		if (!selection) return true;
		navigator.clipboard?.writeText(selection).catch(() => {});
		return false;
	});
};
/** Opens a read-only console terminal in `mount`, sized to fill it; `signal` removes its listeners on the mount. */
var openTerminal = ({ FitAddon, Terminal: GhosttyTerminal, UrlRegexProvider }, mount, options, signal) => {
	const term = new GhosttyTerminal({
		...terminalProps,
		...options
	});
	const fit = new FitAddon();
	mount.setAttribute("inputmode", "none");
	ignoreCanvasScrollbarPresses(mount, signal);
	term.open(mount);
	term.textarea?.setAttribute("inputmode", "none");
	term.loadAddon(fit);
	term.loadAddon(new TouchScrollAddon(term));
	fit.fit();
	fit.observeResize();
	term.registerLinkProvider(new UrlRegexProvider(term));
	preserveScrollPositionOnWrite(term);
	adjustRendering(term);
	copySelectionOnShortcut(term);
	return {
		term,
		fit
	};
};
/** Runs after the browser has laid out and painted the next frame. */
var afterNextLayout = (callback) => {
	requestAnimationFrame(() => requestAnimationFrame(callback));
};
var hasStyleChanged = (appliedStyle) => {
	try {
		return JSON.stringify(buildTerminalStyle()) !== appliedStyle;
	} catch {
		return false;
	}
};
/** Opens the console terminal in the element given to `ref`; Ghostty loads with the first one. */
var useTerminal = () => {
	const [mount, ref] = useState(null);
	const terminal = useRef(null);
	const [terminalReady, setTerminalReady] = useState(false);
	const [scroll] = useState(() => new TerminalScrollStore());
	const [terminalError, setTerminalError] = useState(null);
	const [revision, setRevision] = useState(0);
	const appliedStyle = useRef(null);
	useEffect(() => onThemeChange(() => {
		if (appliedStyle.current !== null && hasStyleChanged(appliedStyle.current)) setRevision((current) => current + 1);
	}), []);
	const retry = useCallback(() => {
		setTerminalError(null);
		setRevision((current) => current + 1);
	}, []);
	useEffect(() => {
		let cancelled = false;
		let mountedTerminal = null;
		const listeners = new AbortController();
		if (!mount) return;
		import("./ghostty-web-DY0U22Rz.js").then(async (module) => ({
			module,
			ghostty: await module.Ghostty.load()
		})).then(({ module, ghostty }) => {
			if (cancelled) return;
			const style = buildTerminalStyle();
			const { term, fit } = openTerminal(module, mount, {
				...style,
				ghostty
			}, listeners.signal);
			scroll.attach(term);
			terminal.current = term;
			appliedStyle.current = JSON.stringify(style);
			mountedTerminal = term;
			setTerminalReady(true);
			afterNextLayout(() => {
				if (!cancelled) fit.fit();
			});
		}).catch((error) => {
			if (!cancelled) {
				console.error("Failed to load the console terminal.", error);
				setTerminalError(error instanceof Error ? error : /* @__PURE__ */ new Error("Failed to load the console terminal."));
			}
		});
		return () => {
			cancelled = true;
			listeners.abort();
			scroll.detach();
			mountedTerminal?.dispose();
			terminal.current = null;
			appliedStyle.current = null;
			setTerminalReady(false);
		};
	}, [
		mount,
		revision,
		scroll
	]);
	return {
		ref,
		retry,
		scroll,
		terminal,
		terminalError,
		terminalReady
	};
};
//#endregion
//#region ../../resources/scripts/components/server/console/useServerTerminal.tsx
var HISTORY_LENGTH = 32;
var noHistory = [];
/** The canvas of one terminal, with the scrollbar drawn in the gutter beside it. */
function createTerminalCanvas({ ref, scroll, terminal }) {
	return function TerminalCanvas({ className }) {
		return /* @__PURE__ */ jsxs("div", {
			className: cn("relative h-full w-full", className),
			children: [/* @__PURE__ */ jsx("div", {
				className: "h-full w-full",
				ref
			}), /* @__PURE__ */ jsx(ConsoleScrollbar, {
				scroll,
				terminal
			})]
		});
	};
}
/** The command line: its value, the history it steps through, and sending. */
function useConsoleCommand(serverId, socket, connected) {
	const [allowed] = usePermissions(["control.console"]);
	const [stored, setHistory] = usePersistedState(`${serverId}:command_history`, []);
	const [value, setValue] = useState("");
	const index = useRef(-1);
	const history = stored ?? noHistory;
	return useMemo(() => {
		const step = (next) => {
			index.current = next;
			setValue(history[next] || "");
		};
		return {
			allowed,
			disabled: !socket || !connected,
			value,
			history,
			setValue,
			previous: () => step(Math.min(index.current + 1, history.length - 1)),
			next: () => step(Math.max(index.current - 1, -1)),
			submit: () => {
				if (!value.length) return;
				setHistory((previous) => [value, ...previous ?? []].slice(0, HISTORY_LENGTH));
				index.current = -1;
				socket?.send(SocketRequest.SEND_COMMAND, value);
				setValue("");
			}
		};
	}, [
		allowed,
		socket,
		connected,
		value,
		history,
		setHistory
	]);
}
/** The server's console: a terminal fed by the websocket, and the command line. */
function useServerTerminal() {
	const { ref, retry, scroll, terminal, terminalError, terminalReady } = useTerminal();
	const scrolledUp = useSyncExternalStore(scroll.subscribe, () => scroll.getSnapshot().viewportY > .5);
	const connected = useSocketConnected();
	const instance = useSocketInstance();
	const command = useConsoleCommand(useCurrentServerIdentifier() ?? "", instance, connected);
	const [Terminal] = useState(() => createTerminalCanvas({
		ref,
		scroll,
		terminal
	}));
	useConsoleSocketLogs({
		connected,
		instance,
		terminal,
		terminalReady
	});
	return useMemo(() => ({
		Terminal,
		loading: !terminalError && (!connected || !terminalReady),
		failed: !!terminalError,
		retry,
		scrolledUp,
		scrollToBottom: () => terminal.current?.scrollToBottom(),
		command
	}), [
		Terminal,
		terminalError,
		connected,
		terminalReady,
		retry,
		scrolledUp,
		terminal,
		command
	]);
}
/** A terminal showing fixed output, for fixtures. */
function createSampleTerminal(lines) {
	return function SampleTerminal({ className }) {
		const { ref, scroll, terminal, terminalReady } = useTerminal();
		const [Canvas] = useState(() => createTerminalCanvas({
			ref,
			scroll,
			terminal
		}));
		useEffect(() => {
			if (terminalReady) for (const line of lines) terminal.current?.writeln(line);
		}, [terminal, terminalReady]);
		return /* @__PURE__ */ jsx(Canvas, { className });
	};
}
//#endregion
//#region ../../resources/scripts/views/server/console.ts
function consoleNotice({ attributes }) {
	if (attributes.is_node_under_maintenance) return "maintenance";
	if (attributes.status === "installing" || attributes.status === "install_failed") return "installing";
	return attributes.is_transferring ? "transferring" : null;
}
function useServerConsoleModel() {
	const server = useLoadedServer();
	return useMemo(() => ({
		name: server.attributes.name,
		description: server.attributes.description,
		notice: consoleNotice(server),
		server,
		features: featureViews(server.attributes.egg_features ?? [])
	}), [server]);
}
function useServerPowerModel() {
	const server = useLoadedServer();
	const state = useServerStatus();
	const connected = useSocketConnected();
	const instance = useSocketInstance();
	const [start, stop, restart] = usePermissions([
		"control.start",
		"control.stop",
		"control.restart"
	]);
	return useMemo(() => {
		const send = (action) => () => instance?.send(SocketRequest.SET_STATE, action);
		return {
			state,
			connected,
			permissions: {
				start,
				stop,
				restart
			},
			enabled: {
				start: connected && state === "offline",
				stop: connected && state !== "offline",
				restart: connected && state !== null,
				kill: connected
			},
			killable: state === "stopping",
			actions: {
				start: send("start"),
				stop: send("stop"),
				restart: send("restart"),
				kill: send("kill")
			},
			server
		};
	}, [
		server,
		state,
		connected,
		instance,
		start,
		stop,
		restart
	]);
}
function primaryAddress({ attributes }) {
	const allocation = relationshipData(attributes.relationships?.allocations).find((candidate) => candidate.attributes.is_default)?.attributes;
	return allocation ? `${allocation.ip_alias || ip(allocation.ip)}:${allocation.port}` : null;
}
function useServerStatsModel() {
	const server = useLoadedServer();
	const state = useServerStatus();
	const stats = useServerStats();
	return useMemo(() => {
		const { limits } = server.attributes;
		return {
			state,
			address: primaryAddress(server),
			uptime: stats.uptime,
			cpu: statMetric(stats.cpu, limits.cpu),
			memory: statMetric(stats.memory, mbToBytes(limits.memory)),
			disk: statMetric(stats.disk, mbToBytes(limits.disk)),
			network: {
				rx: stats.rx,
				tx: stats.tx
			}
		};
	}, [
		server,
		state,
		stats
	]);
}
function useServerGraphsModel() {
	const { cpu, memory } = useLoadedServer().attributes.limits;
	const state = useServerStatus();
	const graphs = useServerGraphs();
	return useMemo(() => ({
		live: state === "starting" || state === "running" || state === "stopping",
		windowMs: CHART_WINDOW_MS,
		cpu: {
			points: graphs.cpu,
			limit: cpu
		},
		memory: {
			points: graphs.memory,
			limit: memory
		},
		network: { points: graphs.network }
	}), [
		state,
		graphs,
		cpu,
		memory
	]);
}
var noop = () => {};
var PRELUDE = "\x1B[1m\x1B[33mcontainer@pterodactyl~ \x1B[0m";
var RunningTerminal = createSampleTerminal([
	`${PRELUDE}Server marked as starting...`,
	"[12:00:01 INFO]: Starting minecraft server version 1.21.4",
	"[12:00:02 INFO]: Loading properties",
	"[12:00:04 INFO]: Preparing level \"world\"",
	"[12:00:09 INFO]: Done (7.412s)! For help, type \"help\"",
	`${PRELUDE}Server marked as running...`
]);
var OfflineTerminal = createSampleTerminal([`${PRELUDE}Server marked as offline...`]);
var command = (options = {}) => ({
	allowed: true,
	disabled: false,
	value: "",
	history: ["say Hello", "list"],
	setValue: noop,
	previous: noop,
	next: noop,
	submit: noop,
	...options
});
var terminalFixture = (options = {}) => ({
	Terminal: RunningTerminal,
	loading: false,
	failed: false,
	retry: noop,
	scrolledUp: false,
	scrollToBottom: noop,
	command: command(),
	...options
});
var fixtureServer = (status = null) => createTestServer({
	identifier: "a1b2c3d4",
	name: "Survival",
	status
});
var powerFixture = (state, options = {}) => ({
	state,
	connected: true,
	permissions: {
		start: true,
		stop: true,
		restart: true
	},
	enabled: {
		start: state === "offline",
		stop: state !== "offline",
		restart: state !== null,
		kill: true
	},
	killable: state === "stopping",
	actions: {
		start: noop,
		stop: noop,
		restart: noop,
		kill: noop
	},
	server: fixtureServer(),
	...options
});
var GiB = 1024 ** 3;
var statsFixture = (state, options = {}) => ({
	state,
	address: "203.0.113.10:25565",
	uptime: state === "running" ? 93784e3 : 0,
	cpu: statMetric(state === "running" ? 37.52 : 0, 100),
	memory: statMetric(state === "running" ? 1.4 * GiB : 0, 2 * GiB),
	disk: statMetric(3.2 * GiB, 10 * GiB),
	network: state === "running" ? {
		rx: 48234112,
		tx: 9812004
	} : {
		rx: 0,
		tx: 0
	},
	...options
});
/** Samples a second apart ending now, so a fixture's graphs sit where live ones would. */
function graphsFixture(live) {
	const now = performance.now();
	const times = Array.from({ length: live ? 20 : 0 }, (_, index) => now - (19 - index) * 1e3);
	return {
		live,
		windowMs: CHART_WINDOW_MS,
		cpu: {
			points: times.map((t, index) => ({
				t,
				value: 30 + 12 * Math.sin(index / 3)
			})),
			limit: 100
		},
		memory: {
			points: times.map((t, index) => ({
				t,
				value: 1300 + index * 6
			})),
			limit: 2048
		},
		network: { points: times.map((t, index) => ({
			t,
			rx: 4e4 + 9e3 * Math.cos(index / 2),
			tx: 12e3 + index * 300
		})) }
	};
}
implementViews({
	"page.server.console": {
		use: useServerConsoleModel,
		fixtureInput: () => ({ active: true }),
		fixtures: {
			default: () => ({
				name: "Survival",
				description: "A vanilla world.",
				notice: null,
				server: fixtureServer(),
				features: []
			}),
			installing: () => ({
				name: "Survival",
				description: null,
				notice: "installing",
				server: fixtureServer("installing"),
				features: []
			}),
			maintenance: () => ({
				name: "Survival",
				description: null,
				notice: "maintenance",
				server: fixtureServer(),
				features: []
			})
		}
	},
	"server.terminal": {
		use: useServerTerminal,
		fixtures: {
			running: () => terminalFixture(),
			connecting: () => terminalFixture({
				Terminal: OfflineTerminal,
				loading: true,
				command: command({ disabled: true })
			}),
			failed: () => terminalFixture({
				Terminal: OfflineTerminal,
				failed: true
			}),
			scrolledUp: () => terminalFixture({ scrolledUp: true }),
			readOnly: () => terminalFixture({ command: command({ allowed: false }) })
		}
	},
	"server.power": {
		use: useServerPowerModel,
		fixtures: {
			running: () => powerFixture("running"),
			offline: () => powerFixture("offline"),
			starting: () => powerFixture("starting"),
			stopping: () => powerFixture("stopping"),
			disconnected: () => powerFixture("running", {
				connected: false,
				enabled: {
					start: false,
					stop: false,
					restart: false,
					kill: false
				}
			}),
			noPermission: () => powerFixture("running", { permissions: {
				start: false,
				stop: false,
				restart: false
			} })
		}
	},
	"server.stats": {
		use: useServerStatsModel,
		fixtures: {
			running: () => statsFixture("running"),
			offline: () => statsFixture("offline"),
			starting: () => statsFixture("starting"),
			alarms: () => statsFixture("running", {
				cpu: statMetric(96, 100),
				memory: statMetric(1.7 * GiB, 2 * GiB),
				disk: statMetric(9.5 * GiB, 10 * GiB)
			}),
			unlimited: () => statsFixture("running", {
				address: null,
				cpu: statMetric(137.5, 0),
				memory: statMetric(3 * GiB, 0),
				disk: statMetric(12 * GiB, 0)
			})
		}
	},
	"server.graphs": {
		use: useServerGraphsModel,
		fixtures: {
			running: () => graphsFixture(true),
			offline: () => graphsFixture(false)
		}
	}
});
//#endregion

//# sourceMappingURL=console-Dx_jfqze.js.map