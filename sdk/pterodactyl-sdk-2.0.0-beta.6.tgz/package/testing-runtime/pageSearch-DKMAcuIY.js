import { c as isFiniteNumber, d as isString } from "./client.gen-Ci-zROOW.js";
import { useSearch } from "@tanstack/react-router";
//#region ../../resources/scripts/router/pageSearch.ts
/** The URL text of a search value the router JSON-parsed. */
var searchText = (value) => {
	if (isString(value)) return value.trim() || void 0;
	return isFiniteNumber(value) || value === true || value === false ? String(value) : void 0;
};
var parsePageSearch = (search) => {
	const page = isString(search.page) || isFiniteNumber(search.page) ? Number(search.page) : NaN;
	return Number.isSafeInteger(page) && page >= 1 ? { page } : {};
};
var getPageSearch = (page) => page > 1 ? { page } : {};
var usePageSearch = () => parsePageSearch(useSearch({ strict: false })).page ?? 1;
var parseDashboardSearch = (search) => {
	const result = { ...parsePageSearch(search) };
	if (search.type === "admin") result.type = "admin";
	return result;
};
var useDashboardSearch = () => {
	const { page = 1, type } = parseDashboardSearch(useSearch({ strict: false }));
	return {
		page,
		type
	};
};
var parseActivitySearch = (search) => {
	const result = { ...parsePageSearch(search) };
	const event = searchText(search.event);
	const user = searchText(search.user);
	if (event) result.event = event;
	if (user) result.user = user;
	return result;
};
var useActivitySearch = () => {
	const { page = 1, event, user } = parseActivitySearch(useSearch({ strict: false }));
	return {
		page,
		event,
		user
	};
};
var parseEmailSearch = (search) => {
	const email = searchText(search.email);
	return email ? { email } : {};
};
//#endregion
export { usePageSearch as a, useDashboardSearch as i, parseEmailSearch as n, useActivitySearch as r, getPageSearch as t };

//# sourceMappingURL=pageSearch-DKMAcuIY.js.map