import { At as currentUserQueryKey, B as EmptyDescription, C as useCompressFiles, Ct as normalizeServerPath, D as useDeleteFiles, E as useDecompressFile, Et as ExtensionContext, F as DropdownMenuItem, Ft as useCurrentServerIdentifier, G as useDialogState, H as EmptyMedia, I as DropdownMenuWithItems, J as Checkbox, K as useAppForm, L as Tooltip, Nt as serverQueryOptions, O as useFileDownloadUrl, Ot as siteSettingsQueryKey, P as ContextDropdownMenu, R as Empty, Rt as useCurrentServerUuid, S as useChmodFiles, St as encodePathSegments, T as useCreateDirectory, Tt as join, U as EmptyTitle, V as EmptyHeader, W as Dialog, X as Select, _ as isFileObjectArchiveType, _n as __commonJSMin, _t as useFileUploadActions, cn as getComponentReplacement, ct as ButtonWithVariants, d as copyFileInput, dn as reportExtensionError, dt as Icon, f as createDirectoryInput, fn as subscribeExtensionRegistry, ft as cn, g as fileObjectKind, gt as Provider, h as fileObjectKey, hn as isReplacementComponent, ht as usePermissions, i as resolvePanelDestination, in as SCREEN_ROOTS, j as useUploadFiles, k as useRenameFiles, l as chmodFilesInput, ln as getExtensionLoadState, lt as Spinner$1, m as deleteFilesInput, on as clearExtensionError, ot as SpinnerOverlay, p as decompressFileInput, pn as useExtensionRegistry, pt as registerClassPrefixes, q as Form, rn as ExtensionImportError, rt as Portal, sn as getComponentOwner, st as Can, t as ExtensionResourceProvider, u as compressFilesInput, un as getSlotComponents, ut as ErrorBoundary, v as isFileObjectEditable, vn as __toESM, vt as useServerDirectory, w as useCopyFile, wt as dirname, y as renameFilesInput, yt as useServerStore } from "./resourceContext-a3g2HE8U.js";
import { t as queryClient } from "./queryClient-D97HhWup.js";
import { t as editorContainerClass } from "./layout-B0n1h8c2.js";
import React, { Component, Suspense, createContext, memo, use, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { QueryClientProvider, QueryErrorResetBoundary } from "@tanstack/react-query";
import { Link, Outlet, RouterProvider, createMemoryHistory, createRootRoute, createRoute, createRouter } from "@tanstack/react-router";
import { toast } from "sonner";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { CloudUpload, Copy, CornerLeftUp, Cpu, EthernetPort, FileArchive, FileCode, FileDown, FileInput, FileText, Folder, FolderOpen, HardDrive, MemoryStick, MoreHorizontal, PackageOpen, Pencil, Plus, Server, Trash2, X } from "lucide-react";
import { useStore } from "@tanstack/react-form";
//#region ../../resources/scripts/components/dashboard/ServerRowMetrics.tsx
var ServerRowMetricIcon = ({ $alarm, icon: IconComponent }) => /* @__PURE__ */ jsx(IconComponent, {
	size: "1em",
	className: cn("inline-block shrink-0", $alarm ? "text-destructive" : "text-muted-foreground")
});
function ServerRowMetricDescription({ $alarm, children }) {
	return /* @__PURE__ */ jsx("p", {
		className: cn("text-sm ml-2", $alarm ? "text-destructive" : "text-muted-foreground"),
		children
	});
}
//#endregion
//#region ../../resources/scripts/lib/formatters.ts
var _CONVERSION_UNIT = 1024;
var _BYTE_UNITS = [
	"Bytes",
	"KiB",
	"MiB",
	"GiB",
	"TiB"
];
function byteUnitIndex(bytes) {
	return Math.min(Math.floor(Math.log(bytes) / Math.log(_CONVERSION_UNIT)), _BYTE_UNITS.length - 1);
}
function scaleBytes(bytes, unit, decimals) {
	return Number((bytes / _CONVERSION_UNIT ** unit).toFixed(Math.floor(Math.max(0, decimals))));
}
function bytesToString(bytes, decimals = 2) {
	if (bytes < 1) return "0 Bytes";
	const i = byteUnitIndex(bytes);
	return `${scaleBytes(bytes, i, decimals)} ${_BYTE_UNITS[i]}`;
}
//#endregion
//#region ../../resources/scripts/extensions/ExtensionMount.tsx
var ExtensionBoundary = class extends Component {
	state = { error: null };
	static getDerivedStateFromError(cause) {
		return { error: cause instanceof Error ? cause : new Error(String(cause)) };
	}
	componentDidCatch(error) {
		reportExtensionError(this.props.extensionId, this.props.context, error);
	}
	componentDidUpdate(previous) {
		if (previous.resetKey !== this.props.resetKey && this.state.error) this.retry();
	}
	retry = () => {
		this.props.onReset();
		clearExtensionError(this.props.extensionId, this.props.context);
		this.setState({ error: null });
	};
	render() {
		return this.state.error ? this.props.fallback(this.state.error, this.retry) : this.props.children;
	}
};
var failedMountsByNotification = /* @__PURE__ */ new Map();
var failureNotificationId = (extensionId, context) => `extension-failure:${extensionId}:${context}`;
function showFailureNotice(notificationId, extensionId, mounts) {
	const retryable = [...mounts].some((mount) => mount.retry);
	toast.error(`The "${extensionId}" extension could not display this content.`, {
		id: notificationId,
		duration: Infinity,
		action: retryable ? {
			label: "Retry extension",
			onClick: () => {
				for (const mount of mounts) mount.retry?.();
			}
		} : {
			label: "Reload page",
			onClick: () => window.location.reload()
		},
		description: retryable ? /* @__PURE__ */ jsx(ButtonWithVariants, {
			type: "button",
			onClick: () => window.location.reload(),
			children: "Reload page"
		}) : void 0
	});
}
/** Mounts sharing a `notificationId` share one toast whose retry resets all of them. */
function ExtensionFailure({ extensionId, retry, notificationId }) {
	useEffect(() => {
		if (!notificationId) return;
		const mount = { retry };
		const mounts = failedMountsByNotification.get(notificationId) ?? /* @__PURE__ */ new Set();
		mounts.add(mount);
		failedMountsByNotification.set(notificationId, mounts);
		if (mounts.size === 1) showFailureNotice(notificationId, extensionId, mounts);
		return () => {
			mounts.delete(mount);
			if (mounts.size) return;
			failedMountsByNotification.delete(notificationId);
			toast.dismiss(notificationId);
		};
	}, [
		extensionId,
		notificationId,
		retry
	]);
	if (notificationId) return null;
	return /* @__PURE__ */ jsxs("div", {
		role: "alert",
		children: [
			/* @__PURE__ */ jsxs("p", { children: [
				"The \"",
				extensionId,
				"\" extension could not display this content."
			] }),
			retry && /* @__PURE__ */ jsx(ButtonWithVariants, {
				type: "button",
				onClick: retry,
				children: "Retry extension"
			}),
			/* @__PURE__ */ jsx(ButtonWithVariants, {
				type: "button",
				onClick: () => window.location.reload(),
				children: "Reload page"
			})
		]
	});
}
function ExtensionMount({ extensionId, context, resetKey, loading = null, isSlot = false, failure, children }) {
	const mount = useMemo(() => ({
		extensionId,
		context
	}), [extensionId, context]);
	return /* @__PURE__ */ jsx(ExtensionContext.Provider, {
		value: mount,
		children: /* @__PURE__ */ jsx(QueryErrorResetBoundary, { children: ({ reset }) => /* @__PURE__ */ jsx(ExtensionBoundary, {
			...mount,
			resetKey,
			onReset: reset,
			fallback: (error, retry) => failure === void 0 ? /* @__PURE__ */ jsx(ExtensionFailure, {
				extensionId,
				notificationId: isSlot ? failureNotificationId(extensionId, context) : void 0,
				retry: error instanceof ExtensionImportError ? void 0 : retry
			}) : failure,
			children: /* @__PURE__ */ jsx(Suspense, {
				fallback: loading,
				children
			})
		}) })
	});
}
//#endregion
//#region ../../resources/scripts/extensions/Slot.tsx
function slotResetKey(name, data) {
	if (!data) return name;
	if ("resource" in data) return `${data.kind}:${data.resource.attributes.id}`;
	if ("directory" in data) return `${data.server.attributes.uuid}:${data.directory}`;
	if ("attributes" in data) return data.attributes.uuid;
	if ("pathname" in data) return data.pathname;
	return name;
}
function Slot({ name, data }) {
	const registrations = useExtensionRegistry(() => getSlotComponents(name));
	const resetKey = slotResetKey(name, data);
	return /* @__PURE__ */ jsx(Fragment, { children: registrations.map(({ id, extensionId, component: Component }) => /* @__PURE__ */ jsx(ExtensionMount, {
		isSlot: true,
		extensionId,
		context: `slot "${name}"`,
		resetKey,
		children: /* @__PURE__ */ jsx(Component, { data })
	}, id)) });
}
//#endregion
//#region ../../resources/scripts/components/dashboard/ServerCardView.tsx
var ServerCardContext = createContext(null);
function Identity({ model }) {
	const context = useContext(ServerCardContext);
	return /* @__PURE__ */ jsxs("div", {
		className: "flex items-center col-span-12 sm:col-span-5 lg:col-span-6",
		children: [
			/* @__PURE__ */ jsx("div", {
				className: "icon mr-4",
				children: /* @__PURE__ */ jsx(Server, {
					size: "1em",
					className: "inline-block"
				})
			}),
			/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
				className: "text-lg wrap-break-word",
				children: model.name
			}), !!model.description && /* @__PURE__ */ jsx("p", {
				className: "text-sm text-muted-foreground wrap-break-word line-clamp-2",
				children: model.description
			})] }),
			/* @__PURE__ */ jsx(Slot, {
				name: "dashboard.serverRow.name.after",
				data: context.server
			})
		]
	});
}
function Address({ model }) {
	return /* @__PURE__ */ jsx("div", {
		className: "flex-1 ml-4 lg:block lg:col-span-2 hidden",
		children: /* @__PURE__ */ jsxs("div", {
			className: "flex justify-center",
			children: [/* @__PURE__ */ jsx(EthernetPort, {
				size: "1em",
				className: "inline-block shrink-0 text-muted-foreground"
			}), /* @__PURE__ */ jsx("p", {
				className: "text-sm text-muted-foreground ml-2",
				children: model.address
			})]
		})
	});
}
var unavailableLabels = {
	suspended: "Suspended",
	"connection-error": "Connection Error",
	maintenance: "Under Maintenance",
	transferring: "Transferring",
	installing: "Installing",
	"restoring-backup": "Restoring Backup",
	unavailable: "Unavailable"
};
var unavailableBadgeColors = {
	suspended: "bg-destructive text-destructive-foreground",
	"connection-error": "bg-destructive text-destructive-foreground",
	maintenance: "bg-warning text-warning-foreground",
	transferring: "bg-popover text-foreground",
	installing: "bg-popover text-foreground",
	"restoring-backup": "bg-popover text-foreground",
	unavailable: "bg-popover text-foreground"
};
function UnavailableBadge({ reason }) {
	return /* @__PURE__ */ jsx("div", {
		className: "flex-1 text-center",
		children: /* @__PURE__ */ jsx("span", {
			className: cn("rounded-sm px-2 py-1 text-xs", unavailableBadgeColors[reason]),
			children: unavailableLabels[reason]
		})
	});
}
function MetricsContent({ state }) {
	if (state.kind === "loading") return /* @__PURE__ */ jsx(Spinner$1, { size: "small" });
	if (state.kind === "unavailable") return /* @__PURE__ */ jsx(UnavailableBadge, { reason: state.reason });
	return /* @__PURE__ */ jsx(Fragment, { children: [
		{
			id: "cpu",
			icon: Cpu,
			metric: state.cpu,
			value: `${state.cpu.value.toFixed(2)} %`,
			limit: state.cpu.limit === 0 ? "Unlimited" : `${state.cpu.limit} %`
		},
		{
			id: "memory",
			icon: MemoryStick,
			metric: state.memory,
			value: bytesToString(state.memory.value),
			limit: state.memory.limit === 0 ? "Unlimited" : bytesToString(state.memory.limit)
		},
		{
			id: "disk",
			icon: HardDrive,
			metric: state.disk,
			value: bytesToString(state.disk.value),
			limit: state.disk.limit === 0 ? "Unlimited" : bytesToString(state.disk.limit)
		}
	].map(({ id, icon, metric, value, limit }) => /* @__PURE__ */ jsxs("div", {
		className: "flex-1 ml-4 sm:block hidden",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "flex justify-center",
			children: [/* @__PURE__ */ jsx(ServerRowMetricIcon, {
				icon,
				$alarm: metric.alarm
			}), /* @__PURE__ */ jsx(ServerRowMetricDescription, {
				$alarm: metric.alarm,
				children: value
			})]
		}), /* @__PURE__ */ jsxs("p", {
			className: "text-xs text-muted-foreground text-center mt-1",
			children: ["of ", limit]
		})]
	}, id)) });
}
function Metrics({ model }) {
	return /* @__PURE__ */ jsx("div", {
		className: "hidden col-span-7 lg:col-span-4 sm:flex items-baseline justify-center",
		children: /* @__PURE__ */ jsx(MetricsContent, { state: model.state })
	});
}
var serverCardParts = {
	identity: Identity,
	address: Address,
	metrics: Metrics
};
function DefaultServerCard({ className, parts }) {
	const { model } = useContext(ServerCardContext);
	const IdentityPart = parts?.identity ?? Identity;
	const AddressPart = parts?.address ?? Address;
	const MetricsPart = parts?.metrics ?? Metrics;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("grid grid-cols-12 gap-4", className),
		children: [
			/* @__PURE__ */ jsx(IdentityPart, { model }),
			/* @__PURE__ */ jsx(AddressPart, { model }),
			/* @__PURE__ */ jsx(MetricsPart, { model })
		]
	});
}
//#endregion
//#region ../../node_modules/dayjs/dayjs.min.js
var require_dayjs_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(t, e) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).dayjs = e();
	})(exports, (function() {
		"use strict";
		var t = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", s = "minute", u = "hour", a = "day", o = "week", c = "month", f = "quarter", h = "year", d = "date", l = "Invalid Date", $ = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|YYYY|YY|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, M = {
			name: "en",
			weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
			months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
			ordinal: function(t) {
				var e = [
					"th",
					"st",
					"nd",
					"rd"
				], n = t % 100;
				return "[" + t + (e[(n - 20) % 10] || e[n] || e[0]) + "]";
			}
		}, m = function(t, e, n) {
			var r = String(t);
			return !r || r.length >= e ? t : "" + Array(e + 1 - r.length).join(n) + t;
		}, v = {
			s: m,
			z: function(t) {
				var e = -t.utcOffset(), n = Math.abs(e), r = Math.floor(n / 60), i = n % 60;
				return (e <= 0 ? "+" : "-") + m(r, 2, "0") + ":" + m(i, 2, "0");
			},
			m: function t(e, n) {
				if (e.date() < n.date()) return -t(n, e);
				var r = 12 * (n.year() - e.year()) + (n.month() - e.month()), i = e.clone().add(r, c), s = n - i < 0, u = e.clone().add(r + (s ? -1 : 1), c);
				return +(-(r + (n - i) / (s ? i - u : u - i)) || 0);
			},
			a: function(t) {
				return t < 0 ? Math.ceil(t) || 0 : Math.floor(t);
			},
			p: function(t) {
				return {
					M: c,
					y: h,
					w: o,
					d: a,
					D: d,
					h: u,
					m: s,
					s: i,
					ms: r,
					Q: f
				}[t] || String(t || "").toLowerCase().replace(/s$/, "");
			},
			u: function(t) {
				return void 0 === t;
			}
		}, g = "en", D = {};
		D[g] = M;
		var p = "$isDayjsObject", S = function(t) {
			return t instanceof _ || !(!t || !t[p]);
		}, w = function t(e, n, r) {
			var i;
			if (!e) return g;
			if ("string" == typeof e) {
				var s = e.toLowerCase();
				D[s] && (i = s), n && (D[s] = n, i = s);
				var u = e.split("-");
				if (!i && u.length > 1) return t(u[0]);
			} else {
				var a = e.name;
				D[a] = e, i = a;
			}
			return !r && i && (g = i), i || !r && g;
		}, O = function(t, e) {
			if (S(t)) return t.clone();
			var n = "object" == typeof e ? e : {};
			return n.date = t, n.args = arguments, new _(n);
		}, b = v;
		b.l = w, b.i = S, b.w = function(t, e) {
			return O(t, {
				locale: e.$L,
				utc: e.$u,
				x: e.$x,
				$offset: e.$offset
			});
		};
		var _ = function() {
			function M(t) {
				this.$L = w(t.locale, null, !0), this.parse(t), this.$x = this.$x || t.x || {}, this[p] = !0;
			}
			var m = M.prototype;
			return m.parse = function(t) {
				this.$d = function(t) {
					var e = t.date, n = t.utc;
					if (null === e) return /* @__PURE__ */ new Date(NaN);
					if (b.u(e)) return /* @__PURE__ */ new Date();
					if (e instanceof Date) return new Date(e);
					if ("string" == typeof e && !/Z$/i.test(e)) {
						var r = e.match($);
						if (r) {
							var i = r[2] - 1 || 0, s = (r[7] || "0").substring(0, 3);
							return n ? new Date(Date.UTC(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s)) : new Date(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s);
						}
					}
					return new Date(e);
				}(t), this.init();
			}, m.init = function() {
				var t = this.$d;
				this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds();
			}, m.$utils = function() {
				return b;
			}, m.isValid = function() {
				return !(this.$d.toString() === l);
			}, m.isSame = function(t, e) {
				var n = O(t);
				return this.startOf(e) <= n && n <= this.endOf(e);
			}, m.isAfter = function(t, e) {
				return O(t) < this.startOf(e);
			}, m.isBefore = function(t, e) {
				return this.endOf(e) < O(t);
			}, m.$g = function(t, e, n) {
				return b.u(t) ? this[e] : this.set(n, t);
			}, m.unix = function() {
				return Math.floor(this.valueOf() / 1e3);
			}, m.valueOf = function() {
				return this.$d.getTime();
			}, m.startOf = function(t, e) {
				var n = this, r = !!b.u(e) || e, f = b.p(t), l = function(t, e) {
					var i = b.w(n.$u ? Date.UTC(n.$y, e, t) : new Date(n.$y, e, t), n);
					return r ? i : i.endOf(a);
				}, $ = function(t, e) {
					return b.w(n.toDate()[t].apply(n.toDate("s"), (r ? [
						0,
						0,
						0,
						0
					] : [
						23,
						59,
						59,
						999
					]).slice(e)), n);
				}, y = this.$W, M = this.$M, m = this.$D, v = "set" + (this.$u ? "UTC" : "");
				switch (f) {
					case h: return r ? l(1, 0) : l(31, 11);
					case c: return r ? l(1, M) : l(0, M + 1);
					case o:
						var g = this.$locale().weekStart || 0, D = (y < g ? y + 7 : y) - g;
						return l(r ? m - D : m + (6 - D), M);
					case a:
					case d: return $(v + "Hours", 0);
					case u: return $(v + "Minutes", 1);
					case s: return $(v + "Seconds", 2);
					case i: return $(v + "Milliseconds", 3);
					default: return this.clone();
				}
			}, m.endOf = function(t) {
				return this.startOf(t, !1);
			}, m.$set = function(t, e) {
				var n, o = b.p(t), f = "set" + (this.$u ? "UTC" : ""), l = (n = {}, n[a] = f + "Date", n[d] = f + "Date", n[c] = f + "Month", n[h] = f + "FullYear", n[u] = f + "Hours", n[s] = f + "Minutes", n[i] = f + "Seconds", n[r] = f + "Milliseconds", n)[o], $ = o === a ? this.$D + (e - this.$W) : e;
				if (o === c || o === h) {
					var y = this.clone().set(d, 1);
					y.$d[l]($), y.init(), this.$d = y.set(d, Math.min(this.$D, y.daysInMonth())).$d;
				} else l && this.$d[l]($);
				return this.init(), this;
			}, m.set = function(t, e) {
				return this.clone().$set(t, e);
			}, m.get = function(t) {
				return this[b.p(t)]();
			}, m.add = function(r, f) {
				var d, l = this;
				r = Number(r);
				var $ = b.p(f), y = function(t) {
					var e = O(l);
					return b.w(e.date(e.date() + Math.round(t * r)), l);
				};
				if ($ === c) return this.set(c, this.$M + r);
				if ($ === h) return this.set(h, this.$y + r);
				if ($ === a) return y(1);
				if ($ === o) return y(7);
				var M = (d = {}, d[s] = e, d[u] = n, d[i] = t, d)[$] || 1, m = this.$d.getTime() + r * M;
				return b.w(m, this);
			}, m.subtract = function(t, e) {
				return this.add(-1 * t, e);
			}, m.format = function(t) {
				var e = this, n = this.$locale();
				if (!this.isValid()) return n.invalidDate || l;
				var r = t || "YYYY-MM-DDTHH:mm:ssZ", i = b.z(this), s = this.$H, u = this.$m, a = this.$M, o = n.weekdays, c = n.months, f = n.meridiem, h = function(t, n, i, s) {
					return t && (t[n] || t(e, r)) || i[n].slice(0, s);
				}, d = function(t) {
					return b.s(s % 12 || 12, t, "0");
				}, $ = f || function(t, e, n) {
					var r = t < 12 ? "AM" : "PM";
					return n ? r.toLowerCase() : r;
				};
				return r.replace(y, (function(t, r) {
					return r || function(t) {
						switch (t) {
							case "YY": return String(e.$y).slice(-2);
							case "YYYY": return b.s(e.$y, 4, "0");
							case "M": return a + 1;
							case "MM": return b.s(a + 1, 2, "0");
							case "MMM": return h(n.monthsShort, a, c, 3);
							case "MMMM": return h(c, a);
							case "D": return e.$D;
							case "DD": return b.s(e.$D, 2, "0");
							case "d": return String(e.$W);
							case "dd": return h(n.weekdaysMin, e.$W, o, 2);
							case "ddd": return h(n.weekdaysShort, e.$W, o, 3);
							case "dddd": return o[e.$W];
							case "H": return String(s);
							case "HH": return b.s(s, 2, "0");
							case "h": return d(1);
							case "hh": return d(2);
							case "a": return $(s, u, !0);
							case "A": return $(s, u, !1);
							case "m": return String(u);
							case "mm": return b.s(u, 2, "0");
							case "s": return String(e.$s);
							case "ss": return b.s(e.$s, 2, "0");
							case "SSS": return b.s(e.$ms, 3, "0");
							case "Z": return i;
						}
						return null;
					}(t) || i.replace(":", "");
				}));
			}, m.utcOffset = function() {
				return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
			}, m.diff = function(r, d, l) {
				var $, y = this, M = b.p(d), m = O(r), v = (m.utcOffset() - this.utcOffset()) * e, g = this - m, D = function() {
					return b.m(y, m);
				};
				switch (M) {
					case h:
						$ = D() / 12;
						break;
					case c:
						$ = D();
						break;
					case f:
						$ = D() / 3;
						break;
					case o:
						$ = (g - v) / 6048e5;
						break;
					case a:
						$ = (g - v) / 864e5;
						break;
					case u:
						$ = g / n;
						break;
					case s:
						$ = g / e;
						break;
					case i:
						$ = g / t;
						break;
					default: $ = g;
				}
				return l ? $ : b.a($);
			}, m.daysInMonth = function() {
				return this.endOf(c).$D;
			}, m.$locale = function() {
				return D[this.$L];
			}, m.locale = function(t, e) {
				if (!t) return this.$L;
				var n = this.clone(), r = w(t, e, !0);
				return r && (n.$L = r), n;
			}, m.clone = function() {
				return b.w(this.$d, this);
			}, m.toDate = function() {
				return new Date(this.valueOf());
			}, m.toJSON = function() {
				return this.isValid() ? this.toISOString() : null;
			}, m.toISOString = function() {
				return this.$d.toISOString();
			}, m.toString = function() {
				return this.$d.toUTCString();
			}, M;
		}(), Y = _.prototype;
		return O.prototype = Y, [
			["$ms", r],
			["$s", i],
			["$m", s],
			["$H", u],
			["$W", a],
			["$M", c],
			["$y", h],
			["$D", d]
		].forEach((function(t) {
			Y[t[1]] = function(e) {
				return this.$g(e, t[0], t[1]);
			};
		})), O.extend = function(t, e) {
			return t.$i || (t(e, _, O), t.$i = !0), O;
		}, O.locale = w, O.isDayjs = S, O.unix = function(t) {
			return O(1e3 * t);
		}, O.en = D[g], O.Ls = D, O.p = {}, O;
	}));
}));
//#endregion
//#region ../../node_modules/dayjs/plugin/advancedFormat.js
var require_advancedFormat = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).dayjs_plugin_advancedFormat = t();
	})(exports, (function() {
		"use strict";
		return function(e, t) {
			var r = t.prototype, n = r.format;
			r.format = function(e) {
				var t = this, r = this.$locale();
				if (!this.isValid()) return n.bind(this)(e);
				var s = this.$utils(), a = (e || "YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g, (function(e) {
					switch (e) {
						case "Q": return Math.ceil((t.$M + 1) / 3);
						case "Do": return r.ordinal(t.$D);
						case "gggg": return t.weekYear();
						case "GGGG": return t.isoWeekYear();
						case "wo": return r.ordinal(t.week(), "W");
						case "w":
						case "ww": return s.s(t.week(), "w" === e ? 1 : 2, "0");
						case "W":
						case "WW": return s.s(t.isoWeek(), "W" === e ? 1 : 2, "0");
						case "k":
						case "kk": return s.s(String(0 === t.$H ? 24 : t.$H), "k" === e ? 1 : 2, "0");
						case "X": return Math.floor(t.$d.getTime() / 1e3);
						case "x": return t.$d.getTime();
						case "z": return "[" + t.offsetName() + "]";
						case "zzz": return "[" + t.offsetName("long") + "]";
						default: return e;
					}
				}));
				return n.bind(this)(a);
			};
		};
	}));
}));
//#endregion
//#region ../../node_modules/dayjs/plugin/relativeTime.js
var require_relativeTime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(r, e) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (r = "undefined" != typeof globalThis ? globalThis : r || self).dayjs_plugin_relativeTime = e();
	})(exports, (function() {
		"use strict";
		return function(r, e, t) {
			r = r || {};
			var n = e.prototype, o = {
				future: "in %s",
				past: "%s ago",
				s: "a few seconds",
				m: "a minute",
				mm: "%d minutes",
				h: "an hour",
				hh: "%d hours",
				d: "a day",
				dd: "%d days",
				M: "a month",
				MM: "%d months",
				y: "a year",
				yy: "%d years"
			};
			function i(r, e, t, o) {
				return n.fromToBase(r, e, t, o);
			}
			t.en.relativeTime = o, n.fromToBase = function(e, n, i, d, u) {
				for (var f, a, s, l = i.$locale().relativeTime || o, h = r.thresholds || [
					{
						l: "s",
						r: 44,
						d: "second"
					},
					{
						l: "m",
						r: 89
					},
					{
						l: "mm",
						r: 44,
						d: "minute"
					},
					{
						l: "h",
						r: 89
					},
					{
						l: "hh",
						r: 21,
						d: "hour"
					},
					{
						l: "d",
						r: 35
					},
					{
						l: "dd",
						r: 25,
						d: "day"
					},
					{
						l: "M",
						r: 45
					},
					{
						l: "MM",
						r: 10,
						d: "month"
					},
					{
						l: "y",
						r: 17
					},
					{
						l: "yy",
						d: "year"
					}
				], m = h.length, c = 0; c < m; c += 1) {
					var y = h[c];
					y.d && (f = d ? t(e).diff(i, y.d, !0) : i.diff(e, y.d, !0));
					var p = (r.rounding || Math.round)(Math.abs(f));
					if (s = f > 0, p <= y.r || !y.r) {
						p <= 1 && c > 0 && (y = h[c - 1]);
						var v = l[y.l];
						u && (p = u("" + p)), a = "string" == typeof v ? v.replace("%d", p) : v(p, n, y.l, s);
						break;
					}
				}
				if (n) return a;
				var M = s ? l.future : l.past;
				return "function" == typeof M ? M(a) : M.replace("%s", a);
			}, n.to = function(r, e) {
				return i(r, e, this, !0);
			}, n.from = function(r, e) {
				return i(r, e, this);
			};
			var d = function(r) {
				return r.$u ? t.utc() : t();
			};
			n.toNow = function(r) {
				return this.to(d(this), r);
			}, n.fromNow = function(r) {
				return this.from(d(this), r);
			};
		};
	}));
}));
//#endregion
//#region ../../resources/scripts/lib/dayjs.ts
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
var import_advancedFormat = /* @__PURE__ */ __toESM(require_advancedFormat());
var import_relativeTime = /* @__PURE__ */ __toESM(require_relativeTime());
import_dayjs_min.default.extend(import_advancedFormat.default);
import_dayjs_min.default.extend(import_relativeTime.default);
var dayjs_default = import_dayjs_min.default;
//#endregion
//#region ../../resources/scripts/components/server/files/FileDetailsView.tsx
var FileDetailsContext = createContext(null);
function FileIcon({ model }) {
	return /* @__PURE__ */ jsx("div", {
		className: "flex-none text-muted-foreground ml-6 mr-4 text-lg pl-3",
		children: /* @__PURE__ */ jsx(Icon, { icon: {
			file: FileText,
			directory: Folder,
			archive: FileArchive,
			symlink: FileInput
		}[model.kind] })
	});
}
function Name({ model }) {
	return /* @__PURE__ */ jsx("div", {
		className: "flex-1 truncate",
		children: model.name
	});
}
function Size({ model }) {
	return model.kind === "directory" ? null : /* @__PURE__ */ jsx("div", {
		className: "w-1/6 text-right mr-4 hidden sm:block",
		children: bytesToString(model.size)
	});
}
function Modified({ model }) {
	return /* @__PURE__ */ jsx("div", {
		className: "w-1/5 text-right mr-4 hidden md:block",
		title: model.modifiedAt,
		children: Math.abs(dayjs_default(model.modifiedAt).diff(dayjs_default(), "hour")) > 48 ? dayjs_default(model.modifiedAt).format("MMM Do, YYYY h:mmA") : dayjs_default(model.modifiedAt).fromNow()
	});
}
var fileDetailsParts = {
	icon: FileIcon,
	name: Name,
	size: Size,
	modified: Modified
};
function DefaultFileDetails({ className, parts }) {
	const model = useContext(FileDetailsContext);
	const IconPart = parts?.icon ?? FileIcon;
	const NamePart = parts?.name ?? Name;
	const SizePart = parts?.size ?? Size;
	const ModifiedPart = parts?.modified ?? Modified;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("flex flex-1 items-center min-w-0", className),
		children: [
			/* @__PURE__ */ jsx(IconPart, { model }),
			/* @__PURE__ */ jsx(NamePart, { model }),
			/* @__PURE__ */ jsx(SizePart, { model }),
			/* @__PURE__ */ jsx(ModifiedPart, { model })
		]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/LazyCodemirrorEditor.tsx
var CodemirrorEditor = React.lazy(() => import("./CodemirrorEditor-DxNA7kvh.js"));
var LazyCodemirrorEditor = (props) => /* @__PURE__ */ jsx(Suspense, {
	fallback: /* @__PURE__ */ jsx("div", {
		className: cn(editorContainerClass, props.className),
		children: /* @__PURE__ */ jsx(Spinner$1, {
			centered: true,
			size: "large"
		})
	}),
	children: /* @__PURE__ */ jsx(CodemirrorEditor, { ...props })
});
//#endregion
//#region ../../resources/scripts/modes.ts
var modes = [
	{
		name: "C",
		mime: "text/x-csrc",
		mode: "clike",
		ext: [
			"c",
			"h",
			"ino"
		]
	},
	{
		name: "C++",
		mime: "text/x-c++src",
		mode: "clike",
		ext: [
			"cpp",
			"c++",
			"cc",
			"cxx",
			"hpp",
			"h++",
			"hh",
			"hxx"
		],
		alias: ["cpp"]
	},
	{
		name: "C#",
		mime: "text/x-csharp",
		mode: "clike",
		ext: ["cs"],
		alias: ["csharp", "cs"]
	},
	{
		name: "CSS",
		mime: "text/css",
		mode: "css",
		ext: ["css"]
	},
	{
		name: "CQL",
		mime: "text/x-cassandra",
		mode: "sql",
		ext: ["cql"]
	},
	{
		name: "Diff",
		mime: "text/x-diff",
		mode: "diff",
		ext: ["diff", "patch"]
	},
	{
		name: "Dockerfile",
		mime: "text/x-dockerfile",
		mode: "dockerfile",
		file: /^Dockerfile$/
	},
	{
		name: "Git Markdown",
		mime: "text/x-gfm",
		mode: "gfm",
		file: /^(readme|contributing|history|license).md$/i
	},
	{
		name: "Golang",
		mime: "text/x-go",
		mode: "go",
		ext: ["go"]
	},
	{
		name: "HTML",
		mime: "text/html",
		mode: "htmlmixed",
		ext: [
			"html",
			"htm",
			"handlebars",
			"hbs"
		],
		alias: ["xhtml"]
	},
	{
		name: "HTTP",
		mime: "message/http",
		mode: "http"
	},
	{
		name: "JavaScript",
		mime: "text/javascript",
		mimes: [
			"text/javascript",
			"text/ecmascript",
			"application/javascript",
			"application/x-javascript",
			"application/ecmascript"
		],
		mode: "javascript",
		ext: ["js"],
		alias: [
			"ecmascript",
			"js",
			"node"
		]
	},
	{
		name: "JSON",
		mime: "application/json",
		mimes: ["application/json", "application/x-json"],
		mode: "javascript",
		ext: ["json", "map"],
		alias: ["json5"]
	},
	{
		name: "Lua",
		mime: "text/x-lua",
		mode: "lua",
		ext: ["lua"]
	},
	{
		name: "Markdown",
		mime: "text/x-markdown",
		mode: "markdown",
		ext: [
			"markdown",
			"md",
			"mkd"
		]
	},
	{
		name: "MariaDB",
		mime: "text/x-mariadb",
		mode: "sql"
	},
	{
		name: "MS SQL",
		mime: "text/x-mssql",
		mode: "sql"
	},
	{
		name: "MySQL",
		mime: "text/x-mysql",
		mode: "sql"
	},
	{
		name: "Nginx",
		mime: "text/x-nginx-conf",
		mode: "nginx",
		file: /nginx.*\.conf$/i
	},
	{
		name: "PHP",
		mime: "text/x-php",
		mimes: [
			"text/x-php",
			"application/x-httpd-php",
			"application/x-httpd-php-open"
		],
		mode: "php",
		ext: [
			"php",
			"php3",
			"php4",
			"php5",
			"php7",
			"phtml"
		]
	},
	{
		name: "Plain Text",
		mime: "text/plain",
		mode: "null",
		ext: [
			"txt",
			"text",
			"conf",
			"def",
			"list",
			"log"
		]
	},
	{
		name: "PostgreSQL",
		mime: "text/x-pgsql",
		mode: "sql"
	},
	{
		name: "Properties",
		mime: "text/x-properties",
		mode: "properties",
		ext: [
			"properties",
			"ini",
			"in"
		],
		alias: ["ini", "properties"]
	},
	{
		name: "Pug",
		mime: "text/x-pug",
		mimes: ["text/x-pug", "text/x-jade"],
		mode: "null",
		ext: ["pug"]
	},
	{
		name: "Python",
		mime: "text/x-python",
		mode: "python",
		ext: [
			"BUILD",
			"bzl",
			"py",
			"pyw"
		],
		file: /^(BUCK|BUILD)$/
	},
	{
		name: "Ruby",
		mime: "text/x-ruby",
		mode: "ruby",
		ext: ["rb"],
		alias: [
			"jruby",
			"macruby",
			"rake",
			"rb",
			"rbx"
		]
	},
	{
		name: "Rust",
		mime: "text/x-rustsrc",
		mode: "rust",
		ext: ["rs"]
	},
	{
		name: "Sass",
		mime: "text/x-sass",
		mode: "sass",
		ext: ["sass"]
	},
	{
		name: "SCSS",
		mime: "text/x-scss",
		mode: "css",
		ext: ["scss"]
	},
	{
		name: "Shell",
		mime: "text/x-sh",
		mimes: ["text/x-sh", "application/x-sh"],
		mode: "shell",
		ext: [
			"sh",
			"ksh",
			"bash"
		],
		alias: [
			"bash",
			"sh",
			"zsh"
		],
		file: /^PKGBUILD$/
	},
	{
		name: "SQL",
		mime: "text/x-sql",
		mode: "sql",
		ext: ["sql"]
	},
	{
		name: "SQLite",
		mime: "text/x-sqlite",
		mode: "sql"
	},
	{
		name: "TOML",
		mime: "text/x-toml",
		mode: "toml",
		ext: ["toml"]
	},
	{
		name: "TypeScript",
		mime: "application/typescript",
		mode: "javascript",
		ext: ["ts"],
		alias: ["ts"]
	},
	{
		name: "Vue",
		mime: "script/x-vue",
		mimes: ["script/x-vue", "text/x-vue"],
		mode: "vue",
		ext: ["vue"]
	},
	{
		name: "XML",
		mime: "application/xml",
		mimes: ["application/xml", "text/xml"],
		mode: "xml",
		ext: [
			"xml",
			"xsl",
			"xsd",
			"svg"
		],
		alias: [
			"rss",
			"wsdl",
			"xsd"
		]
	},
	{
		name: "YAML",
		mime: "text/x-yaml",
		mimes: ["text/x-yaml", "text/yaml"],
		mode: "yaml",
		ext: ["yaml", "yml"],
		alias: ["yml"]
	}
];
//#endregion
//#region ../../resources/scripts/components/server/files/FileEditorView.tsx
var FileEditorContext = createContext(null);
function Notice({ model }) {
	return model.name.endsWith(".pteroignore") ? /* @__PURE__ */ jsx("div", {
		className: "mb-4 p-4 border-l-4 bg-muted rounded-sm border-accent",
		children: /* @__PURE__ */ jsxs("p", {
			className: "text-muted-foreground text-sm",
			children: [
				"You're editing a ",
				/* @__PURE__ */ jsx("code", {
					className: "font-mono bg-muted rounded-sm py-px px-1",
					children: ".pteroignore"
				}),
				" ",
				"file. Any files or directories listed in here will be excluded from backups. Wildcards are supported by using an asterisk (",
				/* @__PURE__ */ jsx("code", {
					className: "font-mono bg-muted rounded-sm py-px px-1",
					children: "*"
				}),
				"). You can negate a prior rule by prepending an exclamation point (",
				/* @__PURE__ */ jsx("code", {
					className: "font-mono bg-muted rounded-sm py-px px-1",
					children: "!"
				}),
				")."
			]
		})
	}) : null;
}
function Editor({ model }) {
	const { read } = useContext(FileEditorContext);
	const [initialContent] = useState(read);
	return /* @__PURE__ */ jsxs("div", {
		className: "relative",
		"aria-busy": model.saving,
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: model.saving }), /* @__PURE__ */ jsx(LazyCodemirrorEditor, {
			mode: model.language,
			initialContent,
			onContentChanged: model.change,
			onContentSaved: () => void model.save()
		})]
	});
}
function Language({ model }) {
	const { setLanguage } = useContext(FileEditorContext);
	return /* @__PURE__ */ jsx("div", {
		className: "w-full min-w-0 rounded-sm bg-muted sm:w-64",
		children: /* @__PURE__ */ jsx(Select, {
			value: model.language,
			onChange: (value) => setLanguage(String(value)),
			disabled: model.saving,
			options: modes.map((mode) => ({
				value: mode.mime,
				label: mode.name
			}))
		})
	});
}
function Actions({ model }) {
	return model.readOnly ? null : /* @__PURE__ */ jsx(ButtonWithVariants, {
		className: "w-full sm:w-auto",
		disabled: model.saving,
		isLoading: model.saving,
		onClick: () => void model.save(),
		children: model.isNew ? "Create File" : "Save Content"
	});
}
var fileEditorParts = {
	notice: Notice,
	editor: Editor,
	language: Language,
	actions: Actions
};
function DefaultFileEditor({ className, parts }) {
	const { model } = useContext(FileEditorContext);
	const NoticePart = parts?.notice ?? Notice;
	const EditorPart = parts?.editor ?? Editor;
	const LanguagePart = parts?.language ?? Language;
	const ActionsPart = parts?.actions ?? Actions;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("min-w-0", className),
		children: [
			/* @__PURE__ */ jsx(NoticePart, { model }),
			/* @__PURE__ */ jsx(EditorPart, { model }),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-4 flex flex-col gap-3 sm:flex-row sm:items-stretch sm:justify-end",
				children: [/* @__PURE__ */ jsx(LanguagePart, { model }), /* @__PURE__ */ jsx(ActionsPart, { model })]
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/NewButton.tsx
var newButtonClass = "inline-flex h-9 shrink-0 items-center justify-center gap-2 px-3 normal-case font-medium tracking-normal";
/** The panel's "create" action: a Plus icon and a sentence-case label such as "New node". */
function NewButton({ icon = Plus, className, children, ...props }) {
	return /* @__PURE__ */ jsx(ButtonWithVariants, {
		className: cn(newButtonClass, className),
		...props,
		children: /* @__PURE__ */ jsxs("span", {
			className: "inline-flex items-center gap-2",
			children: [/* @__PURE__ */ jsx(Icon, {
				icon,
				"aria-hidden": true,
				className: "h-4 w-4"
			}), children]
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/server/files/FileManagerBreadcrumbs.tsx
function FileManagerBreadcrumbs({ children, withinFileEditor, isNewFile }) {
	const id = useCurrentServerIdentifier();
	const directory = useServerDirectory();
	const file = withinFileEditor && !isNewFile ? directory.split("/").pop() || null : null;
	const breadcrumbDirectory = file ? dirname(directory) : directory;
	const breadcrumbs = () => breadcrumbDirectory.split("/").filter((directory) => !!directory).map((directory, index, dirs) => {
		if (!withinFileEditor && index === dirs.length - 1) return { name: directory };
		return {
			name: directory,
			path: `/${dirs.slice(0, index + 1).join("/")}`
		};
	});
	return /* @__PURE__ */ jsxs("div", {
		className: "flex grow-0 items-center text-sm text-muted-foreground overflow-x-hidden",
		children: [
			children || /* @__PURE__ */ jsx("div", { className: "w-12" }),
			"/",
			/* @__PURE__ */ jsx("span", {
				className: "px-1 text-muted-foreground",
				children: "home"
			}),
			"/",
			/* @__PURE__ */ jsx(Link, {
				to: "/server/$id/files",
				params: { id },
				hash: "/",
				className: "px-1 text-foreground no-underline transition-colors duration-150 hover:text-accent",
				children: "container"
			}),
			"/",
			breadcrumbs().map((crumb) => crumb.path ? /* @__PURE__ */ jsxs(React.Fragment, { children: [/* @__PURE__ */ jsx(Link, {
				to: "/server/$id/files",
				params: { id },
				hash: encodePathSegments(crumb.path),
				className: "px-1 text-foreground no-underline transition-colors duration-150 hover:text-accent",
				children: crumb.name
			}), "/"] }, crumb.path) : /* @__PURE__ */ jsx("span", {
				className: "px-1 text-muted-foreground",
				children: crumb.name
			}, `current:${crumb.name}`)),
			file && /* @__PURE__ */ jsx("span", {
				className: "px-1 text-muted-foreground",
				children: file
			})
		]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/Code.tsx
function Code({ dark, className, children }) {
	return /* @__PURE__ */ jsx("code", {
		className: cn("font-mono px-1.5 py-0.5 inline-block rounded-sm", className, {
			"bg-sunken": !dark,
			"bg-muted text-foreground": dark
		}),
		children
	});
}
//#endregion
//#region ../../resources/scripts/components/server/files/FileManagerStatus.tsx
var svgProps = {
	cx: 16,
	cy: 16,
	r: 14,
	strokeWidth: 3,
	fill: "none",
	stroke: "currentColor"
};
var Spinner = ({ progress, className }) => /* @__PURE__ */ jsxs("svg", {
	viewBox: "0 0 32 32",
	className,
	children: [/* @__PURE__ */ jsx("circle", {
		...svgProps,
		className: "opacity-25"
	}), /* @__PURE__ */ jsx("circle", {
		...svgProps,
		stroke: "currentColor",
		strokeDasharray: 28 * Math.PI,
		className: "-rotate-90 origin-[50%_50%] transition-[stroke-dashoffset] duration-300",
		style: { strokeDashoffset: (100 - progress) / 100 * 28 * Math.PI }
	})]
});
var percent = (loaded, total) => total > 0 ? loaded / total * 100 : 0;
var FileUploadList = ({ onClose }) => {
	const cancelFileUpload = useServerStore((state) => state.files.cancelFileUpload);
	const clearFileUploads = useServerStore((state) => state.files.clearFileUploads);
	const uploadsById = useServerStore((state) => state.files.uploads);
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-2 mt-6",
		children: [React.useMemo(() => Object.entries(uploadsById).sort(([a, first], [b, second]) => first.name.localeCompare(second.name) || a.localeCompare(b)), [uploadsById]).map(([id, file]) => /* @__PURE__ */ jsxs("div", {
			className: "flex items-center space-x-3 bg-card p-3 rounded-sm",
			children: [
				/* @__PURE__ */ jsx(Tooltip, {
					content: `${Math.floor(percent(file.loaded, file.total))}%`,
					placement: "left",
					children: /* @__PURE__ */ jsx("div", {
						className: "shrink-0",
						children: /* @__PURE__ */ jsx(Spinner, {
							progress: percent(file.loaded, file.total),
							className: "w-6 h-6"
						})
					})
				}),
				/* @__PURE__ */ jsx(Code, {
					className: "flex-1 truncate",
					children: file.name
				}),
				/* @__PURE__ */ jsx("button", {
					type: "button",
					"aria-label": `Cancel upload of ${file.name}`,
					onClick: () => cancelFileUpload(id),
					className: "text-muted-foreground hover:text-foreground transition-colors duration-75",
					children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
				})
			]
		}, id)), /* @__PURE__ */ jsxs(Dialog.Footer, { children: [/* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
			isSecondary: true,
			onClick: () => clearFileUploads(),
			children: "Cancel Uploads"
		}), /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
			onClick: onClose,
			children: "Close"
		})] })]
	});
};
function FileManagerStatus() {
	const count = useServerStore((state) => Object.keys(state.files.uploads).length);
	const uploaded = useServerStore((state) => Object.values(state.files.uploads).reduce((count, file) => count + file.loaded, 0));
	const total = useServerStore((state) => Object.values(state.files.uploads).reduce((count, file) => count + file.total, 0));
	if (count === 0) return null;
	return /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(Tooltip, {
			content: `${count} files are uploading, click to view`,
			children: /* @__PURE__ */ jsxs("button", {
				type: "button",
				className: "flex items-center justify-center w-10 h-10",
				onClick,
				children: [/* @__PURE__ */ jsx(Spinner, {
					progress: percent(uploaded, total),
					className: "w-8 h-8"
				}), /* @__PURE__ */ jsx(CloudUpload, { className: "h-3 absolute mx-auto animate-pulse" })]
			})
		}),
		children: ({ open, onClose }) => /* @__PURE__ */ jsx(Dialog, {
			open,
			onClose,
			title: "File Uploads",
			description: "The following files are being uploaded to your server.",
			children: /* @__PURE__ */ jsx(FileUploadList, { onClose })
		})
	});
}
//#endregion
//#region ../../resources/scripts/extensions/componentSession.tsx
var COMPONENT_LOAD_TIMEOUT_MS = 5e3;
/** One replacement decision per component name, shared by every mount on the page. */
function createComponentSession() {
	const decisions = /* @__PURE__ */ new Map();
	const listeners = /* @__PURE__ */ new Map();
	const pending = /* @__PURE__ */ new Map();
	const imports = /* @__PURE__ */ new Map();
	const snapshot = (name) => {
		let decision = decisions.get(name);
		if (!decision) {
			decision = getComponentOwner(name) ? { status: "loading" } : { status: "default" };
			decisions.set(name, decision);
		}
		return decision;
	};
	const start = (name) => {
		if (snapshot(name).status !== "loading" || pending.has(name)) return;
		const extensionId = getComponentOwner(name);
		let active = true;
		let unsubscribe = () => {};
		let timer;
		const stop = () => {
			active = false;
			clearTimeout(timer);
			unsubscribe();
			pending.delete(name);
		};
		const settle = (decision) => {
			if (!active) return;
			stop();
			decisions.set(name, decision);
			for (const listener of listeners.get(name) ?? []) listener();
		};
		timer = setTimeout(() => {
			reportExtensionError(extensionId, `component "${name}"`, /* @__PURE__ */ new Error(`Component loading exceeded ${COMPONENT_LOAD_TIMEOUT_MS}ms; the native view is retained until this page is reopened.`));
			settle({ status: "default" });
		}, COMPONENT_LOAD_TIMEOUT_MS);
		const check = () => {
			const state = getExtensionLoadState(extensionId);
			if (state?.status === "failed") settle({ status: "default" });
			else if (state?.status === "loaded") {
				const replacement = getComponentReplacement(name);
				if (!replacement) {
					settle({ status: "default" });
					return;
				}
				let imported = imports.get(name);
				if (!imported) {
					imported = Promise.resolve().then(async () => {
						const Component = "load" in replacement ? (await replacement.load()).default : replacement;
						if (!isReplacementComponent(Component)) throw new Error("The component importer must return a default React component.");
						return Component;
					});
					imports.set(name, imported);
				}
				imported.then((component) => settle({
					status: "ready",
					extensionId,
					component
				}), (error) => {
					if (!active) return;
					reportExtensionError(extensionId, `component "${name}"`, error);
					settle({ status: "default" });
				});
			}
		};
		pending.set(name, stop);
		unsubscribe = subscribeExtensionRegistry(check);
		check();
	};
	return {
		snapshot,
		subscribe(name, listener) {
			const subscribers = listeners.get(name) ?? /* @__PURE__ */ new Set();
			subscribers.add(listener);
			listeners.set(name, subscribers);
			start(name);
			return () => {
				subscribers.delete(listener);
				if (subscribers.size === 0) {
					listeners.delete(name);
					pending.get(name)?.();
				}
			};
		}
	};
}
var ComponentSession = createContext(null);
function useComponentDecision(name) {
	const shared = useContext(ComponentSession);
	const [local] = useState(createComponentSession);
	const session = shared ?? local;
	return useSyncExternalStore(useCallback((listener) => session.subscribe(name, listener), [session, name]), useCallback(() => session.snapshot(name), [session, name]));
}
//#endregion
//#region ../../resources/scripts/extensions/ComponentView.tsx
function SuspendedView({ onSuspend }) {
	useLayoutEffect(onSuspend, [onSuspend]);
	return null;
}
function ComponentView({ name, props, loading, resetKey }) {
	const decision = useComponentDecision(name);
	const [suspended, setSuspended] = useState(false);
	const extensionId = decision.status === "ready" ? decision.extensionId : "";
	const context = `component "${name}" (${resetKey})`;
	const onSuspend = useCallback(() => {
		reportExtensionError(extensionId, context, /* @__PURE__ */ new Error("Replacement suspended outside a local Suspense boundary; using the native view."));
		setSuspended(true);
	}, [extensionId, context]);
	const Default = props.Default;
	if (decision.status === "loading") return loading;
	if (decision.status === "default" || suspended) return /* @__PURE__ */ jsx(Default, {});
	const Component = decision.component;
	return /* @__PURE__ */ jsx(ExtensionMount, {
		extensionId,
		context,
		resetKey,
		loading: /* @__PURE__ */ jsx(SuspendedView, { onSuspend }),
		failure: /* @__PURE__ */ jsx(Default, {}),
		children: /* @__PURE__ */ jsx(Component, { ...props })
	});
}
//#endregion
//#region ../../resources/scripts/components/server/files/RenameFileModal.tsx
var RenameFileModal = ({ files, useMoveTerminology, ...props }) => {
	const uuid = useCurrentServerUuid();
	const directory = useServerDirectory();
	const clearSelectedFiles = useServerStore((state) => state.files.clearSelectedFiles);
	const renameFiles = useRenameFiles();
	const form = useAppForm({
		defaultValues: { name: files.length > 1 ? "" : files[0] || "" },
		onSubmit: async ({ value: { name } }) => {
			const data = files.map((f) => ({
				from: f,
				to: useMoveTerminology && files.length > 1 ? join(name, f) : name
			}));
			try {
				await renameFiles.mutateAsync(renameFilesInput(uuid, directory, data));
				clearSelectedFiles();
			} catch {}
			props.onClose();
		}
	});
	const isSubmitting = useStore(form.store, (state) => state.isSubmitting);
	const name = useStore(form.store, (state) => state.values.name);
	return /* @__PURE__ */ jsxs(Dialog, {
		...props,
		preventExternalClose: isSubmitting,
		hideCloseIcon: isSubmitting,
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: isSubmitting }), /* @__PURE__ */ jsxs(Form, {
			form,
			className: "m-0",
			children: [/* @__PURE__ */ jsxs("div", {
				className: cn("flex flex-wrap", useMoveTerminology ? "items-center" : "items-end"),
				children: [/* @__PURE__ */ jsx("div", {
					className: "w-full sm:flex-1 sm:mr-4",
					children: /* @__PURE__ */ jsx(form.AppField, {
						name: "name",
						children: (field) => /* @__PURE__ */ jsx(field.TextField, {
							type: "string",
							id: "file_name",
							label: "File Name",
							description: useMoveTerminology ? "Enter the new name and directory of this file or folder, relative to the current directory." : void 0,
							autoFocus: true
						})
					})
				}), /* @__PURE__ */ jsx("div", {
					className: "w-full sm:w-auto mt-4 sm:mt-0",
					children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
						className: "w-full",
						children: useMoveTerminology ? "Move" : "Rename"
					}) })
				})]
			}), useMoveTerminology && /* @__PURE__ */ jsxs("p", {
				className: "text-xs mt-2 text-muted-foreground",
				children: [
					/* @__PURE__ */ jsx("strong", {
						className: "text-foreground",
						children: "New location:"
					}),
					"\xA0/home/container/",
					join(directory, name).replace(/^(\.\.\/|\/)+/, "")
				]
			})]
		})]
	});
};
//#endregion
//#region ../../resources/scripts/components/server/files/ChmodFileModal.tsx
var ChmodFileModal = ({ files, ...props }) => {
	const uuid = useCurrentServerUuid();
	const directory = useServerDirectory();
	const clearSelectedFiles = useServerStore((state) => state.files.clearSelectedFiles);
	const chmodFiles = useChmodFiles();
	const form = useAppForm({
		defaultValues: { mode: files.length > 1 ? "" : files[0].mode || "" },
		onSubmit: async ({ value: { mode } }) => {
			const data = files.map((f) => ({
				file: f.file,
				mode
			}));
			try {
				await chmodFiles.mutateAsync(chmodFilesInput(uuid, directory, data));
				clearSelectedFiles();
			} catch {}
			props.onClose();
		}
	});
	const isSubmitting = useStore(form.store, (state) => state.isSubmitting);
	return /* @__PURE__ */ jsxs(Dialog, {
		...props,
		preventExternalClose: isSubmitting,
		hideCloseIcon: isSubmitting,
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: isSubmitting }), /* @__PURE__ */ jsx(Form, {
			form,
			className: "m-0",
			children: /* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-end",
				children: [/* @__PURE__ */ jsx("div", {
					className: "w-full sm:flex-1 sm:mr-4",
					children: /* @__PURE__ */ jsx(form.AppField, {
						name: "mode",
						children: (field) => /* @__PURE__ */ jsx(field.TextField, {
							type: "string",
							id: "file_mode",
							label: "File Mode",
							autoFocus: true
						})
					})
				}), /* @__PURE__ */ jsx("div", {
					className: "w-full sm:w-auto mt-4 sm:mt-0",
					children: /* @__PURE__ */ jsx(form.AppForm, { children: /* @__PURE__ */ jsx(form.SubmitButton, {
						className: "w-full",
						children: "Update"
					}) })
				})]
			})
		})]
	});
};
//#endregion
//#region ../../resources/scripts/components/server/files/FileActionItems.tsx
function FileActionItems({ file, onRename, onMove, onChmod, onCopy, onUnarchive, onArchive, onDownload, onDelete }) {
	const { attributes } = file;
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsxs(Can, {
			action: "file.update",
			children: [
				/* @__PURE__ */ jsx(DropdownMenuItem, {
					onClick: onRename,
					icon: Pencil,
					description: "Change item name",
					children: "Rename"
				}),
				/* @__PURE__ */ jsx(DropdownMenuItem, {
					onClick: onMove,
					icon: CornerLeftUp,
					description: "Move to a path",
					children: "Move"
				}),
				/* @__PURE__ */ jsx(DropdownMenuItem, {
					onClick: onChmod,
					icon: FileCode,
					description: "Edit mode bits",
					children: "Permissions"
				})
			]
		}),
		attributes.is_file && /* @__PURE__ */ jsx(Can, {
			action: "file.create",
			children: /* @__PURE__ */ jsx(DropdownMenuItem, {
				onClick: onCopy,
				icon: Copy,
				description: "Duplicate in place",
				children: "Copy"
			})
		}),
		isFileObjectArchiveType(file) ? /* @__PURE__ */ jsx(Can, {
			action: ["file.create", "file.update"],
			children: /* @__PURE__ */ jsx(DropdownMenuItem, {
				onClick: onUnarchive,
				icon: PackageOpen,
				description: "Extract contents",
				children: "Unarchive"
			})
		}) : /* @__PURE__ */ jsx(Can, {
			action: "file.archive",
			children: /* @__PURE__ */ jsx(DropdownMenuItem, {
				onClick: onArchive,
				icon: FileArchive,
				description: "Compress item",
				children: "Archive"
			})
		}),
		attributes.is_file && /* @__PURE__ */ jsx(DropdownMenuItem, {
			onClick: onDownload,
			icon: FileDown,
			description: "Save locally",
			children: "Download"
		}),
		/* @__PURE__ */ jsx(Can, {
			action: "file.delete",
			children: /* @__PURE__ */ jsx(DropdownMenuItem, {
				onClick: onDelete,
				icon: Trash2,
				danger: true,
				description: "Permanently remove",
				className: "mt-1 border-t border-border/70 pt-3",
				children: "Delete"
			})
		})
	] });
}
//#endregion
//#region ../../resources/scripts/components/server/files/useFileActions.tsx
var FileRowActionsContext = createContext(null);
/** Renders the row action dialogs once for every file row below it. */
function FileRowActionsProvider({ children }) {
	const [modal, setModal] = useState(null);
	const [target, setTarget] = useState(null);
	const uuid = useCurrentServerUuid();
	const directory = useServerDirectory();
	const removeSelectedFile = useServerStore((state) => state.files.removeSelectedFile);
	const { mutateAsync: deleteFiles } = useDeleteFiles();
	const copyFile = useCopyFile(directory);
	const downloadFile = useFileDownloadUrl();
	const compressFiles = useCompressFiles();
	const decompressFile = useDecompressFile();
	const { mutateAsync: copy } = copyFile;
	const { mutateAsync: download } = downloadFile;
	const { mutateAsync: compress } = compressFiles;
	const { mutateAsync: decompress } = decompressFile;
	const actions = useMemo(() => ({
		open: (next, file) => {
			setTarget(file);
			setModal(next);
		},
		copy: ({ attributes }) => {
			copy(copyFileInput(uuid, join(directory, attributes.name))).catch(() => {});
		},
		download: ({ attributes }) => {
			download({
				uuid,
				file: join(directory, attributes.name)
			}).then((url) => {
				window.location.assign(url);
			}).catch(() => {});
		},
		archive: ({ attributes }) => {
			compress(compressFilesInput(uuid, directory, [attributes.name])).catch(() => {});
		},
		unarchive: ({ attributes }) => {
			decompress(decompressFileInput(uuid, directory, attributes.name)).catch(() => {});
		}
	}), [
		uuid,
		directory,
		copy,
		download,
		compress,
		decompress
	]);
	const close = () => setModal(null);
	const name = target?.attributes.name ?? "";
	const doDeletion = () => {
		deleteFiles(deleteFilesInput(uuid, directory, [name])).then(() => removeSelectedFile({
			directory,
			name
		})).catch(() => {});
	};
	const showSpinner = copyFile.isPending || downloadFile.isPending || compressFiles.isPending || decompressFile.isPending;
	return /* @__PURE__ */ jsxs(FileRowActionsContext.Provider, {
		value: actions,
		children: [
			children,
			/* @__PURE__ */ jsxs(Dialog.Confirm, {
				open: modal === "delete",
				onClose: close,
				title: `Delete ${target?.attributes.is_file === false ? "Directory" : "File"}`,
				confirm: "Delete",
				onConfirmed: () => {
					close();
					doDeletion();
				},
				children: [
					"You will not be able to recover the contents of\xA0",
					/* @__PURE__ */ jsx("span", {
						className: "font-semibold text-foreground",
						children: name
					}),
					" once deleted."
				]
			}),
			target && modal === "chmod" && /* @__PURE__ */ jsx(ChmodFileModal, {
				open: true,
				files: [{
					file: name,
					mode: target.attributes.mode_bits ?? ""
				}],
				onClose: close
			}, name),
			target && (modal === "rename" || modal === "move") && /* @__PURE__ */ jsx(RenameFileModal, {
				open: true,
				files: [name],
				useMoveTerminology: modal === "move",
				onClose: close
			}, `${modal}:${name}`),
			/* @__PURE__ */ jsx(SpinnerOverlay, {
				visible: showSpinner,
				fixed: true,
				size: "large"
			})
		]
	});
}
function useFileActions(file) {
	const actions = use(FileRowActionsContext);
	if (!actions) throw new Error("FileRowActionsProvider is missing from the component tree.");
	return { items: /* @__PURE__ */ jsx(FileActionItems, {
		file,
		onRename: () => actions.open("rename", file),
		onMove: () => actions.open("move", file),
		onChmod: () => actions.open("chmod", file),
		onCopy: () => actions.copy(file),
		onUnarchive: () => actions.unarchive(file),
		onArchive: () => actions.archive(file),
		onDownload: () => actions.download(file),
		onDelete: () => actions.open("delete", file)
	}) };
}
//#endregion
//#region ../../resources/scripts/components/server/files/SelectFileCheckbox.tsx
var import_react_fast_compare = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	var hasElementType = typeof Element !== "undefined";
	var hasMap = typeof Map === "function";
	var hasSet = typeof Set === "function";
	var hasArrayBuffer = typeof ArrayBuffer === "function" && !!ArrayBuffer.isView;
	function equal(a, b) {
		if (a === b) return true;
		if (a && b && typeof a == "object" && typeof b == "object") {
			if (a.constructor !== b.constructor) return false;
			var length, i, keys;
			if (Array.isArray(a)) {
				length = a.length;
				if (length != b.length) return false;
				for (i = length; i-- !== 0;) if (!equal(a[i], b[i])) return false;
				return true;
			}
			var it;
			if (hasMap && a instanceof Map && b instanceof Map) {
				if (a.size !== b.size) return false;
				it = a.entries();
				while (!(i = it.next()).done) if (!b.has(i.value[0])) return false;
				it = a.entries();
				while (!(i = it.next()).done) if (!equal(i.value[1], b.get(i.value[0]))) return false;
				return true;
			}
			if (hasSet && a instanceof Set && b instanceof Set) {
				if (a.size !== b.size) return false;
				it = a.entries();
				while (!(i = it.next()).done) if (!b.has(i.value[0])) return false;
				return true;
			}
			if (hasArrayBuffer && ArrayBuffer.isView(a) && ArrayBuffer.isView(b)) {
				length = a.length;
				if (length != b.length) return false;
				for (i = length; i-- !== 0;) if (a[i] !== b[i]) return false;
				return true;
			}
			if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
			if (a.valueOf !== Object.prototype.valueOf && typeof a.valueOf === "function" && typeof b.valueOf === "function") return a.valueOf() === b.valueOf();
			if (a.toString !== Object.prototype.toString && typeof a.toString === "function" && typeof b.toString === "function") return a.toString() === b.toString();
			keys = Object.keys(a);
			length = keys.length;
			if (length !== Object.keys(b).length) return false;
			for (i = length; i-- !== 0;) if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
			if (hasElementType && a instanceof Element) return false;
			for (i = length; i-- !== 0;) {
				if ((keys[i] === "_owner" || keys[i] === "__v" || keys[i] === "__o") && a.$$typeof) continue;
				if (!equal(a[keys[i]], b[keys[i]])) return false;
			}
			return true;
		}
		return a !== a && b !== b;
	}
	module.exports = function isEqual(a, b) {
		try {
			return equal(a, b);
		} catch (error) {
			if ((error.message || "").match(/stack|recursion/i)) {
				console.warn("react-fast-compare cannot handle circular refs");
				return false;
			}
			throw error;
		}
	};
})))());
function SelectFileCheckbox({ name }) {
	const directory = useServerDirectory();
	const isChecked = useServerStore((state) => state.files.selectedDirectory === directory && state.files.selectedFiles.includes(name));
	const appendSelectedFile = useServerStore((state) => state.files.appendSelectedFile);
	const removeSelectedFile = useServerStore((state) => state.files.removeSelectedFile);
	return /* @__PURE__ */ jsx("div", {
		className: "flex-none px-4 py-2 absolute self-center z-30",
		children: /* @__PURE__ */ jsx(Checkbox, {
			name: "selectedFiles",
			value: name,
			"aria-label": `Select ${name}`,
			checked: isChecked,
			onChange: (checked) => checked ? appendSelectedFile({
				directory,
				name
			}) : removeSelectedFile({
				directory,
				name
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/server/files/useFileManagerExtensionData.ts
var FileManagerExtensionContext = createContext(null);
function useFileManagerExtensionData() {
	return useContext(FileManagerExtensionContext);
}
//#endregion
//#region ../../resources/scripts/components/server/files/FileObjectRow.tsx
var fileRowClass = "flex items-center cursor-pointer bg-card rounded-xs mb-px text-sm no-underline hover:text-foreground hover:bg-popover";
var detailsClass = "flex flex-1 items-center text-muted-foreground no-underline px-4 py-2 overflow-hidden truncate";
var Clickable = memo(({ file, children }) => {
	const [canRead] = usePermissions(["file.read"]);
	const [canReadContents] = usePermissions(["file.read-content"]);
	const directory = useServerDirectory();
	const id = useCurrentServerIdentifier();
	const { attributes } = file;
	const hash = encodePathSegments(join(directory, attributes.name));
	if (!(attributes.is_file ? isFileObjectEditable(file) && canReadContents : canRead)) return /* @__PURE__ */ jsx("div", {
		className: cn(detailsClass, "cursor-default"),
		children
	});
	if (attributes.is_file) return /* @__PURE__ */ jsx(Link, {
		"aria-label": attributes.name,
		className: detailsClass,
		to: "/server/$id/files/$action",
		params: {
			id,
			action: "edit"
		},
		hash,
		children
	});
	return /* @__PURE__ */ jsx(Link, {
		"aria-label": attributes.name,
		className: detailsClass,
		to: "/server/$id/files",
		params: { id },
		hash,
		children
	});
}, import_react_fast_compare.default);
var RowActionsSlot = ({ file }) => {
	const extensionData = useFileManagerExtensionData();
	return extensionData && /* @__PURE__ */ jsx(Slot, {
		name: "server.files.rowActions",
		data: {
			...extensionData,
			file
		}
	});
};
var FileObjectRow = ({ file }) => {
	const { items } = useFileActions(file);
	const { attributes } = file;
	const uuid = useCurrentServerUuid();
	const directory = useServerDirectory();
	const model = useMemo(() => ({
		name: attributes.name,
		kind: fileObjectKind(file),
		size: attributes.size ?? 0,
		modifiedAt: attributes.modified_at
	}), [attributes, file]);
	const actionItems = /* @__PURE__ */ jsxs(Fragment, { children: [items, /* @__PURE__ */ jsx(RowActionsSlot, { file })] });
	return /* @__PURE__ */ jsxs(ContextDropdownMenu, {
		className: fileRowClass,
		menuClassName: "w-64",
		items: actionItems,
		children: [
			/* @__PURE__ */ jsx(SelectFileCheckbox, { name: attributes.name }),
			/* @__PURE__ */ jsx(Clickable, {
				file,
				children: /* @__PURE__ */ jsx(FileDetailsContext.Provider, {
					value: model,
					children: /* @__PURE__ */ jsx(ComponentView, {
						name: "server.files.details",
						resetKey: `${uuid ?? ""}:${directory}:${attributes.name}`,
						props: {
							model,
							Default: DefaultFileDetails,
							parts: fileDetailsParts
						},
						loading: /* @__PURE__ */ jsx("div", {
							className: "h-5 w-full animate-pulse rounded-sm bg-muted",
							"aria-label": "Loading file details"
						})
					})
				})
			}),
			/* @__PURE__ */ jsx(DropdownMenuWithItems, {
				className: "w-64",
				triggerClassName: "mr-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",
				triggerContent: /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Icon, {
					icon: MoreHorizontal,
					className: "h-4 w-4"
				}), /* @__PURE__ */ jsx("span", {
					className: "sr-only",
					children: "Open file options"
				})] }),
				children: actionItems
			})
		]
	});
};
var FileObjectRow_default = memo(FileObjectRow, (prevProps, nextProps) => (0, import_react_fast_compare.default)(prevProps.file, nextProps.file));
//#endregion
//#region ../../resources/scripts/components/server/files/MassActionsBar.tsx
/** `selectedFiles` must be entries of the current listing. */
var MassActionsBar = ({ selectedFiles }) => {
	const uuid = useCurrentServerUuid();
	const directory = useServerDirectory();
	const clearSelectedFiles = useServerStore((state) => state.files.clearSelectedFiles);
	const compressFiles = useCompressFiles();
	const deleteFiles = useDeleteFiles();
	const onClickCompress = () => {
		compressFiles.mutateAsync(compressFilesInput(uuid, directory, [...selectedFiles])).then(() => clearSelectedFiles()).catch(() => {});
	};
	const onClickConfirmDeletion = (close) => {
		close();
		deleteFiles.mutateAsync(deleteFilesInput(uuid, directory, [...selectedFiles])).then(() => {
			clearSelectedFiles();
		}).catch(() => {});
	};
	const loading = compressFiles.isPending || deleteFiles.isPending;
	const extensionData = useFileManagerExtensionData();
	return /* @__PURE__ */ jsxs("div", {
		className: "pointer-events-none fixed bottom-0 z-20 left-0 right-0 flex justify-center",
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, {
			visible: loading,
			size: "large",
			fixed: true
		}), /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx("div", {
			className: "pointer-events-none fixed bottom-0 mb-6 flex justify-center w-full z-50",
			children: selectedFiles.length > 0 && /* @__PURE__ */ jsxs("div", {
				className: "flex items-center space-x-4 pointer-events-auto rounded-sm p-4 bg-background/50",
				children: [
					extensionData && /* @__PURE__ */ jsx(Slot, {
						name: "server.files.selectionActions",
						data: extensionData
					}),
					/* @__PURE__ */ jsx(Dialog.Trigger, {
						trigger: ({ onClick }) => /* @__PURE__ */ jsx(ButtonWithVariants, {
							onClick,
							children: "Move"
						}),
						children: ({ open, onClose }) => open && /* @__PURE__ */ jsx(RenameFileModal, {
							files: [...selectedFiles],
							open,
							useMoveTerminology: true,
							onClose
						})
					}),
					/* @__PURE__ */ jsx(ButtonWithVariants, {
						onClick: onClickCompress,
						children: "Archive"
					}),
					/* @__PURE__ */ jsxs(Dialog.ConfirmTrigger, {
						title: "Delete Files",
						confirm: "Delete",
						trigger: ({ onClick }) => /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
							isSecondary: true,
							onClick,
							children: "Delete"
						}),
						onConfirmed: (_event, close) => onClickConfirmDeletion(close),
						children: [/* @__PURE__ */ jsxs("p", {
							className: "mb-2",
							children: [
								"Are you sure you want to delete\xA0",
								/* @__PURE__ */ jsxs("span", {
									className: "font-semibold text-foreground",
									children: [selectedFiles.length, " files"]
								}),
								"? This is a permanent action and the files cannot be recovered."
							]
						}), /* @__PURE__ */ jsxs("ul", {
							className: "mt-2 mb-0 pl-6 list-disc list-outside",
							children: [selectedFiles.slice(0, 15).map((file) => /* @__PURE__ */ jsx("li", { children: file }, file)), selectedFiles.length > 15 && /* @__PURE__ */ jsxs("li", { children: [
								"and ",
								selectedFiles.length - 15,
								" others"
							] })]
						})]
					})
				]
			})
		}) })]
	});
};
//#endregion
//#region ../../resources/scripts/components/server/files/NewDirectoryButton.tsx
var NewDirectoryDialogContent = ({ onClose }) => {
	const uuid = useCurrentServerUuid();
	const directory = useServerDirectory();
	const createDirectory = useCreateDirectory();
	const form = useAppForm({
		defaultValues: { directoryName: "" },
		onSubmit: async ({ value }) => {
			try {
				await createDirectory.mutateAsync(createDirectoryInput(uuid, directory, value.directoryName));
				onClose();
			} catch {}
		}
	});
	const directoryName = useStore(form.store, (state) => state.values.directoryName);
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs(Form, {
		form,
		className: "m-0",
		children: [/* @__PURE__ */ jsx(form.AppField, {
			name: "directoryName",
			validators: { onChange: ({ value }) => value.length >= 1 ? void 0 : "A valid directory name must be provided." },
			children: (field) => /* @__PURE__ */ jsx(field.TextField, {
				autoFocus: true,
				id: "directoryName",
				label: "Name"
			})
		}), /* @__PURE__ */ jsxs("p", {
			className: "mt-2 text-sm md:text-base break-all",
			children: [/* @__PURE__ */ jsx("span", {
				className: "text-foreground",
				children: "This directory will be created as\xA0"
			}), /* @__PURE__ */ jsxs(Code, { children: ["/home/container/", /* @__PURE__ */ jsx("span", {
				className: "text-accent",
				children: normalizeServerPath(join(directory, directoryName))
			})] })]
		})]
	}), /* @__PURE__ */ jsxs(Dialog.Footer, { children: [/* @__PURE__ */ jsx(ButtonWithVariants.Text, {
		className: "w-full sm:w-auto",
		onClick: onClose,
		children: "Cancel"
	}), /* @__PURE__ */ jsx(ButtonWithVariants, {
		className: "w-full sm:w-auto",
		onClick: () => form.handleSubmit(),
		children: "Create"
	})] })] });
};
function NewDirectoryButton({ className }) {
	return /* @__PURE__ */ jsx(Dialog.Trigger, {
		trigger: ({ onClick }) => /* @__PURE__ */ jsx(NewButton, {
			onClick,
			className,
			children: "New folder"
		}),
		children: ({ open, onClose }) => /* @__PURE__ */ jsx(Dialog, {
			open,
			onClose,
			title: "Create folder",
			children: /* @__PURE__ */ jsx(NewDirectoryDialogContent, { onClose })
		})
	});
}
//#endregion
//#region ../../resources/scripts/plugins/useEventListener.ts
var useEventListener_default = (eventName, handler, options) => {
	const savedHandler = useRef(handler);
	const normalizedOptions = options === true || options === false ? void 0 : options;
	const capture = options === true || normalizedOptions?.capture === true;
	const hasOptions = options !== void 0;
	const once = normalizedOptions?.once;
	const passive = normalizedOptions?.passive;
	const signal = normalizedOptions?.signal;
	useEffect(() => {
		savedHandler.current = handler;
	}, [handler]);
	useEffect(() => {
		const target = globalThis.window;
		if (!target?.addEventListener) return;
		const eventListener = (event) => savedHandler.current(event);
		const listenerOptions = hasOptions ? {
			capture,
			once,
			passive,
			signal
		} : void 0;
		target.addEventListener(eventName, eventListener, listenerOptions);
		return () => {
			target.removeEventListener(eventName, eventListener, capture);
		};
	}, [
		capture,
		eventName,
		hasOptions,
		once,
		passive,
		signal
	]);
};
//#endregion
//#region ../../resources/scripts/components/server/files/useFileUploader.ts
var UPLOADED_DISPLAY_MS = 500;
/** Uploads into the current directory; rejects when any file failed, after its error toast. */
function useFileUploader() {
	const removals = useRef(/* @__PURE__ */ new Map());
	const { mutateAsync } = useUploadFiles();
	const uuid = useCurrentServerUuid();
	const directory = useServerDirectory();
	const { removeFileUpload, pushFileUpload, setUploadProgress } = useFileUploadActions();
	useEffect(() => {
		const pending = removals.current;
		return () => {
			for (const [id, timeout] of pending) {
				clearTimeout(timeout);
				removeFileUpload(id);
			}
			pending.clear();
		};
	}, [removeFileUpload]);
	return useCallback(async (files) => {
		if (files.some((file) => !file.type && (!file.size || file.size === 4096))) {
			toast.error("Folder uploads are not supported.");
			throw new Error("Folder uploads are not supported.");
		}
		const { failed } = await mutateAsync({
			uuid,
			directory,
			files: [...files],
			callbacks: {
				onFileQueued: (id, file, abort) => {
					pushFileUpload({
						id,
						data: {
							name: file.name,
							abort,
							loaded: 0,
							total: file.size
						}
					});
				},
				onFileProgress: (id, progress) => setUploadProgress({
					id,
					loaded: progress.loaded
				}),
				onFileSettled: (id, outcome) => {
					if (outcome !== "uploaded") {
						removeFileUpload(id);
						return;
					}
					const timeout = setTimeout(() => {
						removals.current.delete(id);
						removeFileUpload(id);
					}, UPLOADED_DISPLAY_MS);
					removals.current.set(id, timeout);
				}
			}
		});
		if (failed.length > 0) throw new Error(failed.length === 1 ? `Unable to upload ${failed[0].name}.` : `Unable to upload ${failed.length} files.`);
	}, [
		mutateAsync,
		uuid,
		directory,
		removeFileUpload,
		pushFileUpload,
		setUploadProgress
	]);
}
//#endregion
//#region ../../resources/scripts/components/server/files/UploadButton.tsx
function isFileOrDirectory(event) {
	if (!event.dataTransfer?.types) return false;
	return event.dataTransfer.types.some((value) => value.toLowerCase() === "files");
}
function UploadButton({ className }) {
	const fileUploadInput = useRef(null);
	const dropOverlay = useDialogState();
	const upload = useFileUploader();
	useEventListener_default("dragenter", (e) => {
		e.preventDefault();
		e.stopPropagation();
		if (isFileOrDirectory(e)) dropOverlay.show();
	}, { capture: true });
	useEventListener_default("dragexit", dropOverlay.hide, { capture: true });
	useEventListener_default("keydown", dropOverlay.hide);
	const onFileSubmission = (files) => {
		upload([...files]).catch(() => {});
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(Portal, { children: dropOverlay.open && /* @__PURE__ */ jsx("div", {
			className: "fixed z-50 overflow-auto flex w-full inset-0 bg-background/70",
			onDragOver: (e) => e.preventDefault(),
			onDrop: (e) => {
				e.preventDefault();
				e.stopPropagation();
				dropOverlay.hide();
				if (!e.dataTransfer?.files.length) return;
				onFileSubmission(e.dataTransfer.files);
			},
			children: /* @__PURE__ */ jsx("div", {
				className: "w-full flex items-center justify-center pointer-events-none",
				children: /* @__PURE__ */ jsxs("div", {
					className: "flex items-center space-x-4 bg-muted w-full ring-4 ring-ring/50 rounded-sm p-6 mx-10 max-w-sm",
					children: [/* @__PURE__ */ jsx(CloudUpload, { className: "w-10 h-10 shrink-0" }), /* @__PURE__ */ jsx("p", {
						className: "font-header flex-1 text-lg text-foreground text-center",
						children: "Drag and drop files to upload."
					})]
				})
			})
		}) }),
		/* @__PURE__ */ jsx("input", {
			type: "file",
			ref: fileUploadInput,
			className: "hidden",
			"aria-label": "Upload files",
			onChange: (e) => {
				if (!e.currentTarget.files) return;
				onFileSubmission(e.currentTarget.files);
				e.currentTarget.value = "";
			},
			multiple: true
		}),
		/* @__PURE__ */ jsx(NewButton, {
			icon: CloudUpload,
			className,
			onClick: () => fileUploadInput.current && fileUploadInput.current.click(),
			children: "Upload"
		})
	] });
}
//#endregion
//#region ../../resources/scripts/components/server/files/FileManagerView.tsx
var FileManagerContext = createContext(null);
var managerActionsClass = [
	"grid grid-cols-2 sm:grid-cols-3 w-full gap-4 mb-4",
	"md:flex md:flex-1 md:justify-end md:mb-0",
	"[&_button]:w-full [&_button:first-child]:col-span-2 sm:[&_button:first-child]:col-span-1 md:[&_button]:w-auto"
].join(" ");
function Toolbar({ model }) {
	const id = useCurrentServerIdentifier();
	const extensionData = useFileManagerExtensionData();
	return /* @__PURE__ */ jsxs(ErrorBoundary, { children: [/* @__PURE__ */ jsxs("div", {
		className: "flex flex-wrap-reverse md:flex-nowrap mb-4",
		children: [/* @__PURE__ */ jsx(FileManagerBreadcrumbs, { children: /* @__PURE__ */ jsx(Checkbox, {
			className: "mx-4",
			"aria-label": "Select all files",
			checked: model.entries.length > 0 && model.selection.length === model.entries.length,
			indeterminate: model.selection.length > 0 && model.selection.length < model.entries.length,
			onChange: (checked) => model.actions.select(checked ? model.entries.map((entry) => entry.name) : [])
		}) }), model.permissions.create && /* @__PURE__ */ jsxs("div", {
			className: managerActionsClass,
			children: [
				/* @__PURE__ */ jsx(FileManagerStatus, {}),
				/* @__PURE__ */ jsx(NewDirectoryButton, {}),
				model.permissions.update && /* @__PURE__ */ jsx(UploadButton, {}),
				/* @__PURE__ */ jsx(Link, {
					to: "/server/$id/files/$action",
					params: {
						id,
						action: "new"
					},
					hash: encodePathSegments(model.directory),
					children: /* @__PURE__ */ jsx(NewButton, { children: "New file" })
				})
			]
		})]
	}), extensionData && /* @__PURE__ */ jsx(Slot, {
		name: "server.files.toolbar",
		data: extensionData
	})] });
}
function List({ model }) {
	const { files } = useContext(FileManagerContext);
	if (model.loading) return /* @__PURE__ */ jsx(Spinner$1, {
		size: "large",
		centered: true
	});
	if (!files.length) return /* @__PURE__ */ jsx(Empty, {
		className: "border",
		children: /* @__PURE__ */ jsxs(EmptyHeader, { children: [
			/* @__PURE__ */ jsx(EmptyMedia, {
				variant: "icon",
				children: /* @__PURE__ */ jsx(FolderOpen, {})
			}),
			/* @__PURE__ */ jsx(EmptyTitle, { children: "This folder is empty" }),
			/* @__PURE__ */ jsx(EmptyDescription, { children: model.permissions.create ? "Upload files or create a new file or folder to get started." : "There are no files in this folder." })
		] })
	});
	return /* @__PURE__ */ jsxs("div", { children: [model.truncated && /* @__PURE__ */ jsx("div", {
		className: "rounded-sm bg-warning mb-px p-3",
		children: /* @__PURE__ */ jsx("p", {
			className: "text-warning-foreground text-sm text-center",
			children: "This directory is too large to display in the browser, limiting output to first 250 files."
		})
	}), /* @__PURE__ */ jsx(FileRowActionsProvider, { children: files.map((file) => /* @__PURE__ */ jsx(FileObjectRow_default, { file }, fileObjectKey(file))) })] });
}
function Selection({ model }) {
	return model.entries.length > 0 ? /* @__PURE__ */ jsx(MassActionsBar, { selectedFiles: model.selection }) : null;
}
var fileManagerParts = {
	toolbar: Toolbar,
	list: List,
	selection: Selection
};
function DefaultFileManager({ className, parts }) {
	const { model } = useContext(FileManagerContext);
	const ToolbarPart = parts?.toolbar ?? Toolbar;
	const ListPart = parts?.list ?? List;
	const SelectionPart = parts?.selection ?? Selection;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("min-w-0", className),
		children: [
			/* @__PURE__ */ jsx(ToolbarPart, { model }),
			/* @__PURE__ */ jsx(ListPart, { model }),
			/* @__PURE__ */ jsx(SelectionPart, { model })
		]
	});
}
//#endregion
//#region ../../resources/scripts/state/server/context.ts
var ServerContext = { Provider };
//#endregion
//#region ../../resources/scripts/plugins/Websocket.ts
var NORMAL_CLOSE_CODES = new Set([
	1e3,
	1001,
	1003
]);
var SUSPENDED_CLOSE_CODES = new Set([4400, 4409]);
var SOCKET_OPEN_STATE = 1;
var AUTH_SUCCESS_EVENT = "auth success";
var RECONNECT_BASE_DELAY_MS = 1e3;
var RECONNECT_MAX_DELAY_MS = 3e4;
/** Exponential backoff for a 1-based attempt, jittered within the upper half of the window. */
var reconnectDelay = (attempt, random = Math.random) => {
	const ceiling = Math.min(RECONNECT_MAX_DELAY_MS, RECONNECT_BASE_DELAY_MS * 2 ** Math.max(0, attempt - 1));
	return Math.round(ceiling / 2 + random() * (ceiling / 2));
};
var isOffline = () => !navigator.onLine;
var EventEmitter = class {
	listenersByEvent = /* @__PURE__ */ new Map();
	on(event, listener) {
		let listeners = this.listenersByEvent.get(event);
		if (!listeners) {
			listeners = /* @__PURE__ */ new Set();
			this.listenersByEvent.set(event, listeners);
		}
		listeners.add(listener);
		return this;
	}
	addListener(event, listener) {
		let listeners = this.listenersByEvent.get(event);
		if (!listeners) {
			listeners = /* @__PURE__ */ new Set();
			this.listenersByEvent.set(event, listeners);
		}
		listeners.add(listener);
		return this;
	}
	removeListener(event, listener) {
		this.listenersByEvent.get(event)?.delete(listener);
		return this;
	}
	removeAllListeners(event) {
		if (event === void 0) this.listenersByEvent.clear();
		else this.listenersByEvent.delete(event);
		return this;
	}
	emit(event, ...args) {
		const listeners = this.listenersByEvent.get(event);
		if (!listeners || listeners.size === 0) return false;
		for (const listener of [...listeners]) try {
			listener(...args);
		} catch (error) {
			console.error(`Websocket listener failed for "${event}".`, error);
		}
		return true;
	}
};
var Websocket = class Websocket extends EventEmitter {
	static createSocket = (url) => new WebSocket(url);
	socket = null;
	url = null;
	token = "";
	reconnectAttempts = 0;
	reconnectTimer = null;
	awaitingResume = false;
	connect(url) {
		this.disposeSocket();
		this.url = url;
		this.reconnectAttempts = 0;
		this.clearReconnectTimer();
		this.stopAwaitingResume();
		this.openSocket();
		return this;
	}
	setToken(token, isUpdate = false) {
		this.token = token;
		if (isUpdate) this.authenticate();
		return this;
	}
	authenticate() {
		if (this.url && this.token) this.send("auth", this.token);
	}
	close(code, reason) {
		this.url = null;
		this.token = "";
		this.clearReconnectTimer();
		this.stopAwaitingResume();
		this.disposeSocket(code, reason);
	}
	send(event, payload) {
		if (!this.socket || this.socket.readyState !== SOCKET_OPEN_STATE) return false;
		this.socket.send(JSON.stringify({
			event,
			args: Array.isArray(payload) ? payload : [payload]
		}));
		return true;
	}
	openSocket() {
		if (!this.url) return;
		const socket = Websocket.createSocket(this.url);
		this.socket = socket;
		socket.onmessage = (e) => {
			let message;
			try {
				message = JSON.parse(e.data);
			} catch (ex) {
				console.warn("Failed to parse incoming websocket message.", ex);
				return;
			}
			if (message.event === AUTH_SUCCESS_EVENT) this.reconnectAttempts = 0;
			if (message.args) this.emit(message.event, ...message.args);
			else this.emit(message.event);
		};
		socket.onopen = () => {
			this.emit("SOCKET_OPEN");
			this.authenticate();
		};
		socket.onerror = (error) => this.emit("SOCKET_ERROR", error);
		socket.onclose = (event) => {
			this.socket = null;
			this.emit("SOCKET_CLOSE");
			if (!this.url) return;
			if (SUSPENDED_CLOSE_CODES.has(event.code)) {
				this.close(1e3);
				return;
			}
			if (!NORMAL_CLOSE_CODES.has(event.code)) this.scheduleReconnect();
		};
	}
	disposeSocket(code, reason) {
		const socket = this.socket;
		this.socket = null;
		if (socket) {
			socket.onopen = null;
			socket.onmessage = null;
			socket.onerror = null;
			socket.onclose = null;
			socket.close(code, reason);
		}
	}
	scheduleReconnect() {
		if (!this.url || this.reconnectTimer || this.awaitingResume) return;
		if (isOffline()) {
			this.emit("SOCKET_RECONNECT");
			this.awaitResume();
			return;
		}
		if (this.reconnectAttempts >= 10) {
			this.emit("SOCKET_CONNECT_ERROR");
			this.awaitResume();
			return;
		}
		this.reconnectAttempts += 1;
		this.emit("SOCKET_RECONNECT");
		this.reconnectTimer = setTimeout(() => {
			this.reconnectTimer = null;
			this.openSocket();
		}, reconnectDelay(this.reconnectAttempts));
	}
	clearReconnectTimer() {
		if (this.reconnectTimer) {
			clearTimeout(this.reconnectTimer);
			this.reconnectTimer = null;
		}
	}
	awaitResume() {
		if (this.awaitingResume) return;
		this.awaitingResume = true;
		window.addEventListener("online", this.resume);
		document.addEventListener("visibilitychange", this.resume);
	}
	stopAwaitingResume() {
		if (!this.awaitingResume) return;
		this.awaitingResume = false;
		window.removeEventListener("online", this.resume);
		document.removeEventListener("visibilitychange", this.resume);
	}
	resume = () => {
		if (isOffline() || document.visibilityState === "hidden") return;
		this.stopAwaitingResume();
		if (!this.url || this.socket) return;
		this.reconnectAttempts = 0;
		this.emit("SOCKET_RECONNECT");
		this.openSocket();
	};
};
//#endregion
//#region ../../resources/scripts/sdk/testing.tsx
function createTestServer(options = {}) {
	const identifier = options.identifier ?? "test-server";
	const owner = options.owner ?? true;
	return {
		object: "server",
		attributes: {
			identifier,
			uuid: options.uuid ?? "11111111-1111-4111-8111-111111111111",
			__deprecated_uuid_short: identifier,
			server_identifier: identifier,
			internal_id: 1,
			server_owner: owner,
			name: options.name ?? "Test server",
			node: "Test node",
			is_node_under_maintenance: false,
			sftp_details: {
				ip: "127.0.0.1",
				port: 2022
			},
			description: null,
			limits: {
				memory: 1024,
				swap: 0,
				disk: 1024,
				io: 500,
				cpu: 100,
				threads: null,
				oom_disabled: true
			},
			invocation: "run",
			docker_image: "test/image",
			egg_features: options.eggFeatures ?? [],
			egg_tags: options.eggTags ?? [],
			feature_limits: {
				databases: 1,
				allocations: 1,
				backups: 1
			},
			status: options.status ?? null,
			is_suspended: options.status === "suspended",
			is_installing: options.status === "installing",
			is_transferring: false,
			skip_scripts: false
		},
		meta: {
			is_server_owner: owner,
			user_permissions: options.permissions ?? []
		}
	};
}
/** Create one host per test; call dispose after unmounting its Wrapper. */
function createExtensionTestHost(options = {}) {
	registerClassPrefixes([options.prefix]);
	queryClient.clear();
	queryClient.setQueryData(currentUserQueryKey, options.user ?? {
		uuid: "test-user",
		username: "Alex",
		email: "alex@example.test",
		language: "en",
		rootAdmin: false,
		useTotp: false,
		createdAt: /* @__PURE__ */ new Date(0),
		updatedAt: /* @__PURE__ */ new Date(0)
	});
	queryClient.setQueryData(siteSettingsQueryKey, options.siteSettings ?? {
		name: "Test panel",
		locale: "en",
		recaptcha: {
			enabled: false,
			siteKey: ""
		}
	});
	if (options.server) queryClient.setQueryData(serverQueryOptions(options.server.attributes.identifier).queryKey, options.server);
	const socket = new Websocket();
	let updateConnected = () => {
		throw new Error("Mount the test host before changing its connection state.");
	};
	function SocketFixture() {
		const setInstance = useServerStore((state) => state.socket.setInstance);
		const setConnected = useServerStore((state) => state.socket.setConnectionState);
		useLayoutEffect(() => {
			updateConnected = setConnected;
			setInstance(socket);
			setConnected(true);
			return () => {
				setConnected(false);
				setInstance(null);
				socket.removeAllListeners();
			};
		}, [setInstance, setConnected]);
		return null;
	}
	const Content = createContext(null);
	function RenderContent() {
		return useContext(Content);
	}
	function Root() {
		const content = /* @__PURE__ */ jsx(ExtensionMount, {
			extensionId: options.extensionId ?? "test-extension",
			context: "test host",
			resetKey: "test",
			children: /* @__PURE__ */ jsx(ExtensionResourceProvider.Provider, {
				value: options.resource ?? null,
				children: /* @__PURE__ */ jsx(Outlet, {})
			})
		});
		return options.server ? /* @__PURE__ */ jsxs(ServerContext.Provider, { children: [/* @__PURE__ */ jsx(SocketFixture, {}), content] }) : content;
	}
	const root = createRootRoute({ component: Root });
	const authenticated = createRoute({
		getParentRoute: () => root,
		id: "authenticated",
		component: Outlet
	});
	const routes = Object.values(SCREEN_ROOTS).map((path) => {
		const parent = createRoute({
			getParentRoute: () => authenticated,
			path,
			component: Outlet
		});
		return parent.addChildren([createRoute({
			getParentRoute: () => parent,
			path: "/",
			component: RenderContent
		}), createRoute({
			getParentRoute: () => parent,
			path: "$",
			component: RenderContent
		})]);
	});
	const router = createRouter({
		routeTree: root.addChildren([authenticated.addChildren(routes), createRoute({
			getParentRoute: () => root,
			path: "$",
			component: RenderContent
		})]),
		history: createMemoryHistory({ initialEntries: [options.path ?? (options.server ? `/server/${options.server.attributes.identifier}` : "/account")] })
	});
	function Wrapper({ children }) {
		return /* @__PURE__ */ jsx(QueryClientProvider, {
			client: queryClient,
			children: /* @__PURE__ */ jsx(Content.Provider, {
				value: children,
				children: /* @__PURE__ */ jsx(RouterProvider, { router })
			})
		});
	}
	return {
		Wrapper,
		queryClient,
		navigate: async (destination) => {
			const { pathname, ...navigation } = resolvePanelDestination(destination);
			await router.navigate({
				to: pathname,
				...navigation,
				search: navigation.search
			});
		},
		location: () => {
			const { pathname, search, state } = router.state.location;
			return {
				pathname,
				search: { ...search },
				state: { ...state }
			};
		},
		emitWebsocket: (event, data) => {
			socket.emit(event, data);
		},
		setConnected: (connected) => updateConnected(connected),
		dispose: () => {
			socket.removeAllListeners();
			socket.close();
			queryClient.clear();
		}
	};
}
function createTestServerCard(options = {}) {
	return {
		identifier: "test-server",
		uuid: "11111111-1111-4111-8111-111111111111",
		name: "Test server",
		description: null,
		address: "127.0.0.1:25565",
		state: {
			kind: "ready",
			power: "running",
			cpu: {
				value: 12,
				limit: 100,
				alarm: false
			},
			memory: {
				value: 256 * 1024 * 1024,
				limit: 1024 * 1024 * 1024,
				alarm: false
			},
			disk: {
				value: 512 * 1024 * 1024,
				limit: 2048 * 1024 * 1024,
				alarm: false
			}
		},
		...options
	};
}
function createTestFileDetails(options = {}) {
	return {
		name: "config.json",
		kind: "file",
		size: 1024,
		modifiedAt: "2026-01-01T12:00:00Z",
		...options
	};
}
function createTestFileEditor(options = {}) {
	return {
		path: "/config/server.properties",
		name: "server.properties",
		isNew: false,
		content: "motd=Hello\n",
		language: "text/x-properties",
		readOnly: false,
		dirty: false,
		saving: false,
		change: () => {},
		save: async () => true,
		saveAs: async () => true,
		...options
	};
}
function createTestFileManagerEntry(options = {}) {
	const name = options.name ?? "config.json";
	return {
		name,
		path: `/${name}`,
		kind: "file",
		size: 1024,
		mimetype: "application/json",
		mode: "-rw-r--r--",
		modeBits: "0644",
		modifiedAt: "2026-01-01T12:00:00Z",
		openable: true,
		...options
	};
}
function createTestFileManager(options = {}) {
	return {
		directory: "/",
		entries: [createTestFileManagerEntry({
			name: "plugins",
			kind: "directory",
			mimetype: "inode/directory",
			size: 0
		}), createTestFileManagerEntry()],
		truncated: false,
		loading: false,
		refreshing: false,
		selection: [],
		permissions: {
			create: true,
			update: true,
			delete: true,
			archive: true
		},
		actions: {
			open: async () => {},
			navigate: async () => {},
			newFile: async () => {},
			select: () => {},
			refresh: async () => {},
			createDirectory: async () => {},
			rename: async () => {},
			remove: async () => {},
			copy: async () => {},
			archive: async () => {},
			extract: async () => {},
			chmod: async () => {},
			download: async () => {},
			upload: async () => {}
		},
		...options
	};
}
var noDispose = () => {};
function createComponentTestHost(name, options) {
	const extensionId = options.extensionId ?? "test-extension";
	registerClassPrefixes([options.prefix]);
	function Context({ children }) {
		const context = useMemo(() => ({
			extensionId,
			context: `component "${name}" test host`
		}), []);
		return /* @__PURE__ */ jsx(ExtensionContext.Provider, {
			value: context,
			children
		});
	}
	if (name === "dashboard.serverCard") {
		const model = options.model;
		function Wrapper({ children }) {
			const context = useMemo(() => ({
				model,
				server: createTestServer({
					identifier: model.identifier,
					uuid: model.uuid,
					name: model.name
				})
			}), []);
			return /* @__PURE__ */ jsx(Context, { children: /* @__PURE__ */ jsx(ServerCardContext.Provider, {
				value: context,
				children
			}) });
		}
		return {
			Wrapper,
			props: {
				model,
				Default: DefaultServerCard,
				parts: serverCardParts
			},
			dispose: noDispose
		};
	}
	if (name === "server.files.editor") {
		const model = options.model;
		function Wrapper({ children }) {
			const session = useMemo(() => ({
				model,
				read: () => model.content,
				setLanguage: () => {}
			}), []);
			return /* @__PURE__ */ jsx(Context, { children: /* @__PURE__ */ jsx(FileEditorContext.Provider, {
				value: session,
				children
			}) });
		}
		return {
			Wrapper,
			props: {
				model,
				Default: DefaultFileEditor,
				parts: fileEditorParts
			},
			dispose: noDispose
		};
	}
	if (name === "server.files.manager") {
		const model = options.model;
		const host = createExtensionTestHost({
			extensionId,
			server: createTestServer(),
			path: `/server/test-server/files#${model.directory}`
		});
		const files = model.entries.map((entry) => ({
			object: "file_object",
			attributes: {
				name: entry.name,
				mode: entry.mode,
				mode_bits: entry.modeBits,
				size: entry.size,
				is_file: entry.kind !== "directory",
				is_symlink: entry.kind === "symlink",
				mimetype: entry.mimetype,
				created_at: entry.modifiedAt,
				modified_at: entry.modifiedAt
			}
		}));
		const portal = document.getElementById("modal-portal") ? null : document.body.appendChild(Object.assign(document.createElement("div"), { id: "modal-portal" }));
		function Selection() {
			const setSelectedFiles = useServerStore((state) => state.files.setSelectedFiles);
			useLayoutEffect(() => {
				setSelectedFiles({
					directory: model.directory,
					files: [...model.selection]
				});
			}, [setSelectedFiles]);
			return null;
		}
		function Wrapper({ children }) {
			const session = useMemo(() => ({
				model,
				files
			}), []);
			return /* @__PURE__ */ jsx(host.Wrapper, { children: /* @__PURE__ */ jsxs(Context, { children: [/* @__PURE__ */ jsx(Selection, {}), /* @__PURE__ */ jsx(FileManagerContext.Provider, {
				value: session,
				children
			})] }) });
		}
		return {
			Wrapper,
			props: {
				model,
				Default: DefaultFileManager,
				parts: fileManagerParts
			},
			dispose: () => {
				portal?.remove();
				host.dispose();
			}
		};
	}
	const model = options.model;
	function Wrapper({ children }) {
		return /* @__PURE__ */ jsx(Context, { children: /* @__PURE__ */ jsx(FileDetailsContext.Provider, {
			value: model,
			children
		}) });
	}
	return {
		Wrapper,
		props: {
			model,
			Default: DefaultFileDetails,
			parts: fileDetailsParts
		},
		dispose: noDispose
	};
}
//#endregion
export { createComponentTestHost, createExtensionTestHost, createTestFileDetails, createTestFileEditor, createTestFileManager, createTestFileManagerEntry, createTestServer, createTestServerCard };

//# sourceMappingURL=testing.js.map