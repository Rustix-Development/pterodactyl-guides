//#region ../../resources/scripts/components/elements/codemirror/layout.ts
var editorContainerClass = [
	"relative h-[50dvh] min-h-64 overflow-hidden",
	"sm:h-[calc(100dvh-22rem)] sm:min-h-80 lg:h-[calc(100dvh-20rem)]",
	"[&>.cm-editor]:h-full [&>.cm-editor]:overflow-hidden [&>.cm-editor]:rounded-sm"
].join(" ");
//#endregion
export { editorContainerClass as t };

//# sourceMappingURL=layout-B0n1h8c2.js.map