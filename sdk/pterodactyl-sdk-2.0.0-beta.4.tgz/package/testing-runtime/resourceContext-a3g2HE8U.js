import { c as httpErrorToHuman, d as isString, l as isNumber$1, r as client, u as isObject } from "./queryClient-D97HhWup.js";
import * as React$1 from "react";
import React, { Suspense, cloneElement, createContext, use, useCallback, useContext, useEffect, useId, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { partialMatchKey, queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useBlocker, useLocation, useMatch, useNavigate, useParams, useRouter, useSearch } from "@tanstack/react-router";
import { toast } from "sonner";
import axios from "axios";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Check, ChevronDown, Info, Minus, ShieldAlert, TriangleAlert, X } from "lucide-react";
import * as ReactDOM from "react-dom";
import { createPortal } from "react-dom";
import { Input } from "@base-ui/react/input";
import { NumberField } from "@base-ui/react/number-field";
import { createFormHook, createFormHookContexts } from "@tanstack/react-form";
import { Combobox } from "@base-ui/react/combobox";
import { Switch } from "@base-ui/react/switch";
import { Checkbox } from "@base-ui/react/checkbox";
import { Dialog } from "@base-ui/react/dialog";
import { Menu } from "@base-ui/react/menu";
import { ContextMenu } from "@base-ui/react/context-menu";
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
//#region ../../resources/scripts/extensions/formTypes.ts
var EXTENSION_FORM_NAMES = Object.freeze([
	"admin.user",
	"admin.server",
	"admin.node",
	"admin.egg",
	"admin.location",
	"admin.mount",
	"admin.database_host"
]);
//#endregion
//#region ../../resources/scripts/extensions/componentTypes.ts
var COMPONENT_NAMES = [
	"dashboard.serverCard",
	"server.files.details",
	"server.files.editor",
	"server.files.manager"
];
function isReplacementComponent(value) {
	return value instanceof Function || isObject(value) && "$$typeof" in value && (value.$$typeof === Symbol.for("react.memo") || value.$$typeof === Symbol.for("react.forward_ref"));
}
//#endregion
//#region ../../resources/scripts/extensions/registry.ts
/** Every anchor a core <Slot/> renders; registering an unknown name fails at load time. */
var SLOT_NAMES = [
	"nav.items.before",
	"nav.items.after",
	"auth.login.before",
	"auth.login.after",
	"auth.login.form.after",
	"auth.checkpoint.before",
	"auth.checkpoint.after",
	"auth.password.before",
	"auth.password.after",
	"auth.passwordReset.before",
	"auth.passwordReset.after",
	"dashboard.before",
	"dashboard.after",
	"dashboard.serverRow.before",
	"dashboard.serverRow.after",
	"dashboard.serverRow.name.after",
	"dashboard.serverRow.metrics.after",
	"account.navigation.before",
	"account.navigation.after",
	"account.overview.before",
	"account.overview.after",
	"account.api.before",
	"account.api.after",
	"account.ssh.before",
	"account.ssh.after",
	"account.activity.before",
	"account.activity.after",
	"server.navigation.before",
	"server.navigation.after",
	"server.console.before",
	"server.console.power.before",
	"server.console.power.after",
	"server.console.after",
	"server.files.before",
	"server.files.after",
	"server.files.toolbar",
	"server.files.rowActions",
	"server.files.selectionActions",
	"server.files.editor.before",
	"server.files.editor.after",
	"server.databases.before",
	"server.databases.after",
	"server.schedules.before",
	"server.schedules.after",
	"server.schedules.detail.before",
	"server.schedules.detail.after",
	"server.users.before",
	"server.users.after",
	"server.users.create.before",
	"server.users.create.after",
	"server.users.permissions.before",
	"server.backups.before",
	"server.backups.after",
	"server.network.before",
	"server.network.after",
	"server.startup.before",
	"server.startup.after",
	"server.startup.form",
	"server.settings.before",
	"server.settings.after",
	"server.activity.before",
	"server.activity.after",
	"panel.navigation.before",
	"panel.navigation.after",
	"panel.overview.before",
	"panel.overview.after",
	"panel.users.before",
	"panel.users.after",
	"panel.users.create.before",
	"panel.users.create.after",
	"panel.users.detail.before",
	"panel.users.detail.after",
	"panel.locations.before",
	"panel.locations.after",
	"panel.locations.detail.before",
	"panel.locations.detail.after",
	"panel.nodes.before",
	"panel.nodes.after",
	"panel.nodes.create.before",
	"panel.nodes.create.after",
	"panel.nodes.detail.before",
	"panel.nodes.detail.after",
	"panel.nodes.detail.actions",
	"panel.nodes.detail.about.before",
	"panel.nodes.detail.about.after",
	"panel.nodes.detail.settings.before",
	"panel.nodes.detail.settings.after",
	"panel.nodes.detail.configuration.before",
	"panel.nodes.detail.configuration.after",
	"panel.nodes.detail.allocations.before",
	"panel.nodes.detail.allocations.after",
	"panel.nodes.detail.servers.before",
	"panel.nodes.detail.servers.after",
	"panel.servers.before",
	"panel.servers.after",
	"panel.servers.create.before",
	"panel.servers.create.after",
	"panel.servers.detail.before",
	"panel.servers.detail.after",
	"panel.servers.detail.actions",
	"panel.servers.detail.about.before",
	"panel.servers.detail.about.after",
	"panel.servers.detail.details.before",
	"panel.servers.detail.details.after",
	"panel.servers.detail.build.before",
	"panel.servers.detail.build.after",
	"panel.servers.detail.startup.before",
	"panel.servers.detail.startup.after",
	"panel.servers.detail.databases.before",
	"panel.servers.detail.databases.after",
	"panel.servers.detail.mounts.before",
	"panel.servers.detail.mounts.after",
	"panel.servers.detail.manage.before",
	"panel.servers.detail.manage.after",
	"panel.servers.detail.delete.before",
	"panel.servers.detail.delete.after",
	"panel.databaseHosts.before",
	"panel.databaseHosts.after",
	"panel.databaseHosts.create.before",
	"panel.databaseHosts.create.after",
	"panel.databaseHosts.detail.before",
	"panel.databaseHosts.detail.after",
	"panel.mounts.before",
	"panel.mounts.after",
	"panel.mounts.create.before",
	"panel.mounts.create.after",
	"panel.mounts.detail.before",
	"panel.mounts.detail.after",
	"panel.eggs.before",
	"panel.eggs.after",
	"panel.eggs.create.before",
	"panel.eggs.create.after",
	"panel.eggs.detail.before",
	"panel.eggs.detail.after",
	"panel.eggs.detail.actions",
	"panel.users.detail.actions",
	"panel.users.detail.form",
	"panel.eggs.detail.configuration.before",
	"panel.eggs.detail.configuration.after",
	"panel.eggs.detail.tags.before",
	"panel.eggs.detail.tags.after",
	"panel.eggs.detail.variables.before",
	"panel.eggs.detail.variables.after",
	"panel.eggs.detail.script.before",
	"panel.eggs.detail.script.after",
	"panel.tags.before",
	"panel.tags.after",
	"panel.activity.before",
	"panel.activity.after",
	"panel.settings.before",
	"panel.settings.after",
	"panel.extensions.before",
	"panel.extensions.after",
	"panel.apiKeys.before",
	"panel.apiKeys.after"
];
/** The panel path each area and resource mounts its extension screens under. */
var SCREEN_ROOTS = {
	account: "/account",
	server: "/server/$id",
	admin: "/panel",
	"admin.node": "/panel/nodes/$id",
	"admin.server": "/panel/servers/$id",
	"admin.egg": "/panel/eggs/$eggId",
	"admin.user": "/panel/users/$id"
};
var slots = /* @__PURE__ */ new Map();
Object.freeze([]);
Object.freeze([]);
var emptySlots = Object.freeze([]);
var screens = [];
var ExtensionImportError = class extends Error {};
Object.freeze({});
var componentReplacements = /* @__PURE__ */ new Map();
var loadStates = /* @__PURE__ */ new Map();
/** Failures of mounted extension code, by extension and then by context, the latest last. */
var mountErrors = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var entries;
/** Every change notifies every listener; each getter returns the same value until its own data changes. */
function subscribeExtensionRegistry(listener) {
	listeners.add(listener);
	return () => {
		listeners.delete(listener);
	};
}
function useExtensionRegistry(read) {
	return useSyncExternalStore(subscribeExtensionRegistry, read);
}
/** The latest failure of mounted code overrides the load state. */
function runtimeState(id) {
	const latest = [...mountErrors.get(id) ?? []].at(-1);
	return latest ? Object.freeze({
		id,
		status: "failed",
		error: `${latest[0]}: ${latest[1]}`
	}) : loadStates.get(id);
}
function publish() {
	const ids = new Set([...loadStates.keys(), ...mountErrors.keys()]);
	Object.freeze([...ids].flatMap((id) => runtimeState(id) ?? []));
	for (const listener of listeners) listener();
}
function getExtensionLoadState(id) {
	return loadStates.get(id);
}
function getComponentOwner(name) {
	return entries?.find((entry) => entry.components?.includes(name))?.id;
}
function getComponentReplacement(name) {
	return componentReplacements.get(name);
}
/** Records a failure, unless the same one is already recorded for the context; returns its message. */
function recordError(extensionId, context, cause) {
	const message = cause instanceof Error ? cause.message : String(cause);
	const errors = mountErrors.get(extensionId) ?? /* @__PURE__ */ new Map();
	if (errors.get(context) === message) return;
	console.error(`[extensions] "${extensionId}" failed in ${context}:`, cause);
	errors.delete(context);
	errors.set(context, message);
	mountErrors.set(extensionId, errors);
	return message;
}
/** Repeat reports of the same failure in a context are ignored. */
function reportExtensionError(extensionId, context, cause) {
	if (recordError(extensionId, context, cause) !== void 0) publish();
}
function resolveScreenPath(path, params = {}) {
	return path.replaceAll(/\$([a-zA-Z][a-zA-Z0-9_]*)/g, (_match, name) => {
		const value = params[name];
		if (!value) throw new Error(`Missing navigation parameter "${name}".`);
		return encodeURIComponent(value);
	});
}
function getSlotComponents(name) {
	return slots.get(name) ?? emptySlots;
}
function findExtensionScreen(extensionId, id) {
	return screens.find((screen) => screen.extensionId === extensionId && screen.id === id);
}
function clearExtensionError(extensionId, context) {
	const errors = mountErrors.get(extensionId);
	if (!errors?.delete(context)) return;
	if (!errors.size) mountErrors.delete(extensionId);
	publish();
}
//#endregion
//#region ../../resources/scripts/router/params.ts
var routeParamStrings = (params) => Object.fromEntries(Object.entries(params).flatMap(([name, value]) => value === void 0 ? [] : [[name, String(value)]]));
/** Undefined outside the `/server/$id` route. */
var useServerRouteId = () => useMatch({
	from: "/authenticated/server/$id",
	shouldThrow: false,
	select: (match) => match.params.id
});
//#endregion
//#region ../../resources/scripts/api/queryKeyGuards.ts
var isGeneratedQueryKeyRoot = (value) => isObject(value) && (!("_id" in value) || value._id === void 0 || isString(value._id));
var hasGeneratedOperationId = (queryKey, id) => {
	const [key] = queryKey;
	return isGeneratedQueryKeyRoot(key) && key._id === id;
};
//#endregion
//#region ../../resources/scripts/api/generated/sdk.gen.ts
/**
* Get extension job progress
*
* Returns the latest user-scoped progress snapshot, including after reconnect. Expired, disabled, and inaccessible jobs return 404.
*/
var clientGetExtensionJobProgress = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/extension-progress/{extension}/{job}",
	...options
});
/**
* Get account
*
* Returns profile details for the authenticated user.
*/
var clientGetAccount = (options) => (options?.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/account",
	...options
});
/**
* Get server
*
* Returns details for one server the authenticated user can access.
*/
var clientGetServer = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}",
	...options
});
/**
* Get server resources
*
* Returns the latest cached resource utilization reported by Wings for the server.
*/
var clientGetServerResources = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/resources",
	...options
});
/**
* Get server logs
*
* Returns the most recent console output lines Wings holds for the server, oldest first.
*/
var clientGetServerLogs = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/logs",
	...options
});
/**
* Get server extension job progress
*
* Returns the latest server-scoped snapshot to its creator or users holding the operation permission. Expired, disabled, and inaccessible jobs return 404.
*/
var clientGetServerExtensionJobProgress = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/extension-progress/{extension}/{job}",
	...options
});
/**
* Send server command
*
* Sends a console command to the running server through Wings.
*/
var clientSendServerCommand = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/command",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Send power action
*
* Sends a power signal to the server through Wings.
*/
var clientSendPowerAction = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/power",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* List files
*
* Returns files and folders in a server directory.
*/
var clientListFiles = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/list",
	...options
});
/**
* Get file contents
*
* Returns raw text contents for a server file.
*/
var clientGetFileContents = (options) => (options.client ?? client).get({
	responseType: "text",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/contents",
	...options
});
/**
* Get file download URL
*
* Returns a short-lived signed URL for downloading a server file directly from Wings.
*/
var clientGetFileDownloadUrl = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/download",
	...options
});
/**
* Rename files
*
* Renames one or more files or folders in a server directory.
*/
var clientRenameFiles = (options) => (options.client ?? client).put({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/rename",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Copy file
*
* Creates a copy of a file on the server.
*/
var clientCopyFile = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/copy",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Write file contents
*
* Writes the raw request body to a server file. This endpoint does not expect a JSON wrapper for the file contents.
*/
var clientWriteFileContents = (options) => (options.client ?? client).post({
	bodySerializer: null,
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/write",
	...options,
	headers: {
		"Content-Type": "text/plain",
		...options.headers
	}
});
/**
* Compress files
*
* Creates an archive from one or more files or folders in a server directory.
*/
var clientCompressFiles = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/compress",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Decompress file
*
* Extracts an archive in a server directory.
*/
var clientDecompressFile = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/decompress",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Delete files
*
* Deletes one or more files or folders from a server directory.
*/
var clientDeleteFiles = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/delete",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Create folder
*
* Creates a folder in a server directory.
*/
var clientCreateFolder = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/create-folder",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Change file permissions
*
* Updates POSIX mode bits for one or more files or folders in a server directory.
*/
var clientChangeFilePermissions = (options) => (options.client ?? client).post({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/chmod",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Get file upload URL
*
* Returns a short-lived signed URL for uploading a file directly to Wings.
*/
var clientGetFileUploadUrl = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/files/upload",
	...options
});
/**
* List server backups
*
* Returns a paginated list of backups for the server.
*/
var clientListServerBackups = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/backups",
	...options
});
/**
* Create server backup
*
* Starts a new backup for the server.
*/
var clientCreateServerBackup = (options) => (options.client ?? client).post({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/backups",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Get startup configuration
*
* Returns the rendered startup command, available Docker images, raw startup command, and user-visible variables for the server.
*/
var clientGetStartupConfiguration = (options) => (options.client ?? client).get({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/startup",
	...options
});
/**
* Update startup variable
*
* Updates one editable startup variable for the server and returns the updated rendered startup command.
*/
var clientUpdateStartupVariable = (options) => (options.client ?? client).put({
	responseType: "json",
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/startup/variable",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
/**
* Set server Docker image
*
* Updates the server Docker image to one of the images allowed by the server egg.
*/
var clientSetServerDockerImage = (options) => (options.client ?? client).put({
	security: [{
		scheme: "bearer",
		type: "http"
	}],
	url: "/api/client/servers/{server_uuid}/settings/docker-image",
	...options,
	headers: {
		"Content-Type": "application/json",
		...options.headers
	}
});
//#endregion
//#region ../../resources/scripts/api/generated/@tanstack/react-query.gen.ts
var createQueryKey = (id, options, infinite, tags) => {
	const params = {
		_id: id,
		baseURL: options?.baseURL || (options?.client ?? client).getConfig().baseURL
	};
	if (infinite) params._infinite = infinite;
	if (tags) params.tags = tags;
	if (options?.body) params.body = options.body;
	if (options?.headers) params.headers = options.headers;
	if (options?.path) params.path = options.path;
	if (options?.query) params.query = options.query;
	return [params];
};
var createMutationKey = (id, options, tags) => {
	const params = {
		_id: id,
		baseURL: options?.baseURL || (options?.client ?? client).getConfig().baseURL
	};
	if (tags) params.tags = tags;
	if (options?.body) params.body = options.body;
	if (options?.headers) params.headers = options.headers;
	if (options?.path) params.path = options.path;
	if (options?.query) params.query = options.query;
	return [params];
};
var clientGetServerQueryKey = (options) => createQueryKey("clientGetServer", options);
/**
* Get server
*
* Returns details for one server the authenticated user can access.
*/
var clientGetServerOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetServer({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetServerQueryKey(options)
});
var clientGetServerResourcesQueryKey = (options) => createQueryKey("clientGetServerResources", options);
/**
* Get server resources
*
* Returns the latest cached resource utilization reported by Wings for the server.
*/
var clientGetServerResourcesOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetServerResources({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetServerResourcesQueryKey(options)
});
var clientGetServerLogsQueryKey = (options) => createQueryKey("clientGetServerLogs", options);
/**
* Get server logs
*
* Returns the most recent console output lines Wings holds for the server, oldest first.
*/
var clientGetServerLogsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetServerLogs({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetServerLogsQueryKey(options)
});
var clientSendServerCommandMutationKey = (options) => createMutationKey("clientSendServerCommand", options);
/**
* Send server command
*
* Sends a console command to the running server through Wings.
*/
var clientSendServerCommandMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientSendServerCommand({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientSendServerCommandMutationKey(options)
	};
};
var clientSendPowerActionMutationKey = (options) => createMutationKey("clientSendPowerAction", options);
/**
* Send power action
*
* Sends a power signal to the server through Wings.
*/
var clientSendPowerActionMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientSendPowerAction({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientSendPowerActionMutationKey(options)
	};
};
var clientListFilesQueryKey = (options) => createQueryKey("clientListFiles", options);
/**
* List files
*
* Returns files and folders in a server directory.
*/
var clientListFilesOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListFiles({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListFilesQueryKey(options)
});
var clientGetFileContentsQueryKey = (options) => createQueryKey("clientGetFileContents", options);
var clientRenameFilesMutationKey = (options) => createMutationKey("clientRenameFiles", options);
/**
* Rename files
*
* Renames one or more files or folders in a server directory.
*/
var clientRenameFilesMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientRenameFiles({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientRenameFilesMutationKey(options)
	};
};
var clientCopyFileMutationKey = (options) => createMutationKey("clientCopyFile", options);
/**
* Copy file
*
* Creates a copy of a file on the server.
*/
var clientCopyFileMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCopyFile({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCopyFileMutationKey(options)
	};
};
var clientWriteFileContentsMutationKey = (options) => createMutationKey("clientWriteFileContents", options);
/**
* Write file contents
*
* Writes the raw request body to a server file. This endpoint does not expect a JSON wrapper for the file contents.
*/
var clientWriteFileContentsMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientWriteFileContents({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientWriteFileContentsMutationKey(options)
	};
};
var clientCompressFilesMutationKey = (options) => createMutationKey("clientCompressFiles", options);
/**
* Compress files
*
* Creates an archive from one or more files or folders in a server directory.
*/
var clientCompressFilesMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCompressFiles({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCompressFilesMutationKey(options)
	};
};
var clientDecompressFileMutationKey = (options) => createMutationKey("clientDecompressFile", options);
/**
* Decompress file
*
* Extracts an archive in a server directory.
*/
var clientDecompressFileMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDecompressFile({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDecompressFileMutationKey(options)
	};
};
var clientDeleteFilesMutationKey = (options) => createMutationKey("clientDeleteFiles", options);
/**
* Delete files
*
* Deletes one or more files or folders from a server directory.
*/
var clientDeleteFilesMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientDeleteFiles({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientDeleteFilesMutationKey(options)
	};
};
var clientCreateFolderMutationKey = (options) => createMutationKey("clientCreateFolder", options);
/**
* Create folder
*
* Creates a folder in a server directory.
*/
var clientCreateFolderMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateFolder({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateFolderMutationKey(options)
	};
};
var clientChangeFilePermissionsMutationKey = (options) => createMutationKey("clientChangeFilePermissions", options);
/**
* Change file permissions
*
* Updates POSIX mode bits for one or more files or folders in a server directory.
*/
var clientChangeFilePermissionsMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientChangeFilePermissions({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientChangeFilePermissionsMutationKey(options)
	};
};
var clientListServerBackupsQueryKey = (options) => createQueryKey("clientListServerBackups", options);
/**
* List server backups
*
* Returns a paginated list of backups for the server.
*/
var clientListServerBackupsOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientListServerBackups({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientListServerBackupsQueryKey(options)
});
var clientCreateServerBackupMutationKey = (options) => createMutationKey("clientCreateServerBackup", options);
/**
* Create server backup
*
* Starts a new backup for the server.
*/
var clientCreateServerBackupMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientCreateServerBackup({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientCreateServerBackupMutationKey(options)
	};
};
var clientGetStartupConfigurationQueryKey = (options) => createQueryKey("clientGetStartupConfiguration", options);
/**
* Get startup configuration
*
* Returns the rendered startup command, available Docker images, raw startup command, and user-visible variables for the server.
*/
var clientGetStartupConfigurationOptions = (options) => queryOptions({
	queryFn: async ({ queryKey, signal }) => {
		const { data } = await clientGetStartupConfiguration({
			...options,
			...queryKey[0],
			signal,
			throwOnError: true
		});
		return data;
	},
	queryKey: clientGetStartupConfigurationQueryKey(options)
});
var clientUpdateStartupVariableMutationKey = (options) => createMutationKey("clientUpdateStartupVariable", options);
/**
* Update startup variable
*
* Updates one editable startup variable for the server and returns the updated rendered startup command.
*/
var clientUpdateStartupVariableMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientUpdateStartupVariable({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientUpdateStartupVariableMutationKey(options)
	};
};
var clientSetServerDockerImageMutationKey = (options) => createMutationKey("clientSetServerDockerImage", options);
/**
* Set server Docker image
*
* Updates the server Docker image to one of the images allowed by the server egg.
*/
var clientSetServerDockerImageMutation = (options) => {
	return {
		mutationFn: async (fnOptions) => {
			const { data } = await clientSetServerDockerImage({
				...options,
				...fnOptions,
				throwOnError: true
			});
			return data;
		},
		mutationKey: clientSetServerDockerImageMutationKey(options)
	};
};
//#endregion
//#region ../../resources/scripts/plugins/notifications.ts
var DEFAULT_DURATION = 8e3;
var notifyServerError = (title, options = {}) => toast.error(title, {
	duration: DEFAULT_DURATION,
	...options
});
var notifyHttpError = (cause, title, options = {}) => {
	console.error(cause);
	return notifyServerError(title, {
		description: httpErrorToHuman(cause),
		...options
	});
};
//#endregion
//#region ../../resources/scripts/api/server/queries.ts
var emptyPermissions = [];
var ownerPermissions = ["*"];
var serverInput = (id) => ({ path: { server_uuid: id } });
var serverQueryKey = (id) => clientGetServerQueryKey(serverInput(id));
var identifiesServer = (server, id) => isObject(server) && "attributes" in server && isObject(server.attributes) && ("uuid" in server.attributes && server.attributes.uuid === id || "identifier" in server.attributes && server.attributes.identifier === id);
/** Matches every cached copy of the server, keyed by uuid or short identifier. */
var serverQueryFilters = (id) => ({ predicate: ({ queryKey, state }) => hasGeneratedOperationId(queryKey, "clientGetServer") && (partialMatchKey(queryKey, serverQueryKey(id)) || identifiesServer(state.data, id)) });
var updateServerQueryData = (queryClient, id, updater) => {
	const filters = serverQueryFilters(id);
	queryClient.cancelQueries(filters);
	queryClient.setQueriesData(filters, (server) => server ? updater(server) : server);
};
var serverQueryOptions = (id) => clientGetServerOptions(serverInput(id));
var useServerQuery = (id, select) => useQuery({
	...serverQueryOptions(id),
	enabled: id.length > 0,
	select
});
var useCurrentServer = (select) => {
	return useServerQuery(useServerRouteId() ?? "", select).data;
};
var selectServerUuid = (server) => server.attributes.uuid;
var selectServerIdentifier = (server) => server.attributes.identifier;
var selectServerName = (server) => server.attributes.name;
var selectServerPermissions = (server) => server.meta?.is_server_owner ? ownerPermissions : server.meta?.user_permissions ?? emptyPermissions;
var useCurrentServerUuid = () => useCurrentServer(selectServerUuid);
var useCurrentServerIdentifier = () => useCurrentServer(selectServerIdentifier);
var useCurrentServerName = () => useCurrentServer(selectServerName);
var useCurrentServerPermissions = () => useCurrentServer(selectServerPermissions) ?? emptyPermissions;
var useUpdateCurrentServer = () => {
	const id = useServerRouteId();
	const queryClient = useQueryClient();
	return useCallback((updater) => {
		if (!id) return;
		updateServerQueryData(queryClient, id, updater);
	}, [id, queryClient]);
};
//#endregion
//#region ../../resources/scripts/bootstrap.ts
var getBootstrapUser = () => {
	const user = window.PterodactylUser;
	return user ? {
		uuid: user.uuid,
		username: user.username,
		email: user.email,
		language: user.language,
		rootAdmin: user.root_admin,
		useTotp: user.use_totp,
		createdAt: new Date(user.created_at),
		updatedAt: new Date(user.updated_at)
	} : void 0;
};
var getBootstrapSiteSettings = () => window.SiteConfiguration;
//#endregion
//#region ../../resources/scripts/api/account/queries.ts
var currentUserQueryKey = ["account", "current-user"];
var getBootstrapCurrentUser = () => {
	const user = getBootstrapUser();
	if (!user) throw new Error("Current user has not been hydrated.");
	return user;
};
/** Keeps the fields the account endpoint does not return. */
var withAccount = (user, { attributes }) => ({
	...user,
	username: attributes.username,
	email: attributes.email,
	language: attributes.language,
	rootAdmin: attributes.admin
});
var currentUserQueryOptions = () => queryOptions({
	queryKey: currentUserQueryKey,
	queryFn: async ({ client, signal }) => {
		const { data } = await clientGetAccount({ signal });
		return withAccount(client.getQueryData(currentUserQueryKey) ?? getBootstrapCurrentUser(), data);
	},
	initialData: getBootstrapCurrentUser,
	staleTime: Infinity
});
var useCurrentUser = () => useQuery(currentUserQueryOptions()).data;
//#endregion
//#region ../../resources/scripts/api/settings/queries.ts
var siteSettingsQueryKey = ["bootstrap", "site-settings"];
var getSiteSettings = () => {
	const settings = getBootstrapSiteSettings();
	if (!settings) throw new Error("Site settings have not been hydrated.");
	return settings;
};
/** Bootstrap data with no fetcher; changed only by `setSiteSettingsQueryData`. */
var siteSettingsQueryOptions = () => queryOptions({
	queryKey: siteSettingsQueryKey,
	initialData: getSiteSettings,
	staleTime: "static"
});
var useSiteSettings = () => useQuery(siteSettingsQueryOptions()).data;
//#endregion
//#region ../../resources/scripts/extensions/context.ts
var ExtensionContext = createContext(null);
function useExtensionCallback(event, callback) {
	const mount = useContext(ExtensionContext);
	if (!mount) throw new Error("Extension callbacks require an extension mount.");
	const context = `${mount.context}, event "${event}"`;
	return (...args) => {
		try {
			const result = callback(...args);
			if (result) result.then(() => clearExtensionError(mount.extensionId, context), (error) => reportExtensionError(mount.extensionId, context, error));
			else clearExtensionError(mount.extensionId, context);
		} catch (error) {
			reportExtensionError(mount.extensionId, context, error);
		}
	};
}
//#endregion
//#region ../../node_modules/zustand/esm/vanilla.mjs
var createStoreImpl = (createState) => {
	let state;
	const listeners = /* @__PURE__ */ new Set();
	const setState = (partial, replace) => {
		const nextState = typeof partial === "function" ? partial(state) : partial;
		if (!Object.is(nextState, state)) {
			const previousState = state;
			state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
			listeners.forEach((listener) => listener(state, previousState));
		}
	};
	const getState = () => state;
	const getInitialState = () => initialState;
	const subscribe = (listener) => {
		listeners.add(listener);
		return () => listeners.delete(listener);
	};
	const api = {
		setState,
		getState,
		getInitialState,
		subscribe
	};
	const initialState = state = createState(setState, getState, api);
	return api;
};
var createStore = ((createState) => createState ? createStoreImpl(createState) : createStoreImpl);
//#endregion
//#region ../../node_modules/zustand/esm/react.mjs
var identity = (arg) => arg;
function useStore$1(api, selector = identity) {
	const slice = React.useSyncExternalStore(api.subscribe, React.useCallback(() => selector(api.getState()), [api, selector]), React.useCallback(() => selector(api.getInitialState()), [api, selector]));
	React.useDebugValue(slice);
	return slice;
}
//#endregion
//#region ../../resources/scripts/state/server/socket.ts
var createSocket = (set) => ({
	instance: null,
	connected: false,
	reconnecting: false,
	setInstance: (payload) => set((state) => ({ socket: {
		...state.socket,
		instance: payload
	} })),
	setConnectionState: (payload) => set((state) => ({ socket: {
		...state.socket,
		connected: payload
	} })),
	setReconnecting: (payload) => set((state) => ({ socket: {
		...state.socket,
		reconnecting: payload
	} }))
});
//#endregion
//#region ../../resources/scripts/state/server/files.ts
var withoutUpload = (uploads, id) => {
	const { [id]: _removed, ...rest } = uploads;
	return rest;
};
var createFiles = (set, get) => ({
	selectedDirectory: null,
	selectedFiles: [],
	uploads: {},
	clearSelectedFiles: () => set((state) => ({ files: {
		...state.files,
		selectedDirectory: null,
		selectedFiles: []
	} })),
	setSelectedFiles: ({ directory, files }) => set((state) => ({ files: {
		...state.files,
		selectedDirectory: directory,
		selectedFiles: files
	} })),
	appendSelectedFile: ({ directory, name }) => set((state) => ({ files: {
		...state.files,
		selectedDirectory: directory,
		selectedFiles: state.files.selectedDirectory === directory ? [...state.files.selectedFiles.filter((file) => file !== name), name] : [name]
	} })),
	removeSelectedFile: ({ directory, name }) => set((state) => ({ files: {
		...state.files,
		selectedDirectory: directory,
		selectedFiles: state.files.selectedDirectory === directory ? state.files.selectedFiles.filter((file) => file !== name) : []
	} })),
	clearFileUploads: () => {
		for (const upload of Object.values(get().files.uploads)) upload.abort.abort();
		set((state) => ({ files: {
			...state.files,
			uploads: {}
		} }));
	},
	pushFileUpload: ({ id, data }) => set((state) => ({ files: {
		...state.files,
		uploads: {
			...state.files.uploads,
			[id]: data
		}
	} })),
	setUploadProgress: ({ id, loaded }) => set((state) => {
		const upload = state.files.uploads[id];
		if (!upload) return state;
		return { files: {
			...state.files,
			uploads: {
				...state.files.uploads,
				[id]: {
					...upload,
					loaded
				}
			}
		} };
	}),
	removeFileUpload: (id) => set((state) => {
		if (!state.files.uploads[id]) return state;
		return { files: {
			...state.files,
			uploads: withoutUpload(state.files.uploads, id)
		} };
	}),
	cancelFileUpload: (id) => {
		const upload = get().files.uploads[id];
		if (upload) {
			upload.abort.abort();
			set((state) => ({ files: {
				...state.files,
				uploads: withoutUpload(state.files.uploads, id)
			} }));
		}
	}
});
//#endregion
//#region ../../node_modules/pathe/dist/shared/pathe.M-eThtNZ.mjs
var _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
	if (!input) return input;
	return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
var _UNC_REGEX = /^[/\\]{2}/;
var _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
var _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
var normalize = function(path) {
	if (path.length === 0) return ".";
	path = normalizeWindowsPath(path);
	const isUNCPath = path.match(_UNC_REGEX);
	const isPathAbsolute = isAbsolute(path);
	const trailingSeparator = path[path.length - 1] === "/";
	path = normalizeString(path, !isPathAbsolute);
	if (path.length === 0) {
		if (isPathAbsolute) return "/";
		return trailingSeparator ? "./" : ".";
	}
	if (trailingSeparator) path += "/";
	if (_DRIVE_LETTER_RE.test(path)) path += "/";
	if (isUNCPath) {
		if (!isPathAbsolute) return `//./${path}`;
		return `//${path}`;
	}
	return isPathAbsolute && !isAbsolute(path) ? `/${path}` : path;
};
var join = function(...segments) {
	let path = "";
	for (const seg of segments) {
		if (!seg) continue;
		if (path.length > 0) {
			const pathTrailing = path[path.length - 1] === "/";
			const segLeading = seg[0] === "/";
			if (pathTrailing && segLeading) path += seg.slice(1);
			else path += pathTrailing || segLeading ? seg : `/${seg}`;
		} else path += seg;
	}
	return normalize(path);
};
function normalizeString(path, allowAboveRoot) {
	let res = "";
	let lastSegmentLength = 0;
	let lastSlash = -1;
	let dots = 0;
	let char = null;
	for (let index = 0; index <= path.length; ++index) {
		if (index < path.length) char = path[index];
		else if (char === "/") break;
		else char = "/";
		if (char === "/") {
			if (lastSlash === index - 1 || dots === 1);
			else if (dots === 2) {
				if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
					if (res.length > 2) {
						const lastSlashIndex = res.lastIndexOf("/");
						if (lastSlashIndex === -1) {
							res = "";
							lastSegmentLength = 0;
						} else {
							res = res.slice(0, lastSlashIndex);
							lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
						}
						lastSlash = index;
						dots = 0;
						continue;
					} else if (res.length > 0) {
						res = "";
						lastSegmentLength = 0;
						lastSlash = index;
						dots = 0;
						continue;
					}
				}
				if (allowAboveRoot) {
					res += res.length > 0 ? "/.." : "..";
					lastSegmentLength = 2;
				}
			} else {
				if (res.length > 0) res += `/${path.slice(lastSlash + 1, index)}`;
				else res = path.slice(lastSlash + 1, index);
				lastSegmentLength = index - lastSlash - 1;
			}
			lastSlash = index;
			dots = 0;
		} else if (char === "." && dots !== -1) ++dots;
		else dots = -1;
	}
	return res;
}
var isAbsolute = function(p) {
	return _IS_ABSOLUTE_RE.test(p);
};
var dirname = function(p) {
	const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
	if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) segments[0] += "/";
	return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};
//#endregion
//#region ../../resources/scripts/helpers.ts
var cleanDirectoryPath = (path) => path.replaceAll(/(\/(\/*))|(^$)/g, "/");
function fileBitsToString(mode, directory) {
	const m = parseInt(mode, 8);
	let buf = "";
	for (const [i, c] of [..."dalTLDpSugct?"].entries()) if ((m & 1 << 31 - i) !== 0) buf += c;
	if (buf.length === 0) buf = directory ? "d" : "-";
	for (const [i, c] of [..."rwxrwxrwx"].entries()) buf += (m & 1 << 8 - i) === 0 ? "-" : c;
	return buf;
}
function encodePathSegments(path) {
	return path.split("/").map((s) => encodeURIComponent(s)).join("/");
}
function hashToPath(hash) {
	const segments = decodeURIComponent(hash.replace(/^#/, "")).split("/").filter(Boolean);
	return segments.length > 0 ? `/${segments.join("/")}` : "/";
}
/** Strips leading "../" and "/" segments. */
var normalizeServerPath = (path) => normalize(path).replace(/^(\.\.\/|\/)+/, "");
/** The name a newly created directory appears under in its parent's file list. */
var newDirectoryDisplayName = (name) => normalizeServerPath(name).split("/", 1)[0] || name;
//#endregion
//#region ../../resources/scripts/state/server/index.tsx
var createStatus = (set) => ({
	value: null,
	setServerStatus: (payload) => set((state) => ({ status: {
		...state.status,
		value: payload
	} }))
});
var createServerStore = () => createStore()((set, get) => ({
	socket: createSocket(set),
	status: createStatus(set),
	files: createFiles(set, get),
	clearServerState: () => {
		const sock = get().socket.instance;
		if (sock) {
			sock.removeAllListeners();
			sock.close();
		}
		set((state) => ({
			files: {
				...state.files,
				selectedDirectory: null,
				selectedFiles: []
			},
			socket: {
				...state.socket,
				instance: null,
				connected: false,
				reconnecting: false
			},
			status: {
				...state.status,
				value: null
			}
		}));
	}
}));
var StoreContext = createContext(null);
var Provider = ({ children }) => {
	const [store] = useState(createServerStore);
	return /* @__PURE__ */ jsx(StoreContext.Provider, {
		value: store,
		children
	});
};
var useServerStoreApi = () => {
	const store = use(StoreContext);
	if (!store) throw new Error("ServerContext.Provider is missing from the component tree.");
	return store;
};
function useServerStore(selector) {
	return useStore$1(useServerStoreApi(), selector);
}
var useServerDirectory = () => {
	return hashToPath(useLocation({ select: (location) => location.hash }));
};
var useSocketConnected = () => useServerStore((state) => state.socket.connected);
var useSocketInstance = () => useServerStore((state) => state.socket.instance);
var useFileUploadActions = () => {
	const removeFileUpload = useServerStore((state) => state.files.removeFileUpload);
	const pushFileUpload = useServerStore((state) => state.files.pushFileUpload);
	const setUploadProgress = useServerStore((state) => state.files.setUploadProgress);
	return useMemo(() => ({
		removeFileUpload,
		pushFileUpload,
		setUploadProgress
	}), [
		pushFileUpload,
		removeFileUpload,
		setUploadProgress
	]);
};
//#endregion
//#region ../../resources/scripts/plugins/usePermissions.ts
var hasPermission = (userPermissions, permission) => {
	if (userPermissions[0] === "*") return true;
	if (permission.endsWith(".*")) {
		const prefix = permission.slice(0, -1);
		return userPermissions.some((granted) => granted.startsWith(prefix));
	}
	return userPermissions.includes(permission);
};
var usePermissions = (action) => {
	const userPermissions = useCurrentServerPermissions();
	return (Array.isArray(action) ? action : [action]).map((permission) => hasPermission(userPermissions, permission));
};
//#endregion
//#region ../../node_modules/clsx/dist/clsx.mjs
function r(e) {
	var t, f, n = "";
	if ("string" == typeof e || "number" == typeof e) n += e;
	else if ("object" == typeof e) if (Array.isArray(e)) {
		var o = e.length;
		for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
	} else for (f in e) e[f] && (n && (n += " "), n += f);
	return n;
}
function clsx() {
	for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
	return n;
}
//#endregion
//#region ../../node_modules/class-variance-authority/dist/index.mjs
/**
* Copyright 2022 Joe Bell. All rights reserved.
*
* This file is licensed to you under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with the
* License. You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/ var falsyToString = (value) => typeof value === "boolean" ? `${value}` : value === 0 ? "0" : value;
var cx = clsx;
var cva = (base, config) => (props) => {
	var _config_compoundVariants;
	if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
	const { variants, defaultVariants } = config;
	const getVariantClassNames = Object.keys(variants).map((variant) => {
		const variantProp = props === null || props === void 0 ? void 0 : props[variant];
		const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
		if (variantProp === null) return null;
		const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
		return variants[variant][variantKey];
	});
	const propsWithoutUndefined = props && Object.entries(props).reduce((acc, param) => {
		let [key, value] = param;
		if (value === void 0) return acc;
		acc[key] = value;
		return acc;
	}, {});
	return cx(base, getVariantClassNames, config === null || config === void 0 ? void 0 : (_config_compoundVariants = config.compoundVariants) === null || _config_compoundVariants === void 0 ? void 0 : _config_compoundVariants.reduce((acc, param) => {
		let { class: cvClass, className: cvClassName, ...compoundVariantOptions } = param;
		return Object.entries(compoundVariantOptions).every((param) => {
			let [key, value] = param;
			return Array.isArray(value) ? value.includes({
				...defaultVariants,
				...propsWithoutUndefined
			}[key]) : {
				...defaultVariants,
				...propsWithoutUndefined
			}[key] === value;
		}) ? [
			...acc,
			cvClass,
			cvClassName
		] : acc;
	}, []), props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
};
//#endregion
//#region ../../node_modules/tailwind-merge/dist/bundle-mjs.mjs
/**
* Concatenates two arrays faster than the array spread operator.
*/
var concatArrays = (array1, array2) => {
	const combinedArray = new Array(array1.length + array2.length);
	for (let i = 0; i < array1.length; i++) combinedArray[i] = array1[i];
	for (let i = 0; i < array2.length; i++) combinedArray[array1.length + i] = array2[i];
	return combinedArray;
};
var createClassValidatorObject = (classGroupId, validator) => ({
	classGroupId,
	validator
});
var createClassPartObject = (nextPart = /* @__PURE__ */ new Map(), validators = null, classGroupId) => ({
	nextPart,
	validators,
	classGroupId
});
var CLASS_PART_SEPARATOR = "-";
var EMPTY_CONFLICTS = [];
var ARBITRARY_PROPERTY_PREFIX = "arbitrary..";
var createClassGroupUtils = (config) => {
	const classMap = createClassMap(config);
	const { conflictingClassGroups, conflictingClassGroupModifiers } = config;
	const getClassGroupId = (className) => {
		if (className.startsWith("[") && className.endsWith("]")) return getGroupIdForArbitraryProperty(className);
		const classParts = className.split(CLASS_PART_SEPARATOR);
		return getGroupRecursive(classParts, classParts[0] === "" && classParts.length > 1 ? 1 : 0, classMap);
	};
	const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
		if (hasPostfixModifier) {
			const modifierConflicts = conflictingClassGroupModifiers[classGroupId];
			const baseConflicts = conflictingClassGroups[classGroupId];
			if (modifierConflicts) {
				if (baseConflicts) return concatArrays(baseConflicts, modifierConflicts);
				return modifierConflicts;
			}
			return baseConflicts || EMPTY_CONFLICTS;
		}
		return conflictingClassGroups[classGroupId] || EMPTY_CONFLICTS;
	};
	return {
		getClassGroupId,
		getConflictingClassGroupIds
	};
};
var getGroupRecursive = (classParts, startIndex, classPartObject) => {
	if (classParts.length - startIndex === 0) return classPartObject.classGroupId;
	const currentClassPart = classParts[startIndex];
	const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
	if (nextClassPartObject) {
		const result = getGroupRecursive(classParts, startIndex + 1, nextClassPartObject);
		if (result) return result;
	}
	const validators = classPartObject.validators;
	if (validators === null) return;
	const classRest = startIndex === 0 ? classParts.join(CLASS_PART_SEPARATOR) : classParts.slice(startIndex).join(CLASS_PART_SEPARATOR);
	const validatorsLength = validators.length;
	for (let i = 0; i < validatorsLength; i++) {
		const validatorObj = validators[i];
		if (validatorObj.validator(classRest)) return validatorObj.classGroupId;
	}
};
/**
* Get the class group ID for an arbitrary property.
*
* @param className - The class name to get the group ID for. Is expected to be string starting with `[` and ending with `]`.
*/
var getGroupIdForArbitraryProperty = (className) => className.slice(1, -1).indexOf(":") === -1 ? void 0 : (() => {
	const content = className.slice(1, -1);
	const colonIndex = content.indexOf(":");
	const property = content.slice(0, colonIndex);
	return property ? ARBITRARY_PROPERTY_PREFIX + property : void 0;
})();
/**
* Exported for testing only
*/
var createClassMap = (config) => {
	const { theme, classGroups } = config;
	return processClassGroups(classGroups, theme);
};
var processClassGroups = (classGroups, theme) => {
	const classMap = createClassPartObject();
	for (const classGroupId in classGroups) {
		const group = classGroups[classGroupId];
		processClassesRecursively(group, classMap, classGroupId, theme);
	}
	return classMap;
};
var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
	const len = classGroup.length;
	for (let i = 0; i < len; i++) {
		const classDefinition = classGroup[i];
		processClassDefinition(classDefinition, classPartObject, classGroupId, theme);
	}
};
var processClassDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
	if (typeof classDefinition === "string") {
		processStringDefinition(classDefinition, classPartObject, classGroupId);
		return;
	}
	if (typeof classDefinition === "function") {
		processFunctionDefinition(classDefinition, classPartObject, classGroupId, theme);
		return;
	}
	processObjectDefinition(classDefinition, classPartObject, classGroupId, theme);
};
var processStringDefinition = (classDefinition, classPartObject, classGroupId) => {
	const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
	classPartObjectToEdit.classGroupId = classGroupId;
};
var processFunctionDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
	if (isThemeGetter(classDefinition)) {
		processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
		return;
	}
	if (classPartObject.validators === null) classPartObject.validators = [];
	classPartObject.validators.push(createClassValidatorObject(classGroupId, classDefinition));
};
var processObjectDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
	const entries = Object.entries(classDefinition);
	const len = entries.length;
	for (let i = 0; i < len; i++) {
		const [key, value] = entries[i];
		processClassesRecursively(value, getPart(classPartObject, key), classGroupId, theme);
	}
};
var getPart = (classPartObject, path) => {
	let current = classPartObject;
	const parts = path.split(CLASS_PART_SEPARATOR);
	const len = parts.length;
	for (let i = 0; i < len; i++) {
		const part = parts[i];
		let next = current.nextPart.get(part);
		if (!next) {
			next = createClassPartObject();
			current.nextPart.set(part, next);
		}
		current = next;
	}
	return current;
};
var isThemeGetter = (func) => "isThemeGetter" in func && func.isThemeGetter === true;
var createLruCache = (maxCacheSize) => {
	if (maxCacheSize < 1) return {
		get: () => void 0,
		set: () => {}
	};
	let cacheSize = 0;
	let cache = Object.create(null);
	let previousCache = Object.create(null);
	const update = (key, value) => {
		cache[key] = value;
		cacheSize++;
		if (cacheSize > maxCacheSize) {
			cacheSize = 0;
			previousCache = cache;
			cache = Object.create(null);
		}
	};
	return {
		get(key) {
			let value = cache[key];
			if (value !== void 0) return value;
			if ((value = previousCache[key]) !== void 0) {
				update(key, value);
				return value;
			}
		},
		set(key, value) {
			if (key in cache) cache[key] = value;
			else update(key, value);
		}
	};
};
var IMPORTANT_MODIFIER = "!";
var MODIFIER_SEPARATOR = ":";
var EMPTY_MODIFIERS = [];
var createResultObject = (modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition, isExternal) => ({
	modifiers,
	hasImportantModifier,
	baseClassName,
	maybePostfixModifierPosition,
	isExternal
});
var createParseClassName = (config) => {
	const { prefix, experimentalParseClassName } = config;
	/**
	* Parse class name into parts.
	*
	* Inspired by `splitAtTopLevelOnly` used in Tailwind CSS
	* @see https://github.com/tailwindlabs/tailwindcss/blob/v3.2.2/src/util/splitAtTopLevelOnly.js
	*/
	let parseClassName = (className) => {
		const modifiers = [];
		let bracketDepth = 0;
		let parenDepth = 0;
		let modifierStart = 0;
		let postfixModifierPosition;
		const len = className.length;
		for (let index = 0; index < len; index++) {
			const currentCharacter = className[index];
			if (bracketDepth === 0 && parenDepth === 0) {
				if (currentCharacter === MODIFIER_SEPARATOR) {
					modifiers.push(className.slice(modifierStart, index));
					modifierStart = index + 1;
					continue;
				}
				if (currentCharacter === "/") {
					postfixModifierPosition = index;
					continue;
				}
			}
			if (currentCharacter === "[") bracketDepth++;
			else if (currentCharacter === "]") bracketDepth--;
			else if (currentCharacter === "(") parenDepth++;
			else if (currentCharacter === ")") parenDepth--;
		}
		const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.slice(modifierStart);
		let baseClassName = baseClassNameWithImportantModifier;
		let hasImportantModifier = false;
		if (baseClassNameWithImportantModifier.endsWith(IMPORTANT_MODIFIER)) {
			baseClassName = baseClassNameWithImportantModifier.slice(0, -1);
			hasImportantModifier = true;
		} else if (baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER)) {
			baseClassName = baseClassNameWithImportantModifier.slice(1);
			hasImportantModifier = true;
		}
		const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
		return createResultObject(modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition);
	};
	if (prefix) {
		const fullPrefix = prefix + MODIFIER_SEPARATOR;
		const parseClassNameOriginal = parseClassName;
		parseClassName = (className) => className.startsWith(fullPrefix) ? parseClassNameOriginal(className.slice(fullPrefix.length)) : createResultObject(EMPTY_MODIFIERS, false, className, void 0, true);
	}
	if (experimentalParseClassName) {
		const parseClassNameOriginal = parseClassName;
		parseClassName = (className) => experimentalParseClassName({
			className,
			parseClassName: parseClassNameOriginal
		});
	}
	return parseClassName;
};
/**
* Sorts modifiers according to following schema:
* - Predefined modifiers are sorted alphabetically
* - When an arbitrary variant appears, it must be preserved which modifiers are before and after it
*/
var createSortModifiers = (config) => {
	const modifierWeights = /* @__PURE__ */ new Map();
	config.orderSensitiveModifiers.forEach((mod, index) => {
		modifierWeights.set(mod, 1e6 + index);
	});
	return (modifiers) => {
		const result = [];
		let currentSegment = [];
		for (let i = 0; i < modifiers.length; i++) {
			const modifier = modifiers[i];
			const isArbitrary = modifier[0] === "[";
			const isOrderSensitive = modifierWeights.has(modifier);
			if (isArbitrary || isOrderSensitive) {
				if (currentSegment.length > 0) {
					currentSegment.sort();
					result.push(...currentSegment);
					currentSegment = [];
				}
				result.push(modifier);
			} else currentSegment.push(modifier);
		}
		if (currentSegment.length > 0) {
			currentSegment.sort();
			result.push(...currentSegment);
		}
		return result;
	};
};
var createConfigUtils = (config) => ({
	cache: createLruCache(config.cacheSize),
	parseClassName: createParseClassName(config),
	sortModifiers: createSortModifiers(config),
	postfixLookupClassGroupIds: createPostfixLookupClassGroupIds(config),
	...createClassGroupUtils(config)
});
var createPostfixLookupClassGroupIds = (config) => {
	const lookup = Object.create(null);
	const classGroupIds = config.postfixLookupClassGroups;
	if (classGroupIds) for (let i = 0; i < classGroupIds.length; i++) lookup[classGroupIds[i]] = true;
	return lookup;
};
var SPLIT_CLASSES_REGEX = /\s+/;
var mergeClassList = (classList, configUtils) => {
	const { parseClassName, getClassGroupId, getConflictingClassGroupIds, sortModifiers, postfixLookupClassGroupIds } = configUtils;
	/**
	* Set of classGroupIds in following format:
	* `{importantModifier}{variantModifiers}{classGroupId}`
	* @example 'float'
	* @example 'hover:focus:bg-color'
	* @example 'md:!pr'
	*/
	const classGroupsInConflict = [];
	const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
	let result = "";
	for (let index = classNames.length - 1; index >= 0; index -= 1) {
		const originalClassName = classNames[index];
		const { isExternal, modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition } = parseClassName(originalClassName);
		if (isExternal) {
			result = originalClassName + (result.length > 0 ? " " + result : result);
			continue;
		}
		let hasPostfixModifier = !!maybePostfixModifierPosition;
		let classGroupId;
		if (hasPostfixModifier) {
			classGroupId = getClassGroupId(baseClassName.substring(0, maybePostfixModifierPosition));
			const classGroupIdWithPostfix = classGroupId && postfixLookupClassGroupIds[classGroupId] ? getClassGroupId(baseClassName) : void 0;
			if (classGroupIdWithPostfix && classGroupIdWithPostfix !== classGroupId) {
				classGroupId = classGroupIdWithPostfix;
				hasPostfixModifier = false;
			}
		} else classGroupId = getClassGroupId(baseClassName);
		if (!classGroupId) {
			if (!hasPostfixModifier) {
				result = originalClassName + (result.length > 0 ? " " + result : result);
				continue;
			}
			classGroupId = getClassGroupId(baseClassName);
			if (!classGroupId) {
				result = originalClassName + (result.length > 0 ? " " + result : result);
				continue;
			}
			hasPostfixModifier = false;
		}
		const variantModifier = modifiers.length === 0 ? "" : modifiers.length === 1 ? modifiers[0] : sortModifiers(modifiers).join(":");
		const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
		const classId = modifierId + classGroupId;
		if (classGroupsInConflict.indexOf(classId) > -1) continue;
		classGroupsInConflict.push(classId);
		const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
		for (let i = 0; i < conflictGroups.length; ++i) {
			const group = conflictGroups[i];
			classGroupsInConflict.push(modifierId + group);
		}
		result = originalClassName + (result.length > 0 ? " " + result : result);
	}
	return result;
};
/**
* The code in this file is copied from https://github.com/lukeed/clsx and modified to suit the needs of tailwind-merge better.
*
* Specifically:
* - Runtime code from https://github.com/lukeed/clsx/blob/v1.2.1/src/index.js
* - TypeScript types from https://github.com/lukeed/clsx/blob/v1.2.1/clsx.d.ts
*
* Original code has MIT license: Copyright (c) Luke Edwards <luke.edwards05@gmail.com> (lukeed.com)
*/
var twJoin = (...classLists) => {
	let index = 0;
	let argument;
	let resolvedValue;
	let string = "";
	while (index < classLists.length) if (argument = classLists[index++]) {
		if (resolvedValue = toValue(argument)) {
			string && (string += " ");
			string += resolvedValue;
		}
	}
	return string;
};
var toValue = (mix) => {
	if (typeof mix === "string") return mix;
	let resolvedValue;
	let string = "";
	for (let k = 0; k < mix.length; k++) if (mix[k]) {
		if (resolvedValue = toValue(mix[k])) {
			string && (string += " ");
			string += resolvedValue;
		}
	}
	return string;
};
var createTailwindMerge = (createConfigFirst, ...createConfigRest) => {
	let configUtils;
	let cacheGet;
	let cacheSet;
	let functionToCall;
	const initTailwindMerge = (classList) => {
		configUtils = createConfigUtils(createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst()));
		cacheGet = configUtils.cache.get;
		cacheSet = configUtils.cache.set;
		functionToCall = tailwindMerge;
		return tailwindMerge(classList);
	};
	const tailwindMerge = (classList) => {
		const cachedResult = cacheGet(classList);
		if (cachedResult) return cachedResult;
		const result = mergeClassList(classList, configUtils);
		cacheSet(classList, result);
		return result;
	};
	functionToCall = initTailwindMerge;
	return (...args) => functionToCall(twJoin(...args));
};
var fallbackThemeArr = [];
var fromTheme = (key) => {
	const themeGetter = (theme) => theme[key] || fallbackThemeArr;
	themeGetter.isThemeGetter = true;
	return themeGetter;
};
var arbitraryValueRegex = /^\[(?:(\w[\w-]*):)?(.+)\]$/i;
var arbitraryVariableRegex = /^\((?:(\w[\w-]*):)?(.+)\)$/i;
var fractionRegex = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/;
var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
var isFraction = (value) => fractionRegex.test(value);
var isNumber = (value) => !!value && !Number.isNaN(Number(value));
var isInteger = (value) => !!value && Number.isInteger(Number(value));
var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
var isTshirtSize = (value) => tshirtUnitRegex.test(value);
var isAny = () => true;
var isLengthOnly = (value) => lengthUnitRegex.test(value) && !colorFunctionRegex.test(value);
var isNever = () => false;
var isShadow = (value) => shadowRegex.test(value);
var isImage = (value) => imageRegex.test(value);
var isAnyNonArbitrary = (value) => !isArbitraryValue(value) && !isArbitraryVariable(value);
var isNamedContainerQuery = (value) => value.startsWith("@container") && (value[10] === "/" && value[11] !== void 0 || value[11] === "s" && value[16] !== void 0 && value.startsWith("-size/", 10) || value[11] === "n" && value[18] !== void 0 && value.startsWith("-normal/", 10));
var isArbitrarySize = (value) => getIsArbitraryValue(value, isLabelSize, isNever);
var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
var isArbitraryLength = (value) => getIsArbitraryValue(value, isLabelLength, isLengthOnly);
var isArbitraryNumber = (value) => getIsArbitraryValue(value, isLabelNumber, isNumber);
var isArbitraryWeight = (value) => getIsArbitraryValue(value, isLabelWeight, isAny);
var isArbitraryFamilyName = (value) => getIsArbitraryValue(value, isLabelFamilyName, isNever);
var isArbitraryPosition = (value) => getIsArbitraryValue(value, isLabelPosition, isNever);
var isArbitraryImage = (value) => getIsArbitraryValue(value, isLabelImage, isImage);
var isArbitraryShadow = (value) => getIsArbitraryValue(value, isLabelShadow, isShadow);
var isArbitraryVariable = (value) => arbitraryVariableRegex.test(value);
var isArbitraryVariableLength = (value) => getIsArbitraryVariable(value, isLabelLength);
var isArbitraryVariableFamilyName = (value) => getIsArbitraryVariable(value, isLabelFamilyName);
var isArbitraryVariablePosition = (value) => getIsArbitraryVariable(value, isLabelPosition);
var isArbitraryVariableSize = (value) => getIsArbitraryVariable(value, isLabelSize);
var isArbitraryVariableImage = (value) => getIsArbitraryVariable(value, isLabelImage);
var isArbitraryVariableShadow = (value) => getIsArbitraryVariable(value, isLabelShadow, true);
var isArbitraryVariableWeight = (value) => getIsArbitraryVariable(value, isLabelWeight, true);
var getIsArbitraryValue = (value, testLabel, testValue) => {
	const result = arbitraryValueRegex.exec(value);
	if (result) {
		if (result[1]) return testLabel(result[1]);
		return testValue(result[2]);
	}
	return false;
};
var getIsArbitraryVariable = (value, testLabel, shouldMatchNoLabel = false) => {
	const result = arbitraryVariableRegex.exec(value);
	if (result) {
		if (result[1]) return testLabel(result[1]);
		return shouldMatchNoLabel;
	}
	return false;
};
var isLabelPosition = (label) => label === "position" || label === "percentage";
var isLabelImage = (label) => label === "image" || label === "url";
var isLabelSize = (label) => label === "length" || label === "size" || label === "bg-size";
var isLabelLength = (label) => label === "length";
var isLabelNumber = (label) => label === "number";
var isLabelFamilyName = (label) => label === "family-name";
var isLabelWeight = (label) => label === "number" || label === "weight";
var isLabelShadow = (label) => label === "shadow";
var getDefaultConfig = () => {
	/**
	* Theme getters for theme variable namespaces
	* @see https://tailwindcss.com/docs/theme#theme-variable-namespaces
	*/
	const themeColor = fromTheme("color");
	const themeFont = fromTheme("font");
	const themeText = fromTheme("text");
	const themeFontWeight = fromTheme("font-weight");
	const themeTracking = fromTheme("tracking");
	const themeLeading = fromTheme("leading");
	const themeBreakpoint = fromTheme("breakpoint");
	const themeContainer = fromTheme("container");
	const themeSpacing = fromTheme("spacing");
	const themeRadius = fromTheme("radius");
	const themeShadow = fromTheme("shadow");
	const themeInsetShadow = fromTheme("inset-shadow");
	const themeTextShadow = fromTheme("text-shadow");
	const themeDropShadow = fromTheme("drop-shadow");
	const themeBlur = fromTheme("blur");
	const themePerspective = fromTheme("perspective");
	const themeAspect = fromTheme("aspect");
	const themeEase = fromTheme("ease");
	const themeAnimate = fromTheme("animate");
	/**
	* Helpers to avoid repeating the same scales
	*
	* We use functions that create a new array every time they're called instead of static arrays.
	* This ensures that users who modify any scale by mutating the array (e.g. with `array.push(element)`) don't accidentally mutate arrays in other parts of the config.
	*/
	const scaleBreak = () => [
		"auto",
		"avoid",
		"all",
		"avoid-page",
		"page",
		"left",
		"right",
		"column"
	];
	const scalePosition = () => [
		"center",
		"top",
		"bottom",
		"left",
		"right",
		"top-left",
		"left-top",
		"top-right",
		"right-top",
		"bottom-right",
		"right-bottom",
		"bottom-left",
		"left-bottom"
	];
	const scalePositionWithArbitrary = () => [
		...scalePosition(),
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleOverflow = () => [
		"auto",
		"hidden",
		"clip",
		"visible",
		"scroll"
	];
	const scaleOverscroll = () => [
		"auto",
		"contain",
		"none"
	];
	const scaleUnambiguousSpacing = () => [
		isArbitraryVariable,
		isArbitraryValue,
		themeSpacing
	];
	const scaleInset = () => [
		isFraction,
		"full",
		"auto",
		...scaleUnambiguousSpacing()
	];
	const scaleGridTemplateColsRows = () => [
		isInteger,
		"none",
		"subgrid",
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleGridColRowStartAndEnd = () => [
		"auto",
		{ span: [
			"full",
			isInteger,
			isArbitraryVariable,
			isArbitraryValue
		] },
		isInteger,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleGridColRowStartOrEnd = () => [
		isInteger,
		"auto",
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleGridAutoColsRows = () => [
		"auto",
		"min",
		"max",
		"fr",
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleAlignPrimaryAxis = () => [
		"start",
		"end",
		"center",
		"between",
		"around",
		"evenly",
		"stretch",
		"baseline",
		"center-safe",
		"end-safe"
	];
	const scaleAlignSecondaryAxis = () => [
		"start",
		"end",
		"center",
		"stretch",
		"center-safe",
		"end-safe"
	];
	const scaleMargin = () => ["auto", ...scaleUnambiguousSpacing()];
	const scaleSizing = () => [
		isFraction,
		"auto",
		"full",
		"dvw",
		"dvh",
		"lvw",
		"lvh",
		"svw",
		"svh",
		"min",
		"max",
		"fit",
		...scaleUnambiguousSpacing()
	];
	const scaleSizingInline = () => [
		isFraction,
		"screen",
		"full",
		"dvw",
		"lvw",
		"svw",
		"min",
		"max",
		"fit",
		...scaleUnambiguousSpacing()
	];
	const scaleSizingBlock = () => [
		isFraction,
		"screen",
		"full",
		"lh",
		"dvh",
		"lvh",
		"svh",
		"min",
		"max",
		"fit",
		...scaleUnambiguousSpacing()
	];
	const scaleColor = () => [
		themeColor,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleBgPosition = () => [
		...scalePosition(),
		isArbitraryVariablePosition,
		isArbitraryPosition,
		{ position: [isArbitraryVariable, isArbitraryValue] }
	];
	const scaleBgRepeat = () => ["no-repeat", { repeat: [
		"",
		"x",
		"y",
		"space",
		"round"
	] }];
	const scaleBgSize = () => [
		"auto",
		"cover",
		"contain",
		isArbitraryVariableSize,
		isArbitrarySize,
		{ size: [isArbitraryVariable, isArbitraryValue] }
	];
	const scaleGradientStopPosition = () => [
		isPercent,
		isArbitraryVariableLength,
		isArbitraryLength
	];
	const scaleRadius = () => [
		"",
		"none",
		"full",
		themeRadius,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleBorderWidth = () => [
		"",
		isNumber,
		isArbitraryVariableLength,
		isArbitraryLength
	];
	const scaleLineStyle = () => [
		"solid",
		"dashed",
		"dotted",
		"double"
	];
	const scaleBlendMode = () => [
		"normal",
		"multiply",
		"screen",
		"overlay",
		"darken",
		"lighten",
		"color-dodge",
		"color-burn",
		"hard-light",
		"soft-light",
		"difference",
		"exclusion",
		"hue",
		"saturation",
		"color",
		"luminosity"
	];
	const scaleMaskImagePosition = () => [
		isNumber,
		isPercent,
		isArbitraryVariablePosition,
		isArbitraryPosition
	];
	const scaleBlur = () => [
		"",
		"none",
		themeBlur,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleRotate = () => [
		"none",
		isNumber,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleScale = () => [
		"none",
		isNumber,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleSkew = () => [
		isNumber,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleTranslate = () => [
		isFraction,
		"full",
		...scaleUnambiguousSpacing()
	];
	return {
		cacheSize: 500,
		theme: {
			animate: [
				"spin",
				"ping",
				"pulse",
				"bounce"
			],
			aspect: ["video"],
			blur: [isTshirtSize],
			breakpoint: [isTshirtSize],
			color: [isAny],
			container: [isTshirtSize],
			"drop-shadow": [isTshirtSize],
			ease: [
				"in",
				"out",
				"in-out"
			],
			font: [isAnyNonArbitrary],
			"font-weight": [
				"thin",
				"extralight",
				"light",
				"normal",
				"medium",
				"semibold",
				"bold",
				"extrabold",
				"black"
			],
			"inset-shadow": [isTshirtSize],
			leading: [
				"none",
				"tight",
				"snug",
				"normal",
				"relaxed",
				"loose"
			],
			perspective: [
				"dramatic",
				"near",
				"normal",
				"midrange",
				"distant",
				"none"
			],
			radius: [isTshirtSize],
			shadow: [isTshirtSize],
			spacing: ["px", isNumber],
			text: [isTshirtSize],
			"text-shadow": [isTshirtSize],
			tracking: [
				"tighter",
				"tight",
				"normal",
				"wide",
				"wider",
				"widest"
			]
		},
		classGroups: {
			/**
			* Aspect Ratio
			* @see https://tailwindcss.com/docs/aspect-ratio
			*/
			aspect: [{ aspect: [
				"auto",
				"square",
				isFraction,
				isArbitraryValue,
				isArbitraryVariable,
				themeAspect
			] }],
			/**
			* Container
			* @see https://tailwindcss.com/docs/container
			* @deprecated since Tailwind CSS v4.0.0
			*/
			container: ["container"],
			/**
			* Container Type
			* @see https://tailwindcss.com/docs/responsive-design#container-queries
			*/
			"container-type": [{ "@container": [
				"",
				"normal",
				"size",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Container Name
			* @see https://tailwindcss.com/docs/responsive-design#named-containers
			*/
			"container-named": [isNamedContainerQuery],
			/**
			* Columns
			* @see https://tailwindcss.com/docs/columns
			*/
			columns: [{ columns: [
				isNumber,
				isArbitraryValue,
				isArbitraryVariable,
				themeContainer
			] }],
			/**
			* Break After
			* @see https://tailwindcss.com/docs/break-after
			*/
			"break-after": [{ "break-after": scaleBreak() }],
			/**
			* Break Before
			* @see https://tailwindcss.com/docs/break-before
			*/
			"break-before": [{ "break-before": scaleBreak() }],
			/**
			* Break Inside
			* @see https://tailwindcss.com/docs/break-inside
			*/
			"break-inside": [{ "break-inside": [
				"auto",
				"avoid",
				"avoid-page",
				"avoid-column"
			] }],
			/**
			* Box Decoration Break
			* @see https://tailwindcss.com/docs/box-decoration-break
			*/
			"box-decoration": [{ "box-decoration": ["slice", "clone"] }],
			/**
			* Box Sizing
			* @see https://tailwindcss.com/docs/box-sizing
			*/
			box: [{ box: ["border", "content"] }],
			/**
			* Display
			* @see https://tailwindcss.com/docs/display
			*/
			display: [
				"block",
				"inline-block",
				"inline",
				"flex",
				"inline-flex",
				"table",
				"inline-table",
				"table-caption",
				"table-cell",
				"table-column",
				"table-column-group",
				"table-footer-group",
				"table-header-group",
				"table-row-group",
				"table-row",
				"flow-root",
				"grid",
				"inline-grid",
				"contents",
				"list-item",
				"hidden"
			],
			/**
			* Screen Reader Only
			* @see https://tailwindcss.com/docs/display#screen-reader-only
			*/
			sr: ["sr-only", "not-sr-only"],
			/**
			* Floats
			* @see https://tailwindcss.com/docs/float
			*/
			float: [{ float: [
				"right",
				"left",
				"none",
				"start",
				"end"
			] }],
			/**
			* Clear
			* @see https://tailwindcss.com/docs/clear
			*/
			clear: [{ clear: [
				"left",
				"right",
				"both",
				"none",
				"start",
				"end"
			] }],
			/**
			* Isolation
			* @see https://tailwindcss.com/docs/isolation
			*/
			isolation: ["isolate", "isolation-auto"],
			/**
			* Object Fit
			* @see https://tailwindcss.com/docs/object-fit
			*/
			"object-fit": [{ object: [
				"contain",
				"cover",
				"fill",
				"none",
				"scale-down"
			] }],
			/**
			* Object Position
			* @see https://tailwindcss.com/docs/object-position
			*/
			"object-position": [{ object: scalePositionWithArbitrary() }],
			/**
			* Overflow
			* @see https://tailwindcss.com/docs/overflow
			*/
			overflow: [{ overflow: scaleOverflow() }],
			/**
			* Overflow X
			* @see https://tailwindcss.com/docs/overflow
			*/
			"overflow-x": [{ "overflow-x": scaleOverflow() }],
			/**
			* Overflow Y
			* @see https://tailwindcss.com/docs/overflow
			*/
			"overflow-y": [{ "overflow-y": scaleOverflow() }],
			/**
			* Overscroll Behavior
			* @see https://tailwindcss.com/docs/overscroll-behavior
			*/
			overscroll: [{ overscroll: scaleOverscroll() }],
			/**
			* Overscroll Behavior X
			* @see https://tailwindcss.com/docs/overscroll-behavior
			*/
			"overscroll-x": [{ "overscroll-x": scaleOverscroll() }],
			/**
			* Overscroll Behavior Y
			* @see https://tailwindcss.com/docs/overscroll-behavior
			*/
			"overscroll-y": [{ "overscroll-y": scaleOverscroll() }],
			/**
			* Position
			* @see https://tailwindcss.com/docs/position
			*/
			position: [
				"static",
				"fixed",
				"absolute",
				"relative",
				"sticky"
			],
			/**
			* Inset
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			inset: [{ inset: scaleInset() }],
			/**
			* Inset Inline
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			"inset-x": [{ "inset-x": scaleInset() }],
			/**
			* Inset Block
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			"inset-y": [{ "inset-y": scaleInset() }],
			/**
			* Inset Inline Start
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			* @todo class group will be renamed to `inset-s` in next major release
			*/
			start: [{
				"inset-s": scaleInset(),
				/**
				* @deprecated since Tailwind CSS v4.2.0 in favor of `inset-s-*` utilities.
				* @see https://github.com/tailwindlabs/tailwindcss/pull/19613
				*/
				start: scaleInset()
			}],
			/**
			* Inset Inline End
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			* @todo class group will be renamed to `inset-e` in next major release
			*/
			end: [{
				"inset-e": scaleInset(),
				/**
				* @deprecated since Tailwind CSS v4.2.0 in favor of `inset-e-*` utilities.
				* @see https://github.com/tailwindlabs/tailwindcss/pull/19613
				*/
				end: scaleInset()
			}],
			/**
			* Inset Block Start
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			"inset-bs": [{ "inset-bs": scaleInset() }],
			/**
			* Inset Block End
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			"inset-be": [{ "inset-be": scaleInset() }],
			/**
			* Top
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			top: [{ top: scaleInset() }],
			/**
			* Right
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			right: [{ right: scaleInset() }],
			/**
			* Bottom
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			bottom: [{ bottom: scaleInset() }],
			/**
			* Left
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			left: [{ left: scaleInset() }],
			/**
			* Visibility
			* @see https://tailwindcss.com/docs/visibility
			*/
			visibility: [
				"visible",
				"invisible",
				"collapse"
			],
			/**
			* Z-Index
			* @see https://tailwindcss.com/docs/z-index
			*/
			z: [{ z: [
				isInteger,
				"auto",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Flex Basis
			* @see https://tailwindcss.com/docs/flex-basis
			*/
			basis: [{ basis: [
				isFraction,
				"full",
				"auto",
				themeContainer,
				...scaleUnambiguousSpacing()
			] }],
			/**
			* Flex Direction
			* @see https://tailwindcss.com/docs/flex-direction
			*/
			"flex-direction": [{ flex: [
				"row",
				"row-reverse",
				"col",
				"col-reverse"
			] }],
			/**
			* Flex Wrap
			* @see https://tailwindcss.com/docs/flex-wrap
			*/
			"flex-wrap": [{ flex: [
				"nowrap",
				"wrap",
				"wrap-reverse"
			] }],
			/**
			* Flex
			* @see https://tailwindcss.com/docs/flex
			*/
			flex: [{ flex: [
				isNumber,
				isFraction,
				"auto",
				"initial",
				"none",
				isArbitraryValue
			] }],
			/**
			* Flex Grow
			* @see https://tailwindcss.com/docs/flex-grow
			*/
			grow: [{ grow: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Flex Shrink
			* @see https://tailwindcss.com/docs/flex-shrink
			*/
			shrink: [{ shrink: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Order
			* @see https://tailwindcss.com/docs/order
			*/
			order: [{ order: [
				isInteger,
				"first",
				"last",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Grid Template Columns
			* @see https://tailwindcss.com/docs/grid-template-columns
			*/
			"grid-cols": [{ "grid-cols": scaleGridTemplateColsRows() }],
			/**
			* Grid Column Start / End
			* @see https://tailwindcss.com/docs/grid-column
			*/
			"col-start-end": [{ col: scaleGridColRowStartAndEnd() }],
			/**
			* Grid Column Start
			* @see https://tailwindcss.com/docs/grid-column
			*/
			"col-start": [{ "col-start": scaleGridColRowStartOrEnd() }],
			/**
			* Grid Column End
			* @see https://tailwindcss.com/docs/grid-column
			*/
			"col-end": [{ "col-end": scaleGridColRowStartOrEnd() }],
			/**
			* Grid Template Rows
			* @see https://tailwindcss.com/docs/grid-template-rows
			*/
			"grid-rows": [{ "grid-rows": scaleGridTemplateColsRows() }],
			/**
			* Grid Row Start / End
			* @see https://tailwindcss.com/docs/grid-row
			*/
			"row-start-end": [{ row: scaleGridColRowStartAndEnd() }],
			/**
			* Grid Row Start
			* @see https://tailwindcss.com/docs/grid-row
			*/
			"row-start": [{ "row-start": scaleGridColRowStartOrEnd() }],
			/**
			* Grid Row End
			* @see https://tailwindcss.com/docs/grid-row
			*/
			"row-end": [{ "row-end": scaleGridColRowStartOrEnd() }],
			/**
			* Grid Auto Flow
			* @see https://tailwindcss.com/docs/grid-auto-flow
			*/
			"grid-flow": [{ "grid-flow": [
				"row",
				"col",
				"dense",
				"row-dense",
				"col-dense"
			] }],
			/**
			* Grid Auto Columns
			* @see https://tailwindcss.com/docs/grid-auto-columns
			*/
			"auto-cols": [{ "auto-cols": scaleGridAutoColsRows() }],
			/**
			* Grid Auto Rows
			* @see https://tailwindcss.com/docs/grid-auto-rows
			*/
			"auto-rows": [{ "auto-rows": scaleGridAutoColsRows() }],
			/**
			* Gap
			* @see https://tailwindcss.com/docs/gap
			*/
			gap: [{ gap: scaleUnambiguousSpacing() }],
			/**
			* Gap X
			* @see https://tailwindcss.com/docs/gap
			*/
			"gap-x": [{ "gap-x": scaleUnambiguousSpacing() }],
			/**
			* Gap Y
			* @see https://tailwindcss.com/docs/gap
			*/
			"gap-y": [{ "gap-y": scaleUnambiguousSpacing() }],
			/**
			* Justify Content
			* @see https://tailwindcss.com/docs/justify-content
			*/
			"justify-content": [{ justify: [...scaleAlignPrimaryAxis(), "normal"] }],
			/**
			* Justify Items
			* @see https://tailwindcss.com/docs/justify-items
			*/
			"justify-items": [{ "justify-items": [...scaleAlignSecondaryAxis(), "normal"] }],
			/**
			* Justify Self
			* @see https://tailwindcss.com/docs/justify-self
			*/
			"justify-self": [{ "justify-self": ["auto", ...scaleAlignSecondaryAxis()] }],
			/**
			* Align Content
			* @see https://tailwindcss.com/docs/align-content
			*/
			"align-content": [{ content: ["normal", ...scaleAlignPrimaryAxis()] }],
			/**
			* Align Items
			* @see https://tailwindcss.com/docs/align-items
			*/
			"align-items": [{ items: [...scaleAlignSecondaryAxis(), { baseline: ["", "last"] }] }],
			/**
			* Align Self
			* @see https://tailwindcss.com/docs/align-self
			*/
			"align-self": [{ self: [
				"auto",
				...scaleAlignSecondaryAxis(),
				{ baseline: ["", "last"] }
			] }],
			/**
			* Place Content
			* @see https://tailwindcss.com/docs/place-content
			*/
			"place-content": [{ "place-content": scaleAlignPrimaryAxis() }],
			/**
			* Place Items
			* @see https://tailwindcss.com/docs/place-items
			*/
			"place-items": [{ "place-items": [...scaleAlignSecondaryAxis(), "baseline"] }],
			/**
			* Place Self
			* @see https://tailwindcss.com/docs/place-self
			*/
			"place-self": [{ "place-self": ["auto", ...scaleAlignSecondaryAxis()] }],
			/**
			* Padding
			* @see https://tailwindcss.com/docs/padding
			*/
			p: [{ p: scaleUnambiguousSpacing() }],
			/**
			* Padding Inline
			* @see https://tailwindcss.com/docs/padding
			*/
			px: [{ px: scaleUnambiguousSpacing() }],
			/**
			* Padding Block
			* @see https://tailwindcss.com/docs/padding
			*/
			py: [{ py: scaleUnambiguousSpacing() }],
			/**
			* Padding Inline Start
			* @see https://tailwindcss.com/docs/padding
			*/
			ps: [{ ps: scaleUnambiguousSpacing() }],
			/**
			* Padding Inline End
			* @see https://tailwindcss.com/docs/padding
			*/
			pe: [{ pe: scaleUnambiguousSpacing() }],
			/**
			* Padding Block Start
			* @see https://tailwindcss.com/docs/padding
			*/
			pbs: [{ pbs: scaleUnambiguousSpacing() }],
			/**
			* Padding Block End
			* @see https://tailwindcss.com/docs/padding
			*/
			pbe: [{ pbe: scaleUnambiguousSpacing() }],
			/**
			* Padding Top
			* @see https://tailwindcss.com/docs/padding
			*/
			pt: [{ pt: scaleUnambiguousSpacing() }],
			/**
			* Padding Right
			* @see https://tailwindcss.com/docs/padding
			*/
			pr: [{ pr: scaleUnambiguousSpacing() }],
			/**
			* Padding Bottom
			* @see https://tailwindcss.com/docs/padding
			*/
			pb: [{ pb: scaleUnambiguousSpacing() }],
			/**
			* Padding Left
			* @see https://tailwindcss.com/docs/padding
			*/
			pl: [{ pl: scaleUnambiguousSpacing() }],
			/**
			* Margin
			* @see https://tailwindcss.com/docs/margin
			*/
			m: [{ m: scaleMargin() }],
			/**
			* Margin Inline
			* @see https://tailwindcss.com/docs/margin
			*/
			mx: [{ mx: scaleMargin() }],
			/**
			* Margin Block
			* @see https://tailwindcss.com/docs/margin
			*/
			my: [{ my: scaleMargin() }],
			/**
			* Margin Inline Start
			* @see https://tailwindcss.com/docs/margin
			*/
			ms: [{ ms: scaleMargin() }],
			/**
			* Margin Inline End
			* @see https://tailwindcss.com/docs/margin
			*/
			me: [{ me: scaleMargin() }],
			/**
			* Margin Block Start
			* @see https://tailwindcss.com/docs/margin
			*/
			mbs: [{ mbs: scaleMargin() }],
			/**
			* Margin Block End
			* @see https://tailwindcss.com/docs/margin
			*/
			mbe: [{ mbe: scaleMargin() }],
			/**
			* Margin Top
			* @see https://tailwindcss.com/docs/margin
			*/
			mt: [{ mt: scaleMargin() }],
			/**
			* Margin Right
			* @see https://tailwindcss.com/docs/margin
			*/
			mr: [{ mr: scaleMargin() }],
			/**
			* Margin Bottom
			* @see https://tailwindcss.com/docs/margin
			*/
			mb: [{ mb: scaleMargin() }],
			/**
			* Margin Left
			* @see https://tailwindcss.com/docs/margin
			*/
			ml: [{ ml: scaleMargin() }],
			/**
			* Space Between X
			* @see https://tailwindcss.com/docs/margin#adding-space-between-children
			*/
			"space-x": [{ "space-x": scaleUnambiguousSpacing() }],
			/**
			* Space Between X Reverse
			* @see https://tailwindcss.com/docs/margin#adding-space-between-children
			*/
			"space-x-reverse": ["space-x-reverse"],
			/**
			* Space Between Y
			* @see https://tailwindcss.com/docs/margin#adding-space-between-children
			*/
			"space-y": [{ "space-y": scaleUnambiguousSpacing() }],
			/**
			* Space Between Y Reverse
			* @see https://tailwindcss.com/docs/margin#adding-space-between-children
			*/
			"space-y-reverse": ["space-y-reverse"],
			/**
			* Size
			* @see https://tailwindcss.com/docs/width#setting-both-width-and-height
			*/
			size: [{ size: scaleSizing() }],
			/**
			* Inline Size
			* @see https://tailwindcss.com/docs/width
			*/
			"inline-size": [{ inline: ["auto", ...scaleSizingInline()] }],
			/**
			* Min-Inline Size
			* @see https://tailwindcss.com/docs/min-width
			*/
			"min-inline-size": [{ "min-inline": ["auto", ...scaleSizingInline()] }],
			/**
			* Max-Inline Size
			* @see https://tailwindcss.com/docs/max-width
			*/
			"max-inline-size": [{ "max-inline": ["none", ...scaleSizingInline()] }],
			/**
			* Block Size
			* @see https://tailwindcss.com/docs/height
			*/
			"block-size": [{ block: ["auto", ...scaleSizingBlock()] }],
			/**
			* Min-Block Size
			* @see https://tailwindcss.com/docs/min-height
			*/
			"min-block-size": [{ "min-block": ["auto", ...scaleSizingBlock()] }],
			/**
			* Max-Block Size
			* @see https://tailwindcss.com/docs/max-height
			*/
			"max-block-size": [{ "max-block": ["none", ...scaleSizingBlock()] }],
			/**
			* Width
			* @see https://tailwindcss.com/docs/width
			*/
			w: [{ w: [
				themeContainer,
				"screen",
				...scaleSizing()
			] }],
			/**
			* Min-Width
			* @see https://tailwindcss.com/docs/min-width
			*/
			"min-w": [{ "min-w": [
				themeContainer,
				"screen",
				"none",
				...scaleSizing()
			] }],
			/**
			* Max-Width
			* @see https://tailwindcss.com/docs/max-width
			*/
			"max-w": [{ "max-w": [
				themeContainer,
				"screen",
				"none",
				"prose",
				{ screen: [themeBreakpoint] },
				...scaleSizing()
			] }],
			/**
			* Height
			* @see https://tailwindcss.com/docs/height
			*/
			h: [{ h: [
				"screen",
				"lh",
				...scaleSizing()
			] }],
			/**
			* Min-Height
			* @see https://tailwindcss.com/docs/min-height
			*/
			"min-h": [{ "min-h": [
				"screen",
				"lh",
				"none",
				...scaleSizing()
			] }],
			/**
			* Max-Height
			* @see https://tailwindcss.com/docs/max-height
			*/
			"max-h": [{ "max-h": [
				"screen",
				"lh",
				...scaleSizing()
			] }],
			/**
			* Font Size
			* @see https://tailwindcss.com/docs/font-size
			*/
			"font-size": [{ text: [
				"base",
				themeText,
				isArbitraryVariableLength,
				isArbitraryLength
			] }],
			/**
			* Font Smoothing
			* @see https://tailwindcss.com/docs/font-smoothing
			*/
			"font-smoothing": ["antialiased", "subpixel-antialiased"],
			/**
			* Font Style
			* @see https://tailwindcss.com/docs/font-style
			*/
			"font-style": ["italic", "not-italic"],
			/**
			* Font Weight
			* @see https://tailwindcss.com/docs/font-weight
			*/
			"font-weight": [{ font: [
				themeFontWeight,
				isArbitraryVariableWeight,
				isArbitraryWeight
			] }],
			/**
			* Font Stretch
			* @see https://tailwindcss.com/docs/font-stretch
			*/
			"font-stretch": [{ "font-stretch": [
				"ultra-condensed",
				"extra-condensed",
				"condensed",
				"semi-condensed",
				"normal",
				"semi-expanded",
				"expanded",
				"extra-expanded",
				"ultra-expanded",
				isPercent,
				isArbitraryValue
			] }],
			/**
			* Font Family
			* @see https://tailwindcss.com/docs/font-family
			*/
			"font-family": [{ font: [
				isArbitraryVariableFamilyName,
				isArbitraryFamilyName,
				themeFont
			] }],
			/**
			* Font Feature Settings
			* @see https://tailwindcss.com/docs/font-feature-settings
			*/
			"font-features": [{ "font-features": [isArbitraryValue] }],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-normal": ["normal-nums"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-ordinal": ["ordinal"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-slashed-zero": ["slashed-zero"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-figure": ["lining-nums", "oldstyle-nums"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-spacing": ["proportional-nums", "tabular-nums"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
			/**
			* Letter Spacing
			* @see https://tailwindcss.com/docs/letter-spacing
			*/
			tracking: [{ tracking: [
				themeTracking,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Line Clamp
			* @see https://tailwindcss.com/docs/line-clamp
			*/
			"line-clamp": [{ "line-clamp": [
				isNumber,
				"none",
				isArbitraryVariable,
				isArbitraryNumber
			] }],
			/**
			* Line Height
			* @see https://tailwindcss.com/docs/line-height
			*/
			leading: [{ leading: [themeLeading, ...scaleUnambiguousSpacing()] }],
			/**
			* List Style Image
			* @see https://tailwindcss.com/docs/list-style-image
			*/
			"list-image": [{ "list-image": [
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* List Style Position
			* @see https://tailwindcss.com/docs/list-style-position
			*/
			"list-style-position": [{ list: ["inside", "outside"] }],
			/**
			* List Style Type
			* @see https://tailwindcss.com/docs/list-style-type
			*/
			"list-style-type": [{ list: [
				"disc",
				"decimal",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Text Alignment
			* @see https://tailwindcss.com/docs/text-align
			*/
			"text-alignment": [{ text: [
				"left",
				"center",
				"right",
				"justify",
				"start",
				"end"
			] }],
			/**
			* Placeholder Color
			* @deprecated since Tailwind CSS v3.0.0
			* @see https://v3.tailwindcss.com/docs/placeholder-color
			*/
			"placeholder-color": [{ placeholder: scaleColor() }],
			/**
			* Text Color
			* @see https://tailwindcss.com/docs/text-color
			*/
			"text-color": [{ text: scaleColor() }],
			/**
			* Text Decoration
			* @see https://tailwindcss.com/docs/text-decoration
			*/
			"text-decoration": [
				"underline",
				"overline",
				"line-through",
				"no-underline"
			],
			/**
			* Text Decoration Style
			* @see https://tailwindcss.com/docs/text-decoration-style
			*/
			"text-decoration-style": [{ decoration: [...scaleLineStyle(), "wavy"] }],
			/**
			* Text Decoration Thickness
			* @see https://tailwindcss.com/docs/text-decoration-thickness
			*/
			"text-decoration-thickness": [{ decoration: [
				isNumber,
				"from-font",
				"auto",
				isArbitraryVariable,
				isArbitraryLength
			] }],
			/**
			* Text Decoration Color
			* @see https://tailwindcss.com/docs/text-decoration-color
			*/
			"text-decoration-color": [{ decoration: scaleColor() }],
			/**
			* Text Underline Offset
			* @see https://tailwindcss.com/docs/text-underline-offset
			*/
			"underline-offset": [{ "underline-offset": [
				isNumber,
				"auto",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Text Transform
			* @see https://tailwindcss.com/docs/text-transform
			*/
			"text-transform": [
				"uppercase",
				"lowercase",
				"capitalize",
				"normal-case"
			],
			/**
			* Text Overflow
			* @see https://tailwindcss.com/docs/text-overflow
			*/
			"text-overflow": [
				"truncate",
				"text-ellipsis",
				"text-clip"
			],
			/**
			* Text Wrap
			* @see https://tailwindcss.com/docs/text-wrap
			*/
			"text-wrap": [{ text: [
				"wrap",
				"nowrap",
				"balance",
				"pretty"
			] }],
			/**
			* Text Indent
			* @see https://tailwindcss.com/docs/text-indent
			*/
			indent: [{ indent: scaleUnambiguousSpacing() }],
			/**
			* Tab Size
			* @see https://tailwindcss.com/docs/tab-size
			*/
			"tab-size": [{ tab: [
				isInteger,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Vertical Alignment
			* @see https://tailwindcss.com/docs/vertical-align
			*/
			"vertical-align": [{ align: [
				"baseline",
				"top",
				"middle",
				"bottom",
				"text-top",
				"text-bottom",
				"sub",
				"super",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Whitespace
			* @see https://tailwindcss.com/docs/whitespace
			*/
			whitespace: [{ whitespace: [
				"normal",
				"nowrap",
				"pre",
				"pre-line",
				"pre-wrap",
				"break-spaces"
			] }],
			/**
			* Word Break
			* @see https://tailwindcss.com/docs/word-break
			*/
			break: [{ break: [
				"normal",
				"words",
				"all",
				"keep"
			] }],
			/**
			* Overflow Wrap
			* @see https://tailwindcss.com/docs/overflow-wrap
			*/
			wrap: [{ wrap: [
				"break-word",
				"anywhere",
				"normal"
			] }],
			/**
			* Hyphens
			* @see https://tailwindcss.com/docs/hyphens
			*/
			hyphens: [{ hyphens: [
				"none",
				"manual",
				"auto"
			] }],
			/**
			* Content
			* @see https://tailwindcss.com/docs/content
			*/
			content: [{ content: [
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Background Attachment
			* @see https://tailwindcss.com/docs/background-attachment
			*/
			"bg-attachment": [{ bg: [
				"fixed",
				"local",
				"scroll"
			] }],
			/**
			* Background Clip
			* @see https://tailwindcss.com/docs/background-clip
			*/
			"bg-clip": [{ "bg-clip": [
				"border",
				"padding",
				"content",
				"text"
			] }],
			/**
			* Background Origin
			* @see https://tailwindcss.com/docs/background-origin
			*/
			"bg-origin": [{ "bg-origin": [
				"border",
				"padding",
				"content"
			] }],
			/**
			* Background Position
			* @see https://tailwindcss.com/docs/background-position
			*/
			"bg-position": [{ bg: scaleBgPosition() }],
			/**
			* Background Repeat
			* @see https://tailwindcss.com/docs/background-repeat
			*/
			"bg-repeat": [{ bg: scaleBgRepeat() }],
			/**
			* Background Size
			* @see https://tailwindcss.com/docs/background-size
			*/
			"bg-size": [{ bg: scaleBgSize() }],
			/**
			* Background Image
			* @see https://tailwindcss.com/docs/background-image
			*/
			"bg-image": [{ bg: [
				"none",
				{
					linear: [
						{ to: [
							"t",
							"tr",
							"r",
							"br",
							"b",
							"bl",
							"l",
							"tl"
						] },
						isInteger,
						isArbitraryVariable,
						isArbitraryValue
					],
					radial: [
						"",
						isArbitraryVariable,
						isArbitraryValue
					],
					conic: [
						isInteger,
						isArbitraryVariable,
						isArbitraryValue
					]
				},
				isArbitraryVariableImage,
				isArbitraryImage
			] }],
			/**
			* Background Color
			* @see https://tailwindcss.com/docs/background-color
			*/
			"bg-color": [{ bg: scaleColor() }],
			/**
			* Gradient Color Stops From Position
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-from-pos": [{ from: scaleGradientStopPosition() }],
			/**
			* Gradient Color Stops Via Position
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-via-pos": [{ via: scaleGradientStopPosition() }],
			/**
			* Gradient Color Stops To Position
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-to-pos": [{ to: scaleGradientStopPosition() }],
			/**
			* Gradient Color Stops From
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-from": [{ from: scaleColor() }],
			/**
			* Gradient Color Stops Via
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-via": [{ via: scaleColor() }],
			/**
			* Gradient Color Stops To
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-to": [{ to: scaleColor() }],
			/**
			* Border Radius
			* @see https://tailwindcss.com/docs/border-radius
			*/
			rounded: [{ rounded: scaleRadius() }],
			/**
			* Border Radius Start
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-s": [{ "rounded-s": scaleRadius() }],
			/**
			* Border Radius End
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-e": [{ "rounded-e": scaleRadius() }],
			/**
			* Border Radius Top
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-t": [{ "rounded-t": scaleRadius() }],
			/**
			* Border Radius Right
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-r": [{ "rounded-r": scaleRadius() }],
			/**
			* Border Radius Bottom
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-b": [{ "rounded-b": scaleRadius() }],
			/**
			* Border Radius Left
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-l": [{ "rounded-l": scaleRadius() }],
			/**
			* Border Radius Start Start
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-ss": [{ "rounded-ss": scaleRadius() }],
			/**
			* Border Radius Start End
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-se": [{ "rounded-se": scaleRadius() }],
			/**
			* Border Radius End End
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-ee": [{ "rounded-ee": scaleRadius() }],
			/**
			* Border Radius End Start
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-es": [{ "rounded-es": scaleRadius() }],
			/**
			* Border Radius Top Left
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-tl": [{ "rounded-tl": scaleRadius() }],
			/**
			* Border Radius Top Right
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-tr": [{ "rounded-tr": scaleRadius() }],
			/**
			* Border Radius Bottom Right
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-br": [{ "rounded-br": scaleRadius() }],
			/**
			* Border Radius Bottom Left
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-bl": [{ "rounded-bl": scaleRadius() }],
			/**
			* Border Width
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w": [{ border: scaleBorderWidth() }],
			/**
			* Border Width Inline
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-x": [{ "border-x": scaleBorderWidth() }],
			/**
			* Border Width Block
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-y": [{ "border-y": scaleBorderWidth() }],
			/**
			* Border Width Inline Start
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-s": [{ "border-s": scaleBorderWidth() }],
			/**
			* Border Width Inline End
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-e": [{ "border-e": scaleBorderWidth() }],
			/**
			* Border Width Block Start
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-bs": [{ "border-bs": scaleBorderWidth() }],
			/**
			* Border Width Block End
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-be": [{ "border-be": scaleBorderWidth() }],
			/**
			* Border Width Top
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-t": [{ "border-t": scaleBorderWidth() }],
			/**
			* Border Width Right
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-r": [{ "border-r": scaleBorderWidth() }],
			/**
			* Border Width Bottom
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-b": [{ "border-b": scaleBorderWidth() }],
			/**
			* Border Width Left
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-l": [{ "border-l": scaleBorderWidth() }],
			/**
			* Divide Width X
			* @see https://tailwindcss.com/docs/border-width#between-children
			*/
			"divide-x": [{ "divide-x": scaleBorderWidth() }],
			/**
			* Divide Width X Reverse
			* @see https://tailwindcss.com/docs/border-width#between-children
			*/
			"divide-x-reverse": ["divide-x-reverse"],
			/**
			* Divide Width Y
			* @see https://tailwindcss.com/docs/border-width#between-children
			*/
			"divide-y": [{ "divide-y": scaleBorderWidth() }],
			/**
			* Divide Width Y Reverse
			* @see https://tailwindcss.com/docs/border-width#between-children
			*/
			"divide-y-reverse": ["divide-y-reverse"],
			/**
			* Border Style
			* @see https://tailwindcss.com/docs/border-style
			*/
			"border-style": [{ border: [
				...scaleLineStyle(),
				"hidden",
				"none"
			] }],
			/**
			* Divide Style
			* @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
			*/
			"divide-style": [{ divide: [
				...scaleLineStyle(),
				"hidden",
				"none"
			] }],
			/**
			* Border Color
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color": [{ border: scaleColor() }],
			/**
			* Border Color Inline
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-x": [{ "border-x": scaleColor() }],
			/**
			* Border Color Block
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-y": [{ "border-y": scaleColor() }],
			/**
			* Border Color Inline Start
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-s": [{ "border-s": scaleColor() }],
			/**
			* Border Color Inline End
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-e": [{ "border-e": scaleColor() }],
			/**
			* Border Color Block Start
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-bs": [{ "border-bs": scaleColor() }],
			/**
			* Border Color Block End
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-be": [{ "border-be": scaleColor() }],
			/**
			* Border Color Top
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-t": [{ "border-t": scaleColor() }],
			/**
			* Border Color Right
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-r": [{ "border-r": scaleColor() }],
			/**
			* Border Color Bottom
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-b": [{ "border-b": scaleColor() }],
			/**
			* Border Color Left
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-l": [{ "border-l": scaleColor() }],
			/**
			* Divide Color
			* @see https://tailwindcss.com/docs/divide-color
			*/
			"divide-color": [{ divide: scaleColor() }],
			/**
			* Outline Style
			* @see https://tailwindcss.com/docs/outline-style
			*/
			"outline-style": [{ outline: [
				...scaleLineStyle(),
				"none",
				"hidden"
			] }],
			/**
			* Outline Offset
			* @see https://tailwindcss.com/docs/outline-offset
			*/
			"outline-offset": [{ "outline-offset": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Outline Width
			* @see https://tailwindcss.com/docs/outline-width
			*/
			"outline-w": [{ outline: [
				"",
				isNumber,
				isArbitraryVariableLength,
				isArbitraryLength
			] }],
			/**
			* Outline Color
			* @see https://tailwindcss.com/docs/outline-color
			*/
			"outline-color": [{ outline: scaleColor() }],
			/**
			* Box Shadow
			* @see https://tailwindcss.com/docs/box-shadow
			*/
			shadow: [{ shadow: [
				"",
				"none",
				themeShadow,
				isArbitraryVariableShadow,
				isArbitraryShadow
			] }],
			/**
			* Box Shadow Color
			* @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
			*/
			"shadow-color": [{ shadow: scaleColor() }],
			/**
			* Inset Box Shadow
			* @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
			*/
			"inset-shadow": [{ "inset-shadow": [
				"none",
				themeInsetShadow,
				isArbitraryVariableShadow,
				isArbitraryShadow
			] }],
			/**
			* Inset Box Shadow Color
			* @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
			*/
			"inset-shadow-color": [{ "inset-shadow": scaleColor() }],
			/**
			* Ring Width
			* @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
			*/
			"ring-w": [{ ring: scaleBorderWidth() }],
			/**
			* Ring Width Inset
			* @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
			* @deprecated since Tailwind CSS v4.0.0
			* @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
			*/
			"ring-w-inset": ["ring-inset"],
			/**
			* Ring Color
			* @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
			*/
			"ring-color": [{ ring: scaleColor() }],
			/**
			* Ring Offset Width
			* @see https://v3.tailwindcss.com/docs/ring-offset-width
			* @deprecated since Tailwind CSS v4.0.0
			* @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
			*/
			"ring-offset-w": [{ "ring-offset": [isNumber, isArbitraryLength] }],
			/**
			* Ring Offset Color
			* @see https://v3.tailwindcss.com/docs/ring-offset-color
			* @deprecated since Tailwind CSS v4.0.0
			* @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
			*/
			"ring-offset-color": [{ "ring-offset": scaleColor() }],
			/**
			* Inset Ring Width
			* @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
			*/
			"inset-ring-w": [{ "inset-ring": scaleBorderWidth() }],
			/**
			* Inset Ring Color
			* @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
			*/
			"inset-ring-color": [{ "inset-ring": scaleColor() }],
			/**
			* Text Shadow
			* @see https://tailwindcss.com/docs/text-shadow
			*/
			"text-shadow": [{ "text-shadow": [
				"none",
				themeTextShadow,
				isArbitraryVariableShadow,
				isArbitraryShadow
			] }],
			/**
			* Text Shadow Color
			* @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
			*/
			"text-shadow-color": [{ "text-shadow": scaleColor() }],
			/**
			* Opacity
			* @see https://tailwindcss.com/docs/opacity
			*/
			opacity: [{ opacity: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Mix Blend Mode
			* @see https://tailwindcss.com/docs/mix-blend-mode
			*/
			"mix-blend": [{ "mix-blend": [
				...scaleBlendMode(),
				"plus-darker",
				"plus-lighter"
			] }],
			/**
			* Background Blend Mode
			* @see https://tailwindcss.com/docs/background-blend-mode
			*/
			"bg-blend": [{ "bg-blend": scaleBlendMode() }],
			/**
			* Mask Clip
			* @see https://tailwindcss.com/docs/mask-clip
			*/
			"mask-clip": [{ "mask-clip": [
				"border",
				"padding",
				"content",
				"fill",
				"stroke",
				"view"
			] }, "mask-no-clip"],
			/**
			* Mask Composite
			* @see https://tailwindcss.com/docs/mask-composite
			*/
			"mask-composite": [{ mask: [
				"add",
				"subtract",
				"intersect",
				"exclude"
			] }],
			/**
			* Mask Image
			* @see https://tailwindcss.com/docs/mask-image
			*/
			"mask-image-linear-pos": [{ "mask-linear": [isNumber] }],
			"mask-image-linear-from-pos": [{ "mask-linear-from": scaleMaskImagePosition() }],
			"mask-image-linear-to-pos": [{ "mask-linear-to": scaleMaskImagePosition() }],
			"mask-image-linear-from-color": [{ "mask-linear-from": scaleColor() }],
			"mask-image-linear-to-color": [{ "mask-linear-to": scaleColor() }],
			"mask-image-t-from-pos": [{ "mask-t-from": scaleMaskImagePosition() }],
			"mask-image-t-to-pos": [{ "mask-t-to": scaleMaskImagePosition() }],
			"mask-image-t-from-color": [{ "mask-t-from": scaleColor() }],
			"mask-image-t-to-color": [{ "mask-t-to": scaleColor() }],
			"mask-image-r-from-pos": [{ "mask-r-from": scaleMaskImagePosition() }],
			"mask-image-r-to-pos": [{ "mask-r-to": scaleMaskImagePosition() }],
			"mask-image-r-from-color": [{ "mask-r-from": scaleColor() }],
			"mask-image-r-to-color": [{ "mask-r-to": scaleColor() }],
			"mask-image-b-from-pos": [{ "mask-b-from": scaleMaskImagePosition() }],
			"mask-image-b-to-pos": [{ "mask-b-to": scaleMaskImagePosition() }],
			"mask-image-b-from-color": [{ "mask-b-from": scaleColor() }],
			"mask-image-b-to-color": [{ "mask-b-to": scaleColor() }],
			"mask-image-l-from-pos": [{ "mask-l-from": scaleMaskImagePosition() }],
			"mask-image-l-to-pos": [{ "mask-l-to": scaleMaskImagePosition() }],
			"mask-image-l-from-color": [{ "mask-l-from": scaleColor() }],
			"mask-image-l-to-color": [{ "mask-l-to": scaleColor() }],
			"mask-image-x-from-pos": [{ "mask-x-from": scaleMaskImagePosition() }],
			"mask-image-x-to-pos": [{ "mask-x-to": scaleMaskImagePosition() }],
			"mask-image-x-from-color": [{ "mask-x-from": scaleColor() }],
			"mask-image-x-to-color": [{ "mask-x-to": scaleColor() }],
			"mask-image-y-from-pos": [{ "mask-y-from": scaleMaskImagePosition() }],
			"mask-image-y-to-pos": [{ "mask-y-to": scaleMaskImagePosition() }],
			"mask-image-y-from-color": [{ "mask-y-from": scaleColor() }],
			"mask-image-y-to-color": [{ "mask-y-to": scaleColor() }],
			"mask-image-radial": [{ "mask-radial": [isArbitraryVariable, isArbitraryValue] }],
			"mask-image-radial-from-pos": [{ "mask-radial-from": scaleMaskImagePosition() }],
			"mask-image-radial-to-pos": [{ "mask-radial-to": scaleMaskImagePosition() }],
			"mask-image-radial-from-color": [{ "mask-radial-from": scaleColor() }],
			"mask-image-radial-to-color": [{ "mask-radial-to": scaleColor() }],
			"mask-image-radial-shape": [{ "mask-radial": ["circle", "ellipse"] }],
			"mask-image-radial-size": [{ "mask-radial": [{
				closest: ["side", "corner"],
				farthest: ["side", "corner"]
			}] }],
			"mask-image-radial-pos": [{ "mask-radial-at": scalePosition() }],
			"mask-image-conic-pos": [{ "mask-conic": [isNumber] }],
			"mask-image-conic-from-pos": [{ "mask-conic-from": scaleMaskImagePosition() }],
			"mask-image-conic-to-pos": [{ "mask-conic-to": scaleMaskImagePosition() }],
			"mask-image-conic-from-color": [{ "mask-conic-from": scaleColor() }],
			"mask-image-conic-to-color": [{ "mask-conic-to": scaleColor() }],
			/**
			* Mask Mode
			* @see https://tailwindcss.com/docs/mask-mode
			*/
			"mask-mode": [{ mask: [
				"alpha",
				"luminance",
				"match"
			] }],
			/**
			* Mask Origin
			* @see https://tailwindcss.com/docs/mask-origin
			*/
			"mask-origin": [{ "mask-origin": [
				"border",
				"padding",
				"content",
				"fill",
				"stroke",
				"view"
			] }],
			/**
			* Mask Position
			* @see https://tailwindcss.com/docs/mask-position
			*/
			"mask-position": [{ mask: scaleBgPosition() }],
			/**
			* Mask Repeat
			* @see https://tailwindcss.com/docs/mask-repeat
			*/
			"mask-repeat": [{ mask: scaleBgRepeat() }],
			/**
			* Mask Size
			* @see https://tailwindcss.com/docs/mask-size
			*/
			"mask-size": [{ mask: scaleBgSize() }],
			/**
			* Mask Type
			* @see https://tailwindcss.com/docs/mask-type
			*/
			"mask-type": [{ "mask-type": ["alpha", "luminance"] }],
			/**
			* Mask Image
			* @see https://tailwindcss.com/docs/mask-image
			*/
			"mask-image": [{ mask: [
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Filter
			* @see https://tailwindcss.com/docs/filter
			*/
			filter: [{ filter: [
				"",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Blur
			* @see https://tailwindcss.com/docs/blur
			*/
			blur: [{ blur: scaleBlur() }],
			/**
			* Brightness
			* @see https://tailwindcss.com/docs/brightness
			*/
			brightness: [{ brightness: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Contrast
			* @see https://tailwindcss.com/docs/contrast
			*/
			contrast: [{ contrast: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Drop Shadow
			* @see https://tailwindcss.com/docs/drop-shadow
			*/
			"drop-shadow": [{ "drop-shadow": [
				"",
				"none",
				themeDropShadow,
				isArbitraryVariableShadow,
				isArbitraryShadow
			] }],
			/**
			* Drop Shadow Color
			* @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
			*/
			"drop-shadow-color": [{ "drop-shadow": scaleColor() }],
			/**
			* Grayscale
			* @see https://tailwindcss.com/docs/grayscale
			*/
			grayscale: [{ grayscale: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Hue Rotate
			* @see https://tailwindcss.com/docs/hue-rotate
			*/
			"hue-rotate": [{ "hue-rotate": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Invert
			* @see https://tailwindcss.com/docs/invert
			*/
			invert: [{ invert: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Saturate
			* @see https://tailwindcss.com/docs/saturate
			*/
			saturate: [{ saturate: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Sepia
			* @see https://tailwindcss.com/docs/sepia
			*/
			sepia: [{ sepia: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Filter
			* @see https://tailwindcss.com/docs/backdrop-filter
			*/
			"backdrop-filter": [{ "backdrop-filter": [
				"",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Blur
			* @see https://tailwindcss.com/docs/backdrop-blur
			*/
			"backdrop-blur": [{ "backdrop-blur": scaleBlur() }],
			/**
			* Backdrop Brightness
			* @see https://tailwindcss.com/docs/backdrop-brightness
			*/
			"backdrop-brightness": [{ "backdrop-brightness": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Contrast
			* @see https://tailwindcss.com/docs/backdrop-contrast
			*/
			"backdrop-contrast": [{ "backdrop-contrast": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Grayscale
			* @see https://tailwindcss.com/docs/backdrop-grayscale
			*/
			"backdrop-grayscale": [{ "backdrop-grayscale": [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Hue Rotate
			* @see https://tailwindcss.com/docs/backdrop-hue-rotate
			*/
			"backdrop-hue-rotate": [{ "backdrop-hue-rotate": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Invert
			* @see https://tailwindcss.com/docs/backdrop-invert
			*/
			"backdrop-invert": [{ "backdrop-invert": [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Opacity
			* @see https://tailwindcss.com/docs/backdrop-opacity
			*/
			"backdrop-opacity": [{ "backdrop-opacity": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Saturate
			* @see https://tailwindcss.com/docs/backdrop-saturate
			*/
			"backdrop-saturate": [{ "backdrop-saturate": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Sepia
			* @see https://tailwindcss.com/docs/backdrop-sepia
			*/
			"backdrop-sepia": [{ "backdrop-sepia": [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Border Collapse
			* @see https://tailwindcss.com/docs/border-collapse
			*/
			"border-collapse": [{ border: ["collapse", "separate"] }],
			/**
			* Border Spacing
			* @see https://tailwindcss.com/docs/border-spacing
			*/
			"border-spacing": [{ "border-spacing": scaleUnambiguousSpacing() }],
			/**
			* Border Spacing X
			* @see https://tailwindcss.com/docs/border-spacing
			*/
			"border-spacing-x": [{ "border-spacing-x": scaleUnambiguousSpacing() }],
			/**
			* Border Spacing Y
			* @see https://tailwindcss.com/docs/border-spacing
			*/
			"border-spacing-y": [{ "border-spacing-y": scaleUnambiguousSpacing() }],
			/**
			* Table Layout
			* @see https://tailwindcss.com/docs/table-layout
			*/
			"table-layout": [{ table: ["auto", "fixed"] }],
			/**
			* Caption Side
			* @see https://tailwindcss.com/docs/caption-side
			*/
			caption: [{ caption: ["top", "bottom"] }],
			/**
			* Transition Property
			* @see https://tailwindcss.com/docs/transition-property
			*/
			transition: [{ transition: [
				"",
				"all",
				"colors",
				"opacity",
				"shadow",
				"transform",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Transition Behavior
			* @see https://tailwindcss.com/docs/transition-behavior
			*/
			"transition-behavior": [{ transition: ["normal", "discrete"] }],
			/**
			* Transition Duration
			* @see https://tailwindcss.com/docs/transition-duration
			*/
			duration: [{ duration: [
				isNumber,
				"initial",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Transition Timing Function
			* @see https://tailwindcss.com/docs/transition-timing-function
			*/
			ease: [{ ease: [
				"linear",
				"initial",
				themeEase,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Transition Delay
			* @see https://tailwindcss.com/docs/transition-delay
			*/
			delay: [{ delay: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Animation
			* @see https://tailwindcss.com/docs/animation
			*/
			animate: [{ animate: [
				"none",
				themeAnimate,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backface Visibility
			* @see https://tailwindcss.com/docs/backface-visibility
			*/
			backface: [{ backface: ["hidden", "visible"] }],
			/**
			* Perspective
			* @see https://tailwindcss.com/docs/perspective
			*/
			perspective: [{ perspective: [
				themePerspective,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Perspective Origin
			* @see https://tailwindcss.com/docs/perspective-origin
			*/
			"perspective-origin": [{ "perspective-origin": scalePositionWithArbitrary() }],
			/**
			* Rotate
			* @see https://tailwindcss.com/docs/rotate
			*/
			rotate: [{ rotate: scaleRotate() }],
			/**
			* Rotate X
			* @see https://tailwindcss.com/docs/rotate
			*/
			"rotate-x": [{ "rotate-x": scaleRotate() }],
			/**
			* Rotate Y
			* @see https://tailwindcss.com/docs/rotate
			*/
			"rotate-y": [{ "rotate-y": scaleRotate() }],
			/**
			* Rotate Z
			* @see https://tailwindcss.com/docs/rotate
			*/
			"rotate-z": [{ "rotate-z": scaleRotate() }],
			/**
			* Scale
			* @see https://tailwindcss.com/docs/scale
			*/
			scale: [{ scale: scaleScale() }],
			/**
			* Scale X
			* @see https://tailwindcss.com/docs/scale
			*/
			"scale-x": [{ "scale-x": scaleScale() }],
			/**
			* Scale Y
			* @see https://tailwindcss.com/docs/scale
			*/
			"scale-y": [{ "scale-y": scaleScale() }],
			/**
			* Scale Z
			* @see https://tailwindcss.com/docs/scale
			*/
			"scale-z": [{ "scale-z": scaleScale() }],
			/**
			* Scale 3D
			* @see https://tailwindcss.com/docs/scale
			*/
			"scale-3d": ["scale-3d"],
			/**
			* Skew
			* @see https://tailwindcss.com/docs/skew
			*/
			skew: [{ skew: scaleSkew() }],
			/**
			* Skew X
			* @see https://tailwindcss.com/docs/skew
			*/
			"skew-x": [{ "skew-x": scaleSkew() }],
			/**
			* Skew Y
			* @see https://tailwindcss.com/docs/skew
			*/
			"skew-y": [{ "skew-y": scaleSkew() }],
			/**
			* Transform
			* @see https://tailwindcss.com/docs/transform
			*/
			transform: [{ transform: [
				isArbitraryVariable,
				isArbitraryValue,
				"",
				"none",
				"gpu",
				"cpu"
			] }],
			/**
			* Transform Origin
			* @see https://tailwindcss.com/docs/transform-origin
			*/
			"transform-origin": [{ origin: scalePositionWithArbitrary() }],
			/**
			* Transform Style
			* @see https://tailwindcss.com/docs/transform-style
			*/
			"transform-style": [{ transform: ["3d", "flat"] }],
			/**
			* Translate
			* @see https://tailwindcss.com/docs/translate
			*/
			translate: [{ translate: scaleTranslate() }],
			/**
			* Translate X
			* @see https://tailwindcss.com/docs/translate
			*/
			"translate-x": [{ "translate-x": scaleTranslate() }],
			/**
			* Translate Y
			* @see https://tailwindcss.com/docs/translate
			*/
			"translate-y": [{ "translate-y": scaleTranslate() }],
			/**
			* Translate Z
			* @see https://tailwindcss.com/docs/translate
			*/
			"translate-z": [{ "translate-z": scaleTranslate() }],
			/**
			* Translate None
			* @see https://tailwindcss.com/docs/translate
			*/
			"translate-none": ["translate-none"],
			/**
			* Zoom
			* @see https://tailwindcss.com/docs/zoom
			*/
			zoom: [{ zoom: [
				isInteger,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Accent Color
			* @see https://tailwindcss.com/docs/accent-color
			*/
			accent: [{ accent: scaleColor() }],
			/**
			* Appearance
			* @see https://tailwindcss.com/docs/appearance
			*/
			appearance: [{ appearance: ["none", "auto"] }],
			/**
			* Caret Color
			* @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
			*/
			"caret-color": [{ caret: scaleColor() }],
			/**
			* Color Scheme
			* @see https://tailwindcss.com/docs/color-scheme
			*/
			"color-scheme": [{ scheme: [
				"normal",
				"dark",
				"light",
				"light-dark",
				"only-dark",
				"only-light"
			] }],
			/**
			* Cursor
			* @see https://tailwindcss.com/docs/cursor
			*/
			cursor: [{ cursor: [
				"auto",
				"default",
				"pointer",
				"wait",
				"text",
				"move",
				"help",
				"not-allowed",
				"none",
				"context-menu",
				"progress",
				"cell",
				"crosshair",
				"vertical-text",
				"alias",
				"copy",
				"no-drop",
				"grab",
				"grabbing",
				"all-scroll",
				"col-resize",
				"row-resize",
				"n-resize",
				"e-resize",
				"s-resize",
				"w-resize",
				"ne-resize",
				"nw-resize",
				"se-resize",
				"sw-resize",
				"ew-resize",
				"ns-resize",
				"nesw-resize",
				"nwse-resize",
				"zoom-in",
				"zoom-out",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Field Sizing
			* @see https://tailwindcss.com/docs/field-sizing
			*/
			"field-sizing": [{ "field-sizing": ["fixed", "content"] }],
			/**
			* Pointer Events
			* @see https://tailwindcss.com/docs/pointer-events
			*/
			"pointer-events": [{ "pointer-events": ["auto", "none"] }],
			/**
			* Resize
			* @see https://tailwindcss.com/docs/resize
			*/
			resize: [{ resize: [
				"none",
				"",
				"y",
				"x"
			] }],
			/**
			* Scroll Behavior
			* @see https://tailwindcss.com/docs/scroll-behavior
			*/
			"scroll-behavior": [{ scroll: ["auto", "smooth"] }],
			/**
			* Scrollbar Thumb Color
			* @see https://tailwindcss.com/docs/scrollbar-color
			*/
			"scrollbar-thumb-color": [{ "scrollbar-thumb": scaleColor() }],
			/**
			* Scrollbar Track Color
			* @see https://tailwindcss.com/docs/scrollbar-color
			*/
			"scrollbar-track-color": [{ "scrollbar-track": scaleColor() }],
			/**
			* Scrollbar Gutter
			* @see https://tailwindcss.com/docs/scrollbar-gutter
			*/
			"scrollbar-gutter": [{ "scrollbar-gutter": [
				"auto",
				"stable",
				"both"
			] }],
			/**
			* Scrollbar Width
			* @see https://tailwindcss.com/docs/scrollbar-width
			*/
			"scrollbar-w": [{ scrollbar: [
				"auto",
				"thin",
				"none"
			] }],
			/**
			* Scroll Margin
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-m": [{ "scroll-m": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Inline
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mx": [{ "scroll-mx": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Block
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-my": [{ "scroll-my": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Inline Start
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-ms": [{ "scroll-ms": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Inline End
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-me": [{ "scroll-me": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Block Start
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mbs": [{ "scroll-mbs": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Block End
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mbe": [{ "scroll-mbe": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Top
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mt": [{ "scroll-mt": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Right
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mr": [{ "scroll-mr": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Bottom
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mb": [{ "scroll-mb": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Left
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-ml": [{ "scroll-ml": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-p": [{ "scroll-p": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Inline
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-px": [{ "scroll-px": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Block
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-py": [{ "scroll-py": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Inline Start
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-ps": [{ "scroll-ps": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Inline End
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pe": [{ "scroll-pe": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Block Start
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pbs": [{ "scroll-pbs": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Block End
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pbe": [{ "scroll-pbe": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Top
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pt": [{ "scroll-pt": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Right
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pr": [{ "scroll-pr": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Bottom
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pb": [{ "scroll-pb": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Left
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pl": [{ "scroll-pl": scaleUnambiguousSpacing() }],
			/**
			* Scroll Snap Align
			* @see https://tailwindcss.com/docs/scroll-snap-align
			*/
			"snap-align": [{ snap: [
				"start",
				"end",
				"center",
				"align-none"
			] }],
			/**
			* Scroll Snap Stop
			* @see https://tailwindcss.com/docs/scroll-snap-stop
			*/
			"snap-stop": [{ snap: ["normal", "always"] }],
			/**
			* Scroll Snap Type
			* @see https://tailwindcss.com/docs/scroll-snap-type
			*/
			"snap-type": [{ snap: [
				"none",
				"x",
				"y",
				"both"
			] }],
			/**
			* Scroll Snap Type Strictness
			* @see https://tailwindcss.com/docs/scroll-snap-type
			*/
			"snap-strictness": [{ snap: ["mandatory", "proximity"] }],
			/**
			* Touch Action
			* @see https://tailwindcss.com/docs/touch-action
			*/
			touch: [{ touch: [
				"auto",
				"none",
				"manipulation"
			] }],
			/**
			* Touch Action X
			* @see https://tailwindcss.com/docs/touch-action
			*/
			"touch-x": [{ "touch-pan": [
				"x",
				"left",
				"right"
			] }],
			/**
			* Touch Action Y
			* @see https://tailwindcss.com/docs/touch-action
			*/
			"touch-y": [{ "touch-pan": [
				"y",
				"up",
				"down"
			] }],
			/**
			* Touch Action Pinch Zoom
			* @see https://tailwindcss.com/docs/touch-action
			*/
			"touch-pz": ["touch-pinch-zoom"],
			/**
			* User Select
			* @see https://tailwindcss.com/docs/user-select
			*/
			select: [{ select: [
				"none",
				"text",
				"all",
				"auto"
			] }],
			/**
			* Will Change
			* @see https://tailwindcss.com/docs/will-change
			*/
			"will-change": [{ "will-change": [
				"auto",
				"scroll",
				"contents",
				"transform",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Fill
			* @see https://tailwindcss.com/docs/fill
			*/
			fill: [{ fill: ["none", ...scaleColor()] }],
			/**
			* Stroke Width
			* @see https://tailwindcss.com/docs/stroke-width
			*/
			"stroke-w": [{ stroke: [
				isNumber,
				isArbitraryVariableLength,
				isArbitraryLength,
				isArbitraryNumber
			] }],
			/**
			* Stroke
			* @see https://tailwindcss.com/docs/stroke
			*/
			stroke: [{ stroke: ["none", ...scaleColor()] }],
			/**
			* Forced Color Adjust
			* @see https://tailwindcss.com/docs/forced-color-adjust
			*/
			"forced-color-adjust": [{ "forced-color-adjust": ["auto", "none"] }]
		},
		conflictingClassGroups: {
			"container-named": ["container-type"],
			overflow: ["overflow-x", "overflow-y"],
			overscroll: ["overscroll-x", "overscroll-y"],
			inset: [
				"inset-x",
				"inset-y",
				"inset-bs",
				"inset-be",
				"start",
				"end",
				"top",
				"right",
				"bottom",
				"left"
			],
			"inset-x": ["right", "left"],
			"inset-y": ["top", "bottom"],
			flex: [
				"basis",
				"grow",
				"shrink"
			],
			gap: ["gap-x", "gap-y"],
			p: [
				"px",
				"py",
				"ps",
				"pe",
				"pbs",
				"pbe",
				"pt",
				"pr",
				"pb",
				"pl"
			],
			px: ["pr", "pl"],
			py: ["pt", "pb"],
			m: [
				"mx",
				"my",
				"ms",
				"me",
				"mbs",
				"mbe",
				"mt",
				"mr",
				"mb",
				"ml"
			],
			mx: ["mr", "ml"],
			my: ["mt", "mb"],
			size: ["w", "h"],
			"font-size": ["leading"],
			"fvn-normal": [
				"fvn-ordinal",
				"fvn-slashed-zero",
				"fvn-figure",
				"fvn-spacing",
				"fvn-fraction"
			],
			"fvn-ordinal": ["fvn-normal"],
			"fvn-slashed-zero": ["fvn-normal"],
			"fvn-figure": ["fvn-normal"],
			"fvn-spacing": ["fvn-normal"],
			"fvn-fraction": ["fvn-normal"],
			"line-clamp": ["display", "overflow"],
			rounded: [
				"rounded-s",
				"rounded-e",
				"rounded-t",
				"rounded-r",
				"rounded-b",
				"rounded-l",
				"rounded-ss",
				"rounded-se",
				"rounded-ee",
				"rounded-es",
				"rounded-tl",
				"rounded-tr",
				"rounded-br",
				"rounded-bl"
			],
			"rounded-s": ["rounded-ss", "rounded-es"],
			"rounded-e": ["rounded-se", "rounded-ee"],
			"rounded-t": ["rounded-tl", "rounded-tr"],
			"rounded-r": ["rounded-tr", "rounded-br"],
			"rounded-b": ["rounded-br", "rounded-bl"],
			"rounded-l": ["rounded-tl", "rounded-bl"],
			"border-spacing": ["border-spacing-x", "border-spacing-y"],
			"border-w": [
				"border-w-x",
				"border-w-y",
				"border-w-s",
				"border-w-e",
				"border-w-bs",
				"border-w-be",
				"border-w-t",
				"border-w-r",
				"border-w-b",
				"border-w-l"
			],
			"border-w-x": ["border-w-r", "border-w-l"],
			"border-w-y": ["border-w-t", "border-w-b"],
			"border-color": [
				"border-color-x",
				"border-color-y",
				"border-color-s",
				"border-color-e",
				"border-color-bs",
				"border-color-be",
				"border-color-t",
				"border-color-r",
				"border-color-b",
				"border-color-l"
			],
			"border-color-x": ["border-color-r", "border-color-l"],
			"border-color-y": ["border-color-t", "border-color-b"],
			translate: [
				"translate-x",
				"translate-y",
				"translate-none"
			],
			"translate-none": [
				"translate",
				"translate-x",
				"translate-y",
				"translate-z"
			],
			"scroll-m": [
				"scroll-mx",
				"scroll-my",
				"scroll-ms",
				"scroll-me",
				"scroll-mbs",
				"scroll-mbe",
				"scroll-mt",
				"scroll-mr",
				"scroll-mb",
				"scroll-ml"
			],
			"scroll-mx": ["scroll-mr", "scroll-ml"],
			"scroll-my": ["scroll-mt", "scroll-mb"],
			"scroll-p": [
				"scroll-px",
				"scroll-py",
				"scroll-ps",
				"scroll-pe",
				"scroll-pbs",
				"scroll-pbe",
				"scroll-pt",
				"scroll-pr",
				"scroll-pb",
				"scroll-pl"
			],
			"scroll-px": ["scroll-pr", "scroll-pl"],
			"scroll-py": ["scroll-pt", "scroll-pb"],
			touch: [
				"touch-x",
				"touch-y",
				"touch-pz"
			],
			"touch-x": ["touch"],
			"touch-y": ["touch"],
			"touch-pz": ["touch"]
		},
		conflictingClassGroupModifiers: { "font-size": ["leading"] },
		postfixLookupClassGroups: ["container-type"],
		orderSensitiveModifiers: [
			"*",
			"**",
			"after",
			"backdrop",
			"before",
			"details-content",
			"file",
			"first-letter",
			"first-line",
			"marker",
			"placeholder",
			"selection"
		]
	};
};
/**
* @param baseConfig Config where other config will be merged into. This object will be mutated.
* @param configExtension Partial config to merge into the `baseConfig`.
*/
var mergeConfigs = (baseConfig, { cacheSize, prefix, experimentalParseClassName, extend = {}, override = {} }) => {
	overrideProperty(baseConfig, "cacheSize", cacheSize);
	overrideProperty(baseConfig, "prefix", prefix);
	overrideProperty(baseConfig, "experimentalParseClassName", experimentalParseClassName);
	overrideConfigProperties(baseConfig.theme, override.theme);
	overrideConfigProperties(baseConfig.classGroups, override.classGroups);
	overrideConfigProperties(baseConfig.conflictingClassGroups, override.conflictingClassGroups);
	overrideConfigProperties(baseConfig.conflictingClassGroupModifiers, override.conflictingClassGroupModifiers);
	overrideProperty(baseConfig, "postfixLookupClassGroups", override.postfixLookupClassGroups);
	overrideProperty(baseConfig, "orderSensitiveModifiers", override.orderSensitiveModifiers);
	mergeConfigProperties(baseConfig.theme, extend.theme);
	mergeConfigProperties(baseConfig.classGroups, extend.classGroups);
	mergeConfigProperties(baseConfig.conflictingClassGroups, extend.conflictingClassGroups);
	mergeConfigProperties(baseConfig.conflictingClassGroupModifiers, extend.conflictingClassGroupModifiers);
	mergeArrayProperties(baseConfig, extend, "postfixLookupClassGroups");
	mergeArrayProperties(baseConfig, extend, "orderSensitiveModifiers");
	return baseConfig;
};
var overrideProperty = (baseObject, overrideKey, overrideValue) => {
	if (overrideValue !== void 0) baseObject[overrideKey] = overrideValue;
};
var overrideConfigProperties = (baseObject, overrideObject) => {
	if (overrideObject) for (const key in overrideObject) overrideProperty(baseObject, key, overrideObject[key]);
};
var mergeConfigProperties = (baseObject, mergeObject) => {
	if (mergeObject) for (const key in mergeObject) mergeArrayProperties(baseObject, mergeObject, key);
};
var mergeArrayProperties = (baseObject, mergeObject, key) => {
	const mergeValue = mergeObject[key];
	if (mergeValue !== void 0) baseObject[key] = baseObject[key] ? baseObject[key].concat(mergeValue) : mergeValue;
};
var extendTailwindMerge = (configExtension, ...createConfig) => typeof configExtension === "function" ? createTailwindMerge(getDefaultConfig, configExtension, ...createConfig) : createTailwindMerge(() => mergeConfigs(getDefaultConfig(), configExtension), ...createConfig);
//#endregion
//#region ../../resources/scripts/lib/cn.ts
/** The Tailwind prefixes of the enabled extensions (`hw` for `hw:flex`), each extension building with its own. */
var prefixes = /* @__PURE__ */ new Set();
var createMerge = () => extendTailwindMerge({ experimentalParseClassName: ({ className, parseClassName }) => {
	const end = className.indexOf(":");
	return parseClassName(end > 0 && prefixes.has(className.slice(0, end)) ? className.slice(end + 1) : className);
} });
var merge = createMerge();
/**
* Teach `cn` the Tailwind prefixes extensions build with, from the bootstrap payload before
* the first render. A prefix registered later still applies: tailwind-merge caches what it
* resolved, so the merge function is rebuilt whenever a new prefix arrives.
*/
function registerClassPrefixes(names) {
	let added = false;
	for (const name of names) if (name && /^[a-z]+$/.test(name) && !prefixes.has(name)) {
		prefixes.add(name);
		added = true;
	}
	if (added) merge = createMerge();
}
var cn = (...inputs) => merge(clsx(inputs));
//#endregion
//#region ../../resources/scripts/components/elements/Icon.tsx
/** Renders a lucide icon inline at the surrounding text size (1em). */
var Icon = ({ icon: IconComponent, className, size = "1em", ...rest }) => /* @__PURE__ */ jsx(IconComponent, {
	className: cn("inline-block", className),
	size,
	...rest
});
//#endregion
//#region ../../resources/scripts/components/elements/ErrorBoundary.tsx
var retryButtonClass = ["ml-3 shrink-0 rounded-sm border border-border bg-popover px-2 py-1 text-xs uppercase tracking-wide", "text-foreground transition-colors duration-150 hover:bg-secondary"].join(" ");
var keysChanged = (previous = [], next = []) => previous.length !== next.length || previous.some((key, index) => !Object.is(key, next[index]));
var ErrorBoundary = class extends React.Component {
	state = { hasError: false };
	static getDerivedStateFromError() {
		return { hasError: true };
	}
	componentDidCatch(error) {
		console.error(error);
	}
	componentDidUpdate(prevProps, prevState) {
		if (prevState.hasError && this.state.hasError && keysChanged(prevProps.resetKeys, this.props.resetKeys)) this.reset();
	}
	reset = () => {
		this.setState({ hasError: false });
	};
	render() {
		return this.state.hasError ? /* @__PURE__ */ jsx("div", {
			className: "flex items-center justify-center w-full my-4",
			children: /* @__PURE__ */ jsxs("div", {
				role: "alert",
				className: "flex items-center bg-muted rounded-sm p-3 text-destructive",
				children: [
					/* @__PURE__ */ jsx(Icon, {
						icon: TriangleAlert,
						className: "h-4 w-auto mr-2"
					}),
					/* @__PURE__ */ jsx("p", {
						className: "text-sm text-foreground",
						children: "An error was encountered by the application while rendering this view. Try refreshing the page."
					}),
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: retryButtonClass,
						onClick: this.reset,
						children: "Retry"
					})
				]
			})
		}) : this.props.children;
	}
};
//#endregion
//#region ../../resources/scripts/components/elements/Spinner.tsx
var spinnerSize = cva("", {
	variants: { size: {
		small: "w-4 h-4 border-2",
		base: "w-8 h-8 border-[3px]",
		large: "w-16 h-16 border-[6px]"
	} },
	defaultVariants: { size: "base" }
});
var SpinnerComponent = ({ size, isBlue }) => /* @__PURE__ */ jsx("span", { className: cn("block rounded-full animate-[spin_1s_cubic-bezier(0.55,0.25,0.25,0.7)_infinite] border-muted border-t-foreground", isBlue && "border-ring border-t-primary", spinnerSize({ size: size ?? "base" })) });
var Spinner = (({ centered, ...props }) => centered ? /* @__PURE__ */ jsx("div", {
	className: cn("flex justify-center items-center", props.size === "large" ? "m-20" : "m-6"),
	children: /* @__PURE__ */ jsx(SpinnerComponent, { ...props })
}) : /* @__PURE__ */ jsx(SpinnerComponent, { ...props }));
Spinner.displayName = "Spinner";
Spinner.Size = {
	SMALL: "small",
	BASE: "base",
	LARGE: "large"
};
var LocationErrorBoundary = ({ children }) => {
	return /* @__PURE__ */ jsx(ErrorBoundary, {
		resetKeys: [useLocation({ select: (location) => location.href })],
		children
	});
};
var SuspenseErrorBoundary = ({ children }) => useRouter({ warn: false }) ? /* @__PURE__ */ jsx(LocationErrorBoundary, { children }) : /* @__PURE__ */ jsx(ErrorBoundary, { children });
Spinner.Suspense = ({ children, centered = true, size = Spinner.Size.LARGE, ...props }) => /* @__PURE__ */ jsx(Suspense, {
	fallback: /* @__PURE__ */ jsx(Spinner, {
		centered,
		size,
		...props
	}),
	children: /* @__PURE__ */ jsx(SuspenseErrorBoundary, { children })
});
Spinner.Suspense.displayName = "Spinner.Suspense";
//#endregion
//#region ../../resources/scripts/components/elements/Button.tsx
var buttonStyle = cva("relative inline-block rounded-sm border p-2 text-sm uppercase tracking-wide transition-colors duration-150 disabled:cursor-default disabled:opacity-50", {
	variants: {
		color: {
			primary: "bg-primary border-primary text-primary-foreground [&:hover:not(:disabled)]:bg-primary/80 [&:hover:not(:disabled)]:border-primary",
			grey: "border-border bg-popover text-foreground [&:hover:not(:disabled)]:bg-secondary [&:hover:not(:disabled)]:border-secondary",
			green: "border-success bg-success text-success-foreground [&:hover:not(:disabled)]:bg-success/80 [&:hover:not(:disabled)]:border-success",
			red: "border-destructive bg-destructive text-destructive-foreground [&:hover:not(:disabled)]:bg-destructive/80 [&:hover:not(:disabled)]:border-destructive",
			orange: "border-caution bg-caution text-caution-foreground [&:hover:not(:disabled)]:bg-caution/80 [&:hover:not(:disabled)]:border-caution"
		},
		size: {
			xsmall: "px-2 py-1 text-xs",
			small: "px-4 py-2",
			large: "p-4 text-sm",
			xlarge: "p-4 w-full"
		},
		isSecondary: {
			true: "border-border bg-transparent text-foreground [&:hover:not(:disabled)]:border-popover [&:hover:not(:disabled)]:bg-popover [&:hover:not(:disabled)]:text-foreground",
			false: ""
		}
	},
	compoundVariants: [
		{
			isSecondary: true,
			color: "primary",
			class: "[&:hover:not(:disabled)]:bg-primary [&:hover:not(:disabled)]:border-primary [&:hover:not(:disabled)]:text-primary-foreground"
		},
		{
			isSecondary: true,
			color: "red",
			class: "[&:hover:not(:disabled)]:bg-destructive [&:hover:not(:disabled)]:border-destructive [&:hover:not(:disabled)]:text-destructive-foreground"
		},
		{
			isSecondary: true,
			color: "green",
			class: "[&:hover:not(:disabled)]:bg-success [&:hover:not(:disabled)]:border-success [&:hover:not(:disabled)]:text-success-foreground"
		},
		{
			isSecondary: true,
			color: "orange",
			class: "[&:hover:not(:disabled)]:bg-caution [&:hover:not(:disabled)]:border-caution [&:hover:not(:disabled)]:text-caution-foreground"
		},
		{
			isSecondary: false,
			color: "primary",
			class: "[&:active:not(:disabled)]:bg-primary/70 [&:active:not(:disabled)]:border-primary/70"
		},
		{
			isSecondary: false,
			color: "green",
			class: "[&:active:not(:disabled)]:bg-success/70 [&:active:not(:disabled)]:border-success"
		},
		{
			isSecondary: false,
			color: "red",
			class: "[&:active:not(:disabled)]:bg-destructive/70 [&:active:not(:disabled)]:border-destructive"
		},
		{
			isSecondary: false,
			color: "orange",
			class: "[&:active:not(:disabled)]:bg-caution/70 [&:active:not(:disabled)]:border-caution"
		}
	],
	defaultVariants: {
		color: "primary",
		size: "small",
		isSecondary: false
	}
});
var buttonClassName = ({ color, size, isSecondary, className }) => cn(buttonStyle({
	color: isSecondary && !color ? void 0 : color,
	size: size ?? "small",
	isSecondary: !!isSecondary
}), className);
var ButtonStyle = ({ as, color, size, isSecondary, className, ref, ...props }) => {
	return /* @__PURE__ */ jsx(as || "button", {
		ref,
		className: buttonClassName({
			color,
			size,
			isSecondary,
			className
		}),
		...props
	});
};
/** Defaults to `type="button"`; `isLoading` shows a spinner and disables the button. */
var Button = ({ children, isLoading, disabled, type = "button", ref, ...props }) => /* @__PURE__ */ jsxs(ButtonStyle, {
	ref,
	type,
	disabled: disabled || isLoading,
	"aria-busy": isLoading || void 0,
	...props,
	children: [isLoading && /* @__PURE__ */ jsx("span", {
		className: "flex absolute justify-center items-center w-full h-full left-0 top-0",
		children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
	}), /* @__PURE__ */ jsx("span", {
		className: isLoading ? "text-transparent" : void 0,
		children
	})]
});
Button.displayName = "Button";
var TextButton = ({ ref, ...props }) => /* @__PURE__ */ jsx(Button, {
	ref,
	color: "grey",
	...props
});
TextButton.displayName = "Button.Text";
var DangerButton = ({ ref, ...props }) => /* @__PURE__ */ jsx(Button, {
	ref,
	color: "red",
	...props
});
DangerButton.displayName = "Button.Danger";
var ButtonWithVariants = Button;
ButtonWithVariants.Text = TextButton;
ButtonWithVariants.Danger = DangerButton;
//#endregion
//#region ../../resources/scripts/components/elements/Can.tsx
function Can({ action, matchAny = false, renderOnError, children }) {
	const can = usePermissions(action);
	return matchAny && can.some((p) => p) || !matchAny && can.every((p) => p) ? children : renderOnError;
}
//#endregion
//#region ../../resources/scripts/components/elements/SpinnerOverlay.tsx
var SpinnerOverlay = ({ size, fixed, visible, backgroundOpacity, children }) => {
	if (!visible) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("top-0 left-0 flex items-center justify-center w-full h-full rounded-sm flex-col z-40", "bg-background/(--spinner-overlay-opacity)", fixed ? "fixed" : "absolute"),
		style: backgroundOpacity === void 0 ? void 0 : { "--spinner-overlay-opacity": `${backgroundOpacity * 100}%` },
		children: [/* @__PURE__ */ jsx(Spinner, { size }), children && /* @__PURE__ */ jsx("p", {
			className: "mt-4 text-muted-foreground",
			children
		})]
	});
};
//#endregion
//#region ../../resources/scripts/components/ui/typography.ts
var sectionTitleClass = "font-header text-lg font-semibold tracking-normal text-foreground";
var cardTitleClass = "font-header text-sm font-semibold uppercase tracking-wide text-foreground";
//#endregion
//#region ../../resources/scripts/components/elements/Portal.tsx
function Portal({ children }) {
	return createPortal(children, document.getElementById("modal-portal"));
}
//#endregion
//#region ../../resources/scripts/components/form/controls.tsx
var controlBaseClass = [
	"resize-none appearance-none outline-hidden w-full min-w-0",
	"p-3 border-2 rounded-sm text-sm transition-[background-color,border-color,color,box-shadow] duration-150",
	"bg-input border-input hover:border-input text-foreground shadow-none focus:ring-0",
	"focus:shadow-md focus:border-primary focus:ring-2 focus:ring-ring/50",
	"disabled:opacity-75 read-only:cursor-text read-only:bg-muted/40",
	"required:shadow-none invalid:shadow-none"
].join(" ");
var lightClass = "bg-background border-border text-foreground focus:border-primary disabled:bg-muted disabled:border-border";
var errorClass = ["text-destructive border-destructive hover:border-destructive", "focus:border-destructive focus:ring-destructive"].join(" ");
var controlClass = ({ $isLight, $hasError }, className) => cn(controlBaseClass, $isLight && lightClass, $hasError && errorClass, className);
var TextInput = ({ $isLight, $hasError, className, ...props }) => /* @__PURE__ */ jsx(Input, {
	className: controlClass({
		$isLight,
		$hasError
	}, className),
	...props
});
var TextArea = ({ $isLight, $hasError, className, ...props }) => /* @__PURE__ */ jsx("textarea", {
	className: controlClass({
		$isLight,
		$hasError
	}, className),
	...props
});
var NumberInput = ({ $isLight, $hasError, className, value, onValueChange, min, max, step, format, disabled, ...props }) => /* @__PURE__ */ jsx(NumberField.Root, {
	value,
	onValueChange,
	min,
	max,
	step,
	format: {
		useGrouping: false,
		...format
	},
	disabled,
	children: /* @__PURE__ */ jsx(NumberField.Input, {
		className: controlClass({
			$isLight,
			$hasError
		}, className),
		...props
	})
});
//#endregion
//#region ../../resources/scripts/components/elements/Label.tsx
var Label = ({ as, isLight, className, ...props }) => {
	return /* @__PURE__ */ jsx(as || "label", {
		className: cn("block text-sm font-medium uppercase text-foreground mb-1", isLight && "text-muted-foreground", className),
		...props
	});
};
//#endregion
//#region ../../resources/scripts/components/form/context.ts
var { fieldContext, formContext, useFieldContext, useFormContext } = createFormHookContexts();
//#endregion
//#region ../../resources/scripts/components/form/errors.ts
function firstError(errors) {
	if (!errors || errors.length === 0) return;
	const error = errors.find((e) => e !== void 0 && e !== null && e !== "");
	if (error === void 0) return;
	if (isString(error)) return error;
	if (isObject(error) && "message" in error) return String(error.message);
	return String(error);
}
//#endregion
//#region ../../resources/scripts/lib/strings.ts
function capitalize(value) {
	return value.charAt(0).toUpperCase() + value.slice(1);
}
//#endregion
//#region ../../resources/scripts/components/ui/Select.tsx
var inputGroupClass = [
	"relative flex items-center w-full rounded-sm border text-sm transition-colors duration-150",
	"bg-input border-input text-foreground hover:border-input data-[popup-open]:border-input",
	"focus-within:shadow-md focus-within:border-primary focus-within:ring-2 focus-within:ring-ring/50",
	"data-[disabled]:opacity-75 data-[disabled]:cursor-default"
].join(" ");
var inputErrorClass = "border-destructive text-destructive focus-within:border-destructive focus-within:ring-destructive";
var inputClass = ["w-full min-w-0 appearance-none border-0 bg-transparent p-3 pr-10 text-sm text-foreground outline-hidden", "placeholder:text-muted-foreground focus:ring-0 focus:outline-hidden disabled:cursor-default"].join(" ");
var triggerClass = "absolute right-0 top-0 flex h-full w-10 items-center justify-center border-0 bg-transparent p-0 text-muted-foreground [&_svg]:h-4 [&_svg]:w-4 [&_svg]:shrink-0";
var positionerClass$1 = "z-[99999] min-w-[var(--anchor-width)] outline-none";
var popupClass$1 = ["bg-card border border-border rounded-sm shadow-lg py-1 text-sm text-foreground", "w-[var(--anchor-width)] max-w-[var(--available-width)] max-h-[min(18rem,var(--available-height))]"].join(" ");
var listClass = "max-h-72 overflow-y-auto overscroll-contain outline-none";
var itemClass = "flex items-center justify-between px-3 py-2 cursor-pointer select-none outline-hidden data-[highlighted]:bg-popover data-[highlighted]:text-foreground data-[selected]:text-accent data-[disabled]:opacity-50 data-[disabled]:cursor-default";
var emptyClass = "px-3 py-2 text-sm text-muted-foreground empty:p-0";
var groupLabelClass = "px-3 pt-2 pb-1 text-xs uppercase text-muted-foreground empty:hidden";
var selectionSummaryClass = "pointer-events-none whitespace-nowrap px-3 py-3 text-sm text-foreground";
var selectionPreviewClass = "pointer-events-none flex min-w-0 flex-1 items-center px-3 py-2 pr-10 text-sm";
var optionLabel = (option) => {
	if (!option) return "";
	if (option.textLabel !== void 0) return option.textLabel;
	if (isString(option.label) || isNumber$1(option.label)) return String(option.label);
	return String(option.value);
};
var isTextLabel = (label) => isString(label) || isNumber$1(label);
var sameValue = (left, right) => Object.is(left, right);
var isSameOption = (option, selected) => sameValue(option.value, selected.value);
var optionKey = (option) => `${isNumber$1(option.value) ? "number" : "string"}:${String(option.value)}`;
var getOptions = (options, groups) => options ?? groups?.flatMap((group) => group.options) ?? [];
var getGroups = (groups) => groups?.map((group, index) => ({
	value: group.id === void 0 ? `${index}:${group.label}` : optionKey({ value: group.id }),
	label: group.label,
	items: group.options
}));
var ComboboxInputGroup = ({ $hasError, className, ...props }) => /* @__PURE__ */ jsx(Combobox.InputGroup, {
	className: cn(inputGroupClass, $hasError && inputErrorClass, className),
	...props
});
var ComboboxInput = ({ className, ...props }) => /* @__PURE__ */ jsx(Combobox.Input, {
	className: cn(inputClass, className),
	...props
});
var ComboboxTrigger = ({ className, ...props }) => /* @__PURE__ */ jsx(Combobox.Trigger, {
	className: cn(triggerClass, className),
	...props
});
var ComboboxPositioner = ({ className, ...props }) => /* @__PURE__ */ jsx(Combobox.Positioner, {
	className: cn(positionerClass$1, className),
	...props
});
var ComboboxPopup = ({ className, ...props }) => /* @__PURE__ */ jsx(Combobox.Popup, {
	className: cn(popupClass$1, className),
	...props
});
var ComboboxList = ({ className, ...props }) => /* @__PURE__ */ jsx(Combobox.List, {
	className: cn(listClass, className),
	...props
});
var ComboboxItem = ({ className, ...props }) => /* @__PURE__ */ jsx(Combobox.Item, {
	className: cn(itemClass, className),
	...props
});
var ComboboxEmpty = ({ className, ...props }) => /* @__PURE__ */ jsx(Combobox.Empty, {
	className: cn(emptyClass, className),
	...props
});
var ComboboxGroupLabel = ({ className, ...props }) => /* @__PURE__ */ jsx(Combobox.GroupLabel, {
	className: cn(groupLabelClass, className),
	...props
});
var ComboboxSelectionSummary = ({ className, ...props }) => /* @__PURE__ */ jsx("span", {
	className: cn(selectionSummaryClass, className),
	...props
});
var CheckIcon = () => /* @__PURE__ */ jsx(Check, {
	size: 14,
	strokeWidth: 2.5,
	"aria-hidden": true
});
var ChevronIcon = () => /* @__PURE__ */ jsx(ChevronDown, {
	size: 16,
	"aria-hidden": true
});
var ComboboxOptionItem = ({ option, showIndicator }) => /* @__PURE__ */ jsxs(ComboboxItem, {
	value: option,
	disabled: option.disabled,
	children: [/* @__PURE__ */ jsx("span", {
		className: "min-w-0",
		children: option.label
	}), showIndicator && /* @__PURE__ */ jsx(Combobox.ItemIndicator, { children: /* @__PURE__ */ jsx(CheckIcon, {}) })]
});
var ComboboxOptionsList = ({ groups, showIndicator }) => groups ? /* @__PURE__ */ jsx(ComboboxList, { children: (group) => /* @__PURE__ */ jsxs(Combobox.Group, {
	items: group.items,
	children: [/* @__PURE__ */ jsx(ComboboxGroupLabel, { children: group.label }), /* @__PURE__ */ jsx(Combobox.Collection, { children: (option) => /* @__PURE__ */ jsx(ComboboxOptionItem, {
		option,
		showIndicator
	}, optionKey(option)) })]
}, group.value) }) : /* @__PURE__ */ jsx(ComboboxList, { children: (option) => /* @__PURE__ */ jsx(ComboboxOptionItem, {
	option,
	showIndicator
}, optionKey(option)) });
var ComboboxPopupContent = ({ groupedItems, emptyMessage, showIndicator }) => /* @__PURE__ */ jsx(Combobox.Portal, { children: /* @__PURE__ */ jsx(ComboboxPositioner, {
	sideOffset: 4,
	children: /* @__PURE__ */ jsxs(ComboboxPopup, { children: [/* @__PURE__ */ jsx(ComboboxEmpty, { children: emptyMessage }), /* @__PURE__ */ jsx(ComboboxOptionsList, {
		groups: groupedItems,
		showIndicator
	})] })
}) });
var singleSelectedValues = (value) => value === null || value === void 0 ? [] : [value];
var findOption = (candidates, value) => candidates.find((option) => sameValue(option.value, value));
var resolveSelectedOptions = (values, flatOptions, fallback) => values.flatMap((value) => {
	const option = findOption(flatOptions, value) ?? findOption(fallback, value);
	return option ? [option] : [];
});
var selectionSignature = (selected) => selected.map((option) => `${optionKey(option)}:${optionLabel(option)}`).join("\n");
function useSelectedOptions(flatOptions, values) {
	const [remembered, setRemembered] = React.useState(() => resolveSelectedOptions(values, flatOptions, []));
	const selected = resolveSelectedOptions(values, flatOptions, remembered);
	if (selectionSignature(selected) !== selectionSignature(remembered)) setRemembered(selected);
	return selected;
}
var resolveRichSelection = (selectedOption) => selectedOption && !isTextLabel(selectedOption.label) ? selectedOption.label : null;
function useSelectSearch({ onBlur, onSearchChange }) {
	const [searchValue, setSearchValue] = React.useState("");
	const [inputFocused, setInputFocused] = React.useState(false);
	const resetInputValue = React.useCallback(() => {
		setSearchValue("");
		onSearchChange?.("");
	}, [onSearchChange]);
	return {
		searchValue,
		setSearchValue,
		inputFocused,
		resetInputValue,
		handleInputValueChange: React.useCallback((value, eventDetails) => {
			if (eventDetails.reason === "focus-out" || eventDetails.reason === "input-blur" || !inputFocused) {
				resetInputValue();
				return;
			}
			setSearchValue(value);
			onSearchChange?.(value);
		}, [
			inputFocused,
			onSearchChange,
			resetInputValue
		]),
		handleFocus: React.useCallback(() => {
			setInputFocused(true);
		}, []),
		handleBlur: React.useCallback((event) => {
			setInputFocused(false);
			resetInputValue();
			onBlur?.(event);
		}, [onBlur, resetInputValue]),
		externalFilter: onSearchChange ? null : void 0
	};
}
function MultiSelectCombobox({ id, placeholder, searchPlaceholder, emptyMessage, hasError, disabled, items, groupedItems, selectedOptions, inputValue, inputAria, search, onChange }) {
	return /* @__PURE__ */ jsxs(Combobox.Root, {
		multiple: true,
		items,
		value: selectedOptions,
		inputValue,
		onInputValueChange: search.handleInputValueChange,
		onOpenChange: (open) => {
			if (!open) search.resetInputValue();
		},
		onValueChange: (value) => {
			onChange(value.map((option) => option.value));
			search.resetInputValue();
		},
		filter: search.externalFilter,
		disabled,
		itemToStringLabel: optionLabel,
		itemToStringValue: (option) => String(option?.value ?? ""),
		isItemEqualToValue: isSameOption,
		autoHighlight: true,
		children: [/* @__PURE__ */ jsxs(ComboboxInputGroup, {
			$hasError: hasError,
			children: [/* @__PURE__ */ jsx(Combobox.Value, { children: (value) => /* @__PURE__ */ jsxs(Fragment, { children: [value.length > 0 && /* @__PURE__ */ jsx(ComboboxSelectionSummary, { children: `${value.length} selected` }), /* @__PURE__ */ jsx(ComboboxInput, {
				...inputAria,
				id,
				className: value.length > 0 ? "pl-0" : void 0,
				placeholder: value.length > 0 ? searchPlaceholder : placeholder,
				onFocus: search.handleFocus,
				onBlur: search.handleBlur
			})] }) }), /* @__PURE__ */ jsx(ComboboxTrigger, {
				"aria-label": "Open popup",
				children: /* @__PURE__ */ jsx(ChevronIcon, {})
			})]
		}), /* @__PURE__ */ jsx(ComboboxPopupContent, {
			groupedItems,
			emptyMessage,
			showIndicator: true
		})]
	});
}
function SingleSelectCombobox({ id, placeholder, emptyMessage, hasError, disabled, items, groupedItems, selectedOption, inputValue, richSelection, inputFocused, inputAria, search, onChange, onSelectLabel }) {
	return /* @__PURE__ */ jsxs(Combobox.Root, {
		items,
		value: selectedOption,
		inputValue,
		onInputValueChange: search.handleInputValueChange,
		onOpenChange: (open) => {
			if (!open) search.resetInputValue();
		},
		onValueChange: (option) => {
			if (option) {
				onChange(option.value);
				onSelectLabel(optionLabel(option));
			}
		},
		filter: search.externalFilter,
		disabled,
		itemToStringLabel: optionLabel,
		itemToStringValue: (option) => String(option?.value ?? ""),
		isItemEqualToValue: isSameOption,
		autoHighlight: true,
		children: [/* @__PURE__ */ jsxs(ComboboxInputGroup, {
			$hasError: hasError,
			children: [
				richSelection && /* @__PURE__ */ jsx("span", {
					className: cn(selectionPreviewClass, inputFocused && "invisible"),
					children: richSelection
				}),
				/* @__PURE__ */ jsx(ComboboxInput, {
					...inputAria,
					id,
					className: cn(richSelection && "absolute inset-0 h-full", richSelection && !inputFocused && "text-transparent"),
					placeholder,
					onFocus: search.handleFocus,
					onBlur: search.handleBlur
				}),
				/* @__PURE__ */ jsx(ComboboxTrigger, {
					"aria-label": "Open popup",
					children: /* @__PURE__ */ jsx(ChevronIcon, {})
				})
			]
		}), /* @__PURE__ */ jsx(ComboboxPopupContent, {
			groupedItems,
			emptyMessage,
			showIndicator: false
		})]
	});
}
function Select(props) {
	const { id, options, groups, disabled, placeholder, searchPlaceholder = "Search...", emptyMessage = "No results found.", hasError, onBlur, onSearchChange } = props;
	const flatOptions = getOptions(options, groups);
	const groupedItems = getGroups(groups);
	const items = groupedItems ?? flatOptions;
	const search = useSelectSearch({
		onBlur,
		onSearchChange
	});
	const selectedOptions = useSelectedOptions(flatOptions, props.multiple ? props.value : singleSelectedValues(props.value));
	const inputAria = {
		"aria-describedby": props["aria-describedby"],
		"aria-invalid": props["aria-invalid"]
	};
	if (props.multiple) return /* @__PURE__ */ jsx(MultiSelectCombobox, {
		id,
		placeholder,
		searchPlaceholder,
		emptyMessage,
		hasError,
		disabled,
		items,
		groupedItems,
		selectedOptions,
		inputValue: search.inputFocused ? search.searchValue : "",
		inputAria,
		search,
		onChange: props.onChange
	});
	const selectedOption = selectedOptions[0] ?? null;
	const selectedLabel = optionLabel(selectedOption);
	const richSelection = resolveRichSelection(selectedOption);
	return /* @__PURE__ */ jsx(SingleSelectCombobox, {
		id,
		placeholder,
		emptyMessage,
		hasError,
		disabled,
		items,
		groupedItems,
		selectedOption,
		inputValue: search.inputFocused ? search.searchValue : selectedLabel,
		richSelection,
		inputFocused: search.inputFocused,
		inputAria,
		search,
		onChange: props.onChange,
		onSelectLabel: search.setSearchValue
	});
}
//#endregion
//#region ../../resources/scripts/components/ui/Switch.tsx
var rootClass$1 = [
	"group relative inline-block shrink-0 w-12 h-6 rounded-full border cursor-pointer select-none p-0",
	"bg-input border-input transition-colors duration-75",
	"hover:border-primary/70 active:bg-popover data-[checked]:bg-primary data-[checked]:border-primary",
	"data-[disabled]:opacity-60 data-[disabled]:cursor-default"
].join(" ");
var thumbClass = [
	"block absolute top-1/2 left-0.5 size-4.5 -translate-y-1/2 rounded-full border bg-background",
	"transition-[left] duration-75 ease-in",
	"group-data-[checked]:left-[calc(100%_-_1.125rem_-_0.125rem)]",
	"group-data-[checked]:bg-primary-foreground group-data-[checked]:border-primary-foreground"
].join(" ");
function Switch$1({ checked, onChange, disabled, id, name, label, description, controlPosition = "start", className, onBlur, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy }) {
	const generatedId = useId();
	const fieldId = id ?? generatedId;
	const labelId = `${generatedId}-label`;
	const descriptionId = `${generatedId}-description`;
	const hasText = !!label || !!description;
	const control = /* @__PURE__ */ jsx(Switch.Root, {
		id: fieldId,
		name,
		checked,
		onCheckedChange: onChange,
		onBlur,
		disabled,
		"aria-label": ariaLabel,
		"aria-labelledby": ariaLabelledBy ?? (label ? labelId : void 0),
		"aria-describedby": description ? descriptionId : void 0,
		className: rootClass$1,
		children: /* @__PURE__ */ jsx(Switch.Thumb, { className: thumbClass })
	});
	const text = hasText ? /* @__PURE__ */ jsxs("div", {
		className: "min-w-0 flex-1",
		children: [label && /* @__PURE__ */ jsx(Label, {
			id: labelId,
			htmlFor: fieldId,
			className: "cursor-pointer mb-0",
			children: label
		}), description && /* @__PURE__ */ jsx("p", {
			id: descriptionId,
			className: "input-help",
			children: description
		})]
	}) : null;
	return /* @__PURE__ */ jsx("div", {
		className: cn("flex gap-4", description ? "items-start" : "items-center", className),
		children: controlPosition === "end" ? /* @__PURE__ */ jsxs(Fragment, { children: [text, control] }) : /* @__PURE__ */ jsxs(Fragment, { children: [control, text] })
	});
}
//#endregion
//#region ../../resources/scripts/components/ui/Checkbox.tsx
var rootClass = [
	"flex items-center justify-center shrink-0 w-4 h-4 rounded-xs cursor-pointer",
	"bg-input border border-input text-primary-foreground transition-colors duration-75 hover:border-primary/70",
	"data-[checked]:bg-primary data-[checked]:border-transparent",
	"data-[indeterminate]:bg-primary data-[indeterminate]:border-transparent",
	"data-[disabled]:opacity-60 data-[disabled]:cursor-default",
	"[&_svg]:size-3.5"
].join(" ");
function Checkbox$1({ checked, onChange, indeterminate, className, ...props }) {
	return /* @__PURE__ */ jsx(Checkbox.Root, {
		...props,
		checked,
		indeterminate,
		onCheckedChange: onChange,
		className: cn(rootClass, className),
		children: /* @__PURE__ */ jsx(Checkbox.Indicator, { children: indeterminate ? /* @__PURE__ */ jsx(Minus, {
			size: 14,
			strokeWidth: 2.5,
			"aria-hidden": true
		}) : /* @__PURE__ */ jsx(Check, {
			size: 14,
			strokeWidth: 2.5,
			"aria-hidden": true
		}) })
	});
}
//#endregion
//#region ../../resources/scripts/components/form/fields.tsx
var HelpText = ({ id, error, description }) => {
	if (error) return /* @__PURE__ */ jsx("p", {
		id,
		className: "input-help error",
		children: capitalize(error)
	});
	if (!description) return null;
	return /* @__PURE__ */ jsx("p", {
		id,
		className: "input-help",
		children: description
	});
};
var describedBy = (...ids) => ids.filter((id) => !!id).join(" ") || void 0;
function useFieldState(id, description) {
	const field = useFieldContext();
	const generatedId = useId();
	const error = firstError(field.state.meta.errors);
	const helpId = `${generatedId}-help`;
	return {
		field,
		error,
		fieldId: id ?? generatedId,
		helpId,
		describedById: error || description ? helpId : void 0
	};
}
function TextField({ id, label, description, light, onBlur, "aria-describedby": ariaDescribedBy, "aria-invalid": ariaInvalid, ...props }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(TextInput, {
			...props,
			id: fieldId,
			value: field.state.value ?? "",
			onValueChange: (value) => field.handleChange(value),
			onBlur: (event) => {
				field.handleBlur();
				onBlur?.(event);
			},
			"aria-invalid": error ? true : ariaInvalid,
			"aria-describedby": describedBy(ariaDescribedBy, describedById),
			$hasError: !!error,
			$isLight: light
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
function TextAreaField({ id, label, description, light, onBlur, "aria-describedby": ariaDescribedBy, "aria-invalid": ariaInvalid, ...props }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(TextArea, {
			...props,
			id: fieldId,
			value: field.state.value ?? "",
			onChange: (event) => field.handleChange(event.target.value),
			onBlur: (event) => {
				field.handleBlur();
				onBlur?.(event);
			},
			"aria-invalid": error ? true : ariaInvalid,
			"aria-describedby": describedBy(ariaDescribedBy, describedById),
			$hasError: !!error,
			$isLight: light
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
/** Binds a `number | null` field; an emptied input stores null. */
function NumberField$1({ id, label, description, light, min, max, format, ...props }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(NumberInput, {
			...props,
			id: fieldId,
			value: field.state.value ?? null,
			onValueChange: (value) => field.handleChange(value),
			onBlur: field.handleBlur,
			min,
			max,
			format,
			"aria-invalid": error ? true : void 0,
			"aria-describedby": describedById,
			$hasError: !!error,
			$isLight: light
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
function SelectField({ id, label, description, light, options, disabled, placeholder, emptyMessage, onChange, onSearchChange }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(Select, {
			id: fieldId,
			options,
			value: field.state.value ?? null,
			onChange: (value) => {
				field.handleChange(value);
				onChange?.(value);
			},
			disabled,
			placeholder,
			emptyMessage,
			hasError: !!error,
			"aria-invalid": error ? true : void 0,
			"aria-describedby": describedById,
			onBlur: field.handleBlur,
			onSearchChange
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
function MultiSelectField({ id, label, description, light, options, disabled, placeholder = "None selected", searchPlaceholder }) {
	const { field, error, fieldId, helpId, describedById } = useFieldState(id, description);
	const selected = Array.isArray(field.state.value) ? field.state.value : [];
	return /* @__PURE__ */ jsxs("div", { children: [
		label && /* @__PURE__ */ jsx(Label, {
			htmlFor: fieldId,
			isLight: light,
			children: label
		}),
		/* @__PURE__ */ jsx(Select, {
			multiple: true,
			id: fieldId,
			options,
			value: selected,
			onChange: (value) => field.handleChange(value),
			disabled,
			placeholder,
			searchPlaceholder,
			hasError: !!error,
			"aria-invalid": error ? true : void 0,
			"aria-describedby": describedById,
			onBlur: field.handleBlur
		}),
		/* @__PURE__ */ jsx(HelpText, {
			id: helpId,
			error,
			description
		})
	] });
}
function SwitchField({ label, description, disabled, controlPosition, className }) {
	const field = useFieldContext();
	return /* @__PURE__ */ jsx(Switch$1, {
		checked: !!field.state.value,
		onChange: (checked) => field.handleChange(checked),
		onBlur: field.handleBlur,
		disabled,
		label,
		description,
		controlPosition,
		className
	});
}
/** Adds or removes `value` in a `string[]` field. */
function CheckboxField({ value, disabled, className }) {
	const field = useFieldContext();
	const selected = Array.isArray(field.state.value) ? field.state.value : [];
	return /* @__PURE__ */ jsx(Checkbox$1, {
		className,
		checked: selected.includes(value),
		disabled,
		onChange: (checked) => {
			const set = new Set(selected);
			if (checked) set.add(value);
			else set.delete(value);
			field.handleChange([...set]);
		}
	});
}
//#endregion
//#region ../../resources/scripts/components/form/SubmitButton.tsx
/** Disabled while the form cannot submit; shows a spinner while it submits. */
function SubmitButton({ children, disabled, ...props }) {
	return /* @__PURE__ */ jsx(useFormContext().Subscribe, {
		selector: (state) => ({
			canSubmit: state.canSubmit,
			isSubmitting: state.isSubmitting
		}),
		children: ({ canSubmit, isSubmitting }) => /* @__PURE__ */ jsx(ButtonWithVariants, {
			type: "submit",
			disabled: disabled || !canSubmit,
			isLoading: isSubmitting,
			...props,
			children
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/form/Form.tsx
function Form({ form, children, ...props }) {
	return /* @__PURE__ */ jsx("form", {
		noValidate: true,
		...props,
		onSubmit: (event) => {
			event.preventDefault();
			event.stopPropagation();
			form.handleSubmit();
		},
		children
	});
}
var { useAppForm } = createFormHook({
	fieldContext,
	formContext,
	fieldComponents: {
		TextField,
		TextAreaField,
		NumberField: NumberField$1,
		SelectField,
		MultiSelectField,
		SwitchField,
		CheckboxField
	},
	formComponents: { SubmitButton }
});
//#endregion
//#region ../../resources/scripts/components/elements/dialog/context.ts
var DialogContext = React.createContext({
	setIcon: () => null,
	setIconPosition: () => null
});
//#endregion
//#region ../../resources/scripts/components/elements/dialog/DialogFooter.tsx
var DialogFooter = ({ children }) => /* @__PURE__ */ jsx("div", {
	className: "px-6 py-3 bg-card flex items-center justify-end space-x-3 rounded-b-sm",
	children
});
//#endregion
//#region ../../resources/scripts/components/elements/dialog/Dialog.tsx
var focusableSelector = ":is(input, select, textarea, button, a[href], [tabindex]):not([disabled]):not([tabindex=\"-1\"])";
var dialogContainerClass = "flex min-h-full items-center justify-center p-4 text-center";
var closeIconClass = "w-5 h-5 group-hover:rotate-90 transition-transform duration-100";
var backdropClass = ["fixed inset-0 bg-background/50 z-40 transition-opacity duration-150 ease-out", "data-[starting-style]:opacity-0 data-[ending-style]:opacity-0 data-[ending-style]:ease-in"].join(" ");
var panelClass = [
	"relative flex flex-col overflow-hidden bg-card rounded-sm max-w-xl w-full mx-auto shadow-lg text-left",
	"max-h-[calc(100dvh-2rem)] ring-4 ring-border/80 transition duration-150 ease-out",
	"data-[starting-style]:opacity-0 data-[starting-style]:scale-75",
	"data-[ending-style]:opacity-0 data-[ending-style]:scale-75 data-[ending-style]:ease-in"
].join(" ");
function DialogComponent({ open, title, description, onClose, hideCloseIcon, preventExternalClose, children }) {
	const [icon, setIcon] = useState();
	const [iconPosition, setIconPosition] = useState("title");
	const popupRef = React.useRef(null);
	const initialFocus = (interactionType) => {
		if (interactionType === "touch") return popupRef.current;
		return (popupRef.current?.querySelector(focusableSelector))?.getAttribute("role") === "combobox" ? popupRef.current : true;
	};
	const onOpenChange = (nextOpen) => {
		if (nextOpen || preventExternalClose) return;
		onClose();
	};
	const context = useMemo(() => ({
		setIcon,
		setIconPosition
	}), [setIcon, setIconPosition]);
	const items = React.Children.toArray(children);
	const isFooter = (child) => React.isValidElement(child) && child.type === DialogFooter;
	const footer = items.filter(isFooter);
	const content = items.filter((child) => !isFooter(child));
	return /* @__PURE__ */ jsx(DialogContext.Provider, {
		value: context,
		children: /* @__PURE__ */ jsx(Dialog.Root, {
			open,
			onOpenChange,
			children: /* @__PURE__ */ jsxs(Dialog.Portal, { children: [/* @__PURE__ */ jsx(Dialog.Backdrop, { className: backdropClass }), /* @__PURE__ */ jsx("div", {
				className: "fixed inset-0 overflow-y-auto z-50",
				children: /* @__PURE__ */ jsx("div", {
					className: dialogContainerClass,
					children: /* @__PURE__ */ jsxs(Dialog.Popup, {
						ref: popupRef,
						className: panelClass,
						initialFocus,
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "flex min-h-0 flex-1 overflow-y-auto p-6 pb-0",
								children: [iconPosition === "container" && icon, /* @__PURE__ */ jsxs("div", {
									className: "flex-1 min-w-0",
									children: [
										/* @__PURE__ */ jsxs("div", {
											className: "flex items-center",
											children: [iconPosition !== "container" && icon, /* @__PURE__ */ jsxs("div", { children: [title && /* @__PURE__ */ jsx(Dialog.Title, {
												className: cn("font-header text-xl font-semibold tracking-normal text-foreground", description ? "mb-2" : "mb-5", "pr-4"),
												children: title
											}), description && /* @__PURE__ */ jsx(Dialog.Description, {
												className: "mb-5 text-sm leading-relaxed text-muted-foreground",
												children: description
											})] })]
										}),
										content,
										/* @__PURE__ */ jsx("div", { className: "invisible h-6" })
									]
								})]
							}),
							footer,
							!hideCloseIcon && /* @__PURE__ */ jsx("div", {
								className: "absolute right-0 top-0 m-4",
								children: /* @__PURE__ */ jsx(ButtonWithVariants.Text, {
									type: "button",
									size: "xsmall",
									onClick: onClose,
									className: "group w-8 h-8 p-0 inline-flex items-center justify-center",
									children: /* @__PURE__ */ jsx(X, { className: closeIconClass })
								})
							})
						]
					})
				})
			})] })
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/dialog/DialogIcon.tsx
var icons$1 = {
	danger: ShieldAlert,
	warning: TriangleAlert,
	success: Check,
	info: Info
};
var iconClass = "flex items-center justify-center w-10 h-10 rounded-full mr-4";
var iconTypeClass = {
	danger: "bg-destructive text-destructive-foreground",
	warning: "bg-warning text-warning-foreground",
	success: "bg-success text-success-foreground",
	info: "bg-primary text-primary-foreground"
};
var DialogIcon = ({ type, position, className }) => {
	const { setIcon, setIconPosition } = use(DialogContext);
	useEffect(() => {
		const Icon = icons$1[type];
		setIcon(/* @__PURE__ */ jsx("div", {
			className: cn(iconClass, iconTypeClass[type], className),
			children: /* @__PURE__ */ jsx(Icon, { className: "w-6 h-6" })
		}));
		return () => setIcon(void 0);
	}, [
		className,
		setIcon,
		type
	]);
	useEffect(() => {
		setIconPosition(position);
		return () => setIconPosition("title");
	}, [position, setIconPosition]);
	return null;
};
//#endregion
//#region ../../resources/scripts/components/elements/dialog/DialogTrigger.tsx
function DialogTrigger({ children, trigger }) {
	const [instance, setInstance] = useState({
		generation: 0,
		open: false
	});
	const show = useCallback(() => setInstance((current) => current.open ? current : {
		generation: current.generation + 1,
		open: false
	}), []);
	const hide = useCallback(() => setInstance((current) => current.open ? {
		...current,
		open: false
	} : current), []);
	useLayoutEffect(() => {
		if (instance.generation > 0) setInstance((current) => current.open ? current : {
			...current,
			open: true
		});
	}, [instance.generation]);
	return /* @__PURE__ */ jsxs(Fragment, { children: [instance.generation > 0 && /* @__PURE__ */ jsx(React.Fragment, { children: children({
		open: instance.open,
		onClose: hide
	}) }, instance.generation), trigger({ onClick: show })] });
}
//#endregion
//#region ../../resources/scripts/components/elements/dialog/ConfirmationDialog.tsx
function ConfirmationDialog({ confirm = "Okay", pending = false, children, onConfirmed, preventExternalClose, hideCloseIcon, ...props }) {
	const confirmed = useRef(false);
	useLayoutEffect(() => {
		if (!pending) confirmed.current = false;
	});
	return /* @__PURE__ */ jsxs(DialogComponent, {
		...props,
		preventExternalClose: preventExternalClose || pending,
		hideCloseIcon: hideCloseIcon || pending,
		children: [children, /* @__PURE__ */ jsxs(DialogFooter, { children: [/* @__PURE__ */ jsx(ButtonWithVariants.Text, {
			type: "button",
			disabled: pending,
			onClick: props.onClose,
			children: "Cancel"
		}), /* @__PURE__ */ jsx(ButtonWithVariants.Danger, {
			type: "button",
			isLoading: pending,
			onClick: (event) => {
				if (props.open && !pending && !confirmed.current) {
					confirmed.current = true;
					onConfirmed(event);
				}
			},
			children: confirm
		})] })]
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/dialog/useDialogState.ts
var useDialogState = (initialOpen = false) => {
	const [open, setOpen] = useState(initialOpen);
	return {
		open,
		setOpen,
		show: useCallback(() => setOpen(true), []),
		hide: useCallback(() => setOpen(false), []),
		toggle: useCallback(() => setOpen((current) => !current), [])
	};
};
//#endregion
//#region ../../resources/scripts/components/elements/dialog/ConfirmationDialogTrigger.tsx
function ConfirmationDialogTrigger({ onConfirmed, trigger, pending, ...props }) {
	const dialog = useDialogState();
	const confirmingRef = useRef(false);
	const [confirming, setConfirming] = useState(false);
	const onConfirm = (event) => {
		if (confirmingRef.current || pending) return;
		const result = onConfirmed(event, dialog.hide);
		if (!(result instanceof Promise)) return;
		confirmingRef.current = true;
		setConfirming(true);
		result.catch(() => {}).finally(() => {
			confirmingRef.current = false;
			setConfirming(false);
		});
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [trigger({ onClick: dialog.show }), /* @__PURE__ */ jsx(ConfirmationDialog, {
		...props,
		pending: pending || confirming,
		open: dialog.open,
		onClose: dialog.hide,
		onConfirmed: onConfirm
	})] });
}
//#endregion
//#region ../../resources/scripts/components/elements/dialog/index.ts
var Dialog$1 = Object.assign(DialogComponent, {
	Confirm: ConfirmationDialog,
	ConfirmTrigger: ConfirmationDialogTrigger,
	Footer: DialogFooter,
	Icon: DialogIcon,
	Trigger: DialogTrigger
});
//#endregion
//#region ../../resources/scripts/components/ui/empty.tsx
function Empty({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty",
		className: cn("flex min-w-0 flex-1 flex-col items-center justify-center gap-6 rounded-sm border-dashed p-6 text-center text-balance md:p-12", className),
		...props
	});
}
function EmptyHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-header",
		className: cn("flex max-w-sm flex-col items-center gap-2 text-center", className),
		...props
	});
}
var emptyMediaVariants = cva("mb-2 flex shrink-0 items-center justify-center [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: { variant: {
		default: "bg-transparent",
		icon: "flex size-10 shrink-0 items-center justify-center rounded-sm bg-secondary text-secondary-foreground [&_svg:not([class*='size-'])]:size-6"
	} },
	defaultVariants: { variant: "default" }
});
/** `icon` frames a single icon in a tile; `default` leaves the media unframed. */
function EmptyMedia({ className, variant = "default", ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-icon",
		"data-variant": variant,
		className: cn(emptyMediaVariants({ variant }), className),
		...props
	});
}
function EmptyTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-title",
		className: cn("font-header text-lg font-medium tracking-tight text-foreground", className),
		...props
	});
}
function EmptyDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-description",
		className: cn("text-sm/relaxed text-muted-foreground [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-accent", className),
		...props
	});
}
function EmptyContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-content",
		className: cn("flex w-full max-w-sm min-w-0 flex-col items-center gap-4 text-sm text-balance", className),
		...props
	});
}
//#endregion
//#region ../../node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function hasWindow() {
	return typeof window !== "undefined";
}
function getNodeName(node) {
	if (isNode(node)) return (node.nodeName || "").toLowerCase();
	return "#document";
}
function getWindow(node) {
	var _node$ownerDocument;
	return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
	var _ref;
	return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
	if (!hasWindow()) return false;
	return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
	if (!hasWindow()) return false;
	return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
	if (!hasWindow()) return false;
	return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
	if (!hasWindow() || typeof ShadowRoot === "undefined") return false;
	return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
function isOverflowElement(element) {
	const { overflow, overflowX, overflowY, display } = getComputedStyle$1(element);
	return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== "inline" && display !== "contents";
}
function isTableElement(element) {
	return /^(table|td|th)$/.test(getNodeName(element));
}
function isTopLayer(element) {
	try {
		if (element.matches(":popover-open")) return true;
	} catch (_e) {}
	try {
		return element.matches(":modal");
	} catch (_e) {
		return false;
	}
}
var willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
var containRe = /paint|layout|strict|content/;
var isNotNone = (value) => !!value && value !== "none";
var isWebKitValue;
function isContainingBlock(elementOrCss) {
	const css = isElement(elementOrCss) ? getComputedStyle$1(elementOrCss) : elementOrCss;
	return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || "") || containRe.test(css.contain || "");
}
function getContainingBlock(element) {
	let currentNode = getParentNode(element);
	while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
		if (isContainingBlock(currentNode)) return currentNode;
		else if (isTopLayer(currentNode)) return null;
		currentNode = getParentNode(currentNode);
	}
	return null;
}
function isWebKit() {
	if (isWebKitValue == null) isWebKitValue = typeof CSS !== "undefined" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none");
	return isWebKitValue;
}
function isLastTraversableNode(node) {
	return /^(html|body|#document)$/.test(getNodeName(node));
}
function getComputedStyle$1(element) {
	return getWindow(element).getComputedStyle(element);
}
function getNodeScroll(element) {
	if (isElement(element)) return {
		scrollLeft: element.scrollLeft,
		scrollTop: element.scrollTop
	};
	return {
		scrollLeft: element.scrollX,
		scrollTop: element.scrollY
	};
}
function getParentNode(node) {
	if (getNodeName(node) === "html") return node;
	const result = node.assignedSlot || node.parentNode || isShadowRoot(node) && node.host || getDocumentElement(node);
	return isShadowRoot(result) ? result.host : result;
}
function getNearestOverflowAncestor(node) {
	const parentNode = getParentNode(node);
	if (isLastTraversableNode(parentNode)) return node.ownerDocument ? node.ownerDocument.body : node.body;
	if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) return parentNode;
	return getNearestOverflowAncestor(parentNode);
}
function getOverflowAncestors(node, list, traverseIframes) {
	var _node$ownerDocument2;
	if (list === void 0) list = [];
	if (traverseIframes === void 0) traverseIframes = true;
	const scrollableAncestor = getNearestOverflowAncestor(node);
	const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
	const win = getWindow(scrollableAncestor);
	if (isBody) {
		const frameElement = getFrameElement(win);
		return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
	} else return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
}
function getFrameElement(win) {
	return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
}
//#endregion
//#region ../../node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
var min = Math.min;
var max = Math.max;
var round = Math.round;
var floor = Math.floor;
var createCoords = (v) => ({
	x: v,
	y: v
});
var oppositeSideMap = {
	left: "right",
	right: "left",
	bottom: "top",
	top: "bottom"
};
function clamp(start, value, end) {
	return max(start, min(value, end));
}
function evaluate(value, param) {
	return typeof value === "function" ? value(param) : value;
}
function getSide(placement) {
	return placement.split("-")[0];
}
function getAlignment(placement) {
	return placement.split("-")[1];
}
function getOppositeAxis(axis) {
	return axis === "x" ? "y" : "x";
}
function getAxisLength(axis) {
	return axis === "y" ? "height" : "width";
}
function getSideAxis(placement) {
	const firstChar = placement[0];
	return firstChar === "t" || firstChar === "b" ? "y" : "x";
}
function getAlignmentAxis(placement) {
	return getOppositeAxis(getSideAxis(placement));
}
function getAlignmentSides(placement, rects, rtl) {
	if (rtl === void 0) rtl = false;
	const alignment = getAlignment(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const length = getAxisLength(alignmentAxis);
	let mainAlignmentSide = alignmentAxis === "x" ? alignment === (rtl ? "end" : "start") ? "right" : "left" : alignment === "start" ? "bottom" : "top";
	if (rects.reference[length] > rects.floating[length]) mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
	return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
}
function getExpandedPlacements(placement) {
	const oppositePlacement = getOppositePlacement(placement);
	return [
		getOppositeAlignmentPlacement(placement),
		oppositePlacement,
		getOppositeAlignmentPlacement(oppositePlacement)
	];
}
function getOppositeAlignmentPlacement(placement) {
	return placement.includes("start") ? placement.replace("start", "end") : placement.replace("end", "start");
}
var lrPlacement = ["left", "right"];
var rlPlacement = ["right", "left"];
var tbPlacement = ["top", "bottom"];
var btPlacement = ["bottom", "top"];
function getSideList(side, isStart, rtl) {
	switch (side) {
		case "top":
		case "bottom":
			if (rtl) return isStart ? rlPlacement : lrPlacement;
			return isStart ? lrPlacement : rlPlacement;
		case "left":
		case "right": return isStart ? tbPlacement : btPlacement;
		default: return [];
	}
}
function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
	const alignment = getAlignment(placement);
	let list = getSideList(getSide(placement), direction === "start", rtl);
	if (alignment) {
		list = list.map((side) => side + "-" + alignment);
		if (flipAlignment) list = list.concat(list.map(getOppositeAlignmentPlacement));
	}
	return list;
}
function getOppositePlacement(placement) {
	const side = getSide(placement);
	return oppositeSideMap[side] + placement.slice(side.length);
}
function expandPaddingObject(padding) {
	return {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		...padding
	};
}
function getPaddingObject(padding) {
	return typeof padding !== "number" ? expandPaddingObject(padding) : {
		top: padding,
		right: padding,
		bottom: padding,
		left: padding
	};
}
function rectToClientRect(rect) {
	const { x, y, width, height } = rect;
	return {
		width,
		height,
		top: y,
		left: x,
		right: x + width,
		bottom: y + height,
		x,
		y
	};
}
/*!
* tabbable 6.4.0
* @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
*/
var candidateSelector = /* #__PURE__ */ [
	"input:not([inert]):not([inert] *)",
	"select:not([inert]):not([inert] *)",
	"textarea:not([inert]):not([inert] *)",
	"a[href]:not([inert]):not([inert] *)",
	"button:not([inert]):not([inert] *)",
	"[tabindex]:not(slot):not([inert]):not([inert] *)",
	"audio[controls]:not([inert]):not([inert] *)",
	"video[controls]:not([inert]):not([inert] *)",
	"[contenteditable]:not([contenteditable=\"false\"]):not([inert]):not([inert] *)",
	"details>summary:first-of-type:not([inert]):not([inert] *)",
	"details:not([inert]):not([inert] *)"
].join(",");
var NoElement = typeof Element === "undefined";
var matches = NoElement ? function() {} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
var getRootNode = !NoElement && Element.prototype.getRootNode ? function(element) {
	var _element$getRootNode;
	return element === null || element === void 0 ? void 0 : (_element$getRootNode = element.getRootNode) === null || _element$getRootNode === void 0 ? void 0 : _element$getRootNode.call(element);
} : function(element) {
	return element === null || element === void 0 ? void 0 : element.ownerDocument;
};
/**
* Determines if a node is inert or in an inert ancestor.
* @param {Node} [node]
* @param {boolean} [lookUp] If true and `node` is not inert, looks up at ancestors to
*  see if any of them are inert. If false, only `node` itself is considered.
* @returns {boolean} True if inert itself or by way of being in an inert ancestor.
*  False if `node` is falsy.
*/
var _isInert = function isInert(node, lookUp) {
	var _node$getAttribute;
	if (lookUp === void 0) lookUp = true;
	var inertAtt = node === null || node === void 0 ? void 0 : (_node$getAttribute = node.getAttribute) === null || _node$getAttribute === void 0 ? void 0 : _node$getAttribute.call(node, "inert");
	return inertAtt === "" || inertAtt === "true" || lookUp && node && (typeof node.closest === "function" ? node.closest("[inert]") : _isInert(node.parentNode));
};
/**
* Determines if a node's content is editable.
* @param {Element} [node]
* @returns True if it's content-editable; false if it's not or `node` is falsy.
*/
var isContentEditable = function isContentEditable(node) {
	var _node$getAttribute2;
	var attValue = node === null || node === void 0 ? void 0 : (_node$getAttribute2 = node.getAttribute) === null || _node$getAttribute2 === void 0 ? void 0 : _node$getAttribute2.call(node, "contenteditable");
	return attValue === "" || attValue === "true";
};
/**
* @param {Element} el container to check in
* @param {boolean} includeContainer add container to check
* @param {(node: Element) => boolean} filter filter candidates
* @returns {Element[]}
*/
var getCandidates = function getCandidates(el, includeContainer, filter) {
	if (_isInert(el)) return [];
	var candidates = Array.prototype.slice.apply(el.querySelectorAll(candidateSelector));
	if (includeContainer && matches.call(el, candidateSelector)) candidates.unshift(el);
	candidates = candidates.filter(filter);
	return candidates;
};
/**
* @callback GetShadowRoot
* @param {Element} element to check for shadow root
* @returns {ShadowRoot|boolean} ShadowRoot if available or boolean indicating if a shadowRoot is attached but not available.
*/
/**
* @callback ShadowRootFilter
* @param {Element} shadowHostNode the element which contains shadow content
* @returns {boolean} true if a shadow root could potentially contain valid candidates.
*/
/**
* @typedef {Object} CandidateScope
* @property {Element} scopeParent contains inner candidates
* @property {Element[]} candidates list of candidates found in the scope parent
*/
/**
* @typedef {Object} IterativeOptions
* @property {GetShadowRoot|boolean} getShadowRoot true if shadow support is enabled; falsy if not;
*  if a function, implies shadow support is enabled and either returns the shadow root of an element
*  or a boolean stating if it has an undisclosed shadow root
* @property {(node: Element) => boolean} filter filter candidates
* @property {boolean} flatten if true then result will flatten any CandidateScope into the returned list
* @property {ShadowRootFilter} shadowRootFilter filter shadow roots;
*/
/**
* @param {Element[]} elements list of element containers to match candidates from
* @param {boolean} includeContainer add container list to check
* @param {IterativeOptions} options
* @returns {Array.<Element|CandidateScope>}
*/
var _getCandidatesIteratively = function getCandidatesIteratively(elements, includeContainer, options) {
	var candidates = [];
	var elementsToCheck = Array.from(elements);
	while (elementsToCheck.length) {
		var element = elementsToCheck.shift();
		if (_isInert(element, false)) continue;
		if (element.tagName === "SLOT") {
			var assigned = element.assignedElements();
			var nestedCandidates = _getCandidatesIteratively(assigned.length ? assigned : element.children, true, options);
			if (options.flatten) candidates.push.apply(candidates, nestedCandidates);
			else candidates.push({
				scopeParent: element,
				candidates: nestedCandidates
			});
		} else {
			if (matches.call(element, candidateSelector) && options.filter(element) && (includeContainer || !elements.includes(element))) candidates.push(element);
			var shadowRoot = element.shadowRoot || typeof options.getShadowRoot === "function" && options.getShadowRoot(element);
			var validShadowRoot = !_isInert(shadowRoot, false) && (!options.shadowRootFilter || options.shadowRootFilter(element));
			if (shadowRoot && validShadowRoot) {
				var _nestedCandidates = _getCandidatesIteratively(shadowRoot === true ? element.children : shadowRoot.children, true, options);
				if (options.flatten) candidates.push.apply(candidates, _nestedCandidates);
				else candidates.push({
					scopeParent: element,
					candidates: _nestedCandidates
				});
			} else elementsToCheck.unshift.apply(elementsToCheck, element.children);
		}
	}
	return candidates;
};
/**
* @private
* Determines if the node has an explicitly specified `tabindex` attribute.
* @param {HTMLElement} node
* @returns {boolean} True if so; false if not.
*/
var hasTabIndex = function hasTabIndex(node) {
	return !isNaN(parseInt(node.getAttribute("tabindex"), 10));
};
/**
* Determine the tab index of a given node.
* @param {HTMLElement} node
* @returns {number} Tab order (negative, 0, or positive number).
* @throws {Error} If `node` is falsy.
*/
var getTabIndex = function getTabIndex(node) {
	if (!node) throw new Error("No node provided");
	if (node.tabIndex < 0) {
		if ((/^(AUDIO|VIDEO|DETAILS)$/.test(node.tagName) || isContentEditable(node)) && !hasTabIndex(node)) return 0;
	}
	return node.tabIndex;
};
/**
* Determine the tab index of a given node __for sort order purposes__.
* @param {HTMLElement} node
* @param {boolean} [isScope] True for a custom element with shadow root or slot that, by default,
*  has tabIndex -1, but needs to be sorted by document order in order for its content to be
*  inserted into the correct sort position.
* @returns {number} Tab order (negative, 0, or positive number).
*/
var getSortOrderTabIndex = function getSortOrderTabIndex(node, isScope) {
	var tabIndex = getTabIndex(node);
	if (tabIndex < 0 && isScope && !hasTabIndex(node)) return 0;
	return tabIndex;
};
var sortOrderedTabbables = function sortOrderedTabbables(a, b) {
	return a.tabIndex === b.tabIndex ? a.documentOrder - b.documentOrder : a.tabIndex - b.tabIndex;
};
var isInput = function isInput(node) {
	return node.tagName === "INPUT";
};
var isHiddenInput = function isHiddenInput(node) {
	return isInput(node) && node.type === "hidden";
};
var isDetailsWithSummary = function isDetailsWithSummary(node) {
	return node.tagName === "DETAILS" && Array.prototype.slice.apply(node.children).some(function(child) {
		return child.tagName === "SUMMARY";
	});
};
var getCheckedRadio = function getCheckedRadio(nodes, form) {
	for (var i = 0; i < nodes.length; i++) if (nodes[i].checked && nodes[i].form === form) return nodes[i];
};
var isTabbableRadio = function isTabbableRadio(node) {
	if (!node.name) return true;
	var radioScope = node.form || getRootNode(node);
	var queryRadios = function queryRadios(name) {
		return radioScope.querySelectorAll("input[type=\"radio\"][name=\"" + name + "\"]");
	};
	var radioSet;
	if (typeof window !== "undefined" && typeof window.CSS !== "undefined" && typeof window.CSS.escape === "function") radioSet = queryRadios(window.CSS.escape(node.name));
	else try {
		radioSet = queryRadios(node.name);
	} catch (err) {
		console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", err.message);
		return false;
	}
	var checked = getCheckedRadio(radioSet, node.form);
	return !checked || checked === node;
};
var isRadio = function isRadio(node) {
	return isInput(node) && node.type === "radio";
};
var isNonTabbableRadio = function isNonTabbableRadio(node) {
	return isRadio(node) && !isTabbableRadio(node);
};
var isNodeAttached = function isNodeAttached(node) {
	var _nodeRoot;
	var nodeRoot = node && getRootNode(node);
	var nodeRootHost = (_nodeRoot = nodeRoot) === null || _nodeRoot === void 0 ? void 0 : _nodeRoot.host;
	var attached = false;
	if (nodeRoot && nodeRoot !== node) {
		var _nodeRootHost, _nodeRootHost$ownerDo, _node$ownerDocument;
		attached = !!((_nodeRootHost = nodeRootHost) !== null && _nodeRootHost !== void 0 && (_nodeRootHost$ownerDo = _nodeRootHost.ownerDocument) !== null && _nodeRootHost$ownerDo !== void 0 && _nodeRootHost$ownerDo.contains(nodeRootHost) || node !== null && node !== void 0 && (_node$ownerDocument = node.ownerDocument) !== null && _node$ownerDocument !== void 0 && _node$ownerDocument.contains(node));
		while (!attached && nodeRootHost) {
			var _nodeRoot2, _nodeRootHost2, _nodeRootHost2$ownerD;
			nodeRoot = getRootNode(nodeRootHost);
			nodeRootHost = (_nodeRoot2 = nodeRoot) === null || _nodeRoot2 === void 0 ? void 0 : _nodeRoot2.host;
			attached = !!((_nodeRootHost2 = nodeRootHost) !== null && _nodeRootHost2 !== void 0 && (_nodeRootHost2$ownerD = _nodeRootHost2.ownerDocument) !== null && _nodeRootHost2$ownerD !== void 0 && _nodeRootHost2$ownerD.contains(nodeRootHost));
		}
	}
	return attached;
};
var isZeroArea = function isZeroArea(node) {
	var _node$getBoundingClie = node.getBoundingClientRect(), width = _node$getBoundingClie.width, height = _node$getBoundingClie.height;
	return width === 0 && height === 0;
};
var isHidden = function isHidden(node, _ref) {
	var displayCheck = _ref.displayCheck, getShadowRoot = _ref.getShadowRoot;
	if (displayCheck === "full-native") {
		if ("checkVisibility" in node) return !node.checkVisibility({
			checkOpacity: false,
			opacityProperty: false,
			contentVisibilityAuto: true,
			visibilityProperty: true,
			checkVisibilityCSS: true
		});
	}
	if (getComputedStyle(node).visibility === "hidden") return true;
	var nodeUnderDetails = matches.call(node, "details>summary:first-of-type") ? node.parentElement : node;
	if (matches.call(nodeUnderDetails, "details:not([open]) *")) return true;
	if (!displayCheck || displayCheck === "full" || displayCheck === "full-native" || displayCheck === "legacy-full") {
		if (typeof getShadowRoot === "function") {
			var originalNode = node;
			while (node) {
				var parentElement = node.parentElement;
				var rootNode = getRootNode(node);
				if (parentElement && !parentElement.shadowRoot && getShadowRoot(parentElement) === true) return isZeroArea(node);
				else if (node.assignedSlot) node = node.assignedSlot;
				else if (!parentElement && rootNode !== node.ownerDocument) node = rootNode.host;
				else node = parentElement;
			}
			node = originalNode;
		}
		if (isNodeAttached(node)) return !node.getClientRects().length;
		if (displayCheck !== "legacy-full") return true;
	} else if (displayCheck === "non-zero-area") return isZeroArea(node);
	return false;
};
var isDisabledFromFieldset = function isDisabledFromFieldset(node) {
	if (/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(node.tagName)) {
		var parentNode = node.parentElement;
		while (parentNode) {
			if (parentNode.tagName === "FIELDSET" && parentNode.disabled) {
				for (var i = 0; i < parentNode.children.length; i++) {
					var child = parentNode.children.item(i);
					if (child.tagName === "LEGEND") return matches.call(parentNode, "fieldset[disabled] *") ? true : !child.contains(node);
				}
				return true;
			}
			parentNode = parentNode.parentElement;
		}
	}
	return false;
};
var isNodeMatchingSelectorFocusable = function isNodeMatchingSelectorFocusable(options, node) {
	if (node.disabled || isHiddenInput(node) || isHidden(node, options) || isDetailsWithSummary(node) || isDisabledFromFieldset(node)) return false;
	return true;
};
var isNodeMatchingSelectorTabbable = function isNodeMatchingSelectorTabbable(options, node) {
	if (isNonTabbableRadio(node) || getTabIndex(node) < 0 || !isNodeMatchingSelectorFocusable(options, node)) return false;
	return true;
};
var isShadowRootTabbable = function isShadowRootTabbable(shadowHostNode) {
	var tabIndex = parseInt(shadowHostNode.getAttribute("tabindex"), 10);
	if (isNaN(tabIndex) || tabIndex >= 0) return true;
	return false;
};
/**
* @param {Array.<Element|CandidateScope>} candidates
* @returns Element[]
*/
var _sortByOrder = function sortByOrder(candidates) {
	var regularTabbables = [];
	var orderedTabbables = [];
	candidates.forEach(function(item, i) {
		var isScope = !!item.scopeParent;
		var element = isScope ? item.scopeParent : item;
		var candidateTabindex = getSortOrderTabIndex(element, isScope);
		var elements = isScope ? _sortByOrder(item.candidates) : element;
		if (candidateTabindex === 0) isScope ? regularTabbables.push.apply(regularTabbables, elements) : regularTabbables.push(element);
		else orderedTabbables.push({
			documentOrder: i,
			tabIndex: candidateTabindex,
			item,
			isScope,
			content: elements
		});
	});
	return orderedTabbables.sort(sortOrderedTabbables).reduce(function(acc, sortable) {
		sortable.isScope ? acc.push.apply(acc, sortable.content) : acc.push(sortable.content);
		return acc;
	}, []).concat(regularTabbables);
};
var tabbable = function tabbable(container, options) {
	options = options || {};
	var candidates;
	if (options.getShadowRoot) candidates = _getCandidatesIteratively([container], options.includeContainer, {
		filter: isNodeMatchingSelectorTabbable.bind(null, options),
		flatten: false,
		getShadowRoot: options.getShadowRoot,
		shadowRootFilter: isShadowRootTabbable
	});
	else candidates = getCandidates(container, options.includeContainer, isNodeMatchingSelectorTabbable.bind(null, options));
	return _sortByOrder(candidates);
};
//#endregion
//#region ../../node_modules/@floating-ui/react/dist/floating-ui.react.utils.mjs
function getPlatform() {
	const uaData = navigator.userAgentData;
	if (uaData != null && uaData.platform) return uaData.platform;
	return navigator.platform;
}
function getUserAgent() {
	const uaData = navigator.userAgentData;
	if (uaData && Array.isArray(uaData.brands)) return uaData.brands.map((_ref) => {
		let { brand, version } = _ref;
		return brand + "/" + version;
	}).join(" ");
	return navigator.userAgent;
}
function isSafari() {
	return /apple/i.test(navigator.vendor);
}
function isMac() {
	return getPlatform().toLowerCase().startsWith("mac") && !navigator.maxTouchPoints;
}
function isJSDOM() {
	return getUserAgent().includes("jsdom/");
}
var FOCUSABLE_ATTRIBUTE$1 = "data-floating-ui-focusable";
var TYPEABLE_SELECTOR = "input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])";
function activeElement(doc) {
	let activeElement = doc.activeElement;
	while (((_activeElement = activeElement) == null || (_activeElement = _activeElement.shadowRoot) == null ? void 0 : _activeElement.activeElement) != null) {
		var _activeElement;
		activeElement = activeElement.shadowRoot.activeElement;
	}
	return activeElement;
}
function contains(parent, child) {
	if (!parent || !child) return false;
	const rootNode = child.getRootNode == null ? void 0 : child.getRootNode();
	if (parent.contains(child)) return true;
	if (rootNode && isShadowRoot(rootNode)) {
		let next = child;
		while (next) {
			if (parent === next) return true;
			next = next.parentNode || next.host;
		}
	}
	return false;
}
function getTarget(event) {
	if ("composedPath" in event) return event.composedPath()[0];
	return event.target;
}
function isEventTargetWithin(event, node) {
	if (node == null) return false;
	if ("composedPath" in event) return event.composedPath().includes(node);
	const e = event;
	return e.target != null && node.contains(e.target);
}
function isRootElement(element) {
	return element.matches("html,body");
}
function getDocument(node) {
	return (node == null ? void 0 : node.ownerDocument) || document;
}
function isTypeableElement(element) {
	return isHTMLElement(element) && element.matches(TYPEABLE_SELECTOR);
}
function matchesFocusVisible(element) {
	if (!element || isJSDOM()) return true;
	try {
		return element.matches(":focus-visible");
	} catch (_e) {
		return true;
	}
}
function getFloatingFocusElement(floatingElement) {
	if (!floatingElement) return null;
	return floatingElement.hasAttribute(FOCUSABLE_ATTRIBUTE$1) ? floatingElement : floatingElement.querySelector("[data-floating-ui-focusable]") || floatingElement;
}
function getNodeChildren(nodes, id, onlyOpenChildren) {
	if (onlyOpenChildren === void 0) onlyOpenChildren = true;
	return nodes.filter((node) => {
		var _node$context;
		return node.parentId === id && (!onlyOpenChildren || ((_node$context = node.context) == null ? void 0 : _node$context.open));
	}).flatMap((child) => [child, ...getNodeChildren(nodes, child.id, onlyOpenChildren)]);
}
function isReactEvent(event) {
	return "nativeEvent" in event;
}
function isMouseLikePointerType(pointerType, strict) {
	const values = ["mouse", "pen"];
	if (!strict) values.push("", void 0);
	return values.includes(pointerType);
}
var index$1 = typeof document !== "undefined" ? useLayoutEffect : function noop() {};
var SafeReact$1 = { ...React$1 };
function useLatestRef$1(value) {
	const ref = React$1.useRef(value);
	index$1(() => {
		ref.current = value;
	});
	return ref;
}
var useSafeInsertionEffect = SafeReact$1.useInsertionEffect || ((fn) => fn());
function useEffectEvent(callback) {
	const ref = React$1.useRef(() => {
		if (process.env.NODE_ENV !== "production") throw new Error("Cannot call an event handler while rendering.");
	});
	useSafeInsertionEffect(() => {
		ref.current = callback;
	});
	return React$1.useCallback(function() {
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		return ref.current == null ? void 0 : ref.current(...args);
	}, []);
}
var getTabbableOptions = () => ({
	getShadowRoot: true,
	displayCheck: typeof ResizeObserver === "function" && ResizeObserver.toString().includes("[native code]") ? "full" : "none"
});
function getTabbableIn(container, dir) {
	const list = tabbable(container, getTabbableOptions());
	const len = list.length;
	if (len === 0) return;
	const active = activeElement(getDocument(container));
	const index = list.indexOf(active);
	return list[index === -1 ? dir === 1 ? 0 : len - 1 : index + dir];
}
function getNextTabbable(referenceElement) {
	return getTabbableIn(getDocument(referenceElement).body, 1) || referenceElement;
}
function getPreviousTabbable(referenceElement) {
	return getTabbableIn(getDocument(referenceElement).body, -1) || referenceElement;
}
function isOutsideEvent(event, container) {
	const containerElement = container || event.currentTarget;
	const relatedTarget = event.relatedTarget;
	return !relatedTarget || !contains(containerElement, relatedTarget);
}
function disableFocusInside(container) {
	tabbable(container, getTabbableOptions()).forEach((element) => {
		element.dataset.tabindex = element.getAttribute("tabindex") || "";
		element.setAttribute("tabindex", "-1");
	});
}
function enableFocusInside(container) {
	container.querySelectorAll("[data-tabindex]").forEach((element) => {
		const tabindex = element.dataset.tabindex;
		delete element.dataset.tabindex;
		if (tabindex) element.setAttribute("tabindex", tabindex);
		else element.removeAttribute("tabindex");
	});
}
//#endregion
//#region ../../node_modules/@floating-ui/core/dist/floating-ui.core.mjs
function computeCoordsFromPlacement(_ref, placement, rtl) {
	let { reference, floating } = _ref;
	const sideAxis = getSideAxis(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const alignLength = getAxisLength(alignmentAxis);
	const side = getSide(placement);
	const isVertical = sideAxis === "y";
	const commonX = reference.x + reference.width / 2 - floating.width / 2;
	const commonY = reference.y + reference.height / 2 - floating.height / 2;
	const commonAlign = reference[alignLength] / 2 - floating[alignLength] / 2;
	let coords;
	switch (side) {
		case "top":
			coords = {
				x: commonX,
				y: reference.y - floating.height
			};
			break;
		case "bottom":
			coords = {
				x: commonX,
				y: reference.y + reference.height
			};
			break;
		case "right":
			coords = {
				x: reference.x + reference.width,
				y: commonY
			};
			break;
		case "left":
			coords = {
				x: reference.x - floating.width,
				y: commonY
			};
			break;
		default: coords = {
			x: reference.x,
			y: reference.y
		};
	}
	switch (getAlignment(placement)) {
		case "start":
			coords[alignmentAxis] -= commonAlign * (rtl && isVertical ? -1 : 1);
			break;
		case "end":
			coords[alignmentAxis] += commonAlign * (rtl && isVertical ? -1 : 1);
			break;
	}
	return coords;
}
/**
* Resolves with an object of overflow side offsets that determine how much the
* element is overflowing a given clipping boundary on each side.
* - positive = overflowing the boundary by that number of pixels
* - negative = how many pixels left before it will overflow
* - 0 = lies flush with the boundary
* @see https://floating-ui.com/docs/detectOverflow
*/
async function detectOverflow(state, options) {
	var _await$platform$isEle;
	if (options === void 0) options = {};
	const { x, y, platform, rects, elements, strategy } = state;
	const { boundary = "clippingAncestors", rootBoundary = "viewport", elementContext = "floating", altBoundary = false, padding = 0 } = evaluate(options, state);
	const paddingObject = getPaddingObject(padding);
	const element = elements[altBoundary ? elementContext === "floating" ? "reference" : "floating" : elementContext];
	const clippingClientRect = rectToClientRect(await platform.getClippingRect({
		element: ((_await$platform$isEle = await (platform.isElement == null ? void 0 : platform.isElement(element))) != null ? _await$platform$isEle : true) ? element : element.contextElement || await (platform.getDocumentElement == null ? void 0 : platform.getDocumentElement(elements.floating)),
		boundary,
		rootBoundary,
		strategy
	}));
	const rect = elementContext === "floating" ? {
		x,
		y,
		width: rects.floating.width,
		height: rects.floating.height
	} : rects.reference;
	const offsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(elements.floating));
	const offsetScale = await (platform.isElement == null ? void 0 : platform.isElement(offsetParent)) ? await (platform.getScale == null ? void 0 : platform.getScale(offsetParent)) || {
		x: 1,
		y: 1
	} : {
		x: 1,
		y: 1
	};
	const elementClientRect = rectToClientRect(platform.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform.convertOffsetParentRelativeRectToViewportRelativeRect({
		elements,
		rect,
		offsetParent,
		strategy
	}) : rect);
	return {
		top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
		bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
		left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
		right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
	};
}
var MAX_RESET_COUNT = 50;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*
* This export does not have any `platform` interface logic. You will need to
* write one for the platform you are using Floating UI with.
*/
var computePosition$1 = async (reference, floating, config) => {
	const { placement = "bottom", strategy = "absolute", middleware = [], platform } = config;
	const platformWithDetectOverflow = platform.detectOverflow ? platform : {
		...platform,
		detectOverflow
	};
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(floating));
	let rects = await platform.getElementRects({
		reference,
		floating,
		strategy
	});
	let { x, y } = computeCoordsFromPlacement(rects, placement, rtl);
	let statefulPlacement = placement;
	let resetCount = 0;
	const middlewareData = {};
	for (let i = 0; i < middleware.length; i++) {
		const currentMiddleware = middleware[i];
		if (!currentMiddleware) continue;
		const { name, fn } = currentMiddleware;
		const { x: nextX, y: nextY, data, reset } = await fn({
			x,
			y,
			initialPlacement: placement,
			placement: statefulPlacement,
			strategy,
			middlewareData,
			rects,
			platform: platformWithDetectOverflow,
			elements: {
				reference,
				floating
			}
		});
		x = nextX != null ? nextX : x;
		y = nextY != null ? nextY : y;
		middlewareData[name] = {
			...middlewareData[name],
			...data
		};
		if (reset && resetCount < MAX_RESET_COUNT) {
			resetCount++;
			if (typeof reset === "object") {
				if (reset.placement) statefulPlacement = reset.placement;
				if (reset.rects) rects = reset.rects === true ? await platform.getElementRects({
					reference,
					floating,
					strategy
				}) : reset.rects;
				({x, y} = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
			}
			i = -1;
		}
	}
	return {
		x,
		y,
		placement: statefulPlacement,
		strategy,
		middlewareData
	};
};
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$3 = (options) => ({
	name: "arrow",
	options,
	async fn(state) {
		const { x, y, placement, rects, platform, elements, middlewareData } = state;
		const { element, padding = 0 } = evaluate(options, state) || {};
		if (element == null) return {};
		const paddingObject = getPaddingObject(padding);
		const coords = {
			x,
			y
		};
		const axis = getAlignmentAxis(placement);
		const length = getAxisLength(axis);
		const arrowDimensions = await platform.getDimensions(element);
		const isYAxis = axis === "y";
		const minProp = isYAxis ? "top" : "left";
		const maxProp = isYAxis ? "bottom" : "right";
		const clientProp = isYAxis ? "clientHeight" : "clientWidth";
		const endDiff = rects.reference[length] + rects.reference[axis] - coords[axis] - rects.floating[length];
		const startDiff = coords[axis] - rects.reference[axis];
		const arrowOffsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(element));
		let clientSize = arrowOffsetParent ? arrowOffsetParent[clientProp] : 0;
		if (!clientSize || !await (platform.isElement == null ? void 0 : platform.isElement(arrowOffsetParent))) clientSize = elements.floating[clientProp] || rects.floating[length];
		const centerToReference = endDiff / 2 - startDiff / 2;
		const largestPossiblePadding = clientSize / 2 - arrowDimensions[length] / 2 - 1;
		const minPadding = min(paddingObject[minProp], largestPossiblePadding);
		const maxPadding = min(paddingObject[maxProp], largestPossiblePadding);
		const min$1 = minPadding;
		const max = clientSize - arrowDimensions[length] - maxPadding;
		const center = clientSize / 2 - arrowDimensions[length] / 2 + centerToReference;
		const offset = clamp(min$1, center, max);
		const shouldAddOffset = !middlewareData.arrow && getAlignment(placement) != null && center !== offset && rects.reference[length] / 2 - (center < min$1 ? minPadding : maxPadding) - arrowDimensions[length] / 2 < 0;
		const alignmentOffset = shouldAddOffset ? center < min$1 ? center - min$1 : center - max : 0;
		return {
			[axis]: coords[axis] + alignmentOffset,
			data: {
				[axis]: offset,
				centerOffset: center - offset - alignmentOffset,
				...shouldAddOffset && { alignmentOffset }
			},
			reset: shouldAddOffset
		};
	}
});
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "flip",
		options,
		async fn(state) {
			var _middlewareData$arrow, _middlewareData$flip;
			const { placement, middlewareData, rects, initialPlacement, platform, elements } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true, fallbackPlacements: specifiedFallbackPlacements, fallbackStrategy = "bestFit", fallbackAxisSideDirection = "none", flipAlignment = true, ...detectOverflowOptions } = evaluate(options, state);
			if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			const side = getSide(placement);
			const initialSideAxis = getSideAxis(initialPlacement);
			const isBasePlacement = getSide(initialPlacement) === initialPlacement;
			const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
			const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [getOppositePlacement(initialPlacement)] : getExpandedPlacements(initialPlacement));
			const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== "none";
			if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) fallbackPlacements.push(...getOppositeAxisPlacements(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
			const placements = [initialPlacement, ...fallbackPlacements];
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const overflows = [];
			let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
			if (checkMainAxis) overflows.push(overflow[side]);
			if (checkCrossAxis) {
				const sides = getAlignmentSides(placement, rects, rtl);
				overflows.push(overflow[sides[0]], overflow[sides[1]]);
			}
			overflowsData = [...overflowsData, {
				placement,
				overflows
			}];
			if (!overflows.every((side) => side <= 0)) {
				var _middlewareData$flip2, _overflowsData$filter;
				const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
				const nextPlacement = placements[nextIndex];
				if (nextPlacement) {
					if (!(checkCrossAxis === "alignment" ? initialSideAxis !== getSideAxis(nextPlacement) : false) || overflowsData.every((d) => getSideAxis(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) return {
						data: {
							index: nextIndex,
							overflows: overflowsData
						},
						reset: { placement: nextPlacement }
					};
				}
				let resetPlacement = (_overflowsData$filter = overflowsData.filter((d) => d.overflows[0] <= 0).sort((a, b) => a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
				if (!resetPlacement) switch (fallbackStrategy) {
					case "bestFit": {
						var _overflowsData$filter2;
						const placement = (_overflowsData$filter2 = overflowsData.filter((d) => {
							if (hasFallbackAxisSideDirection) {
								const currentSideAxis = getSideAxis(d.placement);
								return currentSideAxis === initialSideAxis || currentSideAxis === "y";
							}
							return true;
						}).map((d) => [d.placement, d.overflows.filter((overflow) => overflow > 0).reduce((acc, overflow) => acc + overflow, 0)]).sort((a, b) => a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
						if (placement) resetPlacement = placement;
						break;
					}
					case "initialPlacement":
						resetPlacement = initialPlacement;
						break;
				}
				if (placement !== resetPlacement) return { reset: { placement: resetPlacement } };
			}
			return {};
		}
	};
};
var originSides = /*#__PURE__*/ new Set(["left", "top"]);
async function convertValueToCoords(state, options) {
	const { placement, platform, elements } = state;
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
	const side = getSide(placement);
	const alignment = getAlignment(placement);
	const isVertical = getSideAxis(placement) === "y";
	const mainAxisMulti = originSides.has(side) ? -1 : 1;
	const crossAxisMulti = rtl && isVertical ? -1 : 1;
	const rawValue = evaluate(options, state);
	let { mainAxis, crossAxis, alignmentAxis } = typeof rawValue === "number" ? {
		mainAxis: rawValue,
		crossAxis: 0,
		alignmentAxis: null
	} : {
		mainAxis: rawValue.mainAxis || 0,
		crossAxis: rawValue.crossAxis || 0,
		alignmentAxis: rawValue.alignmentAxis
	};
	if (alignment && typeof alignmentAxis === "number") crossAxis = alignment === "end" ? alignmentAxis * -1 : alignmentAxis;
	return isVertical ? {
		x: crossAxis * crossAxisMulti,
		y: mainAxis * mainAxisMulti
	} : {
		x: mainAxis * mainAxisMulti,
		y: crossAxis * crossAxisMulti
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$2 = function(options) {
	if (options === void 0) options = 0;
	return {
		name: "offset",
		options,
		async fn(state) {
			var _middlewareData$offse, _middlewareData$arrow;
			const { x, y, placement, middlewareData } = state;
			const diffCoords = await convertValueToCoords(state, options);
			if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			return {
				x: x + diffCoords.x,
				y: y + diffCoords.y,
				data: {
					...diffCoords,
					placement
				}
			};
		}
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "shift",
		options,
		async fn(state) {
			const { x, y, placement, platform } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = false, limiter = { fn: (_ref) => {
				let { x, y } = _ref;
				return {
					x,
					y
				};
			} }, ...detectOverflowOptions } = evaluate(options, state);
			const coords = {
				x,
				y
			};
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const crossAxis = getSideAxis(getSide(placement));
			const mainAxis = getOppositeAxis(crossAxis);
			let mainAxisCoord = coords[mainAxis];
			let crossAxisCoord = coords[crossAxis];
			if (checkMainAxis) {
				const minSide = mainAxis === "y" ? "top" : "left";
				const maxSide = mainAxis === "y" ? "bottom" : "right";
				const min = mainAxisCoord + overflow[minSide];
				const max = mainAxisCoord - overflow[maxSide];
				mainAxisCoord = clamp(min, mainAxisCoord, max);
			}
			if (checkCrossAxis) {
				const minSide = crossAxis === "y" ? "top" : "left";
				const maxSide = crossAxis === "y" ? "bottom" : "right";
				const min = crossAxisCoord + overflow[minSide];
				const max = crossAxisCoord - overflow[maxSide];
				crossAxisCoord = clamp(min, crossAxisCoord, max);
			}
			const limitedCoords = limiter.fn({
				...state,
				[mainAxis]: mainAxisCoord,
				[crossAxis]: crossAxisCoord
			});
			return {
				...limitedCoords,
				data: {
					x: limitedCoords.x - x,
					y: limitedCoords.y - y,
					enabled: {
						[mainAxis]: checkMainAxis,
						[crossAxis]: checkCrossAxis
					}
				}
			};
		}
	};
};
//#endregion
//#region ../../node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
function getCssDimensions(element) {
	const css = getComputedStyle$1(element);
	let width = parseFloat(css.width) || 0;
	let height = parseFloat(css.height) || 0;
	const hasOffset = isHTMLElement(element);
	const offsetWidth = hasOffset ? element.offsetWidth : width;
	const offsetHeight = hasOffset ? element.offsetHeight : height;
	const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
	if (shouldFallback) {
		width = offsetWidth;
		height = offsetHeight;
	}
	return {
		width,
		height,
		$: shouldFallback
	};
}
function unwrapElement(element) {
	return !isElement(element) ? element.contextElement : element;
}
function getScale(element) {
	const domElement = unwrapElement(element);
	if (!isHTMLElement(domElement)) return createCoords(1);
	const rect = domElement.getBoundingClientRect();
	const { width, height, $ } = getCssDimensions(domElement);
	let x = ($ ? round(rect.width) : rect.width) / width;
	let y = ($ ? round(rect.height) : rect.height) / height;
	if (!x || !Number.isFinite(x)) x = 1;
	if (!y || !Number.isFinite(y)) y = 1;
	return {
		x,
		y
	};
}
var noOffsets = /*#__PURE__*/ createCoords(0);
function getVisualOffsets(element) {
	const win = getWindow(element);
	if (!isWebKit() || !win.visualViewport) return noOffsets;
	return {
		x: win.visualViewport.offsetLeft,
		y: win.visualViewport.offsetTop
	};
}
function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
	if (isFixed === void 0) isFixed = false;
	if (!floatingOffsetParent || isFixed && floatingOffsetParent !== getWindow(element)) return false;
	return isFixed;
}
function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
	if (includeScale === void 0) includeScale = false;
	if (isFixedStrategy === void 0) isFixedStrategy = false;
	const clientRect = element.getBoundingClientRect();
	const domElement = unwrapElement(element);
	let scale = createCoords(1);
	if (includeScale) if (offsetParent) {
		if (isElement(offsetParent)) scale = getScale(offsetParent);
	} else scale = getScale(element);
	const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
	let x = (clientRect.left + visualOffsets.x) / scale.x;
	let y = (clientRect.top + visualOffsets.y) / scale.y;
	let width = clientRect.width / scale.x;
	let height = clientRect.height / scale.y;
	if (domElement) {
		const win = getWindow(domElement);
		const offsetWin = offsetParent && isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
		let currentWin = win;
		let currentIFrame = getFrameElement(currentWin);
		while (currentIFrame && offsetParent && offsetWin !== currentWin) {
			const iframeScale = getScale(currentIFrame);
			const iframeRect = currentIFrame.getBoundingClientRect();
			const css = getComputedStyle$1(currentIFrame);
			const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
			const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
			x *= iframeScale.x;
			y *= iframeScale.y;
			width *= iframeScale.x;
			height *= iframeScale.y;
			x += left;
			y += top;
			currentWin = getWindow(currentIFrame);
			currentIFrame = getFrameElement(currentWin);
		}
	}
	return rectToClientRect({
		width,
		height,
		x,
		y
	});
}
function getWindowScrollBarX(element, rect) {
	const leftScroll = getNodeScroll(element).scrollLeft;
	if (!rect) return getBoundingClientRect(getDocumentElement(element)).left + leftScroll;
	return rect.left + leftScroll;
}
function getHTMLOffset(documentElement, scroll) {
	const htmlRect = documentElement.getBoundingClientRect();
	return {
		x: htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect),
		y: htmlRect.top + scroll.scrollTop
	};
}
function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
	let { elements, rect, offsetParent, strategy } = _ref;
	const isFixed = strategy === "fixed";
	const documentElement = getDocumentElement(offsetParent);
	const topLayer = elements ? isTopLayer(elements.floating) : false;
	if (offsetParent === documentElement || topLayer && isFixed) return rect;
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	let scale = createCoords(1);
	const offsets = createCoords(0);
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent);
			scale = getScale(offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		}
	}
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		width: rect.width * scale.x,
		height: rect.height * scale.y,
		x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
		y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
	};
}
function getClientRects(element) {
	return Array.from(element.getClientRects());
}
function getDocumentRect(element) {
	const html = getDocumentElement(element);
	const scroll = getNodeScroll(element);
	const body = element.ownerDocument.body;
	const width = max(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
	const height = max(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
	let x = -scroll.scrollLeft + getWindowScrollBarX(element);
	const y = -scroll.scrollTop;
	if (getComputedStyle$1(body).direction === "rtl") x += max(html.clientWidth, body.clientWidth) - width;
	return {
		width,
		height,
		x,
		y
	};
}
var SCROLLBAR_MAX = 25;
function getViewportRect(element, strategy) {
	const win = getWindow(element);
	const html = getDocumentElement(element);
	const visualViewport = win.visualViewport;
	let width = html.clientWidth;
	let height = html.clientHeight;
	let x = 0;
	let y = 0;
	if (visualViewport) {
		width = visualViewport.width;
		height = visualViewport.height;
		const visualViewportBased = isWebKit();
		if (!visualViewportBased || visualViewportBased && strategy === "fixed") {
			x = visualViewport.offsetLeft;
			y = visualViewport.offsetTop;
		}
	}
	const windowScrollbarX = getWindowScrollBarX(html);
	if (windowScrollbarX <= 0) {
		const doc = html.ownerDocument;
		const body = doc.body;
		const bodyStyles = getComputedStyle(body);
		const bodyMarginInline = doc.compatMode === "CSS1Compat" ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
		const clippingStableScrollbarWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
		if (clippingStableScrollbarWidth <= SCROLLBAR_MAX) width -= clippingStableScrollbarWidth;
	} else if (windowScrollbarX <= SCROLLBAR_MAX) width += windowScrollbarX;
	return {
		width,
		height,
		x,
		y
	};
}
function getInnerBoundingClientRect(element, strategy) {
	const clientRect = getBoundingClientRect(element, true, strategy === "fixed");
	const top = clientRect.top + element.clientTop;
	const left = clientRect.left + element.clientLeft;
	const scale = isHTMLElement(element) ? getScale(element) : createCoords(1);
	return {
		width: element.clientWidth * scale.x,
		height: element.clientHeight * scale.y,
		x: left * scale.x,
		y: top * scale.y
	};
}
function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
	let rect;
	if (clippingAncestor === "viewport") rect = getViewportRect(element, strategy);
	else if (clippingAncestor === "document") rect = getDocumentRect(getDocumentElement(element));
	else if (isElement(clippingAncestor)) rect = getInnerBoundingClientRect(clippingAncestor, strategy);
	else {
		const visualOffsets = getVisualOffsets(element);
		rect = {
			x: clippingAncestor.x - visualOffsets.x,
			y: clippingAncestor.y - visualOffsets.y,
			width: clippingAncestor.width,
			height: clippingAncestor.height
		};
	}
	return rectToClientRect(rect);
}
function hasFixedPositionAncestor(element, stopNode) {
	const parentNode = getParentNode(element);
	if (parentNode === stopNode || !isElement(parentNode) || isLastTraversableNode(parentNode)) return false;
	return getComputedStyle$1(parentNode).position === "fixed" || hasFixedPositionAncestor(parentNode, stopNode);
}
function getClippingElementAncestors(element, cache) {
	const cachedResult = cache.get(element);
	if (cachedResult) return cachedResult;
	let result = getOverflowAncestors(element, [], false).filter((el) => isElement(el) && getNodeName(el) !== "body");
	let currentContainingBlockComputedStyle = null;
	const elementIsFixed = getComputedStyle$1(element).position === "fixed";
	let currentNode = elementIsFixed ? getParentNode(element) : element;
	while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
		const computedStyle = getComputedStyle$1(currentNode);
		const currentNodeIsContaining = isContainingBlock(currentNode);
		if (!currentNodeIsContaining && computedStyle.position === "fixed") currentContainingBlockComputedStyle = null;
		if (elementIsFixed ? !currentNodeIsContaining && !currentContainingBlockComputedStyle : !currentNodeIsContaining && computedStyle.position === "static" && !!currentContainingBlockComputedStyle && (currentContainingBlockComputedStyle.position === "absolute" || currentContainingBlockComputedStyle.position === "fixed") || isOverflowElement(currentNode) && !currentNodeIsContaining && hasFixedPositionAncestor(element, currentNode)) result = result.filter((ancestor) => ancestor !== currentNode);
		else currentContainingBlockComputedStyle = computedStyle;
		currentNode = getParentNode(currentNode);
	}
	cache.set(element, result);
	return result;
}
function getClippingRect(_ref) {
	let { element, boundary, rootBoundary, strategy } = _ref;
	const clippingAncestors = [...boundary === "clippingAncestors" ? isTopLayer(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary), rootBoundary];
	const firstRect = getClientRectFromClippingAncestor(element, clippingAncestors[0], strategy);
	let top = firstRect.top;
	let right = firstRect.right;
	let bottom = firstRect.bottom;
	let left = firstRect.left;
	for (let i = 1; i < clippingAncestors.length; i++) {
		const rect = getClientRectFromClippingAncestor(element, clippingAncestors[i], strategy);
		top = max(rect.top, top);
		right = min(rect.right, right);
		bottom = min(rect.bottom, bottom);
		left = max(rect.left, left);
	}
	return {
		width: right - left,
		height: bottom - top,
		x: left,
		y: top
	};
}
function getDimensions(element) {
	const { width, height } = getCssDimensions(element);
	return {
		width,
		height
	};
}
function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	const documentElement = getDocumentElement(offsetParent);
	const isFixed = strategy === "fixed";
	const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	const offsets = createCoords(0);
	function setLeftRTLScrollbarOffset() {
		offsets.x = getWindowScrollBarX(documentElement);
	}
	if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		} else if (documentElement) setLeftRTLScrollbarOffset();
	}
	if (isFixed && !isOffsetParentAnElement && documentElement) setLeftRTLScrollbarOffset();
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		x: rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x,
		y: rect.top + scroll.scrollTop - offsets.y - htmlOffset.y,
		width: rect.width,
		height: rect.height
	};
}
function isStaticPositioned(element) {
	return getComputedStyle$1(element).position === "static";
}
function getTrueOffsetParent(element, polyfill) {
	if (!isHTMLElement(element) || getComputedStyle$1(element).position === "fixed") return null;
	if (polyfill) return polyfill(element);
	let rawOffsetParent = element.offsetParent;
	if (getDocumentElement(element) === rawOffsetParent) rawOffsetParent = rawOffsetParent.ownerDocument.body;
	return rawOffsetParent;
}
function getOffsetParent(element, polyfill) {
	const win = getWindow(element);
	if (isTopLayer(element)) return win;
	if (!isHTMLElement(element)) {
		let svgOffsetParent = getParentNode(element);
		while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
			if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) return svgOffsetParent;
			svgOffsetParent = getParentNode(svgOffsetParent);
		}
		return win;
	}
	let offsetParent = getTrueOffsetParent(element, polyfill);
	while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) offsetParent = getTrueOffsetParent(offsetParent, polyfill);
	if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) return win;
	return offsetParent || getContainingBlock(element) || win;
}
var getElementRects = async function(data) {
	const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
	const getDimensionsFn = this.getDimensions;
	const floatingDimensions = await getDimensionsFn(data.floating);
	return {
		reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
		floating: {
			x: 0,
			y: 0,
			width: floatingDimensions.width,
			height: floatingDimensions.height
		}
	};
};
function isRTL(element) {
	return getComputedStyle$1(element).direction === "rtl";
}
var platform = {
	convertOffsetParentRelativeRectToViewportRelativeRect,
	getDocumentElement,
	getClippingRect,
	getOffsetParent,
	getElementRects,
	getClientRects,
	getDimensions,
	getScale,
	isElement,
	isRTL
};
function rectsAreEqual(a, b) {
	return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}
function observeMove(element, onMove) {
	let io = null;
	let timeoutId;
	const root = getDocumentElement(element);
	function cleanup() {
		var _io;
		clearTimeout(timeoutId);
		(_io = io) == null || _io.disconnect();
		io = null;
	}
	function refresh(skip, threshold) {
		if (skip === void 0) skip = false;
		if (threshold === void 0) threshold = 1;
		cleanup();
		const elementRectForRootMargin = element.getBoundingClientRect();
		const { left, top, width, height } = elementRectForRootMargin;
		if (!skip) onMove();
		if (!width || !height) return;
		const insetTop = floor(top);
		const insetRight = floor(root.clientWidth - (left + width));
		const insetBottom = floor(root.clientHeight - (top + height));
		const insetLeft = floor(left);
		const options = {
			rootMargin: -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px",
			threshold: max(0, min(1, threshold)) || 1
		};
		let isFirstUpdate = true;
		function handleObserve(entries) {
			const ratio = entries[0].intersectionRatio;
			if (ratio !== threshold) {
				if (!isFirstUpdate) return refresh();
				if (!ratio) timeoutId = setTimeout(() => {
					refresh(false, 1e-7);
				}, 1e3);
				else refresh(false, ratio);
			}
			if (ratio === 1 && !rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) refresh();
			isFirstUpdate = false;
		}
		try {
			io = new IntersectionObserver(handleObserve, {
				...options,
				root: root.ownerDocument
			});
		} catch (_e) {
			io = new IntersectionObserver(handleObserve, options);
		}
		io.observe(element);
	}
	refresh(true);
	return cleanup;
}
/**
* Automatically updates the position of the floating element when necessary.
* Should only be called when the floating element is mounted on the DOM or
* visible on the screen.
* @returns cleanup function that should be invoked when the floating element is
* removed from the DOM or hidden from the screen.
* @see https://floating-ui.com/docs/autoUpdate
*/
function autoUpdate(reference, floating, update, options) {
	if (options === void 0) options = {};
	const { ancestorScroll = true, ancestorResize = true, elementResize = typeof ResizeObserver === "function", layoutShift = typeof IntersectionObserver === "function", animationFrame = false } = options;
	const referenceEl = unwrapElement(reference);
	const ancestors = ancestorScroll || ancestorResize ? [...referenceEl ? getOverflowAncestors(referenceEl) : [], ...floating ? getOverflowAncestors(floating) : []] : [];
	ancestors.forEach((ancestor) => {
		ancestorScroll && ancestor.addEventListener("scroll", update, { passive: true });
		ancestorResize && ancestor.addEventListener("resize", update);
	});
	const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update) : null;
	let reobserveFrame = -1;
	let resizeObserver = null;
	if (elementResize) {
		resizeObserver = new ResizeObserver((_ref) => {
			let [firstEntry] = _ref;
			if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating) {
				resizeObserver.unobserve(floating);
				cancelAnimationFrame(reobserveFrame);
				reobserveFrame = requestAnimationFrame(() => {
					var _resizeObserver;
					(_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
				});
			}
			update();
		});
		if (referenceEl && !animationFrame) resizeObserver.observe(referenceEl);
		if (floating) resizeObserver.observe(floating);
	}
	let frameId;
	let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
	if (animationFrame) frameLoop();
	function frameLoop() {
		const nextRefRect = getBoundingClientRect(reference);
		if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) update();
		prevRefRect = nextRefRect;
		frameId = requestAnimationFrame(frameLoop);
	}
	update();
	return () => {
		var _resizeObserver2;
		ancestors.forEach((ancestor) => {
			ancestorScroll && ancestor.removeEventListener("scroll", update);
			ancestorResize && ancestor.removeEventListener("resize", update);
		});
		cleanupIo?.();
		(_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
		resizeObserver = null;
		if (animationFrame) cancelAnimationFrame(frameId);
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$1 = offset$2;
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$1 = shift$2;
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$1 = flip$2;
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$2 = arrow$3;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*/
var computePosition = (reference, floating, options) => {
	const cache = /* @__PURE__ */ new Map();
	const mergedOptions = {
		platform,
		...options
	};
	const platformWithCache = {
		...mergedOptions.platform,
		_c: cache
	};
	return computePosition$1(reference, floating, {
		...mergedOptions,
		platform: platformWithCache
	});
};
//#endregion
//#region ../../node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
var index = typeof document !== "undefined" ? useLayoutEffect : function noop() {};
function deepEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (typeof a === "function" && a.toString() === b.toString()) return true;
	let length;
	let i;
	let keys;
	if (a && b && typeof a === "object") {
		if (Array.isArray(a)) {
			length = a.length;
			if (length !== b.length) return false;
			for (i = length; i-- !== 0;) if (!deepEqual(a[i], b[i])) return false;
			return true;
		}
		keys = Object.keys(a);
		length = keys.length;
		if (length !== Object.keys(b).length) return false;
		for (i = length; i-- !== 0;) if (!{}.hasOwnProperty.call(b, keys[i])) return false;
		for (i = length; i-- !== 0;) {
			const key = keys[i];
			if (key === "_owner" && a.$$typeof) continue;
			if (!deepEqual(a[key], b[key])) return false;
		}
		return true;
	}
	return a !== a && b !== b;
}
function getDPR(element) {
	if (typeof window === "undefined") return 1;
	return (element.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function roundByDPR(element, value) {
	const dpr = getDPR(element);
	return Math.round(value * dpr) / dpr;
}
function useLatestRef(value) {
	const ref = React$1.useRef(value);
	index(() => {
		ref.current = value;
	});
	return ref;
}
/**
* Provides data to position a floating element.
* @see https://floating-ui.com/docs/useFloating
*/
function useFloating$1(options) {
	if (options === void 0) options = {};
	const { placement = "bottom", strategy = "absolute", middleware = [], platform, elements: { reference: externalReference, floating: externalFloating } = {}, transform = true, whileElementsMounted, open } = options;
	const [data, setData] = React$1.useState({
		x: 0,
		y: 0,
		strategy,
		placement,
		middlewareData: {},
		isPositioned: false
	});
	const [latestMiddleware, setLatestMiddleware] = React$1.useState(middleware);
	if (!deepEqual(latestMiddleware, middleware)) setLatestMiddleware(middleware);
	const [_reference, _setReference] = React$1.useState(null);
	const [_floating, _setFloating] = React$1.useState(null);
	const setReference = React$1.useCallback((node) => {
		if (node !== referenceRef.current) {
			referenceRef.current = node;
			_setReference(node);
		}
	}, []);
	const setFloating = React$1.useCallback((node) => {
		if (node !== floatingRef.current) {
			floatingRef.current = node;
			_setFloating(node);
		}
	}, []);
	const referenceEl = externalReference || _reference;
	const floatingEl = externalFloating || _floating;
	const referenceRef = React$1.useRef(null);
	const floatingRef = React$1.useRef(null);
	const dataRef = React$1.useRef(data);
	const hasWhileElementsMounted = whileElementsMounted != null;
	const whileElementsMountedRef = useLatestRef(whileElementsMounted);
	const platformRef = useLatestRef(platform);
	const openRef = useLatestRef(open);
	const update = React$1.useCallback(() => {
		if (!referenceRef.current || !floatingRef.current) return;
		const config = {
			placement,
			strategy,
			middleware: latestMiddleware
		};
		if (platformRef.current) config.platform = platformRef.current;
		computePosition(referenceRef.current, floatingRef.current, config).then((data) => {
			const fullData = {
				...data,
				isPositioned: openRef.current !== false
			};
			if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
				dataRef.current = fullData;
				ReactDOM.flushSync(() => {
					setData(fullData);
				});
			}
		});
	}, [
		latestMiddleware,
		placement,
		strategy,
		platformRef,
		openRef
	]);
	index(() => {
		if (open === false && dataRef.current.isPositioned) {
			dataRef.current.isPositioned = false;
			setData((data) => ({
				...data,
				isPositioned: false
			}));
		}
	}, [open]);
	const isMountedRef = React$1.useRef(false);
	index(() => {
		isMountedRef.current = true;
		return () => {
			isMountedRef.current = false;
		};
	}, []);
	index(() => {
		if (referenceEl) referenceRef.current = referenceEl;
		if (floatingEl) floatingRef.current = floatingEl;
		if (referenceEl && floatingEl) {
			if (whileElementsMountedRef.current) return whileElementsMountedRef.current(referenceEl, floatingEl, update);
			update();
		}
	}, [
		referenceEl,
		floatingEl,
		update,
		whileElementsMountedRef,
		hasWhileElementsMounted
	]);
	const refs = React$1.useMemo(() => ({
		reference: referenceRef,
		floating: floatingRef,
		setReference,
		setFloating
	}), [setReference, setFloating]);
	const elements = React$1.useMemo(() => ({
		reference: referenceEl,
		floating: floatingEl
	}), [referenceEl, floatingEl]);
	const floatingStyles = React$1.useMemo(() => {
		const initialStyles = {
			position: strategy,
			left: 0,
			top: 0
		};
		if (!elements.floating) return initialStyles;
		const x = roundByDPR(elements.floating, data.x);
		const y = roundByDPR(elements.floating, data.y);
		if (transform) return {
			...initialStyles,
			transform: "translate(" + x + "px, " + y + "px)",
			...getDPR(elements.floating) >= 1.5 && { willChange: "transform" }
		};
		return {
			position: strategy,
			left: x,
			top: y
		};
	}, [
		strategy,
		transform,
		elements.floating,
		data.x,
		data.y
	]);
	return React$1.useMemo(() => ({
		...data,
		update,
		refs,
		elements,
		floatingStyles
	}), [
		data,
		update,
		refs,
		elements,
		floatingStyles
	]);
}
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$1 = (options) => {
	function isRef(value) {
		return {}.hasOwnProperty.call(value, "current");
	}
	return {
		name: "arrow",
		options,
		fn(state) {
			const { element, padding } = typeof options === "function" ? options(state) : options;
			if (element && isRef(element)) {
				if (element.current != null) return arrow$2({
					element: element.current,
					padding
				}).fn(state);
				return {};
			}
			if (element) return arrow$2({
				element,
				padding
			}).fn(state);
			return {};
		}
	};
};
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset = (options, deps) => {
	const result = offset$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift = (options, deps) => {
	const result = shift$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip = (options, deps) => {
	const result = flip$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow = (options, deps) => {
	const result = arrow$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
//#endregion
//#region ../../node_modules/@floating-ui/react/dist/floating-ui.react.mjs
/**
* Merges an array of refs into a single memoized callback ref or `null`.
* @see https://floating-ui.com/docs/react-utils#usemergerefs
*/
function useMergeRefs(refs) {
	const cleanupRef = React$1.useRef(void 0);
	const refEffect = React$1.useCallback((instance) => {
		const cleanups = refs.map((ref) => {
			if (ref == null) return;
			if (typeof ref === "function") {
				const refCallback = ref;
				const refCleanup = refCallback(instance);
				return typeof refCleanup === "function" ? refCleanup : () => {
					refCallback(null);
				};
			}
			ref.current = instance;
			return () => {
				ref.current = null;
			};
		});
		return () => {
			cleanups.forEach((refCleanup) => refCleanup == null ? void 0 : refCleanup());
		};
	}, refs);
	return React$1.useMemo(() => {
		if (refs.every((ref) => ref == null)) return null;
		return (value) => {
			if (cleanupRef.current) {
				cleanupRef.current();
				cleanupRef.current = void 0;
			}
			if (value != null) cleanupRef.current = refEffect(value);
		};
	}, refs);
}
var FOCUSABLE_ATTRIBUTE = "data-floating-ui-focusable";
var ACTIVE_KEY = "active";
var SELECTED_KEY = "selected";
var ARROW_LEFT = "ArrowLeft";
var ARROW_RIGHT = "ArrowRight";
var ARROW_UP = "ArrowUp";
var ARROW_DOWN = "ArrowDown";
var horizontalKeys = [ARROW_LEFT, ARROW_RIGHT];
var verticalKeys = [ARROW_UP, ARROW_DOWN];
[...horizontalKeys, ...verticalKeys];
var SafeReact = { ...React$1 };
var serverHandoffComplete = false;
var count = 0;
var genId = () => "floating-ui-" + Math.random().toString(36).slice(2, 6) + count++;
function useFloatingId() {
	const [id, setId] = React$1.useState(() => serverHandoffComplete ? genId() : void 0);
	index$1(() => {
		if (id == null) setId(genId());
	}, []);
	React$1.useEffect(() => {
		serverHandoffComplete = true;
	}, []);
	return id;
}
/**
* Uses React 18's built-in `useId()` when available, or falls back to a
* slightly less performant (requiring a double render) implementation for
* earlier React versions.
* @see https://floating-ui.com/docs/react-utils#useid
*/
var useId$1 = SafeReact.useId || useFloatingId;
var devMessageSet;
if (process.env.NODE_ENV !== "production") devMessageSet = /*#__PURE__*/ new Set();
function error() {
	var _devMessageSet3;
	for (var _len2 = arguments.length, messages = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) messages[_key2] = arguments[_key2];
	const message = "Floating UI: " + messages.join(" ");
	if (!((_devMessageSet3 = devMessageSet) != null && _devMessageSet3.has(message))) {
		var _devMessageSet4;
		(_devMessageSet4 = devMessageSet) == null || _devMessageSet4.add(message);
		console.error(message);
	}
}
function createEventEmitter() {
	const map = /* @__PURE__ */ new Map();
	return {
		emit(event, data) {
			var _map$get;
			(_map$get = map.get(event)) == null || _map$get.forEach((listener) => listener(data));
		},
		on(event, listener) {
			if (!map.has(event)) map.set(event, /* @__PURE__ */ new Set());
			map.get(event).add(listener);
		},
		off(event, listener) {
			var _map$get2;
			(_map$get2 = map.get(event)) == null || _map$get2.delete(listener);
		}
	};
}
var FloatingNodeContext = /*#__PURE__*/ React$1.createContext(null);
var FloatingTreeContext = /*#__PURE__*/ React$1.createContext(null);
/**
* Returns the parent node id for nested floating elements, if available.
* Returns `null` for top-level floating elements.
*/
var useFloatingParentNodeId = () => {
	var _React$useContext;
	return ((_React$useContext = React$1.useContext(FloatingNodeContext)) == null ? void 0 : _React$useContext.id) || null;
};
/**
* Returns the nearest floating tree context, if available.
*/
var useFloatingTree = () => React$1.useContext(FloatingTreeContext);
function createAttribute(name) {
	return "data-floating-ui-" + name;
}
function clearTimeoutIfSet(timeoutRef) {
	if (timeoutRef.current !== -1) {
		clearTimeout(timeoutRef.current);
		timeoutRef.current = -1;
	}
}
var safePolygonIdentifier = /*#__PURE__*/ createAttribute("safe-polygon");
function getDelay(value, prop, pointerType) {
	if (pointerType && !isMouseLikePointerType(pointerType)) return 0;
	if (typeof value === "number") return value;
	if (typeof value === "function") {
		const result = value();
		if (typeof result === "number") return result;
		return result == null ? void 0 : result[prop];
	}
	return value == null ? void 0 : value[prop];
}
function getRestMs(value) {
	if (typeof value === "function") return value();
	return value;
}
/**
* Opens the floating element while hovering over the reference element, like
* CSS `:hover`.
* @see https://floating-ui.com/docs/useHover
*/
function useHover(context, props) {
	if (props === void 0) props = {};
	const { open, onOpenChange, dataRef, events, elements } = context;
	const { enabled = true, delay = 0, handleClose = null, mouseOnly = false, restMs = 0, move = true } = props;
	const tree = useFloatingTree();
	const parentId = useFloatingParentNodeId();
	const handleCloseRef = useLatestRef$1(handleClose);
	const delayRef = useLatestRef$1(delay);
	const openRef = useLatestRef$1(open);
	const restMsRef = useLatestRef$1(restMs);
	const pointerTypeRef = React$1.useRef();
	const timeoutRef = React$1.useRef(-1);
	const handlerRef = React$1.useRef();
	const restTimeoutRef = React$1.useRef(-1);
	const blockMouseMoveRef = React$1.useRef(true);
	const performedPointerEventsMutationRef = React$1.useRef(false);
	const unbindMouseMoveRef = React$1.useRef(() => {});
	const restTimeoutPendingRef = React$1.useRef(false);
	const isHoverOpen = useEffectEvent(() => {
		var _dataRef$current$open;
		const type = (_dataRef$current$open = dataRef.current.openEvent) == null ? void 0 : _dataRef$current$open.type;
		return (type == null ? void 0 : type.includes("mouse")) && type !== "mousedown";
	});
	React$1.useEffect(() => {
		if (!enabled) return;
		function onOpenChange(_ref) {
			let { open } = _ref;
			if (!open) {
				clearTimeoutIfSet(timeoutRef);
				clearTimeoutIfSet(restTimeoutRef);
				blockMouseMoveRef.current = true;
				restTimeoutPendingRef.current = false;
			}
		}
		events.on("openchange", onOpenChange);
		return () => {
			events.off("openchange", onOpenChange);
		};
	}, [enabled, events]);
	React$1.useEffect(() => {
		if (!enabled) return;
		if (!handleCloseRef.current) return;
		if (!open) return;
		function onLeave(event) {
			if (isHoverOpen()) onOpenChange(false, event, "hover");
		}
		const html = getDocument(elements.floating).documentElement;
		html.addEventListener("mouseleave", onLeave);
		return () => {
			html.removeEventListener("mouseleave", onLeave);
		};
	}, [
		elements.floating,
		open,
		onOpenChange,
		enabled,
		handleCloseRef,
		isHoverOpen
	]);
	const closeWithDelay = React$1.useCallback(function(event, runElseBranch, reason) {
		if (runElseBranch === void 0) runElseBranch = true;
		if (reason === void 0) reason = "hover";
		const closeDelay = getDelay(delayRef.current, "close", pointerTypeRef.current);
		if (closeDelay && !handlerRef.current) {
			clearTimeoutIfSet(timeoutRef);
			timeoutRef.current = window.setTimeout(() => onOpenChange(false, event, reason), closeDelay);
		} else if (runElseBranch) {
			clearTimeoutIfSet(timeoutRef);
			onOpenChange(false, event, reason);
		}
	}, [delayRef, onOpenChange]);
	const cleanupMouseMoveHandler = useEffectEvent(() => {
		unbindMouseMoveRef.current();
		handlerRef.current = void 0;
	});
	const clearPointerEvents = useEffectEvent(() => {
		if (performedPointerEventsMutationRef.current) {
			const body = getDocument(elements.floating).body;
			body.style.pointerEvents = "";
			body.removeAttribute(safePolygonIdentifier);
			performedPointerEventsMutationRef.current = false;
		}
	});
	const isClickLikeOpenEvent = useEffectEvent(() => {
		return dataRef.current.openEvent ? ["click", "mousedown"].includes(dataRef.current.openEvent.type) : false;
	});
	React$1.useEffect(() => {
		if (!enabled) return;
		function onReferenceMouseEnter(event) {
			clearTimeoutIfSet(timeoutRef);
			blockMouseMoveRef.current = false;
			if (mouseOnly && !isMouseLikePointerType(pointerTypeRef.current) || getRestMs(restMsRef.current) > 0 && !getDelay(delayRef.current, "open")) return;
			const openDelay = getDelay(delayRef.current, "open", pointerTypeRef.current);
			if (openDelay) timeoutRef.current = window.setTimeout(() => {
				if (!openRef.current) onOpenChange(true, event, "hover");
			}, openDelay);
			else if (!open) onOpenChange(true, event, "hover");
		}
		function onReferenceMouseLeave(event) {
			if (isClickLikeOpenEvent()) {
				clearPointerEvents();
				return;
			}
			unbindMouseMoveRef.current();
			const doc = getDocument(elements.floating);
			clearTimeoutIfSet(restTimeoutRef);
			restTimeoutPendingRef.current = false;
			if (handleCloseRef.current && dataRef.current.floatingContext) {
				if (!open) clearTimeoutIfSet(timeoutRef);
				handlerRef.current = handleCloseRef.current({
					...dataRef.current.floatingContext,
					tree,
					x: event.clientX,
					y: event.clientY,
					onClose() {
						clearPointerEvents();
						cleanupMouseMoveHandler();
						if (!isClickLikeOpenEvent()) closeWithDelay(event, true, "safe-polygon");
					}
				});
				const handler = handlerRef.current;
				doc.addEventListener("mousemove", handler);
				unbindMouseMoveRef.current = () => {
					doc.removeEventListener("mousemove", handler);
				};
				return;
			}
			if (pointerTypeRef.current === "touch" ? !contains(elements.floating, event.relatedTarget) : true) closeWithDelay(event);
		}
		function onScrollMouseLeave(event) {
			if (isClickLikeOpenEvent()) return;
			if (!dataRef.current.floatingContext) return;
			handleCloseRef.current == null || handleCloseRef.current({
				...dataRef.current.floatingContext,
				tree,
				x: event.clientX,
				y: event.clientY,
				onClose() {
					clearPointerEvents();
					cleanupMouseMoveHandler();
					if (!isClickLikeOpenEvent()) closeWithDelay(event);
				}
			})(event);
		}
		function onFloatingMouseEnter() {
			clearTimeoutIfSet(timeoutRef);
		}
		function onFloatingMouseLeave(event) {
			if (!isClickLikeOpenEvent()) closeWithDelay(event, false);
		}
		if (isElement(elements.domReference)) {
			const reference = elements.domReference;
			const floating = elements.floating;
			if (open) reference.addEventListener("mouseleave", onScrollMouseLeave);
			if (move) reference.addEventListener("mousemove", onReferenceMouseEnter, { once: true });
			reference.addEventListener("mouseenter", onReferenceMouseEnter);
			reference.addEventListener("mouseleave", onReferenceMouseLeave);
			if (floating) {
				floating.addEventListener("mouseleave", onScrollMouseLeave);
				floating.addEventListener("mouseenter", onFloatingMouseEnter);
				floating.addEventListener("mouseleave", onFloatingMouseLeave);
			}
			return () => {
				if (open) reference.removeEventListener("mouseleave", onScrollMouseLeave);
				if (move) reference.removeEventListener("mousemove", onReferenceMouseEnter);
				reference.removeEventListener("mouseenter", onReferenceMouseEnter);
				reference.removeEventListener("mouseleave", onReferenceMouseLeave);
				if (floating) {
					floating.removeEventListener("mouseleave", onScrollMouseLeave);
					floating.removeEventListener("mouseenter", onFloatingMouseEnter);
					floating.removeEventListener("mouseleave", onFloatingMouseLeave);
				}
			};
		}
	}, [
		elements,
		enabled,
		context,
		mouseOnly,
		move,
		closeWithDelay,
		cleanupMouseMoveHandler,
		clearPointerEvents,
		onOpenChange,
		open,
		openRef,
		tree,
		delayRef,
		handleCloseRef,
		dataRef,
		isClickLikeOpenEvent,
		restMsRef
	]);
	index$1(() => {
		var _handleCloseRef$curre;
		if (!enabled) return;
		if (open && (_handleCloseRef$curre = handleCloseRef.current) != null && (_handleCloseRef$curre = _handleCloseRef$curre.__options) != null && _handleCloseRef$curre.blockPointerEvents && isHoverOpen()) {
			performedPointerEventsMutationRef.current = true;
			const floatingEl = elements.floating;
			if (isElement(elements.domReference) && floatingEl) {
				var _tree$nodesRef$curren;
				const body = getDocument(elements.floating).body;
				body.setAttribute(safePolygonIdentifier, "");
				const ref = elements.domReference;
				const parentFloating = tree == null || (_tree$nodesRef$curren = tree.nodesRef.current.find((node) => node.id === parentId)) == null || (_tree$nodesRef$curren = _tree$nodesRef$curren.context) == null ? void 0 : _tree$nodesRef$curren.elements.floating;
				if (parentFloating) parentFloating.style.pointerEvents = "";
				body.style.pointerEvents = "none";
				ref.style.pointerEvents = "auto";
				floatingEl.style.pointerEvents = "auto";
				return () => {
					body.style.pointerEvents = "";
					ref.style.pointerEvents = "";
					floatingEl.style.pointerEvents = "";
				};
			}
		}
	}, [
		enabled,
		open,
		parentId,
		elements,
		tree,
		handleCloseRef,
		isHoverOpen
	]);
	index$1(() => {
		if (!open) {
			pointerTypeRef.current = void 0;
			restTimeoutPendingRef.current = false;
			cleanupMouseMoveHandler();
			clearPointerEvents();
		}
	}, [
		open,
		cleanupMouseMoveHandler,
		clearPointerEvents
	]);
	React$1.useEffect(() => {
		return () => {
			cleanupMouseMoveHandler();
			clearTimeoutIfSet(timeoutRef);
			clearTimeoutIfSet(restTimeoutRef);
			clearPointerEvents();
		};
	}, [
		enabled,
		elements.domReference,
		cleanupMouseMoveHandler,
		clearPointerEvents
	]);
	const reference = React$1.useMemo(() => {
		function setPointerRef(event) {
			pointerTypeRef.current = event.pointerType;
		}
		return {
			onPointerDown: setPointerRef,
			onPointerEnter: setPointerRef,
			onMouseMove(event) {
				const { nativeEvent } = event;
				function handleMouseMove() {
					if (!blockMouseMoveRef.current && !openRef.current) onOpenChange(true, nativeEvent, "hover");
				}
				if (mouseOnly && !isMouseLikePointerType(pointerTypeRef.current)) return;
				if (open || getRestMs(restMsRef.current) === 0) return;
				if (restTimeoutPendingRef.current && event.movementX ** 2 + event.movementY ** 2 < 2) return;
				clearTimeoutIfSet(restTimeoutRef);
				if (pointerTypeRef.current === "touch") handleMouseMove();
				else {
					restTimeoutPendingRef.current = true;
					restTimeoutRef.current = window.setTimeout(handleMouseMove, getRestMs(restMsRef.current));
				}
			}
		};
	}, [
		mouseOnly,
		onOpenChange,
		open,
		openRef,
		restMsRef
	]);
	return React$1.useMemo(() => enabled ? { reference } : {}, [enabled, reference]);
}
var HIDDEN_STYLES = {
	border: 0,
	clip: "rect(0 0 0 0)",
	height: "1px",
	margin: "-1px",
	overflow: "hidden",
	padding: 0,
	position: "fixed",
	whiteSpace: "nowrap",
	width: "1px",
	top: 0,
	left: 0
};
var FocusGuard = /*#__PURE__*/ React$1.forwardRef(function FocusGuard(props, ref) {
	const [role, setRole] = React$1.useState();
	index$1(() => {
		if (isSafari()) setRole("button");
	}, []);
	const restProps = {
		ref,
		tabIndex: 0,
		role,
		"aria-hidden": role ? void 0 : true,
		[createAttribute("focus-guard")]: "",
		style: HIDDEN_STYLES
	};
	return /*#__PURE__*/ jsx("span", {
		...props,
		...restProps
	});
});
var HIDDEN_OWNER_STYLES = {
	clipPath: "inset(50%)",
	position: "fixed",
	top: 0,
	left: 0
};
var PortalContext = /*#__PURE__*/ React$1.createContext(null);
var attr = /*#__PURE__*/ createAttribute("portal");
/**
* @see https://floating-ui.com/docs/FloatingPortal#usefloatingportalnode
*/
function useFloatingPortalNode(props) {
	if (props === void 0) props = {};
	const { id, root } = props;
	const uniqueId = useId$1();
	const portalContext = usePortalContext();
	const [portalNode, setPortalNode] = React$1.useState(null);
	const portalNodeRef = React$1.useRef(null);
	index$1(() => {
		return () => {
			portalNode?.remove();
			queueMicrotask(() => {
				portalNodeRef.current = null;
			});
		};
	}, [portalNode]);
	index$1(() => {
		if (!uniqueId) return;
		if (portalNodeRef.current) return;
		const existingIdRoot = id ? document.getElementById(id) : null;
		if (!existingIdRoot) return;
		const subRoot = document.createElement("div");
		subRoot.id = uniqueId;
		subRoot.setAttribute(attr, "");
		existingIdRoot.appendChild(subRoot);
		portalNodeRef.current = subRoot;
		setPortalNode(subRoot);
	}, [id, uniqueId]);
	index$1(() => {
		if (root === null) return;
		if (!uniqueId) return;
		if (portalNodeRef.current) return;
		let container = root || (portalContext == null ? void 0 : portalContext.portalNode);
		if (container && !isNode(container)) container = container.current;
		container = container || document.body;
		let idWrapper = null;
		if (id) {
			idWrapper = document.createElement("div");
			idWrapper.id = id;
			container.appendChild(idWrapper);
		}
		const subRoot = document.createElement("div");
		subRoot.id = uniqueId;
		subRoot.setAttribute(attr, "");
		container = idWrapper || container;
		container.appendChild(subRoot);
		portalNodeRef.current = subRoot;
		setPortalNode(subRoot);
	}, [
		id,
		root,
		uniqueId,
		portalContext
	]);
	return portalNode;
}
/**
* Portals the floating element into a given container element — by default,
* outside of the app root and into the body.
* This is necessary to ensure the floating element can appear outside any
* potential parent containers that cause clipping (such as `overflow: hidden`),
* while retaining its location in the React tree.
* @see https://floating-ui.com/docs/FloatingPortal
*/
function FloatingPortal(props) {
	const { children, id, root, preserveTabOrder = true } = props;
	const portalNode = useFloatingPortalNode({
		id,
		root
	});
	const [focusManagerState, setFocusManagerState] = React$1.useState(null);
	const beforeOutsideRef = React$1.useRef(null);
	const afterOutsideRef = React$1.useRef(null);
	const beforeInsideRef = React$1.useRef(null);
	const afterInsideRef = React$1.useRef(null);
	const modal = focusManagerState == null ? void 0 : focusManagerState.modal;
	const open = focusManagerState == null ? void 0 : focusManagerState.open;
	const shouldRenderGuards = !!focusManagerState && !focusManagerState.modal && focusManagerState.open && preserveTabOrder && !!(root || portalNode);
	React$1.useEffect(() => {
		if (!portalNode || !preserveTabOrder || modal) return;
		function onFocus(event) {
			if (portalNode && isOutsideEvent(event)) (event.type === "focusin" ? enableFocusInside : disableFocusInside)(portalNode);
		}
		portalNode.addEventListener("focusin", onFocus, true);
		portalNode.addEventListener("focusout", onFocus, true);
		return () => {
			portalNode.removeEventListener("focusin", onFocus, true);
			portalNode.removeEventListener("focusout", onFocus, true);
		};
	}, [
		portalNode,
		preserveTabOrder,
		modal
	]);
	React$1.useEffect(() => {
		if (!portalNode) return;
		if (open) return;
		enableFocusInside(portalNode);
	}, [open, portalNode]);
	return /*#__PURE__*/ jsxs(PortalContext.Provider, {
		value: React$1.useMemo(() => ({
			preserveTabOrder,
			beforeOutsideRef,
			afterOutsideRef,
			beforeInsideRef,
			afterInsideRef,
			portalNode,
			setFocusManagerState
		}), [preserveTabOrder, portalNode]),
		children: [
			shouldRenderGuards && portalNode && /*#__PURE__*/ jsx(FocusGuard, {
				"data-type": "outside",
				ref: beforeOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) {
						var _beforeInsideRef$curr;
						(_beforeInsideRef$curr = beforeInsideRef.current) == null || _beforeInsideRef$curr.focus();
					} else getPreviousTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
				}
			}),
			shouldRenderGuards && portalNode && /*#__PURE__*/ jsx("span", {
				"aria-owns": portalNode.id,
				style: HIDDEN_OWNER_STYLES
			}),
			portalNode && /*#__PURE__*/ ReactDOM.createPortal(children, portalNode),
			shouldRenderGuards && portalNode && /*#__PURE__*/ jsx(FocusGuard, {
				"data-type": "outside",
				ref: afterOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) {
						var _afterInsideRef$curre;
						(_afterInsideRef$curre = afterInsideRef.current) == null || _afterInsideRef$curre.focus();
					} else {
						getNextTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
						focusManagerState != null && focusManagerState.closeOnFocusOut && focusManagerState?.onOpenChange(false, event.nativeEvent, "focus-out");
					}
				}
			})
		]
	});
}
var usePortalContext = () => React$1.useContext(PortalContext);
function isButtonTarget(event) {
	return isHTMLElement(event.target) && event.target.tagName === "BUTTON";
}
function isAnchorTarget(event) {
	return isHTMLElement(event.target) && event.target.tagName === "A";
}
function isSpaceIgnored(element) {
	return isTypeableElement(element);
}
/**
* Opens or closes the floating element when clicking the reference element.
* @see https://floating-ui.com/docs/useClick
*/
function useClick(context, props) {
	if (props === void 0) props = {};
	const { open, onOpenChange, dataRef, elements: { domReference } } = context;
	const { enabled = true, event: eventOption = "click", toggle = true, ignoreMouse = false, keyboardHandlers = true, stickIfOpen = true } = props;
	const pointerTypeRef = React$1.useRef();
	const didKeyDownRef = React$1.useRef(false);
	const reference = React$1.useMemo(() => ({
		onPointerDown(event) {
			pointerTypeRef.current = event.pointerType;
		},
		onMouseDown(event) {
			const pointerType = pointerTypeRef.current;
			if (event.button !== 0) return;
			if (eventOption === "click") return;
			if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
			if (open && toggle && (dataRef.current.openEvent && stickIfOpen ? dataRef.current.openEvent.type === "mousedown" : true)) onOpenChange(false, event.nativeEvent, "click");
			else {
				event.preventDefault();
				onOpenChange(true, event.nativeEvent, "click");
			}
		},
		onClick(event) {
			const pointerType = pointerTypeRef.current;
			if (eventOption === "mousedown" && pointerTypeRef.current) {
				pointerTypeRef.current = void 0;
				return;
			}
			if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
			if (open && toggle && (dataRef.current.openEvent && stickIfOpen ? dataRef.current.openEvent.type === "click" : true)) onOpenChange(false, event.nativeEvent, "click");
			else onOpenChange(true, event.nativeEvent, "click");
		},
		onKeyDown(event) {
			pointerTypeRef.current = void 0;
			if (event.defaultPrevented || !keyboardHandlers || isButtonTarget(event)) return;
			if (event.key === " " && !isSpaceIgnored(domReference)) {
				event.preventDefault();
				didKeyDownRef.current = true;
			}
			if (isAnchorTarget(event)) return;
			if (event.key === "Enter") if (open && toggle) onOpenChange(false, event.nativeEvent, "click");
			else onOpenChange(true, event.nativeEvent, "click");
		},
		onKeyUp(event) {
			if (event.defaultPrevented || !keyboardHandlers || isButtonTarget(event) || isSpaceIgnored(domReference)) return;
			if (event.key === " " && didKeyDownRef.current) {
				didKeyDownRef.current = false;
				if (open && toggle) onOpenChange(false, event.nativeEvent, "click");
				else onOpenChange(true, event.nativeEvent, "click");
			}
		}
	}), [
		dataRef,
		domReference,
		eventOption,
		ignoreMouse,
		keyboardHandlers,
		onOpenChange,
		open,
		stickIfOpen,
		toggle
	]);
	return React$1.useMemo(() => enabled ? { reference } : {}, [enabled, reference]);
}
var bubbleHandlerKeys = {
	pointerdown: "onPointerDown",
	mousedown: "onMouseDown",
	click: "onClick"
};
var captureHandlerKeys = {
	pointerdown: "onPointerDownCapture",
	mousedown: "onMouseDownCapture",
	click: "onClickCapture"
};
var normalizeProp = (normalizable) => {
	var _normalizable$escapeK, _normalizable$outside;
	return {
		escapeKey: typeof normalizable === "boolean" ? normalizable : (_normalizable$escapeK = normalizable == null ? void 0 : normalizable.escapeKey) != null ? _normalizable$escapeK : false,
		outsidePress: typeof normalizable === "boolean" ? normalizable : (_normalizable$outside = normalizable == null ? void 0 : normalizable.outsidePress) != null ? _normalizable$outside : true
	};
};
/**
* Closes the floating element when a dismissal is requested — by default, when
* the user presses the `escape` key or outside of the floating element.
* @see https://floating-ui.com/docs/useDismiss
*/
function useDismiss(context, props) {
	if (props === void 0) props = {};
	const { open, onOpenChange, elements, dataRef } = context;
	const { enabled = true, escapeKey = true, outsidePress: unstable_outsidePress = true, outsidePressEvent = "pointerdown", referencePress = false, referencePressEvent = "pointerdown", ancestorScroll = false, bubbles, capture } = props;
	const tree = useFloatingTree();
	const outsidePressFn = useEffectEvent(typeof unstable_outsidePress === "function" ? unstable_outsidePress : () => false);
	const outsidePress = typeof unstable_outsidePress === "function" ? outsidePressFn : unstable_outsidePress;
	const endedOrStartedInsideRef = React$1.useRef(false);
	const { escapeKey: escapeKeyBubbles, outsidePress: outsidePressBubbles } = normalizeProp(bubbles);
	const { escapeKey: escapeKeyCapture, outsidePress: outsidePressCapture } = normalizeProp(capture);
	const isComposingRef = React$1.useRef(false);
	const closeOnEscapeKeyDown = useEffectEvent((event) => {
		var _dataRef$current$floa;
		if (!open || !enabled || !escapeKey || event.key !== "Escape") return;
		if (isComposingRef.current) return;
		const nodeId = (_dataRef$current$floa = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa.nodeId;
		const children = tree ? getNodeChildren(tree.nodesRef.current, nodeId) : [];
		if (!escapeKeyBubbles) {
			event.stopPropagation();
			if (children.length > 0) {
				let shouldDismiss = true;
				children.forEach((child) => {
					var _child$context;
					if ((_child$context = child.context) != null && _child$context.open && !child.context.dataRef.current.__escapeKeyBubbles) {
						shouldDismiss = false;
						return;
					}
				});
				if (!shouldDismiss) return;
			}
		}
		onOpenChange(false, isReactEvent(event) ? event.nativeEvent : event, "escape-key");
	});
	const closeOnEscapeKeyDownCapture = useEffectEvent((event) => {
		var _getTarget2;
		const callback = () => {
			var _getTarget;
			closeOnEscapeKeyDown(event);
			(_getTarget = getTarget(event)) == null || _getTarget.removeEventListener("keydown", callback);
		};
		(_getTarget2 = getTarget(event)) == null || _getTarget2.addEventListener("keydown", callback);
	});
	const closeOnPressOutside = useEffectEvent((event) => {
		var _dataRef$current$floa2;
		const insideReactTree = dataRef.current.insideReactTree;
		dataRef.current.insideReactTree = false;
		const endedOrStartedInside = endedOrStartedInsideRef.current;
		endedOrStartedInsideRef.current = false;
		if (outsidePressEvent === "click" && endedOrStartedInside) return;
		if (insideReactTree) return;
		if (typeof outsidePress === "function" && !outsidePress(event)) return;
		const target = getTarget(event);
		const inertSelector = "[" + createAttribute("inert") + "]";
		const markers = getDocument(elements.floating).querySelectorAll(inertSelector);
		let targetRootAncestor = isElement(target) ? target : null;
		while (targetRootAncestor && !isLastTraversableNode(targetRootAncestor)) {
			const nextParent = getParentNode(targetRootAncestor);
			if (isLastTraversableNode(nextParent) || !isElement(nextParent)) break;
			targetRootAncestor = nextParent;
		}
		if (markers.length && isElement(target) && !isRootElement(target) && !contains(target, elements.floating) && Array.from(markers).every((marker) => !contains(targetRootAncestor, marker))) return;
		if (isHTMLElement(target) && floating) {
			const lastTraversableNode = isLastTraversableNode(target);
			const style = getComputedStyle$1(target);
			const scrollRe = /auto|scroll/;
			const isScrollableX = lastTraversableNode || scrollRe.test(style.overflowX);
			const isScrollableY = lastTraversableNode || scrollRe.test(style.overflowY);
			const canScrollX = isScrollableX && target.clientWidth > 0 && target.scrollWidth > target.clientWidth;
			const canScrollY = isScrollableY && target.clientHeight > 0 && target.scrollHeight > target.clientHeight;
			const isRTL = style.direction === "rtl";
			const pressedVerticalScrollbar = canScrollY && (isRTL ? event.offsetX <= target.offsetWidth - target.clientWidth : event.offsetX > target.clientWidth);
			const pressedHorizontalScrollbar = canScrollX && event.offsetY > target.clientHeight;
			if (pressedVerticalScrollbar || pressedHorizontalScrollbar) return;
		}
		const nodeId = (_dataRef$current$floa2 = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa2.nodeId;
		const targetIsInsideChildren = tree && getNodeChildren(tree.nodesRef.current, nodeId).some((node) => {
			var _node$context;
			return isEventTargetWithin(event, (_node$context = node.context) == null ? void 0 : _node$context.elements.floating);
		});
		if (isEventTargetWithin(event, elements.floating) || isEventTargetWithin(event, elements.domReference) || targetIsInsideChildren) return;
		const children = tree ? getNodeChildren(tree.nodesRef.current, nodeId) : [];
		if (children.length > 0) {
			let shouldDismiss = true;
			children.forEach((child) => {
				var _child$context2;
				if ((_child$context2 = child.context) != null && _child$context2.open && !child.context.dataRef.current.__outsidePressBubbles) {
					shouldDismiss = false;
					return;
				}
			});
			if (!shouldDismiss) return;
		}
		onOpenChange(false, event, "outside-press");
	});
	const closeOnPressOutsideCapture = useEffectEvent((event) => {
		var _getTarget4;
		const callback = () => {
			var _getTarget3;
			closeOnPressOutside(event);
			(_getTarget3 = getTarget(event)) == null || _getTarget3.removeEventListener(outsidePressEvent, callback);
		};
		(_getTarget4 = getTarget(event)) == null || _getTarget4.addEventListener(outsidePressEvent, callback);
	});
	React$1.useEffect(() => {
		if (!open || !enabled) return;
		dataRef.current.__escapeKeyBubbles = escapeKeyBubbles;
		dataRef.current.__outsidePressBubbles = outsidePressBubbles;
		let compositionTimeout = -1;
		function onScroll(event) {
			onOpenChange(false, event, "ancestor-scroll");
		}
		function handleCompositionStart() {
			window.clearTimeout(compositionTimeout);
			isComposingRef.current = true;
		}
		function handleCompositionEnd() {
			compositionTimeout = window.setTimeout(() => {
				isComposingRef.current = false;
			}, isWebKit() ? 5 : 0);
		}
		const doc = getDocument(elements.floating);
		if (escapeKey) {
			doc.addEventListener("keydown", escapeKeyCapture ? closeOnEscapeKeyDownCapture : closeOnEscapeKeyDown, escapeKeyCapture);
			doc.addEventListener("compositionstart", handleCompositionStart);
			doc.addEventListener("compositionend", handleCompositionEnd);
		}
		outsidePress && doc.addEventListener(outsidePressEvent, outsidePressCapture ? closeOnPressOutsideCapture : closeOnPressOutside, outsidePressCapture);
		let ancestors = [];
		if (ancestorScroll) {
			if (isElement(elements.domReference)) ancestors = getOverflowAncestors(elements.domReference);
			if (isElement(elements.floating)) ancestors = ancestors.concat(getOverflowAncestors(elements.floating));
			if (!isElement(elements.reference) && elements.reference && elements.reference.contextElement) ancestors = ancestors.concat(getOverflowAncestors(elements.reference.contextElement));
		}
		ancestors = ancestors.filter((ancestor) => {
			var _doc$defaultView;
			return ancestor !== ((_doc$defaultView = doc.defaultView) == null ? void 0 : _doc$defaultView.visualViewport);
		});
		ancestors.forEach((ancestor) => {
			ancestor.addEventListener("scroll", onScroll, { passive: true });
		});
		return () => {
			if (escapeKey) {
				doc.removeEventListener("keydown", escapeKeyCapture ? closeOnEscapeKeyDownCapture : closeOnEscapeKeyDown, escapeKeyCapture);
				doc.removeEventListener("compositionstart", handleCompositionStart);
				doc.removeEventListener("compositionend", handleCompositionEnd);
			}
			outsidePress && doc.removeEventListener(outsidePressEvent, outsidePressCapture ? closeOnPressOutsideCapture : closeOnPressOutside, outsidePressCapture);
			ancestors.forEach((ancestor) => {
				ancestor.removeEventListener("scroll", onScroll);
			});
			window.clearTimeout(compositionTimeout);
		};
	}, [
		dataRef,
		elements,
		escapeKey,
		outsidePress,
		outsidePressEvent,
		open,
		onOpenChange,
		ancestorScroll,
		enabled,
		escapeKeyBubbles,
		outsidePressBubbles,
		closeOnEscapeKeyDown,
		escapeKeyCapture,
		closeOnEscapeKeyDownCapture,
		closeOnPressOutside,
		outsidePressCapture,
		closeOnPressOutsideCapture
	]);
	React$1.useEffect(() => {
		dataRef.current.insideReactTree = false;
	}, [
		dataRef,
		outsidePress,
		outsidePressEvent
	]);
	const reference = React$1.useMemo(() => ({
		onKeyDown: closeOnEscapeKeyDown,
		...referencePress && {
			[bubbleHandlerKeys[referencePressEvent]]: (event) => {
				onOpenChange(false, event.nativeEvent, "reference-press");
			},
			...referencePressEvent !== "click" && { onClick(event) {
				onOpenChange(false, event.nativeEvent, "reference-press");
			} }
		}
	}), [
		closeOnEscapeKeyDown,
		onOpenChange,
		referencePress,
		referencePressEvent
	]);
	const floating = React$1.useMemo(() => {
		function setMouseDownOrUpInside(event) {
			if (event.button !== 0) return;
			endedOrStartedInsideRef.current = true;
		}
		return {
			onKeyDown: closeOnEscapeKeyDown,
			onMouseDown: setMouseDownOrUpInside,
			onMouseUp: setMouseDownOrUpInside,
			[captureHandlerKeys[outsidePressEvent]]: () => {
				dataRef.current.insideReactTree = true;
			}
		};
	}, [
		closeOnEscapeKeyDown,
		outsidePressEvent,
		dataRef
	]);
	return React$1.useMemo(() => enabled ? {
		reference,
		floating
	} : {}, [
		enabled,
		reference,
		floating
	]);
}
function useFloatingRootContext(options) {
	const { open = false, onOpenChange: onOpenChangeProp, elements: elementsProp } = options;
	const floatingId = useId$1();
	const dataRef = React$1.useRef({});
	const [events] = React$1.useState(() => createEventEmitter());
	const nested = useFloatingParentNodeId() != null;
	if (process.env.NODE_ENV !== "production") {
		const optionDomReference = elementsProp.reference;
		if (optionDomReference && !isElement(optionDomReference)) error("Cannot pass a virtual element to the `elements.reference` option,", "as it must be a real DOM element. Use `refs.setPositionReference()`", "instead.");
	}
	const [positionReference, setPositionReference] = React$1.useState(elementsProp.reference);
	const onOpenChange = useEffectEvent((open, event, reason) => {
		dataRef.current.openEvent = open ? event : void 0;
		events.emit("openchange", {
			open,
			event,
			reason,
			nested
		});
		onOpenChangeProp?.(open, event, reason);
	});
	const refs = React$1.useMemo(() => ({ setPositionReference }), []);
	const elements = React$1.useMemo(() => ({
		reference: positionReference || elementsProp.reference || null,
		floating: elementsProp.floating || null,
		domReference: elementsProp.reference
	}), [
		positionReference,
		elementsProp.reference,
		elementsProp.floating
	]);
	return React$1.useMemo(() => ({
		dataRef,
		open,
		onOpenChange,
		elements,
		events,
		floatingId,
		refs
	}), [
		open,
		onOpenChange,
		elements,
		events,
		floatingId,
		refs
	]);
}
/**
* Provides data to position a floating element and context to add interactions.
* @see https://floating-ui.com/docs/useFloating
*/
function useFloating(options) {
	if (options === void 0) options = {};
	const { nodeId } = options;
	const internalRootContext = useFloatingRootContext({
		...options,
		elements: {
			reference: null,
			floating: null,
			...options.elements
		}
	});
	const rootContext = options.rootContext || internalRootContext;
	const computedElements = rootContext.elements;
	const [_domReference, setDomReference] = React$1.useState(null);
	const [positionReference, _setPositionReference] = React$1.useState(null);
	const domReference = (computedElements == null ? void 0 : computedElements.domReference) || _domReference;
	const domReferenceRef = React$1.useRef(null);
	const tree = useFloatingTree();
	index$1(() => {
		if (domReference) domReferenceRef.current = domReference;
	}, [domReference]);
	const position = useFloating$1({
		...options,
		elements: {
			...computedElements,
			...positionReference && { reference: positionReference }
		}
	});
	const setPositionReference = React$1.useCallback((node) => {
		const computedPositionReference = isElement(node) ? {
			getBoundingClientRect: () => node.getBoundingClientRect(),
			getClientRects: () => node.getClientRects(),
			contextElement: node
		} : node;
		_setPositionReference(computedPositionReference);
		position.refs.setReference(computedPositionReference);
	}, [position.refs]);
	const setReference = React$1.useCallback((node) => {
		if (isElement(node) || node === null) {
			domReferenceRef.current = node;
			setDomReference(node);
		}
		if (isElement(position.refs.reference.current) || position.refs.reference.current === null || node !== null && !isElement(node)) position.refs.setReference(node);
	}, [position.refs]);
	const refs = React$1.useMemo(() => ({
		...position.refs,
		setReference,
		setPositionReference,
		domReference: domReferenceRef
	}), [
		position.refs,
		setReference,
		setPositionReference
	]);
	const elements = React$1.useMemo(() => ({
		...position.elements,
		domReference
	}), [position.elements, domReference]);
	const context = React$1.useMemo(() => ({
		...position,
		...rootContext,
		refs,
		elements,
		nodeId
	}), [
		position,
		refs,
		elements,
		nodeId,
		rootContext
	]);
	index$1(() => {
		rootContext.dataRef.current.floatingContext = context;
		const node = tree == null ? void 0 : tree.nodesRef.current.find((node) => node.id === nodeId);
		if (node) node.context = context;
	});
	return React$1.useMemo(() => ({
		...position,
		context,
		refs,
		elements
	}), [
		position,
		refs,
		elements,
		context
	]);
}
function isMacSafari() {
	return isMac() && isSafari();
}
/**
* Opens the floating element while the reference element has focus, like CSS
* `:focus`.
* @see https://floating-ui.com/docs/useFocus
*/
function useFocus(context, props) {
	if (props === void 0) props = {};
	const { open, onOpenChange, events, dataRef, elements } = context;
	const { enabled = true, visibleOnly = true } = props;
	const blockFocusRef = React$1.useRef(false);
	const timeoutRef = React$1.useRef(-1);
	const keyboardModalityRef = React$1.useRef(true);
	React$1.useEffect(() => {
		if (!enabled) return;
		const win = getWindow(elements.domReference);
		function onBlur() {
			if (!open && isHTMLElement(elements.domReference) && elements.domReference === activeElement(getDocument(elements.domReference))) blockFocusRef.current = true;
		}
		function onKeyDown() {
			keyboardModalityRef.current = true;
		}
		function onPointerDown() {
			keyboardModalityRef.current = false;
		}
		win.addEventListener("blur", onBlur);
		if (isMacSafari()) {
			win.addEventListener("keydown", onKeyDown, true);
			win.addEventListener("pointerdown", onPointerDown, true);
		}
		return () => {
			win.removeEventListener("blur", onBlur);
			if (isMacSafari()) {
				win.removeEventListener("keydown", onKeyDown, true);
				win.removeEventListener("pointerdown", onPointerDown, true);
			}
		};
	}, [
		elements.domReference,
		open,
		enabled
	]);
	React$1.useEffect(() => {
		if (!enabled) return;
		function onOpenChange(_ref) {
			let { reason } = _ref;
			if (reason === "reference-press" || reason === "escape-key") blockFocusRef.current = true;
		}
		events.on("openchange", onOpenChange);
		return () => {
			events.off("openchange", onOpenChange);
		};
	}, [events, enabled]);
	React$1.useEffect(() => {
		return () => {
			clearTimeoutIfSet(timeoutRef);
		};
	}, []);
	const reference = React$1.useMemo(() => ({
		onMouseLeave() {
			blockFocusRef.current = false;
		},
		onFocus(event) {
			if (blockFocusRef.current) return;
			const target = getTarget(event.nativeEvent);
			if (visibleOnly && isElement(target)) {
				if (isMacSafari() && !event.relatedTarget) {
					if (!keyboardModalityRef.current && !isTypeableElement(target)) return;
				} else if (!matchesFocusVisible(target)) return;
			}
			onOpenChange(true, event.nativeEvent, "focus");
		},
		onBlur(event) {
			blockFocusRef.current = false;
			const relatedTarget = event.relatedTarget;
			const nativeEvent = event.nativeEvent;
			const movedToFocusGuard = isElement(relatedTarget) && relatedTarget.hasAttribute(createAttribute("focus-guard")) && relatedTarget.getAttribute("data-type") === "outside";
			timeoutRef.current = window.setTimeout(() => {
				var _dataRef$current$floa;
				const activeEl = activeElement(elements.domReference ? elements.domReference.ownerDocument : document);
				if (!relatedTarget && activeEl === elements.domReference) return;
				if (contains((_dataRef$current$floa = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa.refs.floating.current, activeEl) || contains(elements.domReference, activeEl) || movedToFocusGuard) return;
				onOpenChange(false, nativeEvent, "focus");
			});
		}
	}), [
		dataRef,
		elements.domReference,
		onOpenChange,
		visibleOnly
	]);
	return React$1.useMemo(() => enabled ? { reference } : {}, [enabled, reference]);
}
function mergeProps(userProps, propsList, elementKey) {
	const map = /* @__PURE__ */ new Map();
	const isItem = elementKey === "item";
	let domUserProps = userProps;
	if (isItem && userProps) {
		const { [ACTIVE_KEY]: _, [SELECTED_KEY]: __, ...validProps } = userProps;
		domUserProps = validProps;
	}
	return {
		...elementKey === "floating" && {
			tabIndex: -1,
			[FOCUSABLE_ATTRIBUTE]: ""
		},
		...domUserProps,
		...propsList.map((value) => {
			const propsOrGetProps = value ? value[elementKey] : null;
			if (typeof propsOrGetProps === "function") return userProps ? propsOrGetProps(userProps) : null;
			return propsOrGetProps;
		}).concat(userProps).reduce((acc, props) => {
			if (!props) return acc;
			Object.entries(props).forEach((_ref) => {
				let [key, value] = _ref;
				if (isItem && [ACTIVE_KEY, SELECTED_KEY].includes(key)) return;
				if (key.indexOf("on") === 0) {
					if (!map.has(key)) map.set(key, []);
					if (typeof value === "function") {
						var _map$get;
						(_map$get = map.get(key)) == null || _map$get.push(value);
						acc[key] = function() {
							var _map$get2;
							for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
							return (_map$get2 = map.get(key)) == null ? void 0 : _map$get2.map((fn) => fn(...args)).find((val) => val !== void 0);
						};
					}
				} else acc[key] = value;
			});
			return acc;
		}, {})
	};
}
/**
* Merges an array of interaction hooks' props into prop getters, allowing
* event handler functions to be composed together without overwriting one
* another.
* @see https://floating-ui.com/docs/useInteractions
*/
function useInteractions(propsList) {
	if (propsList === void 0) propsList = [];
	const referenceDeps = propsList.map((key) => key == null ? void 0 : key.reference);
	const floatingDeps = propsList.map((key) => key == null ? void 0 : key.floating);
	const itemDeps = propsList.map((key) => key == null ? void 0 : key.item);
	const getReferenceProps = React$1.useCallback((userProps) => mergeProps(userProps, propsList, "reference"), referenceDeps);
	const getFloatingProps = React$1.useCallback((userProps) => mergeProps(userProps, propsList, "floating"), floatingDeps);
	const getItemProps = React$1.useCallback((userProps) => mergeProps(userProps, propsList, "item"), itemDeps);
	return React$1.useMemo(() => ({
		getReferenceProps,
		getFloatingProps,
		getItemProps
	}), [
		getReferenceProps,
		getFloatingProps,
		getItemProps
	]);
}
var componentRoleToAriaRoleMap = /*#__PURE__*/ new Map([
	["select", "listbox"],
	["combobox", "listbox"],
	["label", false]
]);
/**
* Adds base screen reader props to the reference and floating elements for a
* given floating element `role`.
* @see https://floating-ui.com/docs/useRole
*/
function useRole(context, props) {
	var _elements$domReferenc, _componentRoleToAriaR;
	if (props === void 0) props = {};
	const { open, elements, floatingId: defaultFloatingId } = context;
	const { enabled = true, role = "dialog" } = props;
	const defaultReferenceId = useId$1();
	const referenceId = ((_elements$domReferenc = elements.domReference) == null ? void 0 : _elements$domReferenc.id) || defaultReferenceId;
	const floatingId = React$1.useMemo(() => {
		var _getFloatingFocusElem;
		return ((_getFloatingFocusElem = getFloatingFocusElement(elements.floating)) == null ? void 0 : _getFloatingFocusElem.id) || defaultFloatingId;
	}, [elements.floating, defaultFloatingId]);
	const ariaRole = (_componentRoleToAriaR = componentRoleToAriaRoleMap.get(role)) != null ? _componentRoleToAriaR : role;
	const isNested = useFloatingParentNodeId() != null;
	const reference = React$1.useMemo(() => {
		if (ariaRole === "tooltip" || role === "label") return { ["aria-" + (role === "label" ? "labelledby" : "describedby")]: open ? floatingId : void 0 };
		return {
			"aria-expanded": open ? "true" : "false",
			"aria-haspopup": ariaRole === "alertdialog" ? "dialog" : ariaRole,
			"aria-controls": open ? floatingId : void 0,
			...ariaRole === "listbox" && { role: "combobox" },
			...ariaRole === "menu" && { id: referenceId },
			...ariaRole === "menu" && isNested && { role: "menuitem" },
			...role === "select" && { "aria-autocomplete": "none" },
			...role === "combobox" && { "aria-autocomplete": "list" }
		};
	}, [
		ariaRole,
		floatingId,
		isNested,
		open,
		referenceId,
		role
	]);
	const floating = React$1.useMemo(() => {
		const floatingProps = {
			id: floatingId,
			...ariaRole && { role: ariaRole }
		};
		if (ariaRole === "tooltip" || role === "label") return floatingProps;
		return {
			...floatingProps,
			...ariaRole === "menu" && { "aria-labelledby": referenceId }
		};
	}, [
		ariaRole,
		floatingId,
		referenceId,
		role
	]);
	const item = React$1.useCallback((_ref) => {
		let { active, selected } = _ref;
		const commonProps = {
			role: "option",
			...active && { id: floatingId + "-fui-option" }
		};
		switch (role) {
			case "select":
			case "combobox": return {
				...commonProps,
				"aria-selected": selected
			};
		}
		return {};
	}, [floatingId, role]);
	return React$1.useMemo(() => enabled ? {
		reference,
		floating,
		item
	} : {}, [
		enabled,
		reference,
		floating,
		item
	]);
}
var camelCaseToKebabCase = (str) => str.replace(/[A-Z]+(?![a-z])|[A-Z]/g, ($, ofs) => (ofs ? "-" : "") + $.toLowerCase());
function execWithArgsOrReturn(valueOrFn, args) {
	return typeof valueOrFn === "function" ? valueOrFn(args) : valueOrFn;
}
function useDelayUnmount(open, durationMs) {
	const [isMounted, setIsMounted] = React$1.useState(open);
	if (open && !isMounted) setIsMounted(true);
	React$1.useEffect(() => {
		if (!open && isMounted) {
			const timeout = setTimeout(() => setIsMounted(false), durationMs);
			return () => clearTimeout(timeout);
		}
	}, [
		open,
		isMounted,
		durationMs
	]);
	return isMounted;
}
/**
* Provides a status string to apply CSS transitions to a floating element,
* correctly handling placement-aware transitions.
* @see https://floating-ui.com/docs/useTransition#usetransitionstatus
*/
function useTransitionStatus(context, props) {
	if (props === void 0) props = {};
	const { open, elements: { floating } } = context;
	const { duration = 250 } = props;
	const closeDuration = (typeof duration === "number" ? duration : duration.close) || 0;
	const [status, setStatus] = React$1.useState("unmounted");
	const isMounted = useDelayUnmount(open, closeDuration);
	if (!isMounted && status === "close") setStatus("unmounted");
	index$1(() => {
		if (!floating) return;
		if (open) {
			setStatus("initial");
			const frame = requestAnimationFrame(() => {
				ReactDOM.flushSync(() => {
					setStatus("open");
				});
			});
			return () => {
				cancelAnimationFrame(frame);
			};
		}
		setStatus("close");
	}, [open, floating]);
	return {
		isMounted,
		status
	};
}
/**
* Provides styles to apply CSS transitions to a floating element, correctly
* handling placement-aware transitions. Wrapper around `useTransitionStatus`.
* @see https://floating-ui.com/docs/useTransition#usetransitionstyles
*/
function useTransitionStyles(context, props) {
	if (props === void 0) props = {};
	const { initial: unstable_initial = { opacity: 0 }, open: unstable_open, close: unstable_close, common: unstable_common, duration = 250 } = props;
	const placement = context.placement;
	const side = placement.split("-")[0];
	const fnArgs = React$1.useMemo(() => ({
		side,
		placement
	}), [side, placement]);
	const isNumberDuration = typeof duration === "number";
	const openDuration = (isNumberDuration ? duration : duration.open) || 0;
	const closeDuration = (isNumberDuration ? duration : duration.close) || 0;
	const [styles, setStyles] = React$1.useState(() => ({
		...execWithArgsOrReturn(unstable_common, fnArgs),
		...execWithArgsOrReturn(unstable_initial, fnArgs)
	}));
	const { isMounted, status } = useTransitionStatus(context, { duration });
	const initialRef = useLatestRef$1(unstable_initial);
	const openRef = useLatestRef$1(unstable_open);
	const closeRef = useLatestRef$1(unstable_close);
	const commonRef = useLatestRef$1(unstable_common);
	index$1(() => {
		const initialStyles = execWithArgsOrReturn(initialRef.current, fnArgs);
		const closeStyles = execWithArgsOrReturn(closeRef.current, fnArgs);
		const commonStyles = execWithArgsOrReturn(commonRef.current, fnArgs);
		const openStyles = execWithArgsOrReturn(openRef.current, fnArgs) || Object.keys(initialStyles).reduce((acc, key) => {
			acc[key] = "";
			return acc;
		}, {});
		if (status === "initial") setStyles((styles) => ({
			transitionProperty: styles.transitionProperty,
			...commonStyles,
			...initialStyles
		}));
		if (status === "open") setStyles({
			transitionProperty: Object.keys(openStyles).map(camelCaseToKebabCase).join(","),
			transitionDuration: openDuration + "ms",
			...commonStyles,
			...openStyles
		});
		if (status === "close") {
			const styles = closeStyles || initialStyles;
			setStyles({
				transitionProperty: Object.keys(styles).map(camelCaseToKebabCase).join(","),
				transitionDuration: closeDuration + "ms",
				...commonStyles,
				...styles
			});
		}
	}, [
		closeDuration,
		closeRef,
		initialRef,
		openRef,
		commonRef,
		openDuration,
		status,
		fnArgs
	]);
	return {
		isMounted,
		styles
	};
}
//#endregion
//#region ../../resources/scripts/components/elements/tooltip/Tooltip.tsx
var arrowSides = {
	top: "bottom-[-6px] left-0",
	bottom: "top-[-6px] left-0",
	right: "top-0 left-[-6px]",
	left: "top-0 right-[-6px]"
};
function useTooltipInteractions(context, enabled, { interactions = ["hover", "focus"], rest = 30, delay = 0 }) {
	return useInteractions([
		useHover(context, {
			restMs: rest,
			delay,
			mouseOnly: true,
			enabled: enabled && interactions.includes("hover")
		}),
		useFocus(context, { enabled: enabled && interactions.includes("focus") }),
		useClick(context, { enabled: enabled && interactions.includes("click") }),
		useRole(context, {
			role: "tooltip",
			enabled
		}),
		useDismiss(context, { enabled })
	]);
}
function TooltipArrow({ ref, placement, position }) {
	const side = arrowSides[placement.split("-")[0]];
	return /* @__PURE__ */ jsx("div", {
		ref,
		style: { transform: `translate(${Math.round(position?.x || 0)}px, ${Math.round(position?.y || 0)}px) rotate(45deg)` },
		className: cn("absolute bg-popover w-3 h-3", side)
	});
}
function Tooltip({ children, ...props }) {
	const arrowEl = useRef(null);
	const [open, setOpen] = useState(false);
	const enabled = !props.disabled;
	if (!enabled && open) setOpen(false);
	const { refs, floatingStyles, middlewareData, context, placement } = useFloating({
		open: open && enabled,
		strategy: "fixed",
		transform: false,
		placement: props.placement || "top",
		middleware: [
			offset(props.arrow ? 10 : 6),
			flip(),
			shift({ padding: 6 }),
			arrow({
				element: arrowEl,
				padding: 6
			})
		],
		onOpenChange: setOpen,
		whileElementsMounted: autoUpdate
	});
	const { getReferenceProps, getFloatingProps } = useTooltipInteractions(context, enabled, props);
	const { isMounted, styles: transitionStyles } = useTransitionStyles(context, {
		duration: {
			open: 100,
			close: 75
		},
		initial: {
			opacity: 0,
			transform: "scale(0.85)"
		},
		open: {
			opacity: 1,
			transform: "scale(1)"
		},
		close: { opacity: 0 }
	});
	const referenceRef = useMergeRefs([refs.setReference, children.props.ref]);
	return /* @__PURE__ */ jsxs(Fragment, { children: [cloneElement(children, getReferenceProps({
		...children.props,
		ref: referenceRef
	})), isMounted && /* @__PURE__ */ jsx(FloatingPortal, { children: /* @__PURE__ */ jsxs("div", {
		...getFloatingProps({
			ref: refs.setFloating,
			className: cn("bg-popover text-sm text-popover-foreground px-3 py-2 rounded-sm pointer-events-none max-w-[24rem] z-9999", props.className),
			style: {
				...floatingStyles,
				...transitionStyles
			}
		}),
		children: [props.content, props.arrow && /* @__PURE__ */ jsx(TooltipArrow, {
			ref: arrowEl,
			placement,
			position: middlewareData.arrow
		})]
	}) })] });
}
//#endregion
//#region ../../resources/scripts/components/elements/dropdown/DropdownMenu.tsx
var positionerClass = "z-[9999] outline-hidden";
var popupClass = "min-w-56 bg-popover border border-border rounded-sm shadow-xl p-1.5 text-sm text-popover-foreground outline-hidden origin-[var(--transform-origin)] transition duration-100 data-[starting-style]:opacity-0 data-[starting-style]:scale-95 data-[ending-style]:opacity-0 data-[ending-style]:scale-95";
var MenuItemContext = React.createContext(Menu.Item);
var ContextMenuItem = (props) => /* @__PURE__ */ jsx(ContextMenu.Item, { ...props });
function DropdownMenu({ triggerContent, triggerClassName, openOnHover, children, className }) {
	return /* @__PURE__ */ jsxs(Menu.Root, { children: [/* @__PURE__ */ jsx(Menu.Trigger, {
		className: triggerClassName,
		openOnHover,
		closeDelay: openOnHover ? 150 : 0,
		children: triggerContent
	}), /* @__PURE__ */ jsx(Menu.Portal, { children: /* @__PURE__ */ jsx(Menu.Positioner, {
		className: positionerClass,
		sideOffset: 4,
		align: "end",
		children: /* @__PURE__ */ jsx(Menu.Popup, {
			className: cn(popupClass, className),
			children: /* @__PURE__ */ jsx(MenuItemContext.Provider, {
				value: Menu.Item,
				children
			})
		})
	}) })] });
}
/** Opens `items` at the cursor on right-click or long-press over `children`. */
function ContextDropdownMenu({ className, menuClassName, children, items }) {
	return /* @__PURE__ */ jsxs(ContextMenu.Root, { children: [/* @__PURE__ */ jsx(ContextMenu.Trigger, {
		className,
		children
	}), /* @__PURE__ */ jsx(ContextMenu.Portal, { children: /* @__PURE__ */ jsx(ContextMenu.Positioner, {
		className: positionerClass,
		children: /* @__PURE__ */ jsx(ContextMenu.Popup, {
			className: cn(popupClass, menuClassName),
			children: /* @__PURE__ */ jsx(MenuItemContext.Provider, {
				value: ContextMenuItem,
				children: items
			})
		})
	}) })] });
}
/** An item for either DropdownMenu or ContextDropdownMenu. */
function DropdownMenuItem({ icon, danger, description, className, children, ...props }) {
	return /* @__PURE__ */ jsxs(use(MenuItemContext), {
		className: cn("group flex w-full gap-3 px-2.5 py-2.5 rounded-sm cursor-pointer select-none outline-hidden", description ? "items-start" : "items-center", "text-foreground transition-colors data-[highlighted]:bg-muted data-[highlighted]:text-foreground", danger && "text-destructive data-[highlighted]:bg-destructive/10 data-[highlighted]:text-destructive", className),
		...props,
		children: [icon && /* @__PURE__ */ jsx("span", {
			className: cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-sm border border-border bg-muted text-muted-foreground transition-colors", description && "mt-0.5", "group-data-[highlighted]:border-border group-data-[highlighted]:bg-background group-data-[highlighted]:text-foreground", danger && "border-destructive/30 bg-destructive/10 text-destructive group-data-[highlighted]:border-destructive/40 group-data-[highlighted]:bg-destructive/15 group-data-[highlighted]:text-destructive"),
			children: /* @__PURE__ */ jsx(Icon, {
				icon,
				className: "h-4 w-4"
			})
		}), /* @__PURE__ */ jsxs("span", {
			className: "flex min-w-0 flex-1 flex-col",
			children: [/* @__PURE__ */ jsx("span", {
				className: "truncate text-sm font-medium leading-5",
				children
			}), description && /* @__PURE__ */ jsx("span", {
				className: cn("mt-0.5 text-xs leading-4 text-muted-foreground", "group-data-[highlighted]:text-muted-foreground", danger && "group-data-[highlighted]:text-destructive/80"),
				children: description
			})]
		})]
	});
}
var DropdownMenuWithItems = DropdownMenu;
DropdownMenuWithItems.Item = DropdownMenuItem;
//#endregion
//#region ../../resources/scripts/api/queryData.ts
var removeListItems = (current, matches) => current ? {
	...current,
	data: current.data.filter((item) => !matches(item))
} : current;
var updateListItems = (current, matches, updater) => current ? {
	...current,
	data: current.data.map((item) => matches(item) ? updater(item) : item)
} : current;
//#endregion
//#region ../../resources/scripts/api/server/files/queries.ts
var UPLOAD_CONCURRENCY = 3;
var uploadSequence = 0;
var serverFilesInput = (uuid, directory) => ({
	path: { server_uuid: uuid },
	query: { directory: cleanDirectoryPath(directory) }
});
var serverFileContentInput = (uuid, file) => ({
	path: { server_uuid: uuid },
	query: { file }
});
var createDirectoryInput = (uuid, directory, name) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		name
	}
});
var renameFilesInput = (uuid, directory, files) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		files
	}
});
var chmodFilesInput = (uuid, directory, files) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		files: files.map(({ file, mode }) => ({
			file,
			mode
		}))
	}
});
var deleteFilesInput = (uuid, directory, files) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		files
	}
});
var copyFileInput = (uuid, location) => ({
	path: { server_uuid: uuid },
	body: { location }
});
var compressFilesInput = (uuid, directory, files) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		files
	},
	timeout: 6e4,
	timeoutErrorMessage: "It looks like this archive is taking a long time to generate. It will appear once completed."
});
var decompressFileInput = (uuid, directory, file) => ({
	path: { server_uuid: uuid },
	body: {
		root: directory,
		file
	},
	timeout: 3e5,
	timeoutErrorMessage: "It looks like this archive is taking a long time to be unarchived. Once completed the unarchived files will appear."
});
var writeFileContentsInput = (uuid, file, content) => ({
	path: { server_uuid: uuid },
	query: { file },
	body: content
});
var serverFilesQueryKey = (uuid, directory) => clientListFilesQueryKey(serverFilesInput(uuid, directory));
var allServerFilesQueryKey = (uuid) => clientListFilesQueryKey({ path: { server_uuid: uuid } });
var serverFileContentQueryKey = (uuid, file) => clientGetFileContentsQueryKey(serverFileContentInput(uuid, file));
var serverFilesQueryUpdate = async (queryClient, uuid, directory, updater) => {
	await queryClient.cancelQueries({ queryKey: serverFilesQueryKey(uuid, directory) });
	return queryClient.setQueryData(serverFilesQueryKey(uuid, directory), updater);
};
var updateServerFileContent = async (queryClient, uuid, file, content) => {
	await queryClient.cancelQueries({ queryKey: serverFileContentQueryKey(uuid, file) });
	return queryClient.setQueryData(serverFileContentQueryKey(uuid, file), content);
};
var getFileContents = async (uuid, file, signal) => {
	return (await clientGetFileContents({
		...serverFileContentInput(uuid, file),
		signal
	})).data ?? "";
};
var getFileDownloadUrl = async (uuid, file) => {
	return (await clientGetFileDownloadUrl({
		path: { server_uuid: uuid },
		query: { file }
	})).data.attributes.url;
};
var getFileUploadUrl = async (uuid, signal) => {
	return (await clientGetFileUploadUrl({
		path: { server_uuid: uuid },
		signal
	})).data.attributes.url;
};
var fileObjectKey = ({ attributes }) => `${attributes.is_file ? "file" : "dir"}_${attributes.name}`;
var isFileObjectArchiveType = ({ attributes }) => attributes.is_file && [
	"application/vnd.rar",
	"application/x-rar-compressed",
	"application/x-tar",
	"application/x-br",
	"application/x-bzip2",
	"application/gzip",
	"application/x-gzip",
	"application/x-lzip",
	"application/x-sz",
	"application/x-xz",
	"application/zstd",
	"application/zip",
	"application/x-7z-compressed"
].includes(attributes.mimetype);
var fileObjectKind = (file) => {
	if (!file.attributes.is_file) return "directory";
	if (file.attributes.is_symlink) return "symlink";
	return isFileObjectArchiveType(file) ? "archive" : "file";
};
var isFileObjectEditable = (file) => {
	if (isFileObjectArchiveType(file) || !file.attributes.is_file) return false;
	return [
		"application/jar",
		"application/octet-stream",
		"inode/directory",
		/^image\/(?!svg\+xml)/
	].every((m) => !file.attributes.mimetype.match(m));
};
var generateDirectoryData = (name) => ({
	object: "file_object",
	attributes: {
		name: newDirectoryDisplayName(name),
		mode: "drwxr-xr-x",
		mode_bits: "0755",
		size: 0,
		is_file: false,
		is_symlink: false,
		mimetype: "",
		created_at: (/* @__PURE__ */ new Date()).toISOString(),
		modified_at: (/* @__PURE__ */ new Date()).toISOString()
	}
});
var serverFilesQueryOptions = (uuid, directory) => clientListFilesOptions(serverFilesInput(uuid, directory));
var serverFileContentQueryOptions = (uuid, file) => queryOptions({
	queryKey: serverFileContentQueryKey(uuid, file),
	queryFn: ({ signal }) => getFileContents(uuid, file, signal),
	staleTime: 0
});
var useCreateDirectory = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateFolderMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root && body.name) await serverFilesQueryUpdate(queryClient, path.server_uuid, body.root, (files) => ({
				object: files?.object ?? "list",
				data: [...files?.data ?? [], generateDirectoryData(body.name)]
			}));
			toast.success("Directory created");
		},
		onError: (error) => notifyHttpError(error, "Unable to create directory")
	});
};
var useRenameFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientRenameFilesMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root && body.files?.length === 1) {
				const [{ from, to }] = body.files;
				const staysInDirectory = to.split("/").length === 1;
				await serverFilesQueryUpdate(queryClient, path.server_uuid, body.root, (current) => staysInDirectory ? updateListItems(current, (file) => file.attributes.name === from, (file) => ({
					...file,
					attributes: {
						...file.attributes,
						name: to
					}
				})) : removeListItems(current, (file) => file.attributes.name === from));
			}
			await queryClient.invalidateQueries({ queryKey: allServerFilesQueryKey(path.server_uuid) });
			toast.success("Files updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update files")
	});
};
var useChmodFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientChangeFilePermissionsMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root && body.files?.length === 1) {
				const [{ file, mode }] = body.files;
				const modeBits = mode.padStart(4, "0");
				await serverFilesQueryUpdate(queryClient, path.server_uuid, body.root, (current) => updateListItems(current, (item) => item.attributes.name === file, (item) => ({
					...item,
					attributes: {
						...item.attributes,
						mode: fileBitsToString(modeBits, !item.attributes.is_file),
						mode_bits: modeBits
					}
				})));
			}
			if (body?.root) await queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(path.server_uuid, body.root) });
			toast.success("Permissions updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update permissions")
	});
};
var useDeleteFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDeleteFilesMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root && body.files) {
				const files = body.files;
				await serverFilesQueryUpdate(queryClient, path.server_uuid, body.root, (current) => removeListItems(current, (file) => files.includes(file.attributes.name)));
			}
			toast.success(body?.files?.length === 1 ? "File deleted" : "Files deleted");
		},
		onError: (error) => notifyHttpError(error, "Unable to delete files")
	});
};
var useCopyFile = (directory) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCopyFileMutation(),
		onSuccess: async (_data, { path }) => {
			if (directory) await queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(path.server_uuid, directory) });
			toast.success("File copied");
		},
		onError: (error) => notifyHttpError(error, "Unable to copy file")
	});
};
var useCompressFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCompressFilesMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root) await queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(path.server_uuid, body.root) });
			toast.success("Archive started");
		},
		onError: (error) => notifyHttpError(error, "Unable to archive files")
	});
};
var useDecompressFile = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientDecompressFileMutation(),
		onSuccess: async (_data, { path, body }) => {
			if (body?.root) await queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(path.server_uuid, body.root) });
			toast.success("Unarchive started");
		},
		onError: (error) => notifyHttpError(error, "Unable to unarchive file")
	});
};
var useFileDownloadUrl = () => useMutation({
	mutationFn: ({ uuid, file }) => getFileDownloadUrl(uuid, file),
	onError: (error) => notifyHttpError(error, "Unable to create file download")
});
var useSaveFileContent = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientWriteFileContentsMutation(),
		onSuccess: async (_data, { path, query, body }) => {
			await updateServerFileContent(queryClient, path.server_uuid, query.file, body);
			toast.success("File saved");
		},
		onError: (error) => notifyHttpError(error, "Unable to save file")
	});
};
var runPooled = async (items, concurrency, task) => {
	let next = 0;
	const worker = async () => {
		if (next >= items.length) return;
		await task(items[next++]);
		return worker();
	};
	await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
};
var uploadFile = async (uuid, directory, file, signal, onUploadProgress) => {
	const url = await getFileUploadUrl(uuid, signal);
	await axios.post(url, { files: file }, {
		signal,
		headers: { "Content-Type": "multipart/form-data" },
		params: { directory },
		onUploadProgress
	});
};
/** Uploads files a few at a time, then refreshes the listing once every file has settled. */
var useUploadFiles = () => {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async ({ callbacks, directory, files, uuid }) => {
			const queued = files.map((file) => {
				const id = `upload-${++uploadSequence}`;
				const controller = new AbortController();
				callbacks.onFileQueued(id, file, controller);
				return {
					id,
					file,
					controller
				};
			});
			const summary = {
				uploaded: [],
				cancelled: [],
				failed: []
			};
			await runPooled(queued, UPLOAD_CONCURRENCY, async ({ id, file, controller }) => {
				let outcome = "cancelled";
				if (!controller.signal.aborted) try {
					await uploadFile(uuid, directory, file, controller.signal, (progress) => callbacks.onFileProgress(id, progress));
					outcome = "uploaded";
				} catch (error) {
					if (!controller.signal.aborted && !axios.isCancel(error)) {
						outcome = "failed";
						notifyHttpError(error, `Unable to upload ${file.name}`);
					}
				}
				summary[outcome].push(file);
				callbacks.onFileSettled(id, outcome);
			});
			return summary;
		},
		onSuccess: ({ uploaded, failed }) => {
			if (uploaded.length > 0 && failed.length === 0) toast.success("Upload complete");
		},
		onError: (error) => notifyHttpError(error, "Unable to upload files"),
		onSettled: (_data, _error, { uuid, directory }) => queryClient.invalidateQueries({ queryKey: serverFilesQueryKey(uuid, directory) })
	});
};
//#endregion
//#region ../../resources/scripts/router/redirect.ts
var redirectOrigin = "http://redirect.invalid";
var parseRedirectSearch = (search) => {
	const redirect = isString(search.redirect) ? search.redirect.trim() : "";
	if (!redirect.startsWith("/")) return {};
	let url;
	try {
		url = new URL(redirect, redirectOrigin);
	} catch {
		return {};
	}
	if (url.origin !== redirectOrigin || url.pathname === "/auth" || url.pathname.startsWith("/auth/")) return {};
	const path = `${url.pathname}${url.search}${url.hash}`;
	return path === "/" ? {} : { redirect: path };
};
//#endregion
//#region ../../resources/scripts/plugins/useNavigationBlocker.ts
var UNSAVED_CHANGES_MESSAGE = "You have unsaved changes. Leave this page and discard them?";
/** Asks before leaving while `shouldBlock` holds, including back/forward and tab close. */
function useNavigationBlocker(shouldBlock, options = {}) {
	const latest = useRef({
		shouldBlock,
		options
	});
	useEffect(() => {
		latest.current = {
			shouldBlock,
			options
		};
	});
	const isBlocking = useCallback(() => {
		const { shouldBlock } = latest.current;
		return shouldBlock instanceof Function ? shouldBlock() : shouldBlock;
	}, []);
	useBlocker({
		shouldBlockFn: useCallback(async ({ action, current, next }) => {
			if (!isBlocking()) return false;
			const { confirm, message = UNSAVED_CHANGES_MESSAGE } = latest.current.options;
			if (!confirm) return !window.confirm(message);
			try {
				return !await confirm({
					action,
					current: {
						pathname: current.pathname,
						params: routeParamStrings(current.params),
						search: current.search
					},
					next: {
						pathname: next.pathname,
						params: routeParamStrings(next.params),
						search: next.search
					}
				});
			} catch (error) {
				console.error(error);
				return !window.confirm(message);
			}
		}, [isBlocking]),
		enableBeforeUnload: useCallback(() => latest.current.options.beforeUnload !== false && isBlocking(), [isBlocking])
	});
}
//#endregion
//#region ../../resources/scripts/sdk/navigation.tsx
function resolvePanelDestination(destination) {
	let path;
	if ("to" in destination) path = destination.to;
	else {
		const screen = findExtensionScreen(destination.extension, destination.screen);
		if (!screen) throw new Error(`Unknown extension screen "${destination.extension}:${destination.screen}".`);
		path = `${SCREEN_ROOTS[screen.parent ?? screen.area]}/${screen.path}`;
	}
	return {
		pathname: resolveScreenPath(path, destination.params),
		search: destination.search,
		hash: destination.hash,
		replace: destination.replace
	};
}
function usePanelNavigate() {
	const navigate = useNavigate();
	return useCallback((destination) => {
		const { pathname, ...options } = resolvePanelDestination(destination);
		return navigate({
			to: pathname,
			...options,
			search: options.search
		});
	}, [navigate]);
}
function usePanelLocation() {
	const { pathname } = useLocation();
	const params = useParams({ strict: false });
	const search = useSearch({ strict: false });
	return {
		pathname,
		params: routeParamStrings(params),
		search
	};
}
function PanelLink({ destination, exact = false, ...props }) {
	const { pathname, ...options } = resolvePanelDestination(destination);
	return /* @__PURE__ */ jsx(Link, {
		to: pathname,
		...options,
		search: options.search,
		activeOptions: {
			exact,
			includeSearch: false
		},
		...props
	});
}
function useOpenLoginCheckpoint() {
	const navigate = useNavigate();
	const { redirect } = parseRedirectSearch(useSearch({ strict: false }));
	return useCallback((confirmationToken) => navigate({
		to: "/auth/login/checkpoint",
		search: { redirect },
		replace: true,
		state: { token: confirmationToken }
	}), [navigate, redirect]);
}
//#endregion
//#region ../../resources/scripts/extensions/resourceContext.ts
var ExtensionResourceProvider = createContext(null);
function useCurrentResource() {
	return useContext(ExtensionResourceProvider);
}
//#endregion
export { Label as $, clientSetServerDockerImageMutation as $t, useSaveFileContent as A, currentUserQueryKey as At, EmptyDescription as B, notifyHttpError as Bt, useCompressFiles as C, normalizeServerPath as Ct, useDeleteFiles as D, useExtensionCallback as Dt, useDecompressFile as E, ExtensionContext as Et, DropdownMenuItem as F, useCurrentServerIdentifier as Ft, useDialogState as G, clientGetServerResourcesQueryKey as Gt, EmptyMedia as H, clientGetFileContentsQueryKey as Ht, DropdownMenuWithItems as I, useCurrentServerName as It, Checkbox$1 as J, clientListFilesQueryKey as Jt, useAppForm as K, clientGetStartupConfigurationOptions as Kt, Tooltip as L, useCurrentServerPermissions as Lt, writeFileContentsInput as M, serverQueryFilters as Mt, updateListItems as N, serverQueryOptions as Nt, useFileDownloadUrl as O, siteSettingsQueryKey as Ot, ContextDropdownMenu as P, useCurrentServer as Pt, useFormContext as Q, clientSendServerCommandMutation as Qt, Empty as R, useCurrentServerUuid as Rt, useChmodFiles as S, encodePathSegments as St, useCreateDirectory as T, join as Tt, EmptyTitle as U, clientGetServerLogsOptions as Ut, EmptyHeader as V, clientCreateServerBackupMutation as Vt, Dialog$1 as W, clientGetServerResourcesOptions as Wt, Select as X, clientListServerBackupsQueryKey as Xt, Switch$1 as Y, clientListServerBackupsOptions as Yt, useFieldContext as Z, clientSendPowerActionMutation as Zt, isFileObjectArchiveType as _, __commonJSMin as _n, useFileUploadActions as _t, useOpenLoginCheckpoint as a, SLOT_NAMES as an, sectionTitleClass as at, serverFileContentQueryOptions as b, useSocketConnected as bt, useNavigationBlocker as c, getComponentReplacement as cn, ButtonWithVariants as ct, copyFileInput as d, reportExtensionError as dn, Icon as dt, clientUpdateStartupVariableMutation as en, NumberInput as et, createDirectoryInput as f, subscribeExtensionRegistry as fn, cn as ft, fileObjectKind as g, EXTENSION_FORM_NAMES as gn, Provider as gt, fileObjectKey as h, isReplacementComponent as hn, usePermissions as ht, resolvePanelDestination as i, SCREEN_ROOTS as in, cardTitleClass as it, useUploadFiles as j, useCurrentUser as jt, useRenameFiles as k, useSiteSettings as kt, chmodFilesInput as l, getExtensionLoadState as ln, Spinner as lt, deleteFilesInput as m, COMPONENT_NAMES as mn, hasPermission as mt, useCurrentResource as n, clientGetServerExtensionJobProgress as nn, TextInput as nt, usePanelLocation as o, clearExtensionError as on, SpinnerOverlay as ot, decompressFileInput as p, useExtensionRegistry as pn, registerClassPrefixes as pt, Form as q, clientGetStartupConfigurationQueryKey as qt, PanelLink as r, ExtensionImportError as rn, Portal as rt, usePanelNavigate as s, getComponentOwner as sn, Can as st, ExtensionResourceProvider as t, clientGetExtensionJobProgress as tn, TextArea as tt, compressFilesInput as u, getSlotComponents as un, ErrorBoundary as ut, isFileObjectEditable as v, __toESM as vn, useServerDirectory as vt, useCopyFile as w, dirname as wt, serverFilesQueryOptions as x, useSocketInstance as xt, renameFilesInput as y, useServerStore as yt, EmptyContent as z, useUpdateCurrentServer as zt };

//# sourceMappingURL=resourceContext-a3g2HE8U.js.map